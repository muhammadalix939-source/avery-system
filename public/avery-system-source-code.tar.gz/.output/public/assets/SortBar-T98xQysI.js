import { k as require_jsx_runtime } from "./store-DLjJF6C7.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-51KhIokW.js";
import { g as createLucideIcon } from "./index-BgfHyeon.js";
// node_modules/lucide-react/dist/esm/icons/arrow-up-down.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "arrow-up-down",
	size: 24,
	node: [
		["path", {
			d: "m21 16-4 4-4-4",
			key: "f6ql7i"
		}],
		["path", {
			d: "M17 20V4",
			key: "1ejh1v"
		}],
		["path", {
			d: "m3 8 4-4 4 4",
			key: "11wl7u"
		}],
		["path", {
			d: "M7 4v16",
			key: "1glfcx"
		}]
	]
};
__iconData.node;
var ArrowUpDown = createLucideIcon(__iconData);
// src/lib/sort-utils.ts
var STANDARD_SORT_OPTIONS = [
	{
		value: "date_desc",
		label: "Date: Newest First",
		category: "date"
	},
	{
		value: "date_asc",
		label: "Date: Oldest First",
		category: "date"
	},
	{
		value: "amount_desc",
		label: "Amount: Highest First",
		category: "amount"
	},
	{
		value: "amount_asc",
		label: "Amount: Lowest First",
		category: "amount"
	},
	{
		value: "name_asc",
		label: "Name / ID: A → Z",
		category: "alpha"
	},
	{
		value: "name_desc",
		label: "Name / ID: Z → A",
		category: "alpha"
	}
];
/**
* Universal stable multi-criteria sorting function
*/
function sortEntities(items, sortKey, accessors) {
	return [...items].sort((a, b) => {
		switch (sortKey) {
			case "date_desc": {
				const da = accessors.date ? accessors.date(a) || "" : "";
				return (accessors.date ? accessors.date(b) || "" : "").localeCompare(da);
			}
			case "date_asc": {
				const da = accessors.date ? accessors.date(a) || "" : "";
				const db = accessors.date ? accessors.date(b) || "" : "";
				return da.localeCompare(db);
			}
			case "amount_desc": {
				const amtA = accessors.amount ? Number(accessors.amount(a)) || 0 : 0;
				return (accessors.amount ? Number(accessors.amount(b)) || 0 : 0) - amtA;
			}
			case "amount_asc": return (accessors.amount ? Number(accessors.amount(a)) || 0 : 0) - (accessors.amount ? Number(accessors.amount(b)) || 0 : 0);
			case "name_asc": {
				const na = accessors.name ? (accessors.name(a) || "").toLowerCase() : "";
				const nb = accessors.name ? (accessors.name(b) || "").toLowerCase() : "";
				return na.localeCompare(nb);
			}
			case "name_desc": {
				const na = accessors.name ? (accessors.name(a) || "").toLowerCase() : "";
				return (accessors.name ? (accessors.name(b) || "").toLowerCase() : "").localeCompare(na);
			}
			default: return 0;
		}
	});
}
// src/components/SortBar.tsx
var import_jsx_runtime = require_jsx_runtime();
function SortBar({ value, onChange, options = STANDARD_SORT_OPTIONS, className = "", label = "Sort by:" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center gap-2 ${className}`,
		children: [label && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-[11px] font-medium text-muted-foreground whitespace-nowrap flex items-center gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-3 w-3 text-muted-foreground/70" }), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
			value,
			onValueChange: (v) => onChange(v),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
				className: "h-8 text-xs bg-background/50 border-border/60 hover:border-primary/50 transition-colors w-[180px]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select sorting..." })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
				align: "end",
				className: "border-border bg-card",
				children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: opt.value,
					className: "text-xs",
					children: opt.label
				}, opt.value))
			})]
		})]
	});
}
export { sortEntities as n, SortBar as t };
