import { g as createLucideIcon } from "./index-BgfHyeon.js";
// node_modules/lucide-react/dist/esm/icons/clock.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "clock",
	size: 24,
	node: [["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}], ["path", {
		d: "M12 6v6l4 2",
		key: "mmk7yg"
	}]]
};
__iconData.node;
var Clock = createLucideIcon(__iconData);
export { Clock as t };
