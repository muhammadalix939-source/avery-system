import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime } from "./store-DLjJF6C7.js";
import { t as DetailDialog } from "./DetailDialog-BQz-pf5v.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-51KhIokW.js";
import { t as Download } from "./download-CEfpC1QR.js";
import { t as Eye } from "./eye-CC3nCxz_.js";
import { t as Pencil } from "./pencil-B3wEbWek.js";
import { t as Plus } from "./plus-DpXfoyfH.js";
import { t as Trash } from "./trash-YMvfXcpp.js";
import { t as generateAgentReport } from "./pdf-S7DRzVmW.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as Label } from "./label-C_GFC7te.js";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-Bb6Qejxv.js";
import { t as StatusBadge } from "./StatusBadge-6vwJ3trL.js";
import { a as paymentAllocations, o as purchaseAllocations } from "./allocations-CV2mwFEX.js";
import { t as StatementDialog } from "./StatementDialog-C7VKb__5.js";
// src/routes/agents.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AgentsPage() {
	const store = useStore();
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [detailOpen, setDetailOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [stmtOpen, setStmtOpen] = (0, import_react.useState)(false);
	const [stmtAgent, setStmtAgent] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		email: "",
		status: "Active",
		openingSales: "",
		openingClients: "",
		openingCommission: "",
		openingPaidCommission: ""
	});
	function handleAdd() {
		store.addAgent({
			name: form.name,
			phone: form.phone,
			email: form.email,
			totalSales: 0,
			totalClients: 0,
			commission: 0,
			paidCommission: 0,
			status: form.status,
			openingSales: Number(form.openingSales) || 0,
			openingClients: Number(form.openingClients) || 0,
			openingCommission: Number(form.openingCommission) || 0,
			openingPaidCommission: Number(form.openingPaidCommission) || 0
		});
		setForm({
			name: "",
			phone: "",
			email: "",
			status: "Active",
			openingSales: "",
			openingClients: "",
			openingCommission: "",
			openingPaidCommission: ""
		});
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		store.updateAgent(selected.id, {
			name: form.name,
			phone: form.phone,
			email: form.email,
			status: form.status,
			openingSales: Number(form.openingSales) || 0,
			openingClients: Number(form.openingClients) || 0,
			openingCommission: Number(form.openingCommission) || 0,
			openingPaidCommission: Number(form.openingPaidCommission) || 0
		});
		setEditOpen(false);
	}
	function openEdit(a) {
		setSelected(a);
		setForm({
			name: a.name,
			phone: a.phone,
			email: a.email,
			status: a.status,
			openingSales: String(a.openingSales || 0),
			openingClients: String(a.openingClients || 0),
			openingCommission: String(a.openingCommission || 0),
			openingPaidCommission: String(a.openingPaidCommission || 0)
		});
		setEditOpen(true);
	}
	function openStmt(a) {
		setStmtAgent(a);
		setStmtOpen(true);
	}
	function downloadReport(a, range) {
		generateAgentReport(a, store.entries, {
			...range,
			bookings: store.bookings,
			clients: store.clients
		});
	}
	const relatedEntries = (() => {
		if (!selected) return [];
		const agentHeads = new Set(store.bookings.filter((b) => b.agentId === selected.id).map((b) => b.headId));
		const clientTypes = /* @__PURE__ */ new Set([
			"client_receive",
			"client_charge",
			"client_refund"
		]);
		return store.entries.filter((e) => e.type === "agent_commission" && e.referenceId === selected.id || clientTypes.has(e.type) && e.headId && agentHeads.has(e.headId) || e.type === "supplier_payment" && paymentAllocations(e).some((l) => l.target === "agent" && l.agentId === selected.id) || e.type === "purchase" && purchaseAllocations(e).some((l) => l.target === "agent" && l.agentId === selected.id) || e.type === "other_sale" && e.referenceId === selected.id);
	})();
	const formFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Name"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.name,
				onChange: (e) => setForm({
					...form,
					name: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Phone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.phone,
					onChange: (e) => setForm({
						...form,
						phone: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.email,
					onChange: (e) => setForm({
						...form,
						email: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Status"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: form.status,
				onValueChange: (v) => setForm({
					...form,
					status: v
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "bg-accent/20 border-border mt-1 h-8 text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "Active",
					children: "Active"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "Inactive",
					children: "Inactive"
				})] })]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border/30 pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold text-warning mb-2",
					children: "Opening Balances (legacy / carry-forward)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Previous Sales"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: form.openingSales,
							onChange: (e) => setForm({
								...form,
								openingSales: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Previous Clients"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: form.openingClients,
							onChange: (e) => setForm({
								...form,
								openingClients: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Previous Commission"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: form.openingCommission,
							onChange: (e) => setForm({
								...form,
								openingCommission: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Previous Paid"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: form.openingPaidCommission,
							onChange: (e) => setForm({
								...form,
								openingPaidCommission: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] })
					]
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Agent Management",
				subtitle: `${store.agents.length} agents`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: setAddOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: () => setForm({
								name: "",
								phone: "",
								email: "",
								status: "Active",
								openingSales: "",
								openingClients: "",
								openingCommission: "",
								openingPaidCommission: ""
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add Agent"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add New Agent" }) }),
							formFields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleAdd,
								className: "w-full",
								children: "Add Agent"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3",
				children: store.agents.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: i * .1 },
					className: "glass-card glass-card-hover rounded-xl p-5 transition-all duration-300",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary",
								children: a.name.split(" ").map((n) => n[0]).join("")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: a.status }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											setSelected(a);
											setDetailOpen(true);
										},
										className: "rounded p-1 hover:bg-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3.5 w-3.5 text-primary" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => openStmt(a),
										className: "rounded p-1 hover:bg-accent",
										title: "Download Statement",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => openEdit(a),
										className: "rounded p-1 hover:bg-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => store.deleteAgent(a.id),
										className: "rounded p-1 hover:bg-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold",
							children: a.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								a.id,
								" · ",
								a.email
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: a.phone
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-3 gap-2 border-t border-border/50 pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase text-muted-foreground",
										children: "Sales"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-primary",
										children: formatCurrency(a.totalSales + (a.openingSales || 0))
									}),
									(a.openingSales || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[9px] text-muted-foreground",
										children: [
											"incl. ",
											formatCurrency(a.openingSales || 0),
											" B/F"
										]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase text-muted-foreground",
										children: "Clients"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										children: a.totalClients + (a.openingClients || 0)
									}),
									(a.openingClients || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[9px] text-muted-foreground",
										children: [
											"incl. ",
											a.openingClients,
											" B/F"
										]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase text-muted-foreground",
										children: "Commission"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-success",
										children: formatCurrency(a.commission + (a.openingCommission || 0))
									}),
									(a.openingCommission || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[9px] text-muted-foreground",
										children: [
											"incl. ",
											formatCurrency(a.openingCommission || 0),
											" B/F"
										]
									})
								] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 border-t border-border/50 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "Paid"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-success",
								children: formatCurrency(a.paidCommission + (a.openingPaidCommission || 0))
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "Payable"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-destructive",
								children: formatCurrency(a.commission + (a.openingCommission || 0) - (a.paidCommission + (a.openingPaidCommission || 0)))
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setSelected(a);
								setDetailOpen(true);
							},
							className: "mt-3 w-full rounded-lg border border-border/50 px-3 py-2 text-left text-[10px] uppercase tracking-wider text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary",
							children: "View · Clients, Business Account & Other Sale"
						})
					]
				}, a.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Agent — ", selected?.id] }) }),
						formFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailDialog, {
				open: detailOpen,
				onOpenChange: setDetailOpen,
				type: "agent",
				data: selected,
				entries: relatedEntries,
				allClients: store.clients,
				allBookings: store.bookings
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementDialog, {
				open: stmtOpen,
				onOpenChange: setStmtOpen,
				title: `Agent Statement — ${stmtAgent?.name || ""}`,
				subtitle: "Pick a period and what to include. Opening balance, receipts and remaining balance are calculated automatically.",
				showScope: true,
				onDownload: (range) => stmtAgent && downloadReport(stmtAgent, range)
			})
		]
	});
}
export { AgentsPage as component };
