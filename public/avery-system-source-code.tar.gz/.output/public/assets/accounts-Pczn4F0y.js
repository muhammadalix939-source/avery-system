import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { O as toast, S as computeBookingFinancials, T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime, n as computeAccountBalance, t as buildAccountLedger } from "./store-DLjJF6C7.js";
import { n as Banknote, t as Landmark } from "./landmark-C2bF4lO7.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-51KhIokW.js";
import { t as CircleCheck } from "./circle-check-CPvWbtJ5.js";
import { t as Clock } from "./clock-t2Qg8pfP.js";
import { t as Eye } from "./eye-CC3nCxz_.js";
import { t as OctagonAlert } from "./octagon-alert-lg_q6oU2.js";
import { t as Plus } from "./plus-DpXfoyfH.js";
import { t as Trash } from "./trash-YMvfXcpp.js";
import { t as TrendingUp } from "./trending-up-CdHn1ffe.js";
import { c as RefreshCw, g as createLucideIcon, i as Users, r as Wallet, s as Search } from "./index-BgfHyeon.js";
import { n as PageHeader } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as Label } from "./label-C_GFC7te.js";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-Bb6Qejxv.js";
// node_modules/lucide-react/dist/esm/icons/chart-pie.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$1 = {
	name: "chart-pie",
	size: 24,
	node: [["path", {
		d: "M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",
		key: "pzmjnu"
	}], ["path", {
		d: "M21.21 15.89A10 10 0 1 1 8 2.83",
		key: "k2fpak"
	}]],
	aliases: ["pie-chart"]
};
__iconData$1.node;
var ChartPie = createLucideIcon(__iconData$1);
// node_modules/lucide-react/dist/esm/icons/user-check.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "user-check",
	size: 24,
	node: [
		["path", {
			d: "m16 11 2 2 4-4",
			key: "9rsbq5"
		}],
		["path", {
			d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
			key: "1yyitq"
		}],
		["circle", {
			cx: "9",
			cy: "7",
			r: "4",
			key: "nufk8"
		}]
	]
};
__iconData.node;
var UserCheck = createLucideIcon(__iconData);
// src/routes/accounts.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var icons = {
	Cash: Banknote,
	Bank: Landmark,
	"Mobile Wallet": Wallet
};
var emptyAccount = {
	name: "",
	type: "Bank",
	number: "",
	branch: "",
	openingBalance: "",
	openingDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
};
var emptyDrawer = {
	name: "",
	role: "Partner",
	phone: "",
	sharePercent: "50",
	openingDrawings: "",
	notes: ""
};
function AccountsPage() {
	const store = useStore();
	const [accOpen, setAccOpen] = (0, import_react.useState)(false);
	const [accForm, setAccForm] = (0, import_react.useState)(emptyAccount);
	const [selAccId, setSelAccId] = (0, import_react.useState)(null);
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [drawerOpen, setDrawerOpen] = (0, import_react.useState)(false);
	const [drawerForm, setDrawerForm] = (0, import_react.useState)(emptyDrawer);
	const [editingDrawerId, setEditingDrawerId] = (0, import_react.useState)(null);
	const [selectedDrawerForStatement, setSelectedDrawerForStatement] = (0, import_react.useState)(null);
	const [profitModalOpen, setProfitModalOpen] = (0, import_react.useState)(false);
	const [profitFilterStatus, setProfitFilterStatus] = (0, import_react.useState)("all");
	const [profitFilterMargin, setProfitFilterMargin] = (0, import_react.useState)("all");
	const [profitFilterSource, setProfitFilterSource] = (0, import_react.useState)("all");
	const [profitFilterPackage, setProfitFilterPackage] = (0, import_react.useState)("all");
	const [profitFilterMonth, setProfitFilterMonth] = (0, import_react.useState)("all");
	const [profitFilterYear, setProfitFilterYear] = (0, import_react.useState)("all");
	const [profitSearch, setProfitSearch] = (0, import_react.useState)("");
	const [drawingsModalOpen, setDrawingsModalOpen] = (0, import_react.useState)(false);
	const selectedAccount = store.accounts.find((a) => a.id === selAccId) || store.accounts[0];
	const ledgerRows = selectedAccount ? buildAccountLedger(selectedAccount.id).filter((r) => (!from || r.date >= from) && (!to || r.date <= to)) : [];
	const totalLiquid = store.accounts.reduce((s, a) => s + computeAccountBalance(a.id), 0);
	const { earnedProfit, unearnedProfit, totalProjectedProfit, earnedCount, unearnedCount, totalSales, totalCosts, totalCommissions, totalCustomerDiscounts, totalSupplierRebates, totalLossDealsCount, totalLossAmount } = (0, import_react.useMemo)(() => {
		let earned = 0;
		let unearned = 0;
		let earnedCnt = 0;
		let unearnedCnt = 0;
		let sales = 0;
		let costs = 0;
		let commissions = 0;
		let custDisc = 0;
		let supReb = 0;
		let lossCnt = 0;
		let lossAmt = 0;
		store.bookings.forEach((b) => {
			const fin = computeBookingFinancials(b);
			const profit = fin.netProfit;
			sales += fin.grossSale;
			costs += fin.netCost;
			commissions += fin.netCommission;
			custDisc += fin.discount;
			supReb += fin.supplierDiscount;
			if (fin.isLoss) {
				lossCnt += 1;
				lossAmt += fin.lossAmount;
			}
			if (b.profitStatus === "earned") {
				earned += profit;
				earnedCnt += 1;
			} else {
				unearned += profit;
				unearnedCnt += 1;
			}
		});
		return {
			earnedProfit: earned,
			unearnedProfit: unearned,
			totalProjectedProfit: earned + unearned,
			earnedCount: earnedCnt,
			unearnedCount: unearnedCnt,
			totalSales: sales,
			totalCosts: costs,
			totalCommissions: commissions,
			totalCustomerDiscounts: custDisc,
			totalSupplierRebates: supReb,
			totalLossDealsCount: lossCnt,
			totalLossAmount: lossAmt
		};
	}, [store.bookings]);
	const allDrawings = (0, import_react.useMemo)(() => {
		return store.entries.filter((e) => e.type === "drawing");
	}, [store.entries]);
	const totalDrawingsAmount = (0, import_react.useMemo)(() => {
		return allDrawings.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
	}, [allDrawings]);
	const netRetainedProfit = earnedProfit - totalDrawingsAmount;
	const filteredBookings = (0, import_react.useMemo)(() => {
		return store.bookings.filter((b) => {
			const fin = computeBookingFinancials(b);
			if (profitFilterMargin === "profit" && fin.isLoss) return false;
			if (profitFilterMargin === "loss" && !fin.isLoss) return false;
			if (profitFilterStatus === "earned" && b.profitStatus !== "earned") return false;
			if (profitFilterStatus === "unearned" && b.profitStatus === "earned") return false;
			if (profitFilterSource === "agent" && !b.agentId) return false;
			if (profitFilterSource === "direct" && b.agentId) return false;
			if (profitFilterPackage !== "all" && b.packageType !== profitFilterPackage) return false;
			const dateStr = b.travelDate || b.createdAt || "";
			if (profitFilterYear !== "all" && !dateStr.startsWith(profitFilterYear)) return false;
			if (profitFilterMonth !== "all") {
				const parts = dateStr.split("-");
				if (parts.length >= 2 && parts[1] !== profitFilterMonth) return false;
			}
			if (profitSearch.trim()) {
				const q = profitSearch.toLowerCase().trim();
				const headMatch = b.headId.toLowerCase().includes(q);
				const agentMatch = b.agentId?.toLowerCase().includes(q) || false;
				const destMatch = b.destination?.toLowerCase().includes(q) || false;
				const pkgMatch = b.packageType.toLowerCase().includes(q);
				const clientMatch = store.clients.filter((c) => c.headId === b.headId).some((c) => `${c.firstName} ${c.lastName}`.toLowerCase().includes(q));
				if (!headMatch && !agentMatch && !destMatch && !pkgMatch && !clientMatch) return false;
			}
			return true;
		});
	}, [
		store.bookings,
		store.clients,
		profitFilterMargin,
		profitFilterStatus,
		profitFilterSource,
		profitFilterPackage,
		profitFilterMonth,
		profitFilterYear,
		profitSearch
	]);
	const filteredStats = (0, import_react.useMemo)(() => {
		let sales = 0;
		let costs = 0;
		let commissions = 0;
		let profit = 0;
		let earned = 0;
		let unearned = 0;
		let custDiscounts = 0;
		let supRebates = 0;
		let lossCount = 0;
		filteredBookings.forEach((b) => {
			const fin = computeBookingFinancials(b);
			const p = fin.netProfit;
			sales += fin.grossSale;
			costs += fin.netCost;
			commissions += fin.netCommission;
			profit += p;
			custDiscounts += fin.discount;
			supRebates += fin.supplierDiscount;
			if (fin.isLoss) lossCount += 1;
			if (b.profitStatus === "earned") earned += p;
			else unearned += p;
		});
		return {
			sales,
			costs,
			commissions,
			profit,
			earned,
			unearned,
			custDiscounts,
			supRebates,
			lossCount
		};
	}, [filteredBookings]);
	const openProfitModal = (status) => {
		setProfitFilterStatus(status);
		setProfitModalOpen(true);
	};
	const saveAccount = () => {
		if (!accForm.name.trim()) {
			toast.error("Please enter an account name");
			return;
		}
		store.addAccount({
			...accForm,
			openingBalance: Number(accForm.openingBalance) || 0
		});
		setAccForm(emptyAccount);
		setAccOpen(false);
		toast.success("Account created successfully");
	};
	const saveDrawer = () => {
		if (!drawerForm.name.trim()) {
			toast.error("Please enter partner name");
			return;
		}
		const data = {
			name: drawerForm.name.trim(),
			role: drawerForm.role.trim() || "Partner",
			phone: drawerForm.phone.trim() || void 0,
			sharePercent: Number(drawerForm.sharePercent) || 0,
			openingDrawings: Number(drawerForm.openingDrawings) || 0,
			notes: drawerForm.notes.trim() || void 0
		};
		if (editingDrawerId) {
			store.updateDrawer(editingDrawerId, data);
			toast.success("Partner details updated");
		} else {
			store.addDrawer(data);
			toast.success("Partner added to equity registry");
		}
		setDrawerForm(emptyDrawer);
		setEditingDrawerId(null);
		setDrawerOpen(false);
	};
	const openEditDrawer = (d) => {
		setDrawerForm({
			name: d.name,
			role: d.role || "Partner",
			phone: d.phone || "",
			sharePercent: d.sharePercent != null ? String(d.sharePercent) : "50",
			openingDrawings: d.openingDrawings != null ? String(d.openingDrawings) : "",
			notes: d.notes || ""
		});
		setEditingDrawerId(d.id);
		setDrawerOpen(true);
	};
	const getPartnerDrawings = (partner) => {
		return store.entries.filter((e) => {
			if (e.type !== "drawing") return false;
			return e.drawerId === partner.id || e.drawerName && e.drawerName.toLowerCase() === partner.name.toLowerCase() || e.referenceId && e.referenceId === partner.id || e.referenceName && e.referenceName.toLowerCase() === partner.name.toLowerCase();
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Accounts & Profit Engine",
				subtitle: `Liquid Liquidity: ${formatCurrency(totalLiquid)} · Realized Profit: ${formatCurrency(earnedProfit)}`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "gap-1.5 text-xs bg-card/60 hover:bg-accent border-border",
						onClick: () => {
							setDrawerForm(emptyDrawer);
							setEditingDrawerId(null);
							setDrawerOpen(true);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5 text-primary" }), "Add Partner / Drawer"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
						open: accOpen,
						onOpenChange: setAccOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => setAccOpen(true),
							className: "gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Bank / Cash Account"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
							className: "border-border bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add Financial Account" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Account Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: accForm.name,
										onChange: (e) => setAccForm({
											...accForm,
											name: e.target.value
										}),
										placeholder: "e.g. Meezan Bank Main / Head Office Cash",
										className: "mt-1"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Account Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: accForm.type,
										onValueChange: (v) => setAccForm({
											...accForm,
											type: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "mt-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
											"Cash",
											"Bank",
											"Mobile Wallet"
										].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: t,
											children: t
										}, t)) })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Account / IBAN No." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: accForm.number,
												onChange: (e) => setAccForm({
													...accForm,
													number: e.target.value
												}),
												placeholder: "PK...",
												className: "mt-1"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Branch / Identifier" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: accForm.branch,
												onChange: (e) => setAccForm({
													...accForm,
													branch: e.target.value
												}),
												placeholder: "Main Branch / Lahore",
												className: "mt-1"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Opening Balance (PKR)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												value: accForm.openingBalance,
												onChange: (e) => setAccForm({
													...accForm,
													openingBalance: e.target.value
												}),
												placeholder: "0",
												className: "mt-1 font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Opening Date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												value: accForm.openingDate,
												onChange: (e) => setAccForm({
													...accForm,
													openingDate: e.target.value
												}),
												className: "mt-1"
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: saveAccount,
										className: "mt-2",
										children: "Save Account"
									})
								]
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold tracking-wide text-foreground",
						children: "Profit Realization & Equity Summary"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] text-muted-foreground flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-success animate-pulse" }), "Click any card to inspect sales breakdown & toggle profit status"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => openProfitModal("earned"),
						className: "group glass-card rounded-xl p-4 text-left border-border hover:border-success/60 hover:bg-success/5 transition-all shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-10 w-10 items-center justify-center rounded-lg bg-success/15 text-success group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-success/15 px-2 py-0.5 text-[10px] font-bold text-success uppercase tracking-wider",
									children: "Actual Realized"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs font-medium text-muted-foreground",
								children: "Earned Profit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-2xl font-bold font-mono text-success",
								children: formatCurrency(earnedProfit)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 flex items-center justify-between text-[11px] border-t border-border/40 pt-2 text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [earnedCount, " Confirmed Head(s)"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-success font-medium group-hover:underline flex items-center gap-0.5",
									children: "Inspect Realized →"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => openProfitModal("unearned"),
						className: "group glass-card rounded-xl p-4 text-left border-border hover:border-warning/60 hover:bg-warning/5 transition-all shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-10 w-10 items-center justify-center rounded-lg bg-warning/15 text-warning group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-warning/15 px-2 py-0.5 text-[10px] font-bold text-warning uppercase tracking-wider",
									children: "Pipeline / Accrued"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs font-medium text-muted-foreground",
								children: "Unearned Profit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-2xl font-bold font-mono text-warning",
								children: formatCurrency(unearnedProfit)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 flex items-center justify-between text-[11px] border-t border-border/40 pt-2 text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [unearnedCount, " Pending Head(s)"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-warning font-medium group-hover:underline flex items-center gap-0.5",
									children: "Convert to Earned →"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => openProfitModal("all"),
						className: "group glass-card rounded-xl p-4 text-left border-border hover:border-primary/60 hover:bg-primary/5 transition-all shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPie, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-bold text-primary uppercase tracking-wider",
									children: "Full Portfolio"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs font-medium text-muted-foreground",
								children: "Total Projected Profit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-2xl font-bold font-mono text-foreground",
								children: formatCurrency(totalProjectedProfit)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 flex items-center justify-between text-[11px] border-t border-border/40 pt-2 text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Sales: ", formatCurrency(totalSales)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary font-medium group-hover:underline flex items-center gap-0.5",
									children: "Multi-Filter View →"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setDrawingsModalOpen(true),
						className: "group glass-card rounded-xl p-4 text-left border-border hover:border-destructive/60 hover:bg-destructive/5 transition-all shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/15 text-destructive group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-bold text-destructive uppercase tracking-wider",
									children: "Owner Drawings"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs font-medium text-muted-foreground",
								children: "Total Partner Withdrawals"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-2xl font-bold font-mono text-destructive",
								children: formatCurrency(totalDrawingsAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 flex items-center justify-between text-[11px] border-t border-border/40 pt-2 text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Retained: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: netRetainedProfit >= 0 ? "text-success" : "text-destructive",
									children: formatCurrency(netRetainedProfit)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive font-medium group-hover:underline flex items-center gap-0.5",
									children: "Audit Withdrawals →"
								})]
							})
						]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card rounded-xl p-4 md:p-5 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-border/50 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display text-base font-semibold text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-primary" }), "Partner Equity & Drawing Account Cards"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Manage drawer profiles, equity shares, and monitor individual withdrawal statements across accounts."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							setDrawerForm(emptyDrawer);
							setEditingDrawerId(null);
							setDrawerOpen(true);
						},
						className: "gap-1.5 text-xs h-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5" }), "Add Partner Profile"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
					children: store.drawers.map((partner) => {
						const drawings = getPartnerDrawings(partner);
						const totalDrawn = drawings.reduce((sum, e) => sum + (Number(e.amount) || 0), 0) + (partner.openingDrawings || 0);
						const accountMap = /* @__PURE__ */ new Map();
						drawings.forEach((e) => {
							const accName = store.accounts.find((a) => a.id === e.accountId)?.name || e.paymentMethod || "Cash Account";
							accountMap.set(accName, (accountMap.get(accName) || 0) + (Number(e.amount) || 0));
						});
						const equityEntitlement = Math.round(earnedProfit * (partner.sharePercent || 0) / 100);
						const remainingShare = equityEntitlement - totalDrawn;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border/60 bg-accent/5 p-4 flex flex-col justify-between hover:border-primary/50 transition-all shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-foreground text-sm",
											children: partner.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-semibold text-primary",
											children: [partner.sharePercent || 0, "% Equity"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: [
											partner.role || "Partner",
											" ",
											partner.phone && `· ${partner.phone}`
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "h-7 w-7 text-muted-foreground hover:text-foreground",
											title: "Edit Partner",
											onClick: () => openEditDrawer(partner),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-3.5 w-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											variant: "ghost",
											className: "h-7 w-7 text-muted-foreground hover:text-destructive",
											title: "Delete Partner",
											onClick: () => {
												if (store.drawers.length <= 1) {
													toast.error("At least one partner must remain");
													return;
												}
												store.deleteDrawer(partner.id);
												toast.success("Partner removed");
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5" })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid grid-cols-2 gap-2 rounded-lg bg-background/50 p-2.5 border border-border/40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] uppercase tracking-wider text-muted-foreground",
											children: "Total Drawn"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-base font-bold font-mono text-destructive",
											children: formatCurrency(totalDrawn)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] text-muted-foreground",
											children: [drawings.length, " withdrawal(s)"]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] uppercase tracking-wider text-muted-foreground",
											children: "Share of Earned"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-base font-bold font-mono text-success",
											children: formatCurrency(equityEntitlement)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `text-[10px] font-semibold ${remainingShare >= 0 ? "text-success" : "text-destructive"}`,
											children: ["Net: ", formatCurrency(remainingShare)]
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
										children: "Disbursement Accounts Used:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-1.5 mt-1",
										children: [accountMap.size === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] text-muted-foreground italic",
											children: "No withdrawals recorded yet"
										}), Array.from(accountMap.entries()).map(([accName, amt]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-md border border-border/50 bg-accent/20 px-2 py-0.5 text-[10px] font-medium text-foreground flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [accName, ":"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "font-mono text-destructive",
												children: formatCurrency(amt)
											})]
										}, accName))]
									})]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 pt-3 border-t border-border/40 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground font-mono",
									children: partner.id
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setSelectedDrawerForStatement(partner),
									className: "h-7 text-xs gap-1 hover:bg-primary hover:text-primary-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3 w-3" }),
										"View Statement (",
										drawings.length,
										")"
									]
								})]
							})]
						}, partner.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-display text-base font-semibold text-foreground flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-4 w-4 text-primary" }), "Chart of Accounts (Cash & Bank Ledgers)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Select an account below to view its running double-entry ledger and reconciliation state."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-semibold text-foreground",
							children: ["Combined Liquidity: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary font-mono",
								children: formatCurrency(totalLiquid)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4",
						children: [store.accounts.map((a) => {
							const Icon = icons[a.type] || Wallet;
							const bal = computeAccountBalance(a.id);
							const active = selectedAccount?.id === a.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelAccId(a.id),
								className: `glass-card rounded-xl p-4 text-left transition-all ${active ? "border-primary shadow-md bg-primary/5 ring-1 ring-primary/40" : "glass-card-hover"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex h-9 w-9 items-center justify-center rounded-md bg-primary/10",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-primary" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded bg-accent/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-muted-foreground font-semibold",
											children: a.type
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm font-semibold text-foreground",
										children: a.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: [a.number, a.branch].filter(Boolean).join(" · ") || a.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-baseline justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground",
											children: "Balance:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `font-mono text-base font-bold ${bal < 0 ? "text-destructive" : "text-success"}`,
											children: formatCurrency(bal)
										})]
									})
								]
							}, a.id);
						}), store.accounts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No accounts created yet."
						})]
					}),
					selectedAccount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-4 md:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-col gap-3 md:flex-row md:items-end md:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-display text-base font-semibold text-foreground",
								children: [selectedAccount.name, " — Running Ledger"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"Opening ",
									formatCurrency(selectedAccount.openingBalance),
									" on ",
									selectedAccount.openingDate || "2026-01-01"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs",
										children: "From"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: from,
										onChange: (e) => setFrom(e.target.value),
										className: "h-9 text-xs"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs",
										children: "To"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: to,
										onChange: (e) => setTo(e.target.value),
										className: "h-9 text-xs"
									})] }),
									(from || to) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => {
											setFrom("");
											setTo("");
										},
										className: "h-9 text-xs",
										children: "Clear"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										size: "icon",
										title: "Delete account",
										className: "h-9 w-9 text-destructive hover:bg-destructive/10",
										onClick: () => {
											if (store.accounts.length <= 1) {
												toast.error("At least one account must remain");
												return;
											}
											store.deleteAccount(selectedAccount.id);
											setSelAccId(null);
											toast.success("Account deleted");
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-4 w-4" })
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-lg border border-border/40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[650px] text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border bg-accent/20 text-left text-xs uppercase tracking-wider text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3.5 py-2.5",
											children: "Date"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3.5 py-2.5",
											children: "Description & Reference"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3.5 py-2.5",
											children: "Type"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3.5 py-2.5 text-right",
											children: "In (+)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3.5 py-2.5 text-right",
											children: "Out (-)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3.5 py-2.5 text-right",
											children: "Balance"
										})
									]
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [ledgerRows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50 hover:bg-accent/30 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 whitespace-nowrap text-xs font-mono",
											children: r.date
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 capitalize text-xs font-medium",
											children: r.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 text-[10px]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded bg-accent/30 px-1.5 py-0.5 font-semibold text-muted-foreground",
												children: r.transactionType
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 text-right text-success font-mono font-semibold",
											children: r.direction === "in" ? formatCurrency(r.amount) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 text-right text-destructive font-mono font-semibold",
											children: r.direction === "out" ? formatCurrency(r.amount) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `px-3.5 py-2.5 text-right font-mono font-bold ${r.runningBalanceAfter >= 0 ? "text-foreground" : "text-destructive"}`,
											children: formatCurrency(r.runningBalanceAfter)
										})
									]
								}, r.id)), ledgerRows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 6,
									className: "px-3 py-8 text-center text-xs text-muted-foreground",
									children: "No transactions recorded in this period."
								}) })] })]
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: profitModalOpen,
				onOpenChange: setProfitModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-4xl border-border bg-card max-h-[90vh] flex flex-col p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
							className: "border-b border-border/50 pb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
									className: "text-lg font-bold flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-5 w-5 text-primary" }), "Profit Realization Engine — Earned vs Unearned Sales"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Convert sales profit from Unearned (Pipeline) to Earned (Actual) with 1-click accounting verification."
								})] })
							})
						}),
						totalLossDealsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 rounded-lg border border-rose-500/50 bg-rose-500/10 p-2.5 flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-4 w-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-semibold text-rose-300",
									children: [
										"Negative Margin Alert: ",
										totalLossDealsCount,
										" Loss Deal(s) Detected"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-rose-200/80",
									children: [
										"Total negative loss: -",
										formatCurrency(totalLossAmount),
										". Concessions/commissions exceed sale value."
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setProfitFilterMargin(profitFilterMargin === "loss" ? "all" : "loss"),
								className: `h-7 text-[10px] border-rose-500/50 ${profitFilterMargin === "loss" ? "bg-rose-500 text-white" : "text-rose-300 hover:bg-rose-500/20"}`,
								children: profitFilterMargin === "loss" ? "Show All Deals" : "Isolate Loss Deals →"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-3 bg-accent/10 p-3 rounded-xl border border-border/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-6 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Margin Category"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: profitFilterMargin,
										onValueChange: (v) => setProfitFilterMargin(v),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 text-xs mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "All Deals"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "profit",
												children: "Profitable Deals Only"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "loss",
												children: "Loss Deals Only (Negative)"
											})
										] })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Profit Status"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: profitFilterStatus,
										onValueChange: (v) => setProfitFilterStatus(v),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 text-xs mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "All Profits"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "earned",
												children: "Earned (Actual)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "unearned",
												children: "Unearned (Pending)"
											})
										] })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Sale Source"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: profitFilterSource,
										onValueChange: (v) => setProfitFilterSource(v),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 text-xs mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "All Sources"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "agent",
												children: "Agent Sales Only"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "direct",
												children: "Direct Clients Only"
											})
										] })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Package"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: profitFilterPackage,
										onValueChange: setProfitFilterPackage,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 text-xs mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "All Packages"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Umrah",
												children: "Umrah"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Hajj",
												children: "Hajj"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Flight",
												children: "Flight"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Tour",
												children: "Tour"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Custom",
												children: "Custom"
											})
										] })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Travel Month"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: profitFilterMonth,
										onValueChange: setProfitFilterMonth,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 text-xs mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "All Months"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "01",
												children: "January"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "02",
												children: "February"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "03",
												children: "March"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "04",
												children: "April"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "05",
												children: "May"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "06",
												children: "June"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "07",
												children: "July"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "08",
												children: "August"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "09",
												children: "September"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "10",
												children: "October"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "11",
												children: "November"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "12",
												children: "December"
											})
										] })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Year"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: profitFilterYear,
										onValueChange: setProfitFilterYear,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 text-xs mt-0.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "All Years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2024",
												children: "2024"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2025",
												children: "2025"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2026",
												children: "2026"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2027",
												children: "2027"
											})
										] })]
									})] })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: profitSearch,
										onChange: (e) => setProfitSearch(e.target.value),
										placeholder: "Filter by Head ID (e.g. AV-HD-001), Client name, or Agent ID...",
										className: "h-8 pl-8 text-xs bg-background/50"
									})]
								}), (profitFilterStatus !== "all" || profitFilterMargin !== "all" || profitFilterSource !== "all" || profitFilterPackage !== "all" || profitFilterMonth !== "all" || profitFilterYear !== "all" || profitSearch) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => {
										setProfitFilterStatus("all");
										setProfitFilterMargin("all");
										setProfitFilterSource("all");
										setProfitFilterPackage("all");
										setProfitFilterMonth("all");
										setProfitFilterYear("all");
										setProfitSearch("");
									},
									className: "h-8 text-xs text-muted-foreground hover:text-foreground",
									children: "Reset Filters"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-accent/20 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground uppercase",
										children: "Filtered Sales"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold font-mono text-foreground",
										children: formatCurrency(filteredStats.sales)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-accent/20 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground uppercase",
										children: "Costs + Comm"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold font-mono text-destructive",
										children: formatCurrency(filteredStats.costs + filteredStats.commissions)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-amber-500/10 border border-amber-500/30 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-amber-400 uppercase font-semibold",
										children: "Cust. Discounts"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-bold font-mono text-amber-400",
										children: ["-", formatCurrency(filteredStats.custDiscounts)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-emerald-500/10 border border-emerald-500/30 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-emerald-400 uppercase font-semibold",
										children: "Sup. Rebates"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-bold font-mono text-emerald-400",
										children: ["+", formatCurrency(filteredStats.supRebates)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-success/10 border border-success/30 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-success uppercase font-semibold",
										children: "Earned Profit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold font-mono text-success",
										children: formatCurrency(filteredStats.earned)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-warning/10 border border-warning/30 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-warning uppercase font-semibold",
										children: "Unearned Profit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold font-mono text-warning",
										children: formatCurrency(filteredStats.unearned)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex-1 overflow-y-auto rounded-lg border border-border/40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-accent/20 sticky top-0 border-b border-border z-10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "text-left uppercase tracking-wider text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2",
												children: "Head ID / Package"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2",
												children: "Source / Agent"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right",
												children: "Sale Total"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right",
												children: "Cost"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right",
												children: "Commission"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right",
												children: "Net Profit"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-center",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right",
												children: "Conversion Action"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
									className: "divide-y divide-border/40",
									children: [filteredBookings.map((b) => {
										const fin = computeBookingFinancials(b);
										const isEarned = b.profitStatus === "earned";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-accent/20 transition-colors",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "px-3 py-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-primary",
														children: b.headId
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-[10px] text-muted-foreground",
														children: [
															b.packageType,
															" · ",
															b.travelDate
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "px-3 py-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-medium text-foreground",
														children: b.agentId ? `Agent: ${b.agentId}` : "Direct Client"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-[10px] text-muted-foreground",
														children: b.destination || "Standard"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-right font-mono font-medium",
													children: formatCurrency(b.totalAmount)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-right font-mono text-destructive",
													children: formatCurrency(b.totalCost)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-right font-mono text-warning",
													children: formatCurrency(b.commission)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "px-3 py-2 text-right font-mono",
													children: [
														fin.isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col items-end",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-bold text-rose-400 flex items-center gap-1",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3 w-3 text-rose-500" }),
																	"-",
																	formatCurrency(fin.lossAmount)
																]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[9px] text-rose-300 font-semibold uppercase",
																children: [
																	"Loss (",
																	fin.marginPercent.toFixed(1),
																	"%)"
																]
															})]
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col items-end",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-success",
																children: formatCurrency(fin.netProfit)
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[9px] text-muted-foreground",
																children: [
																	"(",
																	fin.marginPercent.toFixed(1),
																	"%)"
																]
															})]
														}),
														fin.discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-[9px] text-amber-400",
															children: [
																"Disc: ",
																formatCurrency(fin.discount),
																" ",
																b.discountSettlement === "agent_commission" ? "(Agent)" : "(Agency)"
															]
														}),
														fin.supplierDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-[9px] text-emerald-400",
															children: ["Rebate: +", formatCurrency(fin.supplierDiscount)]
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-center",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider ${isEarned ? "bg-success/20 text-success border border-success/40" : "bg-warning/20 text-warning border border-warning/40"}`,
														children: isEarned ? "Earned" : "Unearned"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: isEarned ? "outline" : "default",
														onClick: () => {
															store.toggleBookingProfitStatus(b.id);
															toast.success(isEarned ? `Reverted ${b.headId} to Unearned Profit` : `Converted ${b.headId} to Earned Actual Profit`);
														},
														className: `h-7 text-[11px] gap-1 font-semibold ${isEarned ? "border-warning/50 text-warning hover:bg-warning/10" : "bg-success text-success-foreground hover:bg-success/90"}`,
														children: isEarned ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3 w-3" }), "Revert to Unearned"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }), "Mark as Earned"] })
													})
												})
											]
										}, b.id);
									}), filteredBookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 8,
										className: "px-3 py-8 text-center text-xs text-muted-foreground",
										children: "No sales matching the selected filters."
									}) })]
								})]
							})
						})
					]
				})
			}),
			selectedDrawerForStatement && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedDrawerForStatement,
				onOpenChange: (open) => !open && setSelectedDrawerForStatement(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl border-border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
						className: "border-b border-border/50 pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-between",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
								className: "text-base font-bold flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-5 w-5 text-primary" }),
									selectedDrawerForStatement.name,
									" — Drawing Statement"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground mt-0.5",
								children: [
									selectedDrawerForStatement.role,
									" · ",
									selectedDrawerForStatement.sharePercent,
									"% Profit Equity"
								]
							})] })
						})
					}), (() => {
						const statementEntries = getPartnerDrawings(selectedDrawerForStatement);
						const sum = statementEntries.reduce((s, e) => s + (Number(e.amount) || 0), 0) + (selectedDrawerForStatement.openingDrawings || 0);
						let running = selectedDrawerForStatement.openingDrawings || 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between rounded-lg bg-destructive/10 border border-destructive/20 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase font-semibold text-destructive",
									children: "Cumulative Withdrawals"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-bold font-mono text-destructive",
									children: formatCurrency(sum)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Total Withdrawals: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: statementEntries.length })] }), selectedDrawerForStatement.openingDrawings ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px]",
										children: ["Opening Baseline: ", formatCurrency(selectedDrawerForStatement.openingDrawings)]
									}) : null]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-h-[50vh] overflow-y-auto rounded-lg border border-border/40",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-accent/20 sticky top-0 border-b border-border",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "text-left uppercase tracking-wider text-muted-foreground",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Date"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Account & Channel"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2",
													children: "Purpose / Note"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2 text-right",
													children: "Amount"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-3 py-2 text-right",
													children: "Running Total"
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
										className: "divide-y divide-border/40",
										children: [statementEntries.map((e) => {
											const amt = Number(e.amount) || 0;
											running += amt;
											const acc = store.accounts.find((a) => a.id === e.accountId);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-accent/20",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2 font-mono whitespace-nowrap",
														children: e.date
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-3 py-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-semibold text-foreground",
															children: acc?.name || e.paymentMethod || "Cash"
														}), e.txnRef && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[10px] text-muted-foreground block",
															children: ["Ref: ", e.txnRef]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2 text-muted-foreground",
														children: [e.chargeCategory, e.note].filter(Boolean).join(" · ") || "Personal drawing"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2 text-right font-mono font-bold text-destructive",
														children: formatCurrency(amt)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-3 py-2 text-right font-mono font-semibold text-foreground",
														children: formatCurrency(running)
													})
												]
											}, e.id);
										}), statementEntries.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 5,
											className: "px-3 py-6 text-center text-muted-foreground italic",
											children: "No drawing transactions recorded for this partner yet."
										}) })]
									})]
								})
							})]
						});
					})()]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: drawingsModalOpen,
				onOpenChange: setDrawingsModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-3xl border-border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
						className: "border-b border-border/50 pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-bold flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-5 w-5 text-destructive" }), "All Partner Drawings & Withdrawals Ledger"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg bg-accent/20 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase text-muted-foreground font-semibold",
								children: "Total Drawn from Business"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold font-mono text-destructive",
								children: formatCurrency(totalDrawingsAmount)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Retained Operating Profit:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `font-mono font-bold text-base ${netRetainedProfit >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(netRetainedProfit)
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-h-[55vh] overflow-y-auto rounded-lg border border-border/40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-accent/20 sticky top-0 border-b border-border",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "text-left uppercase tracking-wider text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2",
												children: "Date"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2",
												children: "Drawn By"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2",
												children: "Account"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2",
												children: "Category & Note"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 text-right",
												children: "Amount (PKR)"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
									className: "divide-y divide-border/40",
									children: [allDrawings.map((e) => {
										const acc = store.accounts.find((a) => a.id === e.accountId);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-accent/20",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 font-mono whitespace-nowrap",
													children: e.date
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 font-semibold text-foreground",
													children: e.drawerName || e.referenceName || "Partner"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-muted-foreground",
													children: acc?.name || e.paymentMethod || "Cash"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-muted-foreground",
													children: [e.chargeCategory, e.note].filter(Boolean).join(" · ") || "Drawing"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-3 py-2 text-right font-mono font-bold text-destructive",
													children: formatCurrency(e.amount)
												})
											]
										}, e.id);
									}), allDrawings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 5,
										className: "px-3 py-6 text-center text-muted-foreground italic",
										children: "No drawing entries recorded yet."
									}) })]
								})]
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: drawerOpen,
				onOpenChange: setDrawerOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "border-border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editingDrawerId ? "Edit Partner Profile" : "Register Partner / Drawer" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 mt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Full Name *" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: drawerForm.name,
								onChange: (e) => setDrawerForm({
									...drawerForm,
									name: e.target.value
								}),
								placeholder: "e.g. Muhammad Ali",
								className: "mt-1"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Role / Title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: drawerForm.role,
									onChange: (e) => setDrawerForm({
										...drawerForm,
										role: e.target.value
									}),
									placeholder: "Managing Partner / Director",
									className: "mt-1"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Equity Share (%)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "0",
									max: "100",
									value: drawerForm.sharePercent,
									onChange: (e) => setDrawerForm({
										...drawerForm,
										sharePercent: e.target.value
									}),
									placeholder: "50",
									className: "mt-1 font-mono"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone / Contact" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: drawerForm.phone,
									onChange: (e) => setDrawerForm({
										...drawerForm,
										phone: e.target.value
									}),
									placeholder: "0300-1234567",
									className: "mt-1"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Opening Drawings (PKR)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: drawerForm.openingDrawings,
									onChange: (e) => setDrawerForm({
										...drawerForm,
										openingDrawings: e.target.value
									}),
									placeholder: "0",
									className: "mt-1 font-mono"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Operational Notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: drawerForm.notes,
								onChange: (e) => setDrawerForm({
									...drawerForm,
									notes: e.target.value
								}),
								placeholder: "Special authority, responsibilities...",
								className: "mt-1"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: saveDrawer,
								className: "mt-2",
								children: editingDrawerId ? "Update Partner" : "Save Partner"
							})
						]
					})]
				})
			})
		]
	});
}
export { AccountsPage as component };
