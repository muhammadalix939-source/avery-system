import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { O as toast, T as formatCurrency, a as useStore, c as signInWithGoogle, j as require_react, k as require_jsx_runtime, l as testConnection, o as auth, p as onAuthStateChanged, s as logOut } from "./store-DLjJF6C7.js";
import { t as CircleCheck } from "./circle-check-CPvWbtJ5.js";
import { n as Copy, t as Textarea } from "./textarea-MZb_Jg8r.js";
import { t as Download } from "./download-CEfpC1QR.js";
import { t as RotateCcw } from "./rotate-ccw-Q-S1YtUF.js";
import { t as ShieldCheck } from "./shield-check-BDluUh3C.js";
import { t as Trash } from "./trash-YMvfXcpp.js";
import { t as TriangleAlert } from "./triangle-alert-CI6HNCIP.js";
import { a as Sparkles, c as RefreshCw, g as createLucideIcon, o as Settings, p as Database, u as LogOut } from "./index-BgfHyeon.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as Label } from "./label-C_GFC7te.js";
// node_modules/lucide-react/dist/esm/icons/cloud.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$3 = {
	name: "cloud",
	size: 24,
	node: [["path", {
		d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",
		key: "p7xjir"
	}]]
};
__iconData$3.node;
var Cloud = createLucideIcon(__iconData$3);
// node_modules/lucide-react/dist/esm/icons/log-in.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$2 = {
	name: "log-in",
	size: 24,
	node: [
		["path", {
			d: "m10 17 5-5-5-5",
			key: "1bsop3"
		}],
		["path", {
			d: "M15 12H3",
			key: "6jk70r"
		}],
		["path", {
			d: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
			key: "u53s6r"
		}]
	]
};
__iconData$2.node;
var LogIn = createLucideIcon(__iconData$2);
// node_modules/lucide-react/dist/esm/icons/save.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$1 = {
	name: "save",
	size: 24,
	node: [
		["path", {
			d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
			key: "1c8476"
		}],
		["path", {
			d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",
			key: "1ydtos"
		}],
		["path", {
			d: "M7 3v4a1 1 0 0 0 1 1h7",
			key: "t51u73"
		}]
	]
};
__iconData$1.node;
var Save = createLucideIcon(__iconData$1);
// node_modules/lucide-react/dist/esm/icons/upload.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "upload",
	size: 24,
	node: [
		["path", {
			d: "M12 3v12",
			key: "1x0j5s"
		}],
		["path", {
			d: "m17 8-5-5-5 5",
			key: "7q97r8"
		}],
		["path", {
			d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
			key: "ih7n3h"
		}]
	]
};
__iconData.node;
var Upload = createLucideIcon(__iconData);
// src/routes/settings.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const store = useStore();
	const [user, setUser] = (0, import_react.useState)(null);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [testingConn, setTestingConn] = (0, import_react.useState)(false);
	const [connStatus, setConnStatus] = (0, import_react.useState)(null);
	const [restoringBaseline, setRestoringBaseline] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		const unsub = onAuthStateChanged(auth, (u) => setUser(u));
		return () => unsub();
	}, []);
	const [form, setForm] = (0, import_react.useState)({
		revenue: String(store.opening.revenue || 0),
		pending: String(store.opening.pending || 0),
		bookings: String(store.opening.bookings || 0),
		clients: String(store.opening.clients || 0),
		supplierDue: String(store.opening.supplierDue || 0),
		profit: String(store.opening.profit || 0),
		cost: String(store.opening.cost || 0),
		expenses: String(store.opening.expenses || 0),
		commission: String(store.opening.commission || 0),
		cash: String(store.opening.cash || 0),
		note: store.opening.note || ""
	});
	function save() {
		store.setOpeningBalances({
			revenue: Number(form.revenue) || 0,
			pending: Number(form.pending) || 0,
			bookings: Number(form.bookings) || 0,
			clients: Number(form.clients) || 0,
			supplierDue: Number(form.supplierDue) || 0,
			profit: Number(form.profit) || 0,
			cost: Number(form.cost) || 0,
			expenses: Number(form.expenses) || 0,
			commission: Number(form.commission) || 0,
			cash: Number(form.cash) || 0,
			note: form.note
		});
		toast.success("Opening balances saved");
	}
	function reset() {
		setForm({
			revenue: "0",
			pending: "0",
			bookings: "0",
			clients: "0",
			supplierDue: "0",
			profit: "0",
			cost: "0",
			expenses: "0",
			commission: "0",
			cash: "0",
			note: ""
		});
	}
	function wipeAll(keepOpening) {
		if (!confirm(keepOpening ? "This will permanently delete all clients, bookings, agents, suppliers, entries and monthly history. Opening balances will be kept. Continue?" : "This will permanently delete EVERYTHING (including opening balances) and reset the system to a true blank slate. Continue?")) return;
		store.resetAllData({ keepOpening });
		if (!keepOpening) setForm({
			revenue: "0",
			pending: "0",
			bookings: "0",
			clients: "0",
			supplierDue: "0",
			profit: "0",
			cost: "0",
			expenses: "0",
			commission: "0",
			cash: "0",
			note: ""
		});
		toast.success(keepOpening ? "All operational data cleared." : "System fully reset to blank slate.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Settings",
				subtitle: "Edit dashboard opening balances and business defaults"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-6 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b border-border/50 pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-5 w-5 text-primary" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold",
							children: "Dashboard Opening Balances"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "These values are added on top of your live data so the dashboard reflects your full business history (including records that aren't entered into the system yet)."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
						children: [
							[
								"revenue",
								"Opening Revenue (PKR)",
								"Cash already collected before this system"
							],
							[
								"cost",
								"Opening Cost of Sales (PKR)",
								"Supplier cost of those old sales — must be filled if Opening Revenue is filled, otherwise profit inflates"
							],
							[
								"expenses",
								"Opening Expenses (PKR)",
								"Office / operating expenses already incurred"
							],
							[
								"commission",
								"Opening Agent Commission (PKR)",
								"Commission already earned by agents on old sales"
							],
							[
								"cash",
								"Opening Cash / Bank (PKR)",
								"Actual money in hand + bank when you started using this system"
							],
							[
								"pending",
								"Opening Pending (PKR)",
								"Outstanding receivables from old bookings"
							],
							[
								"bookings",
								"Opening Bookings (count)",
								"Historical booking count"
							],
							[
								"clients",
								"Opening Clients (count)",
								"Historical client count"
							],
							[
								"supplierDue",
								"Opening Supplier Due (PKR)",
								"What you still owe legacy suppliers"
							],
							[
								"profit",
								"Profit Adjustment (PKR)",
								"Manual correction only — leave 0 if you filled Opening Revenue/Cost/Expenses above"
							]
						].map(([key, label, hint]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-semibold",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form[key],
								onChange: (e) => setForm({
									...form,
									[key]: e.target.value
								}),
								className: "bg-accent/20 border-border mt-1 h-9 text-sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[10px] text-muted-foreground",
								children: hint
							})
						] }, key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs font-semibold",
						children: "Notes (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.note,
						onChange: (e) => setForm({
							...form,
							note: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 text-sm",
						placeholder: "Any internal notes about how these baseline numbers were calculated…",
						rows: 3
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: save,
							className: "gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4" }), " Save Opening Balances"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: reset,
							variant: "outline",
							children: "Reset to zero"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-primary/20 bg-primary/5 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-primary mb-2",
							children: "Live Preview"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-xs sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Revenue baseline",
									value: formatCurrency(Number(form.revenue) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Cost baseline",
									value: formatCurrency(Number(form.cost) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Expenses baseline",
									value: formatCurrency(Number(form.expenses) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Commission baseline",
									value: formatCurrency(Number(form.commission) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Cash baseline",
									value: formatCurrency(Number(form.cash) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Opening gross profit",
									value: formatCurrency((Number(form.revenue) || 0) - (Number(form.cost) || 0) - (Number(form.expenses) || 0) - (Number(form.commission) || 0))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Pending baseline",
									value: formatCurrency(Number(form.pending) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Bookings baseline",
									value: String(Number(form.bookings) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Clients baseline",
									value: String(Number(form.clients) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Supplier due baseline",
									value: formatCurrency(Number(form.supplierDue) || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Profit adjustment",
									value: formatCurrency(Number(form.profit) || 0)
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .1 },
				className: "glass-card rounded-xl p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold mb-2",
					children: "Per-entity opening balances"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Opening balances for individual ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary font-medium",
							children: "agents"
						}),
						",",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary font-medium",
							children: " suppliers"
						}),
						" and",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary font-medium",
							children: " clients"
						}),
						" are set inside each record's edit form (Previous Commission, Previous Payable, etc). These flow into their statements automatically."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .15 },
				className: "glass-card rounded-xl p-6 space-y-4 border-primary/30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border/50 pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "h-5 w-5 text-primary" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-semibold",
									children: "Cloud Database (Google Cloud Firestore)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${mounted && user ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30" : "bg-amber-500/10 text-amber-400 border border-amber-500/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 rounded-full ${mounted && user ? "bg-emerald-400" : "bg-amber-400"}` }), mounted && user ? "Cloud Synced" : "Provisioned & Ready"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Persistent enterprise cloud storage enabled for multi-user and real-time CRM updates."
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: mounted && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground hidden sm:inline",
								children: ["Signed in as ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: user.email
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: async () => {
									await logOut();
									setUser(null);
									toast.info("Signed out of Cloud DB");
								},
								className: "gap-1.5 text-xs h-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" }), " Sign Out"]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: async () => {
								try {
									const u = await signInWithGoogle();
									setUser(u);
									toast.success(`Connected as ${u.email}`);
									await store.syncToCloud();
								} catch (err) {
									toast.error(err instanceof Error ? err.message : "Sign-in failed");
								}
							},
							className: "gap-1.5 text-xs h-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "h-3.5 w-3.5" }), " Connect with Google"]
						}) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-background/50 p-3 border border-border/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase font-semibold text-muted-foreground",
									children: "Cloud Project"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-foreground mt-0.5",
									children: "xanthic-indexer-c01dl"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-background/50 p-3 border border-border/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase font-semibold text-muted-foreground",
									children: "Database Engine"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-foreground mt-0.5",
									children: "Firestore (Enterprise Free Tier)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-background/50 p-3 border border-border/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase font-semibold text-muted-foreground",
									children: "Last Cloud Sync"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-foreground mt-0.5",
									children: mounted && store.lastSyncedAt ? store.lastSyncedAt : "Pending manual/auto sync"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border/60 bg-muted/20 p-3.5 space-y-2.5 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-emerald-400 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-foreground",
										children: "Authorized System Admins:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[11px] text-muted-foreground",
										children: "alianus09x@gmail.com"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "•"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[11px] text-emerald-400 font-medium",
										children: "anusshahid016@gmail.com"
									})
								]
							}), mounted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								className: "h-7 text-[11px] gap-1 px-2.5",
								onClick: () => {
									navigator.clipboard.writeText(window.location.hostname);
									toast.success(`Copied current host (${window.location.hostname}) to clipboard!`);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3 w-3" }),
									"Copy Domain (",
									window.location.hostname,
									")"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted-foreground leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "Lovable / Multi-device Setup:"
								}),
								" To allow signing in inside Lovable or custom preview URLs, ensure your domain (e.g. ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
									className: "bg-background/80 px-1 py-0.5 rounded text-foreground font-mono",
									children: "lovable.app"
								}),
								", ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
									className: "bg-background/80 px-1 py-0.5 rounded text-foreground font-mono",
									children: "lovableproject.com"
								}),
								") is added to ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "Firebase Console → Authentication → Settings tab → Authorized domains"
								}),
								"."
							]
						})]
					}),
					connStatus && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-primary/20 bg-primary/5 p-3 text-xs flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: connStatus })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: testingConn,
								onClick: async () => {
									setTestingConn(true);
									try {
										const res = await testConnection();
										setConnStatus(res.message);
										toast.success(res.message);
									} catch (e) {
										toast.error(e instanceof Error ? e.message : "Connection failed");
									} finally {
										setTestingConn(false);
									}
								},
								className: "gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${testingConn ? "animate-spin" : ""}` }), "Test Connection"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								disabled: store.cloudSyncStatus === "syncing",
								onClick: async () => {
									if (!user) {
										toast.info("Please connect your Google Account first to authenticate cloud writes");
										return;
									}
									try {
										toast.loading("Uploading CRM state to Firestore...", { id: "sync-toast" });
										const res = await store.syncToCloud();
										if (res && res.success === false) toast.error(`Upload aborted: ${res.reason || "Not authenticated"}`, { id: "sync-toast" });
										else toast.success("All data uploaded and backed up to Firestore!", { id: "sync-toast" });
									} catch (e) {
										toast.error(e instanceof Error ? e.message : "Upload failed", { id: "sync-toast" });
									}
								},
								className: "gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "h-3.5 w-3.5" }), "Upload Local Data to Cloud DB"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: store.cloudSyncStatus === "syncing",
								onClick: async () => {
									if (!user) {
										toast.info("Please connect your Google Account first to authenticate cloud reads");
										return;
									}
									try {
										toast.loading("Fetching latest data from Firestore...", { id: "load-toast" });
										const res = await store.loadFromCloud();
										toast.success(`Pulled ${res?.count || 0} records from Cloud DB!`, { id: "load-toast" });
									} catch (e) {
										toast.error(e instanceof Error ? e.message : "Pull failed", { id: "load-toast" });
									}
								},
								className: "gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${store.cloudSyncStatus === "syncing" ? "animate-spin" : ""}` }), "Pull from Cloud DB"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									const data = {
										clients: store.clients,
										bookings: store.bookings,
										agents: store.agents,
										suppliers: store.suppliers,
										entries: store.entries,
										groups: store.groups,
										accounts: store.accounts,
										opening: store.opening,
										alertSettings: store.alertSettings,
										exportedAt: (/* @__PURE__ */ new Date()).toISOString()
									};
									const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
									const url = URL.createObjectURL(blob);
									const a = document.createElement("a");
									a.href = url;
									a.download = `avery-crm-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
									a.click();
									URL.revokeObjectURL(url);
									toast.success("Offline backup downloaded (JSON)");
								},
								className: "gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), "Download Backup (JSON)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex cursor-pointer items-center justify-center gap-2 rounded-md border border-input bg-background px-3 py-1.5 text-xs font-medium hover:bg-accent transition-colors",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-3.5 w-3.5" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Restore Backup (JSON)" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: ".json",
										className: "hidden",
										onChange: (e) => {
											const file = e.target.files?.[0];
											if (!file) return;
											const reader = new FileReader();
											reader.onload = (evt) => {
												try {
													const parsed = JSON.parse(evt.target?.result);
													localStorage.setItem("av-crm-store-v1", JSON.stringify(parsed));
													toast.success("Backup loaded successfully! Refreshing...");
													setTimeout(() => window.location.reload(), 600);
												} catch {
													toast.error("Invalid JSON file");
												}
											};
											reader.readAsText(file);
										}
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/avery-system-source-code.tar.gz",
								download: "avery-system-source-code.tar.gz",
								className: "inline-flex items-center justify-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/20 transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Download Full Codebase (.tar.gz)" })]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .18 },
				className: "glass-card rounded-xl p-6 space-y-4 border-emerald-500/30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b border-border/50 pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-emerald-400" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-semibold",
								children: "Pre-Error Baseline Restore & Cloud Cleanup"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-semibold text-emerald-400",
								children: "Verified Clean State"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Recover the clean real operational dataset (authentic bookings, client heads, suppliers with carry-forwards, and default ledger). Purges corrupted entries and zombie records from Firestore Cloud DB."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3.5 space-y-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-emerald-300",
							children: "Why use this if you experienced data corruption or accidental deletions:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc pl-4 space-y-1 text-muted-foreground text-[11px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Suppliers Carry-Forwards:" }), " Restores opening payables and paid balances for Sky Wings, Noor, Fast Visa, etc., so statements are 100% accurate."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "ID Collision Immunity:" }), " Automatic monotonic counter recalculation ensures new entries never reuse existing IDs."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Cloud DB Purge:" }), " When choosing “Restore & Overwrite Cloud DB”, Firestore is purged of orphaned documents that caused pull errors."] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2.5 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							disabled: restoringBaseline,
							onClick: async () => {
								if (!confirm("This will restore the verified clean data baseline locally. An Undo button will be available in case you wish to revert. Continue?")) return;
								try {
									setRestoringBaseline(true);
									await store.restoreCleanBaseline(false);
									toast.success("Clean baseline restored locally! All supplier statements and balances re-indexed.");
								} catch (err) {
									toast.error(err instanceof Error ? err.message : "Restore failed");
								} finally {
									setRestoringBaseline(false);
								}
							},
							className: "gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: `h-3.5 w-3.5 ${restoringBaseline ? "animate-spin" : ""}` }), "Restore Clean Data Locally"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							disabled: restoringBaseline || store.cloudSyncStatus === "syncing",
							onClick: async () => {
								if (!user) {
									toast.error("Please connect your Google Account first in the Cloud Database section above.");
									return;
								}
								if (!confirm("WARNING: This will restore the verified clean baseline locally AND permanently overwrite Firestore Cloud DB (purging all corrupted entries, orphan records, and mismatched supplier figures). Both phone and desktop will now sync to the clean data.\n\nAre you sure you want to proceed?")) return;
								try {
									setRestoringBaseline(true);
									toast.loading("Restoring baseline and cleaning Firestore Cloud DB...", { id: "clean-cloud-toast" });
									await store.restoreCleanBaseline(true);
									toast.success("Success! Clean data restored and Cloud DB completely purged of errors.", { id: "clean-cloud-toast" });
								} catch (err) {
									toast.error(err instanceof Error ? err.message : "Cloud restore failed", { id: "clean-cloud-toast" });
								} finally {
									setRestoringBaseline(false);
								}
							},
							className: "gap-2 text-xs bg-emerald-600 hover:bg-emerald-500 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), "Restore & Overwrite Cloud DB (Purge Errors)"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .2 },
				className: "glass-card rounded-xl p-6 border-destructive/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 border-b border-border/50 pb-4 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-5 w-5 text-destructive" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-destructive",
						children: "Danger Zone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Use these only when starting fresh. Mock / sample data lingering in the system can be wiped here."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => wipeAll(true),
						variant: "outline",
						className: "gap-2 border-warning/40 text-warning hover:bg-warning/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-4 w-4" }), " Clear all operational data (keep opening balances)"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => wipeAll(false),
						variant: "destructive",
						className: "gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-4 w-4" }), " Wipe everything (full reset)"]
					})]
				})]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded bg-background/50 px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-foreground",
			children: value
		})]
	});
}
export { SettingsPage as component };
