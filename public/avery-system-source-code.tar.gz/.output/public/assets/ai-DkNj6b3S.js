import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { O as toast, T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime } from "./store-DLjJF6C7.js";
import { t as Check } from "./check-CgDXgYNO.js";
import { t as ChevronRight } from "./chevron-right-C7dOGd2P.js";
import { t as Compass } from "./compass-CDUpyvlR.js";
import { n as Copy, t as Textarea } from "./textarea-MZb_Jg8r.js";
import { t as TrendingUp } from "./trending-up-CdHn1ffe.js";
import { S as TSS_SERVER_FUNCTION_FACTORY, a as Sparkles, b as parseRedirect, c as RefreshCw, g as createLucideIcon, p as Database, v as createClientRpc, x as getStartOptions, y as isRedirect } from "./index-BgfHyeon.js";
import { n as PageHeader } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
// node_modules/cookie-es/dist/index.mjs
function splitSetCookieString(cookiesString) {
	if (Array.isArray(cookiesString)) return cookiesString.flatMap((c) => splitSetCookieString(c));
	if (typeof cookiesString !== "string") return [];
	const cookiesStrings = [];
	let pos = 0;
	let start;
	let ch;
	let lastComma;
	let nextStart;
	let cookiesSeparatorFound;
	const skipWhitespace = () => {
		while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) pos += 1;
		return pos < cookiesString.length;
	};
	const notSpecialChar = () => {
		ch = cookiesString.charAt(pos);
		return ch !== "=" && ch !== ";" && ch !== ",";
	};
	while (pos < cookiesString.length) {
		start = pos;
		cookiesSeparatorFound = false;
		while (skipWhitespace()) {
			ch = cookiesString.charAt(pos);
			if (ch === ",") {
				lastComma = pos;
				pos += 1;
				skipWhitespace();
				nextStart = pos;
				while (pos < cookiesString.length && notSpecialChar()) pos += 1;
				if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
					cookiesSeparatorFound = true;
					pos = nextStart;
					cookiesStrings.push(cookiesString.slice(start, lastComma));
					start = pos;
				} else pos = lastComma + 1;
			} else pos += 1;
		}
		if (!cookiesSeparatorFound || pos >= cookiesString.length) cookiesStrings.push(cookiesString.slice(start));
	}
	return cookiesStrings;
}
// node_modules/@tanstack/router-core/dist/esm/ssr/headers.js
function toHeadersInstance(init) {
	if (init instanceof Headers) return init;
	else if (Array.isArray(init)) return new Headers(init);
	else if (typeof init === "object") return new Headers(init);
	else return null;
}
function mergeHeaders(...headers) {
	return headers.reduce((acc, header) => {
		const headersInstance = toHeadersInstance(header);
		if (!headersInstance) return acc;
		for (const [key, value] of headersInstance.entries()) if (key === "set-cookie") splitSetCookieString(value).forEach((cookie) => acc.append("set-cookie", cookie));
		else acc.set(key, value);
		return acc;
	}, new Headers());
}
// node_modules/lucide-react/dist/esm/icons/bot.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$3 = {
	name: "bot",
	size: 24,
	node: [
		["path", {
			d: "M12 8V4H8",
			key: "hb8ula"
		}],
		["rect", {
			width: "16",
			height: "12",
			x: "4",
			y: "8",
			rx: "2",
			key: "enze0r"
		}],
		["path", {
			d: "M2 14h2",
			key: "vft8re"
		}],
		["path", {
			d: "M20 14h2",
			key: "4cs60a"
		}],
		["path", {
			d: "M15 13v2",
			key: "1xurst"
		}],
		["path", {
			d: "M9 13v2",
			key: "rq6x2g"
		}]
	]
};
__iconData$3.node;
var Bot = createLucideIcon(__iconData$3);
// node_modules/lucide-react/dist/esm/icons/message-square.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$2 = {
	name: "message-square",
	size: 24,
	node: [["path", {
		d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
		key: "18887p"
	}]]
};
__iconData$2.node;
var MessageSquare = createLucideIcon(__iconData$2);
// node_modules/lucide-react/dist/esm/icons/send.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$1 = {
	name: "send",
	size: 24,
	node: [["path", {
		d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
		key: "1ffxy3"
	}], ["path", {
		d: "m21.854 2.147-10.94 10.939",
		key: "12cjpa"
	}]]
};
__iconData$1.node;
var Send = createLucideIcon(__iconData$1);
// node_modules/lucide-react/dist/esm/icons/sliders-horizontal.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "sliders-horizontal",
	size: 24,
	node: [
		["path", {
			d: "M10 5H3",
			key: "1qgfaw"
		}],
		["path", {
			d: "M12 19H3",
			key: "yhmn1j"
		}],
		["path", {
			d: "M14 3v4",
			key: "1sua03"
		}],
		["path", {
			d: "M16 17v4",
			key: "1q0r14"
		}],
		["path", {
			d: "M21 12h-9",
			key: "1o4lsq"
		}],
		["path", {
			d: "M21 19h-5",
			key: "1rlt1p"
		}],
		["path", {
			d: "M21 5h-7",
			key: "1oszz2"
		}],
		["path", {
			d: "M8 10v4",
			key: "tgpxqk"
		}],
		["path", {
			d: "M8 12H3",
			key: "a7s4jb"
		}]
	]
};
__iconData.node;
var SlidersHorizontal = createLucideIcon(__iconData);
// node_modules/@tanstack/start-client-core/dist/esm/safeObjectMerge.js
function isSafeKey(key) {
	return key !== "__proto__" && key !== "constructor" && key !== "prototype";
}
/**
* Merge target and source into a new null-proto object, filtering dangerous keys.
*/
function safeObjectMerge(target, source) {
	const result = Object.create(null);
	if (target) {
		const keys = Object.keys(target);
		for (let i = 0; i < keys.length; i++) {
			const key = keys[i];
			if (isSafeKey(key)) result[key] = target[key];
		}
	}
	if (source && typeof source === "object") {
		const keys = Object.keys(source);
		for (let i = 0; i < keys.length; i++) {
			const key = keys[i];
			if (isSafeKey(key)) result[key] = source[key];
		}
	}
	return result;
}
/**
* Create a null-prototype object, optionally copying from source.
*/
function createNullProtoObject(source) {
	return source ? safeObjectMerge(source, void 0) : Object.create(null);
}
// node_modules/@tanstack/start-client-core/dist/esm/getStartContextServerOnly.js
var getStartContextServerOnly = () => {
	throw new Error("createServerOnlyFn() functions can only be called on the server!");
};
// node_modules/@tanstack/start-client-core/dist/esm/createServerFn.js
var createServerFn = (options, __opts) => {
	const resolvedOptions = __opts || options || {};
	if (typeof resolvedOptions.method === "undefined") resolvedOptions.method = "GET";
	const res = {
		options: resolvedOptions,
		middleware: (middleware) => {
			const newMiddleware = [...resolvedOptions.middleware || []];
			middleware.forEach((item) => {
				if (TSS_SERVER_FUNCTION_FACTORY in item) {
					if (item.options.middleware) newMiddleware.push(...item.options.middleware);
				} else newMiddleware.push(item);
			});
			const res = createServerFn(void 0, {
				...resolvedOptions,
				middleware: newMiddleware
			});
			res[TSS_SERVER_FUNCTION_FACTORY] = true;
			return res;
		},
		validator: (validator) => {
			return createServerFn(void 0, {
				...resolvedOptions,
				validator
			});
		},
		handler: (...args) => {
			const [extractedFn, serverFn] = args;
			const newOptions = {
				...resolvedOptions,
				extractedFn,
				serverFn
			};
			const resolvedMiddleware = [...newOptions.middleware || [], serverFnBaseToMiddleware(newOptions)];
			extractedFn.method = resolvedOptions.method;
			return Object.assign(async (opts) => {
				const result = await executeMiddleware(resolvedMiddleware, "client", {
					...extractedFn,
					...newOptions,
					data: opts?.data,
					headers: opts?.headers,
					signal: opts?.signal,
					fetch: opts?.fetch,
					context: createNullProtoObject()
				});
				if ("error" in result) throw parseRedirect(result.error) ?? result.error;
				return result.result;
			}, {
				...extractedFn,
				method: resolvedOptions.method,
				__executeServer: void 0
			});
		}
	};
	const fun = (options) => {
		return createServerFn(void 0, {
			...resolvedOptions,
			...options
		});
	};
	return Object.assign(fun, res);
};
function mergeOptionalSendContext(target, source) {
	return target === void 0 && source === void 0 ? void 0 : safeObjectMerge(target, source);
}
function mergeOptionalHeaders(target, source) {
	return target || source ? mergeHeaders(target, source) : void 0;
}
async function executeMiddleware(middlewares, env, opts) {
	const flattenedMiddlewares = flattenMiddlewares((getStartOptions()?.functionMiddleware || []).concat(middlewares), void 0, env === "server" ? new Set(getStartContextServerOnly({ throwIfNotFound: false })?.executedRequestMiddlewares) : void 0);
	let index = 0;
	const callNextMiddleware = async (callerCtx, userCtx) => {
		let ctx = callerCtx;
		if (userCtx !== void 0) {
			ctx = {
				...callerCtx,
				...userCtx
			};
			ctx.context = safeObjectMerge(callerCtx.context, userCtx.context);
			ctx.sendContext = mergeOptionalSendContext(callerCtx.sendContext, userCtx.sendContext);
			ctx.headers = mergeOptionalHeaders(callerCtx.headers, userCtx.headers);
			ctx._callSiteFetch = callerCtx._callSiteFetch;
			ctx.fetch = callerCtx._callSiteFetch ?? userCtx.fetch ?? callerCtx.fetch;
			ctx.result = userCtx.result !== void 0 ? userCtx.result : userCtx instanceof Response ? userCtx : callerCtx.result;
		}
		let result = ctx;
		while (index < flattenedMiddlewares.length) {
			const options = flattenedMiddlewares[index++].options;
			const validator = options.validator;
			if (validator && env === "server") ctx.data = await execValidator(validator, ctx.data);
			const middlewareFn = env === "client" ? options.client : options.server;
			if (middlewareFn) {
				result = await middlewareFn({
					...ctx,
					next: (nextCtx = {}) => callNextMiddleware(ctx, nextCtx)
				});
				if (result instanceof Response) {
					if (isRedirect(result)) throw result;
					result = {
						...ctx,
						result
					};
				} else if (!result) throw new Error("User middleware returned undefined. You must call next() or return a result in your middlewares.");
				break;
			}
		}
		if ("error" in result) throw result.error;
		return result;
	};
	const initialCtx = {
		...opts,
		headers: opts.headers || (env === "client" ? {} : void 0),
		sendContext: opts.sendContext,
		context: opts.context || createNullProtoObject(),
		_callSiteFetch: opts.fetch
	};
	if (initialCtx.sendContext !== void 0) initialCtx.sendContext ||= {};
	try {
		return await callNextMiddleware(initialCtx);
	} catch (error) {
		return {
			...initialCtx,
			error
		};
	}
}
function flattenMiddlewares(middlewares, maxDepth = 100, seen = /* @__PURE__ */ new Set()) {
	const flattened = [];
	const recurse = (middleware, depth) => {
		if (depth > maxDepth) throw new Error(`Middleware nesting depth exceeded maximum of ${maxDepth}. Check for circular references.`);
		middleware.forEach((m) => {
			if (m.options.middleware) recurse(m.options.middleware, depth + 1);
			if (!seen.has(m)) {
				seen.add(m);
				flattened.push(m);
			}
		});
	};
	recurse(middlewares, 0);
	return flattened;
}
async function execValidator(validator, input) {
	if (validator == null) return {};
	if ("~standard" in validator) {
		const result = await validator["~standard"].validate(input);
		if (result.issues) throw new Error(JSON.stringify(result.issues, void 0, 2));
		return result.value;
	}
	if ("parse" in validator) return validator.parse(input);
	if (typeof validator === "function") return validator(input);
	throw new Error("Invalid validator type!");
}
function serverFnBaseToMiddleware(options) {
	return {
		"~types": void 0,
		options: {
			validator: options.validator,
			client: async ({ next, sendContext, fetch, ...ctx }) => {
				const payload = {
					...ctx,
					context: sendContext,
					fetch
				};
				return next(await options.extractedFn?.(payload));
			},
			server: void 0
		}
	};
}
// src/lib/ai.server.ts
var import_react = /* @__PURE__ */ __toESM(require_react());
var runOmniAIRoute = createServerFn({ method: "POST" }).handler(createClientRpc("f07e9bd9f5c8d55bc7ca2af8f80a92f901eda385f0a90d58f811158f5d6df047"));
// src/routes/ai.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
var MODES = [
	{
		id: "crm_assistant",
		label: "CRM Copilot",
		icon: Bot,
		desc: "Ask queries about your bookings, agents, revenue, and daily operations"
	},
	{
		id: "itinerary_generator",
		label: "Itinerary Builder",
		icon: Compass,
		desc: "Generate professional day-by-day Umrah, Hajj & Tour travel packages"
	},
	{
		id: "profit_advisor",
		label: "Profit Advisor",
		icon: TrendingUp,
		desc: "Analyze profit margins, supplier cost efficiency & cash flow strategy"
	},
	{
		id: "client_message_drafter",
		label: "Client Messaging",
		icon: MessageSquare,
		desc: "Draft personalized WhatsApp/SMS alerts in English & Roman Urdu"
	}
];
var QUICK_PROMPTS = {
	crm_assistant: [
		"Give me an executive summary of our active bookings and overall business health.",
		"Which agent has brought the most revenue and what is their commission?",
		"Review our outstanding client balances and suggest immediate collection priorities.",
		"Summarize all pending travel dates scheduled for the upcoming 30 days."
	],
	itinerary_generator: [
		"Create a 15-day VIP Umrah itinerary with 5 nights in Makkah (Clock Tower) and 5 nights in Madinah (Dar Al Taqwa). Include Ziyarat points.",
		"Draft a 10-day Economy Umrah itinerary for a family of 4 with private transport between Jeddah, Makkah, and Madinah.",
		"Design a 7-day Northern Pakistan Tour itinerary (Hunza, Skardu, Attabad Lake) with hotels and meal plans.",
		"Generate a 21-day Standard Hajj package schedule with Aziziya shifting and Mina/Arafat guidance."
	],
	profit_advisor: [
		"Analyze our package revenue vs supplier purchase costs and suggest margin improvements.",
		"How should we price our upcoming Ramadan Umrah packages to maximize gross margins?",
		"Evaluate our supplier payables and suggest an optimal payment schedule to preserve cash on hand.",
		"What strategies can help increase our booking ticket size and client retention?"
	],
	client_message_drafter: [
		"Draft a polite WhatsApp payment reminder for a client whose remaining balance of Rs 150,000 is overdue before travel.",
		"Draft an official booking confirmation message with flight details and hotel check-in instructions in Urdu & English.",
		"Create a welcome message wishing a blessed journey to an Umrah family departing tomorrow.",
		"Draft a notification informing a client that their Saudi Umrah eVisa has been successfully issued."
	]
};
function OmniAIPage() {
	const store = useStore();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [activeMode, setActiveMode] = (0, import_react.useState)("crm_assistant");
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [includeContext, setIncludeContext] = (0, import_react.useState)(true);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [response, setResponse] = (0, import_react.useState)(null);
	const [responseModel, setResponseModel] = (0, import_react.useState)("gemini-3.8-flash");
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const crmSnapshot = (0, import_react.useMemo)(() => {
		const totalRev = store.bookings.reduce((s, b) => s + (b.amountReceived || 0), 0) + (store.opening.revenue || 0);
		const totalPurchases = store.entries.filter((e) => e.type === "purchase").reduce((s, e) => s + e.amount, 0);
		const totalExpenses = store.entries.filter((e) => e.type === "expense").reduce((s, e) => s + e.amount, 0);
		const totalProfit = totalRev - totalPurchases - totalExpenses + (store.opening.profit || 0);
		const supplierDue = store.suppliers.reduce((s, sp) => s + Math.max(0, (sp.totalPayable || 0) - (sp.totalPaid || 0)), 0);
		return {
			totalRevenue: totalRev,
			totalProfit,
			totalBookings: store.bookings.length,
			totalClients: store.clients.length,
			supplierDue,
			recentBookings: store.bookings.slice(0, 5).map((b) => ({
				headId: b.headId,
				packageType: b.packageType,
				amount: b.totalAmount,
				status: b.status
			})),
			topAgents: store.agents.slice(0, 5).map((a) => ({
				name: a.name,
				clients: a.totalClients,
				sales: a.totalSales
			}))
		};
	}, [
		store.bookings,
		store.clients,
		store.suppliers,
		store.entries,
		store.agents,
		store.opening
	]);
	const handleSend = async (customPrompt) => {
		const textToSend = (customPrompt || prompt).trim();
		if (!textToSend) {
			toast.info("Please enter a prompt or pick a quick suggestion");
			return;
		}
		setLoading(true);
		setResponse(null);
		try {
			const res = await runOmniAIRoute({ data: {
				mode: activeMode,
				prompt: textToSend,
				crmSnapshot: includeContext ? crmSnapshot : void 0
			} });
			if (res.success && res.content) {
				setResponse(res.content);
				setResponseModel(res.model || "gemini-3.8-flash");
				toast.success("AI response generated");
			} else {
				toast.error(res.error || "Failed to generate response");
				setResponse(`Error: ${res.error || "Could not retrieve response from Gemini API"}`);
			}
		} catch (e) {
			const msg = e instanceof Error ? e.message : "Error communicating with Omni AI server";
			toast.error(msg);
			setResponse(`Error: ${msg}`);
		} finally {
			setLoading(false);
		}
	};
	const handleCopy = () => {
		if (!response) return;
		navigator.clipboard.writeText(response);
		setCopied(true);
		toast.success("Copied to clipboard");
		setTimeout(() => setCopied(false), 2e3);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Omni AI Assistant",
				subtitle: "Executive AI Co-pilot & Itinerary Generator powered by Gemini 3.8 Flash",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Omni Router · Gemini 3.8 Flash" })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: MODES.map((m) => {
					const Icon = m.icon;
					const isSelected = activeMode === m.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setActiveMode(m.id);
							setResponse(null);
						},
						className: `flex flex-col text-left rounded-xl p-4 border transition-all ${isSelected ? "border-primary bg-primary/10 shadow-sm" : "border-border/60 bg-card/60 hover:border-border hover:bg-card/90"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-2 rounded-lg ${isSelected ? "bg-primary text-primary-foreground" : "bg-accent/40 text-foreground"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-sm text-foreground",
								children: m.label
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground line-clamp-2",
							children: m.desc
						})]
					}, m.id);
				})
			}),
			mounted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-border/60 bg-accent/15 p-4 text-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "h-4 w-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: "Live CRM Context Feed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "The Omni Router seamlessly injects real-time agency metrics into prompts for accurate answers."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-3 font-mono text-[11px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["Rev: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: formatCurrency(crmSnapshot.totalRevenue)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["Profit: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-success",
										children: formatCurrency(crmSnapshot.totalProfit)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["Bookings: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: crmSnapshot.totalBookings
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5 cursor-pointer select-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: includeContext,
								onChange: (e) => setIncludeContext(e.target.checked),
								className: "rounded border-input text-primary focus:ring-primary h-3.5 w-3.5"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground",
								children: "Include Context"
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-sm font-semibold flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4 text-primary" }), "Prompt & Request"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground font-mono",
									children: MODES.find((m) => m.id === activeMode)?.label
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: prompt,
								onChange: (e) => setPrompt(e.target.value),
								placeholder: `Type your instructions in English, Urdu, or Roman Urdu...\ne.g. "${QUICK_PROMPTS[activeMode][0]}"`,
								rows: 5,
								className: "resize-none text-sm bg-background/60"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => {
										setPrompt("");
										setResponse(null);
									},
									className: "text-xs text-muted-foreground h-8",
									children: "Clear"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => handleSend(),
									disabled: loading || !prompt.trim(),
									size: "sm",
									className: "gap-2 text-xs h-8",
									children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3.5 w-3.5 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Processing..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ask Omni AI" })] })
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
							children: [
								"Suggested ",
								MODES.find((m) => m.id === activeMode)?.label,
								" Prompts"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: QUICK_PROMPTS[activeMode].map((qp, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									setPrompt(qp);
									handleSend(qp);
								},
								disabled: loading,
								className: "group flex w-full items-start gap-2 rounded-lg border border-border/50 bg-accent/10 p-2.5 text-left text-xs transition-colors hover:border-primary/40 hover:bg-primary/5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 text-muted-foreground group-hover:text-primary shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground/90 group-hover:text-foreground",
									children: qp
								})]
							}, idx))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-6 min-h-[460px] flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-border/50 pb-4 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm font-semibold",
									children: "Executive AI Response"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-muted-foreground font-mono",
									children: [
										"Model: ",
										responseModel,
										" · Latency: Low"
									]
								})] })]
							}), response && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: handleCopy,
								className: "gap-1.5 text-xs h-8",
								children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-emerald-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copied ? "Copied" : "Copy" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 flex flex-col justify-start",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-8 w-8 animate-spin text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-foreground",
									children: "Omni AI is thinking..."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Routing through Gemini 3.8 Flash with live CRM context"
								})] })]
							}) : response ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "prose prose-sm dark:prose-invert max-w-none text-foreground text-xs leading-relaxed whitespace-pre-wrap font-sans bg-accent/5 p-4 rounded-lg border border-border/40 overflow-y-auto max-h-[600px]",
								children: response
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 flex flex-col items-center justify-center p-8 text-center text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "h-10 w-10 text-muted-foreground/40 mb-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-foreground",
										children: "Omni AI Assistant Ready"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs max-w-md mt-1",
										children: "Select a suggested prompt from the left or type any custom request. Your assistant has direct access to live bookings, package details, and financial ledgers."
									})
								]
							})
						})]
					})
				})]
			})
		]
	});
}
export { OmniAIPage as component };
