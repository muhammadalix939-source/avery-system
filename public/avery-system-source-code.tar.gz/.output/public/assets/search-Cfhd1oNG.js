import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { E as getClientName, T as formatCurrency, _ as getChecklist, a as useStore, g as checklistProgress, j as require_react, k as require_jsx_runtime } from "./store-DLjJF6C7.js";
import { t as DetailDialog } from "./DetailDialog-BQz-pf5v.js";
import { i as urgencyLabel, n as computeUrgency, t as computeGroupStats } from "./groups-6NvV7uvi.js";
import { s as Search } from "./index-BgfHyeon.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as StatusBadge } from "./StatusBadge-6vwJ3trL.js";
import { t as ChecklistBadge } from "./ChecklistBadge-DEB0WH27.js";
// src/routes/search.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var typeColors = {
	booking: "bg-primary/10 text-primary",
	client: "bg-success/10 text-success",
	agent: "bg-warning/10 text-warning",
	supplier: "bg-chart-3/10 text-chart-3",
	group: "bg-primary/10 text-primary"
};
function SearchPage() {
	const store = useStore();
	const [query, setQuery] = (0, import_react.useState)("");
	const [debounced, setDebounced] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setDebounced(query), 120);
		return () => clearTimeout(t);
	}, [query]);
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("all");
	const [detailOpen, setDetailOpen] = (0, import_react.useState)(false);
	const [selectedType, setSelectedType] = (0, import_react.useState)("client");
	const [selectedData, setSelectedData] = (0, import_react.useState)(null);
	const results = (0, import_react.useMemo)(() => searchAll(debounced, store), [debounced, store]);
	const filtered = (0, import_react.useMemo)(() => typeFilter === "all" ? results : results.filter((r) => r.type === typeFilter), [results, typeFilter]);
	function handleClick(r) {
		setSelectedType(r.type === "group" ? "booking" : r.type);
		setSelectedData(r.raw);
		setDetailOpen(true);
	}
	const relatedEntries = selectedData && "id" in selectedData ? store.entries.filter((e) => e.referenceId === selectedData.id || e.headId === selectedData.headId) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Search",
				subtitle: "Find any record — click for full details"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Search by Head ID, Client ID, Name, Phone, Agent, Supplier...",
					value: query,
					onChange: (e) => setQuery(e.target.value),
					className: "h-12 bg-accent/20 pl-12 text-base border-border"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"all",
					"booking",
					"client",
					"agent",
					"supplier",
					"group"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTypeFilter(t),
					className: `rounded-lg px-4 py-2 text-xs font-medium capitalize transition-all ${typeFilter === t ? "bg-primary text-primary-foreground" : "bg-accent/30 text-muted-foreground hover:bg-accent/50"}`,
					children: t === "all" ? "All" : `${t}s`
				}, t))
			}),
			query && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [filtered.length, " results found"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: filtered.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: i * .03 },
					onClick: () => handleClick(r),
					className: "glass-card glass-card-hover flex items-center justify-between rounded-xl px-5 py-4 transition-all duration-200 cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `rounded-md px-2 py-1 text-[10px] font-semibold uppercase ${typeColors[r.type]}`,
							children: r.type
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: r.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: r.subtitle
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							r.client && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChecklistBadge, {
								client: r.client,
								compact: true
							}),
							r.extra && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-primary",
								children: r.extra
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: r.status })
						]
					})]
				}, `${r.type}-${r.id}`))
			}),
			query && filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center py-16 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mb-3 h-12 w-12 text-muted-foreground/30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"No results found for \"",
						query,
						"\""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailDialog, {
				open: detailOpen,
				onOpenChange: setDetailOpen,
				type: selectedType,
				data: selectedData,
				entries: relatedEntries,
				allClients: store.clients,
				allBookings: store.bookings
			})
		]
	});
}
function searchAll(query, store) {
	const q = query.toLowerCase().trim();
	if (!q) return [];
	const results = [];
	store.bookings.forEach((b) => {
		if (b.headId.toLowerCase().includes(q) || b.agentId.toLowerCase().includes(q) || b.supplierId.toLowerCase().includes(q)) results.push({
			type: "booking",
			id: b.headId,
			title: b.headId,
			subtitle: `${b.packageType} · ${b.clientIds.length} clients · ${b.travelDate}`,
			status: b.status,
			extra: formatCurrency(b.totalAmount),
			raw: b
		});
	});
	store.clients.forEach((c) => {
		const fullName = getClientName(c).toLowerCase();
		const checklistText = getChecklist(c).map((i) => `${i.label} ${i.status}`).join(" ").toLowerCase();
		const progress = checklistProgress(c);
		const alertText = `${progress.isComplete ? "completed services" : "pending services"} ${progress.label}`;
		if (c.id.toLowerCase().includes(q) || fullName.includes(q) || c.phone.includes(q) || c.passport.toLowerCase().includes(q) || checklistText.includes(q) || alertText.includes(q)) results.push({
			type: "client",
			id: c.id,
			title: getClientName(c),
			subtitle: `${c.id} · ${c.headId} · ${c.passport}`,
			status: c.paymentStatus,
			extra: formatCurrency(c.amountPaid),
			raw: c,
			client: c
		});
	});
	store.agents.forEach((a) => {
		if (a.id.toLowerCase().includes(q) || a.name.toLowerCase().includes(q) || a.phone.includes(q)) results.push({
			type: "agent",
			id: a.id,
			title: a.name,
			subtitle: `${a.id} · ${a.totalClients} clients`,
			status: a.status,
			extra: formatCurrency(a.totalSales),
			raw: a
		});
	});
	store.suppliers.forEach((s) => {
		if (s.id.toLowerCase().includes(q) || s.companyName.toLowerCase().includes(q) || s.phone.includes(q)) {
			const remaining = s.totalPayable - s.totalPaid;
			results.push({
				type: "supplier",
				id: s.id,
				title: s.companyName,
				subtitle: `${s.id} · ${s.serviceType}`,
				status: remaining === 0 ? "Paid" : "Partial",
				extra: formatCurrency(remaining),
				raw: s
			});
		}
	});
	store.groups.forEach((g) => {
		const stats = computeGroupStats(g, store);
		const u = computeUrgency(stats);
		if ([
			g.id,
			g.name,
			g.pnr,
			g.flightNumber,
			g.category,
			g.date,
			u.isFull ? "full closed" : "active open"
		].filter(Boolean).join(" ").toLowerCase().includes(q)) results.push({
			type: "group",
			id: g.id,
			title: g.name,
			subtitle: `${g.id} · ${g.category} · ${g.date || "no date"} · ${u.capacity > 0 ? `${u.remainingSeats}/${u.capacity} seats left` : `${stats.usedPax} pax`} · ${u.reason}`,
			status: u.isFull ? "Inactive" : "Active",
			extra: urgencyLabel[u.level],
			raw: stats.heads[0]?.booking ?? { headId: g.id }
		});
	});
	return results;
}
export { SearchPage as component };
