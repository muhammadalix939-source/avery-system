import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime, m as getPKTDate } from "./store-DLjJF6C7.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-51KhIokW.js";
import { t as Download } from "./download-CEfpC1QR.js";
import { t as Pencil } from "./pencil-B3wEbWek.js";
import { t as Plus } from "./plus-DpXfoyfH.js";
import { t as Trash } from "./trash-YMvfXcpp.js";
import { g as createLucideIcon, l as Receipt, r as Wallet } from "./index-BgfHyeon.js";
import { s as generatePaymentReceipt } from "./pdf-S7DRzVmW.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as Label } from "./label-C_GFC7te.js";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-Bb6Qejxv.js";
// node_modules/lucide-react/dist/esm/icons/trending-down.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "trending-down",
	size: 24,
	node: [["path", {
		d: "M16 17h6v-6",
		key: "t6n2it"
	}], ["path", {
		d: "m22 17-8.5-8.5-5 5L2 7",
		key: "x473p"
	}]]
};
__iconData.node;
var TrendingDown = createLucideIcon(__iconData);
// src/routes/expenses.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	"Office Rent",
	"Utilities",
	"Salaries",
	"Marketing",
	"Stationery",
	"Travel",
	"Meals",
	"Software / Subscriptions",
	"Maintenance",
	"Bank Charges",
	"Other"
];
function ExpensesPage() {
	const store = useStore();
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [search, setSearch] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("All");
	const [form, setForm] = (0, import_react.useState)({
		date: "",
		category: "Office Rent",
		referenceName: "",
		amount: "",
		note: "",
		groupId: ""
	});
	const expenses = (0, import_react.useMemo)(() => store.entries.filter((e) => e.type === "expense").sort((a, b) => b.date.localeCompare(a.date)), [store.entries]);
	const filtered = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		return expenses.filter((e) => {
			if (category !== "All" && (e.headId || "Other") !== category) return false;
			if (!q) return true;
			return (e.referenceName + " " + e.note + " " + e.id).toLowerCase().includes(q);
		});
	}, [
		expenses,
		search,
		category
	]);
	const total = (0, import_react.useMemo)(() => filtered.reduce((s, e) => s + e.amount, 0), [filtered]);
	const monthTotal = (0, import_react.useMemo)(() => {
		const m = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
		return expenses.filter((e) => e.date.startsWith(m)).reduce((s, e) => s + e.amount, 0);
	}, [expenses]);
	function handleAdd() {
		store.addEntry({
			date: form.date || getPKTDate(),
			type: "expense",
			headId: form.category,
			referenceId: "",
			referenceName: form.referenceName || form.category,
			amount: Number(form.amount) || 0,
			note: form.note,
			groupId: form.groupId || void 0
		});
		setForm({
			date: "",
			category: "Office Rent",
			referenceName: "",
			amount: "",
			note: "",
			groupId: ""
		});
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		store.updateEntry(selected.id, {
			date: form.date,
			headId: form.category,
			referenceName: form.referenceName,
			amount: Number(form.amount) || 0,
			note: form.note,
			groupId: form.groupId || void 0
		});
		setEditOpen(false);
	}
	function openEdit(e) {
		setSelected(e);
		setForm({
			date: e.date,
			category: e.headId || "Other",
			referenceName: e.referenceName,
			amount: String(e.amount),
			note: e.note,
			groupId: e.groupId || ""
		});
		setEditOpen(true);
	}
	const formFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Date"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: form.date,
					onChange: (e) => setForm({
						...form,
						date: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-9"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Category"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.category,
					onValueChange: (v) => setForm({
						...form,
						category: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-9 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: c,
						children: c
					}, c)) })]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Description"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.referenceName,
				onChange: (e) => setForm({
					...form,
					referenceName: e.target.value
				}),
				placeholder: "e.g. April Office Rent",
				className: "bg-accent/20 border-border mt-1 h-9"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Amount (PKR)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "number",
				value: form.amount,
				onChange: (e) => setForm({
					...form,
					amount: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-9"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Note"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.note,
				onChange: (e) => setForm({
					...form,
					note: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-9"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Tag to Group (optional)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.groupId || "none",
					onValueChange: (v) => setForm({
						...form,
						groupId: v === "none" ? "" : v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-9 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "No group" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "none",
						children: "No group (general expense)"
					}), store.groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
						value: g.id,
						children: [
							g.id,
							" — ",
							g.name
						]
					}, g.id))] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[10px] text-muted-foreground",
					children: "Group-tagged expenses (gifts, kits, hospitality) reduce that group's net profit."
				})
			] })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Expenses",
				subtitle: "Track every outflow professionally",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: setAddOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: () => setForm({
								date: getPKTDate(),
								category: "Office Rent",
								referenceName: "",
								amount: "",
								note: "",
								groupId: ""
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Expense"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add Expense" }) }),
							formFields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleAdd,
								className: "w-full",
								children: "Submit"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "glass-card rounded-xl p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "Total Records"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold",
								children: filtered.length
							})] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "glass-card rounded-xl p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-5 w-5 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "Filtered Total"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold text-destructive",
								children: formatCurrency(total)
							})] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "glass-card rounded-xl p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-5 w-5 text-warning" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "This Month"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold text-warning",
								children: formatCurrency(monthTotal)
							})] })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Search expenses...",
					value: search,
					onChange: (e) => setSearch(e.target.value),
					className: "w-64 bg-accent/20 border-border"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: category,
					onValueChange: setCategory,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-48 bg-accent/20 border-border text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "All",
						children: "All Categories"
					}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: c,
						children: c
					}, c))] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[60vh] overflow-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "sticky top-0 bg-card/95 backdrop-blur z-10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "ID"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Date"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Category"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Description"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Note"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-right",
											children: "Amount"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Actions"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filtered.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold text-primary",
										children: e.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: e.date
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-md bg-accent/30 px-2 py-1 text-[10px] font-semibold uppercase text-warning",
											children: e.headId || "Other"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-medium",
										children: e.referenceName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground text-xs max-w-[240px] truncate",
										children: e.note
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 text-right font-semibold text-destructive",
										children: ["- ", formatCurrency(e.amount)]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => generatePaymentReceipt(e),
													className: "rounded p-1 hover:bg-accent",
													title: "Receipt",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openEdit(e),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => store.deleteEntry(e.id),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
												})
											]
										})
									})
								]
							}, e.id)), filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "px-4 py-12 text-center text-muted-foreground text-sm",
								children: "No expenses match the filter."
							}) })] }),
							filtered.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
								className: "bg-accent/20",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 5,
										className: "px-4 py-3 text-right text-xs font-bold uppercase",
										children: "Total"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right font-bold text-destructive",
										children: formatCurrency(total)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {})
								] })
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Expense — ", selected?.id] }) }),
						formFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			})
		]
	});
}
export { ExpensesPage as component };
