// src/lib/allocations.ts
/**
* Split an integer total equally across count lines.
* Base = floor(total / count), remainder r = total - base * count.
* The FIRST r lines get +1.
* Sum is guaranteed to equal total for all integer totals and counts.
*/
function splitEqual(total, count) {
	if (count <= 0) return [];
	const safeTotal = Math.max(0, Math.round(Number(total) || 0));
	if (count === 1) return [safeTotal];
	const base = Math.floor(safeTotal / count);
	const remainder = safeTotal - base * count;
	const result = new Array(count);
	for (let i = 0; i < count; i++) result[i] = base + (i < remainder ? 1 : 0);
	return result;
}
/**
* Rebalances unlocked allocation lines equally so the total of all lines equals `total`.
* Locked lines maintain their current amounts.
*/
function rebalanceEqual(lines, total) {
	if (lines.length === 0) return [];
	const safeTotal = Math.max(0, Math.round(Number(total) || 0));
	const lockedSum = lines.filter((l) => l.locked).reduce((s, l) => s + (l.amount || 0), 0);
	const unlockedIndices = lines.map((l, i) => !l.locked ? i : -1).filter((i) => i !== -1);
	if (unlockedIndices.length === 0) return lines;
	const splits = splitEqual(Math.max(0, safeTotal - lockedSum), unlockedIndices.length);
	return lines.map((line, idx) => {
		if (line.locked) return line;
		const uPos = unlockedIndices.indexOf(idx);
		const newAmt = splits[uPos];
		const updated = {
			...line,
			amount: newAmt
		};
		if (line.target === "agent") updated.saleAmount = line.saleAmount !== void 0 ? line.saleAmount : newAmt;
		return updated;
	});
}
/**
* Manual helper: sets (total - sum of other lines) on the last unlocked line.
*/
function autoBalanceLast(lines, total) {
	if (lines.length === 0) return [];
	const safeTotal = Math.max(0, Math.round(Number(total) || 0));
	let targetIdx = -1;
	for (let i = lines.length - 1; i >= 0; i--) if (!lines[i].locked) {
		targetIdx = i;
		break;
	}
	if (targetIdx === -1) targetIdx = lines.length - 1;
	const otherSum = lines.reduce((s, l, i) => i === targetIdx ? s : s + (l.amount || 0), 0);
	const remainder = Math.max(0, safeTotal - otherSum);
	return lines.map((line, i) => {
		if (i !== targetIdx) return line;
		const updated = {
			...line,
			amount: remainder
		};
		if (line.target === "agent" && line.saleAmount === void 0) updated.saleAmount = remainder;
		return updated;
	});
}
/**
* Validates a cost allocation breakdown.
*/
function validateAllocations(lines, total, ctx) {
	const errors = [];
	const safeTotal = Math.round(Number(total) || 0);
	if (!lines || lines.length === 0) return {
		ok: false,
		errors: ["At least one allocation line is required"],
		remaining: safeTotal
	};
	const sum = lines.reduce((s, l) => s + (l.amount || 0), 0);
	const remaining = safeTotal - sum;
	if (remaining !== 0) errors.push(`Total allocated (${sum.toLocaleString()} PKR) does not match purchase amount (${safeTotal.toLocaleString()} PKR). Remaining: ${remaining.toLocaleString()} PKR`);
	const seenTargets = /* @__PURE__ */ new Set();
	lines.forEach((line, index) => {
		const lineNum = index + 1;
		if (!line.amount || line.amount <= 0 || !Number.isInteger(line.amount)) errors.push(`Line ${lineNum}: Amount must be a positive whole PKR integer.`);
		if (line.target === "head") {
			if (!line.headId) errors.push(`Line ${lineNum}: Please select a client Head.`);
			else if (!ctx.heads.has(line.headId)) errors.push(`Line ${lineNum}: Unknown client Head (${line.headId}).`);
			else if (line.clientId) {
				if (!ctx.membersOf(line.headId).has(line.clientId)) errors.push(`Line ${lineNum}: Client member ${line.clientId} does not belong to Head ${line.headId}.`);
			}
			const key = `head:${line.headId || ""}:${line.clientId || "ALL"}`;
			if (seenTargets.has(key)) errors.push(`Line ${lineNum}: Duplicate allocation for Head ${line.headId}${line.clientId ? ` (member ${line.clientId})` : ""}. Combine amounts instead.`);
			seenTargets.add(key);
		} else if (line.target === "agent") {
			if (!line.agentId) errors.push(`Line ${lineNum}: Please select an Agent.`);
			else if (!ctx.agents.has(line.agentId)) errors.push(`Line ${lineNum}: Unknown Agent (${line.agentId}).`);
			if (line.saleAmount !== void 0 && (line.saleAmount < 0 || !Number.isInteger(line.saleAmount))) errors.push(`Line ${lineNum}: Agent sale amount must be non-negative whole PKR.`);
			const key = `agent:${line.agentId || ""}`;
			if (seenTargets.has(key)) errors.push(`Line ${lineNum}: Duplicate allocation for Agent ${line.agentId}. Combine amounts instead.`);
			seenTargets.add(key);
		} else if (line.target === "office") {
			const key = "office";
			if (seenTargets.has(key)) errors.push(`Line ${lineNum}: Duplicate Office / Stock line. Combine amounts instead.`);
			seenTargets.add(key);
		} else errors.push(`Line ${lineNum}: Invalid allocation target "${line.target}".`);
	});
	return {
		ok: errors.length === 0,
		errors,
		remaining
	};
}
/**
* Pure Legacy Adapter for Purchase Cost Allocations.
* If e.allocations is present and non-empty, returns it.
* Otherwise synthesizes ONE line from legacy fields.
*/
function purchaseAllocations(e) {
	if (e.allocations && e.allocations.length > 0) return e.allocations;
	const amt = Number(e.amount) || 0;
	if (e.purchasedFor === "client" && e.headId) return [{
		id: "A1",
		target: "head",
		headId: e.headId,
		...e.clientId ? { clientId: e.clientId } : {},
		amount: amt
	}];
	if (e.purchasedFor === "agent" && e.agentId) return [{
		id: "A1",
		target: "agent",
		agentId: e.agentId,
		amount: amt,
		saleAmount: e.saleAmount ?? amt,
		...e.forClientName ? { forClientName: e.forClientName } : {}
	}];
	if (e.headId) return [{
		id: "A1",
		target: "head",
		headId: e.headId,
		...e.clientId ? { clientId: e.clientId } : {},
		amount: amt
	}];
	return [{
		id: "A1",
		target: "office",
		amount: amt
	}];
}
/**
* Computes total cost allocated to a specific client Head across all purchases.
*/
function headCostOf(entries, headId) {
	if (!headId) return 0;
	return entries.reduce((sum, e) => {
		if (e.type !== "purchase") return sum;
		return sum + purchaseAllocations(e).filter((l) => l.target === "head" && l.headId === headId).reduce((s, l) => s + (l.amount || 0), 0);
	}, 0);
}
/**
* Computes all Other Sale rows for an Agent (both purchase agent lines and direct other_sale entries).
*/
function agentOtherSaleRows(entries, agentId) {
	if (!agentId) return [];
	const rows = [];
	entries.forEach((e) => {
		if (e.type === "purchase") purchaseAllocations(e).forEach((line) => {
			if (line.target === "agent" && line.agentId === agentId) {
				const cost = line.amount || 0;
				const sale = line.saleAmount !== void 0 ? line.saleAmount : cost;
				rows.push({
					entry: e,
					line,
					sale,
					cost,
					profit: sale - cost
				});
			}
		});
		else if (e.type === "other_sale" && e.referenceId === agentId) {
			const sale = Number(e.amount) || 0;
			rows.push({
				entry: e,
				sale,
				cost: 0,
				profit: sale
			});
		}
	});
	return rows.sort((a, b) => (a.entry.date || "").localeCompare(b.entry.date || ""));
}
/**
* Pure Legacy Adapter for Supplier Payment Allocations.
*/
function paymentAllocations(e) {
	if (e.paymentAllocations && e.paymentAllocations.length > 0) return e.paymentAllocations;
	const amt = Number(e.amount) || 0;
	if (e.headId) return [{
		id: "P1",
		target: "head",
		headId: e.headId,
		amount: amt
	}];
	if (e.groupId) return [{
		id: "P1",
		target: "group",
		groupId: e.groupId,
		amount: amt
	}];
	if (e.agentId) return [{
		id: "P1",
		target: "agent",
		agentId: e.agentId,
		amount: amt
	}];
	return [{
		id: "P1",
		target: "unallocated",
		amount: amt
	}];
}
/**
* Computes supplier payments made on behalf of a specific Head:
*  1) Direct head allocations on supplier_payment entries
*  2) Group allocations prorated by this Head's share of the Group's allocated purchase bill
*/
function headSupplierPaid(entries, headId) {
	if (!headId) return 0;
	const paymentEntries = entries.filter((e) => e.type === "supplier_payment");
	const purchaseEntries = entries.filter((e) => e.type === "purchase");
	let directPaid = 0;
	const groupPaidMap = /* @__PURE__ */ new Map();
	paymentEntries.forEach((p) => {
		paymentAllocations(p).forEach((l) => {
			if (l.target === "head" && l.headId === headId) directPaid += l.amount || 0;
			else if (l.target === "group" && l.groupId) groupPaidMap.set(l.groupId, (groupPaidMap.get(l.groupId) || 0) + (l.amount || 0));
		});
	});
	let proratedPaid = 0;
	groupPaidMap.forEach((groupPaymentTotal, gid) => {
		const groupPurchases = purchaseEntries.filter((p) => p.groupId === gid);
		const groupBill = groupPurchases.reduce((s, p) => s + (p.amount || 0), 0);
		if (groupBill <= 0) return;
		const headCostInGroup = groupPurchases.reduce((sum, p) => {
			return sum + purchaseAllocations(p).filter((l) => l.target === "head" && l.headId === headId).reduce((s, l) => s + (l.amount || 0), 0);
		}, 0);
		if (headCostInGroup > 0) proratedPaid += groupPaymentTotal * (headCostInGroup / groupBill);
	});
	return Math.round(directPaid + proratedPaid);
}
export { paymentAllocations as a, splitEqual as c, headSupplierPaid as i, validateAllocations as l, autoBalanceLast as n, purchaseAllocations as o, headCostOf as r, rebalanceEqual as s, agentOtherSaleRows as t };
