import { k as require_jsx_runtime } from "./store-DLjJF6C7.js";
// src/components/StatusBadge.tsx
var import_jsx_runtime = require_jsx_runtime();
var statusStyles = {
	Paid: "bg-success/15 text-success border-success/20",
	Confirmed: "bg-success/15 text-success border-success/20",
	Active: "bg-success/15 text-success border-success/20",
	Partial: "bg-warning/15 text-warning border-warning/20",
	Pending: "bg-warning/15 text-warning border-warning/20",
	Unpaid: "bg-destructive/15 text-destructive border-destructive/20",
	Cancelled: "bg-destructive/15 text-destructive border-destructive/20",
	Inactive: "bg-muted text-muted-foreground border-border"
};
function StatusBadge({ status }) {
	const style = statusStyles[status] || "bg-muted text-muted-foreground border-border";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold ${style}`,
		children: status
	});
}
export { StatusBadge as t };
