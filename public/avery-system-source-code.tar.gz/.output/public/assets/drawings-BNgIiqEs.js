import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime } from "./store-DLjJF6C7.js";
import { n as PageHeader } from "./clsx-Cbd36OJ7.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as Label } from "./label-C_GFC7te.js";
import { t as computeTotals } from "./reports-Fx3YLxZs.js";
// src/routes/drawings.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DrawingsPage() {
	const store = useStore();
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [person, setPerson] = (0, import_react.useState)("all");
	const profitAt = (0, import_react.useMemo)(() => {
		const cache = /* @__PURE__ */ new Map();
		return (date) => {
			if (cache.has(date)) return cache.get(date);
			const bookings = store.bookings.filter((b) => (b.createdAt || b.travelDate || "").slice(0, 10) <= date);
			const entries = store.entries.filter((e) => e.date <= date);
			const v = computeTotals({
				bookings,
				clients: store.clients,
				agents: store.agents,
				suppliers: store.suppliers,
				entries,
				opening: store.opening
			}).netProfit;
			cache.set(date, v);
			return v;
		};
	}, [
		store.bookings,
		store.entries,
		store.clients,
		store.agents,
		store.suppliers,
		store.opening
	]);
	const all = store.entries.filter((e) => e.type === "drawing").sort((a, b) => a.date.localeCompare(b.date));
	const people = [...new Set(all.map((e) => e.referenceName || "Owner"))];
	const rows = all.filter((e) => (!from || e.date >= from) && (!to || e.date <= to) && (person === "all" || (e.referenceName || "Owner") === person));
	const profitNow = computeTotals({
		bookings: store.bookings,
		clients: store.clients,
		agents: store.agents,
		suppliers: store.suppliers,
		entries: store.entries,
		opening: store.opening
	}).netProfit;
	const totalDrawn = all.reduce((s, e) => s + e.amount, 0);
	const periodDrawn = rows.reduce((s, e) => s + e.amount, 0);
	const retained = profitNow - totalDrawn;
	let cumulative = 0;
	const withRunning = all.map((e) => {
		cumulative += e.amount;
		return {
			e,
			cum: cumulative
		};
	});
	const runOf = new Map(withRunning.map((r) => [r.e.id, r.cum]));
	const card = (label, value, tone, hint) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-card rounded-xl p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-1 text-xl font-bold ${tone}`,
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] text-muted-foreground",
				children: hint
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Owner Drawings",
				subtitle: "Money taken out by owners / partners against business profit"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					card("Net Profit Today", formatCurrency(profitNow), "text-primary", "Business profit, before drawings"),
					card("Total Drawn", formatCurrency(totalDrawn), "text-destructive", `${all.length} drawings`),
					card("Retained Profit", formatCurrency(retained), retained >= 0 ? "text-success" : "text-destructive", "Profit − drawings"),
					card("Drawn in Filter", formatCurrency(periodDrawn), "text-warning", `${rows.length} shown`)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card flex flex-wrap items-end gap-3 rounded-xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: "mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: "mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Drawn By"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: person,
						onChange: (e) => setPerson(e.target.value),
						className: "mt-1 h-9 rounded-md border border-border bg-accent/20 px-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Everyone"
						}), people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p,
							children: p
						}, p))]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ml-auto text-[10px] text-muted-foreground",
						children: "Add drawings from Entries → New Entry → Owner / Partner Drawing."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass-card overflow-x-auto rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Drawn By"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Purpose"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Paid Via"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Amount"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Profit on Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Total Drawn to Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Profit Left After"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((e) => {
						const p = profitAt(e.date);
						const cum = runOf.get(e.id) || 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: e.date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: e.referenceName || "Owner"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs text-muted-foreground",
									children: [e.chargeCategory, e.note].filter(Boolean).join(" · ") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs",
									children: [
										e.paymentMethod || "Cash",
										store.accounts.find((a) => a.id === e.accountId)?.name,
										e.chequeNo && `Chq ${e.chequeNo}`,
										e.txnRef
									].filter(Boolean).join(" · ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-right font-semibold text-destructive",
									children: formatCurrency(e.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-right",
									children: formatCurrency(p)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-right text-warning",
									children: formatCurrency(cum)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-4 py-3 text-right font-semibold ${p - cum >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(p - cum)
								})
							]
						}, e.id);
					}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 8,
						className: "px-4 py-8 text-center text-xs text-muted-foreground",
						children: "No drawings recorded."
					}) })] })]
				})
			})
		]
	});
}
export { DrawingsPage as component };
