import { g as createLucideIcon } from "./index-BgfHyeon.js";
// node_modules/lucide-react/dist/esm/icons/check.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "check",
	size: 24,
	node: [["path", {
		d: "M20 6 9 17l-5-5",
		key: "1gmf2c"
	}]]
};
__iconData.node;
var Check = createLucideIcon(__iconData);
export { Check as t };
