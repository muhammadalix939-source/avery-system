import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { j as require_react } from "./store-DLjJF6C7.js";
import { O as useLayoutEffect2 } from "./dialog-Bb6Qejxv.js";
// node_modules/@radix-ui/react-use-size/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
function useSize(element) {
	const [size, setSize] = import_react.useState(void 0);
	useLayoutEffect2(() => {
		if (element) {
			setSize({
				width: element.offsetWidth,
				height: element.offsetHeight
			});
			let rAF = 0;
			const resizeObserver = new ResizeObserver((entries) => {
				if (!Array.isArray(entries)) return;
				if (!entries.length) return;
				const entry = entries[0];
				window.cancelAnimationFrame(rAF);
				rAF = window.requestAnimationFrame(() => {
					let width;
					let height;
					if ("borderBoxSize" in entry) {
						const borderSizeEntry = entry["borderBoxSize"];
						const borderSize = Array.isArray(borderSizeEntry) ? borderSizeEntry[0] : borderSizeEntry;
						width = borderSize["inlineSize"];
						height = borderSize["blockSize"];
					} else {
						width = element.offsetWidth;
						height = element.offsetHeight;
					}
					setSize({
						width,
						height
					});
				});
			});
			resizeObserver.observe(element, { box: "border-box" });
			return () => {
				window.cancelAnimationFrame(rAF);
				resizeObserver.unobserve(element);
			};
		} else setSize(void 0);
	}, [element]);
	return size;
}
__name(useSize, "useSize");
export { useSize as t };
