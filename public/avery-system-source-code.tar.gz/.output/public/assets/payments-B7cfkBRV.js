import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime, w as distributePayment } from "./store-DLjJF6C7.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as StatusBadge } from "./StatusBadge-6vwJ3trL.js";
// src/routes/payments.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PaymentsPage() {
	const store = useStore();
	const [selectedHead, setSelectedHead] = (0, import_react.useState)(store.bookings[0]?.headId || "");
	const [paymentInput, setPaymentInput] = (0, import_react.useState)("");
	const booking = store.bookings.find((b) => b.headId === selectedHead);
	if (!booking) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-muted-foreground",
		children: "No bookings available"
	});
	const clients = store.clients.filter((c) => c.headId === selectedHead);
	const amountToUse = paymentInput ? Number(paymentInput) : booking.amountReceived;
	const distributedClients = distributePayment(clients, amountToUse);
	const totalPaid = distributedClients.reduce((s, c) => s + c.amountPaid, 0);
	const totalDue = distributedClients.reduce((s, c) => s + c.amountDue, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Payment Distribution",
				subtitle: "Auto-distribute payments across clients under a Head ID"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: store.bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setSelectedHead(b.headId);
						setPaymentInput("");
					},
					className: `rounded-lg px-4 py-2 text-xs font-medium transition-all ${selectedHead === b.headId ? "bg-primary text-primary-foreground" : "bg-accent/30 text-muted-foreground hover:bg-accent/50"}`,
					children: b.headId
				}, b.headId))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: ["Payment Simulator — ", selectedHead]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 grid grid-cols-1 gap-4 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase text-muted-foreground",
									children: booking.discount ? "Net Customer Due" : "Total Package"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-bold",
									children: formatCurrency(booking.totalAmount)
								}),
								booking.discount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-amber-400",
									children: [
										"Gross: ",
										formatCurrency(booking.baseAmount ?? booking.totalAmount + booking.discount),
										" (Disc: -",
										formatCurrency(booking.discount),
										")"
									]
								}) : null
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "Received"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-bold text-success",
								children: formatCurrency(totalPaid)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase text-muted-foreground",
								children: "Pending"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-bold text-destructive",
								children: formatCurrency(Math.max(0, totalDue - totalPaid))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-[10px] uppercase text-muted-foreground",
										children: "Simulate Payment"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										placeholder: "Enter amount...",
										value: paymentInput,
										onChange: (e) => setPaymentInput(e.target.value),
										className: "bg-accent/20 border-border"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => setPaymentInput(String(booking.totalAmount)),
									children: "Full"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [totalDue > 0 ? Math.round(totalPaid / totalDue * 100) : 0, "% collected"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								formatCurrency(totalPaid),
								" / ",
								formatCurrency(totalDue)
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-3 overflow-hidden rounded-full bg-accent/30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								className: "h-full rounded-full bg-primary",
								initial: { width: 0 },
								animate: { width: `${totalDue > 0 ? totalPaid / totalDue * 100 : 0}%` },
								transition: { duration: .6 }
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: distributedClients.map((c, i) => {
							const percent = c.amountDue > 0 ? Math.round(c.amountPaid / c.amountDue * 100) : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									x: -20
								},
								animate: {
									opacity: 1,
									x: 0
								},
								transition: { delay: i * .05 },
								className: "flex items-center gap-4 rounded-lg border border-border/30 bg-accent/10 px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary",
									children: i + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium",
											children: `${c.firstName} ${c.lastName}`.trim()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: c.id
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-sm font-medium",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-success",
													children: formatCurrency(c.amountPaid)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted-foreground",
													children: [" / ", formatCurrency(c.amountDue)]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 h-1.5 overflow-hidden rounded-full bg-accent/30",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
											className: `h-full rounded-full ${c.paymentStatus === "Paid" ? "bg-success" : c.paymentStatus === "Partial" ? "bg-warning" : "bg-destructive/30"}`,
											initial: { width: 0 },
											animate: { width: `${percent}%` },
											transition: {
												duration: .4,
												delay: i * .05
											}
										})
									})]
								})]
							}, c.id);
						})
					})
				]
			})
		]
	});
}
export { PaymentsPage as component };
