import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { C as computeBookingProfit, E as getClientName, O as toast, S as computeBookingFinancials, T as formatCurrency, a as useStore, b as PACKAGE_TYPES, j as require_react, k as require_jsx_runtime, m as getPKTDate, r as computeGroupUsedPax } from "./store-DLjJF6C7.js";
import { n as sortEntities, t as SortBar } from "./SortBar-T98xQysI.js";
import { t as Check } from "./check-CgDXgYNO.js";
import { a as SelectValue, c as PopperContent, d as createCollection, i as SelectTrigger, l as createPopperScope, n as SelectContent, o as Popper, r as SelectItem, s as PopperAnchor, t as Select, u as useDirection } from "./select-51KhIokW.js";
import { t as ChevronRight } from "./chevron-right-C7dOGd2P.js";
import { n as GroupSeatStrip, r as Plane, t as SearchableSelect } from "./SearchableSelect-Do-d2KwI.js";
import { t as CircleCheck } from "./circle-check-CPvWbtJ5.js";
import { t as Download } from "./download-CEfpC1QR.js";
import { t as Eye } from "./eye-CC3nCxz_.js";
import { t as OctagonAlert } from "./octagon-alert-lg_q6oU2.js";
import { t as Pencil } from "./pencil-B3wEbWek.js";
import { t as Plus } from "./plus-DpXfoyfH.js";
import { t as RotateCcw } from "./rotate-ccw-Q-S1YtUF.js";
import { t as ShieldCheck } from "./shield-check-BDluUh3C.js";
import { t as Trash } from "./trash-YMvfXcpp.js";
import { t as TriangleAlert } from "./triangle-alert-CI6HNCIP.js";
import { f as FileText, g as createLucideIcon, s as Search } from "./index-BgfHyeon.js";
import { a as generateInvoice, i as generateHotelVoucher, l as generateTransportVoucher, o as generatePaymentHistory, r as generateFlightVoucher } from "./pdf-S7DRzVmW.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { a as useComposedRefs, r as createSlot, t as cn } from "./utils-AV1U8VYN.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { n as dispatchDiscreteCustomEvent, t as Primitive } from "./dist-Caq8Ts7X.js";
import { t as Label } from "./label-C_GFC7te.js";
import { A as composeEventHandlers, C as useFocusScopeBranch, D as useCallbackRef, E as DismissableLayer, O as useLayoutEffect2, S as FocusScopeBranchProvider, T as useFocusGuards, _ as useControllableState, a as DialogTrigger, b as useId, g as hideOthers, h as ReactRemoveScroll, i as DialogTitle, k as createContextScope, n as DialogContent, r as DialogHeader, t as Dialog, v as Presence, w as useFocusScopeBranchRegistry, x as FocusScope, y as Portal } from "./dialog-Bb6Qejxv.js";
import { t as StatusBadge } from "./StatusBadge-6vwJ3trL.js";
import { a as paymentAllocations, i as headSupplierPaid, o as purchaseAllocations, r as headCostOf } from "./allocations-CV2mwFEX.js";
// node_modules/lucide-react/dist/esm/icons/car.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$3 = {
	name: "car",
	size: 24,
	node: [
		["path", {
			d: "M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",
			key: "5owen"
		}],
		["circle", {
			cx: "7",
			cy: "17",
			r: "2",
			key: "u2ysq9"
		}],
		["path", {
			d: "M9 17h6",
			key: "r8uit2"
		}],
		["circle", {
			cx: "17",
			cy: "17",
			r: "2",
			key: "axvx0g"
		}]
	]
};
__iconData$3.node;
var Car = createLucideIcon(__iconData$3);
// node_modules/lucide-react/dist/esm/icons/circle.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$2 = {
	name: "circle",
	size: 24,
	node: [["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}]]
};
__iconData$2.node;
var Circle = createLucideIcon(__iconData$2);
// node_modules/lucide-react/dist/esm/icons/hotel.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$1 = {
	name: "hotel",
	size: 24,
	node: [
		["path", {
			d: "M10 22v-6.57",
			key: "1wmca3"
		}],
		["path", {
			d: "M12 11h.01",
			key: "z322tv"
		}],
		["path", {
			d: "M12 7h.01",
			key: "1ivr5q"
		}],
		["path", {
			d: "M14 15.43V22",
			key: "1q2vjd"
		}],
		["path", {
			d: "M15 16a5 5 0 0 0-6 0",
			key: "o9wqvi"
		}],
		["path", {
			d: "M16 11h.01",
			key: "xkw8gn"
		}],
		["path", {
			d: "M16 7h.01",
			key: "1kdx03"
		}],
		["path", {
			d: "M8 11h.01",
			key: "1dfujw"
		}],
		["path", {
			d: "M8 7h.01",
			key: "1vti4s"
		}],
		["rect", {
			x: "4",
			y: "2",
			width: "16",
			height: "20",
			rx: "2",
			key: "1uxh74"
		}]
	]
};
__iconData$1.node;
var Hotel = createLucideIcon(__iconData$1);
// node_modules/lucide-react/dist/esm/icons/tag.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "tag",
	size: 24,
	node: [["path", {
		d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
		key: "vktsd0"
	}], ["circle", {
		cx: "7.5",
		cy: "7.5",
		r: ".5",
		fill: "currentColor",
		key: "kqv944"
	}]]
};
__iconData.node;
var Tag = createLucideIcon(__iconData);
// node_modules/@radix-ui/react-use-is-hydrated/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var __defProp$3 = Object.defineProperty;
var __name$3 = (target, value) => __defProp$3(target, "name", {
	value,
	configurable: true
});
var _isHydrated = false;
function useIsHydrated() {
	const [isHydrated, setIsHydrated] = import_react.useState(_isHydrated);
	import_react.useEffect(() => {
		if (!_isHydrated) {
			_isHydrated = true;
			setIsHydrated(true);
		}
	}, []);
	return isHydrated;
}
__name$3(useIsHydrated, "useIsHydrated");
var useReactSyncExternalStore = import_react[" useSyncExternalStore ".trim().toString()];
function subscribe() {
	return () => {};
}
__name$3(subscribe, "subscribe");
function useIsHydratedModern() {
	return useReactSyncExternalStore(subscribe, () => true, () => false);
}
__name$3(useIsHydratedModern, "useIsHydratedModern");
var useIsHydrated2 = typeof useReactSyncExternalStore === "function" ? useIsHydratedModern : useIsHydrated;
// node_modules/@radix-ui/react-roving-focus/dist/index.mjs
var import_jsx_runtime = require_jsx_runtime();
var __defProp$2 = Object.defineProperty;
var __name$2 = (target, value) => __defProp$2(target, "name", {
	value,
	configurable: true
});
var ENTRY_FOCUS = "rovingFocusGroup.onEntryFocus";
var EVENT_OPTIONS = {
	bubbles: false,
	cancelable: true
};
var GROUP_NAME = "RovingFocusGroup";
var [Collection$1, useCollection$1, createCollectionScope$1] = createCollection(GROUP_NAME);
var [createRovingFocusGroupContext, createRovingFocusGroupScope] = createContextScope(GROUP_NAME, [createCollectionScope$1]);
var Orientation = {
	Vertical: "vertical",
	Horizontal: "horizontal"
};
var Direction$1 = {
	LTR: "ltr",
	RTL: "rtl"
};
var [RovingFocusProvider, useRovingFocusContext] = createRovingFocusGroupContext(GROUP_NAME);
var RovingFocusGroup = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$2(function RovingFocusGroup2(props, forwardedRef) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection$1.Provider, {
		scope: props.__scopeRovingFocusGroup,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection$1.Slot, {
			scope: props.__scopeRovingFocusGroup,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RovingFocusGroupImpl, {
				...props,
				ref: forwardedRef
			})
		})
	});
}, "RovingFocusGroup"));
var RovingFocusGroupImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$2(function RovingFocusGroupImpl2(props, forwardedRef) {
	const { __scopeRovingFocusGroup, orientation, loop = false, dir, currentTabStopId: currentTabStopIdProp, defaultCurrentTabStopId, onCurrentTabStopIdChange, onEntryFocus, preventScrollOnEntryFocus = false, ...groupProps } = props;
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const direction = useDirection(dir);
	const [currentTabStopId, setCurrentTabStopId] = useControllableState({
		prop: currentTabStopIdProp,
		defaultProp: defaultCurrentTabStopId ?? null,
		onChange: onCurrentTabStopIdChange,
		caller: GROUP_NAME
	});
	const [isTabbingBackOut, setIsTabbingBackOut] = import_react.useState(false);
	const handleEntryFocus = useCallbackRef(onEntryFocus);
	const getItems = useCollection$1(__scopeRovingFocusGroup);
	const isClickFocusRef = import_react.useRef(false);
	const [focusableItemsCount, setFocusableItemsCount] = import_react.useState(0);
	import_react.useEffect(() => {
		const node = ref.current;
		if (node) {
			node.addEventListener(ENTRY_FOCUS, handleEntryFocus);
			return () => node.removeEventListener(ENTRY_FOCUS, handleEntryFocus);
		}
	}, [handleEntryFocus]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RovingFocusProvider, {
		scope: __scopeRovingFocusGroup,
		orientation,
		dir: direction,
		loop,
		currentTabStopId,
		onItemFocus: import_react.useCallback((tabStopId) => setCurrentTabStopId(tabStopId), [setCurrentTabStopId]),
		onItemShiftTab: import_react.useCallback(() => setIsTabbingBackOut(true), []),
		onFocusableItemAdd: import_react.useCallback(() => setFocusableItemsCount((prevCount) => prevCount + 1), []),
		onFocusableItemRemove: import_react.useCallback(() => setFocusableItemsCount((prevCount) => prevCount - 1), []),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
			tabIndex: isTabbingBackOut || focusableItemsCount === 0 ? -1 : 0,
			"data-orientation": orientation,
			...groupProps,
			ref: composedRefs,
			style: {
				outline: "none",
				...props.style
			},
			onMouseDown: composeEventHandlers(props.onMouseDown, () => {
				isClickFocusRef.current = true;
			}),
			onFocus: composeEventHandlers(props.onFocus, (event) => {
				const isKeyboardFocus = !isClickFocusRef.current;
				if (event.target === event.currentTarget && isKeyboardFocus && !isTabbingBackOut) {
					const entryFocusEvent = new CustomEvent(ENTRY_FOCUS, EVENT_OPTIONS);
					event.currentTarget.dispatchEvent(entryFocusEvent);
					if (!entryFocusEvent.defaultPrevented) {
						const items = getItems().filter((item) => item.focusable);
						focusFirst$1([
							items.find((item) => item.active),
							items.find((item) => item.id === currentTabStopId),
							...items
						].filter(Boolean).map((item) => item.ref.current), preventScrollOnEntryFocus);
					}
				}
				isClickFocusRef.current = false;
			}),
			onBlur: composeEventHandlers(props.onBlur, () => setIsTabbingBackOut(false))
		})
	});
}, "RovingFocusGroupImpl"));
var ITEM_NAME$1 = "RovingFocusGroupItem";
var RovingFocusGroupItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$2(function RovingFocusGroupItem2(props, forwardedRef) {
	const { __scopeRovingFocusGroup, focusable = true, active = false, tabStopId, children, ...itemProps } = props;
	const autoId = useId();
	const id = tabStopId || autoId;
	const context = useRovingFocusContext(ITEM_NAME$1, __scopeRovingFocusGroup);
	const isCurrentTabStop = context.currentTabStopId === id;
	const getItems = useCollection$1(__scopeRovingFocusGroup);
	const { onFocusableItemAdd, onFocusableItemRemove, currentTabStopId } = context;
	const isHydrated = useIsHydrated2();
	useLayoutEffect2(() => {
		if (!isHydrated || !focusable) return;
		onFocusableItemAdd();
		return () => onFocusableItemRemove();
	}, [
		isHydrated,
		focusable,
		onFocusableItemAdd,
		onFocusableItemRemove
	]);
	import_react.useEffect(() => {
		if (isHydrated || !focusable) return;
		onFocusableItemAdd();
		return () => onFocusableItemRemove();
	}, [
		isHydrated,
		focusable,
		onFocusableItemAdd,
		onFocusableItemRemove
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection$1.ItemSlot, {
		scope: __scopeRovingFocusGroup,
		id,
		focusable,
		active,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
			tabIndex: isCurrentTabStop ? 0 : -1,
			"data-orientation": context.orientation,
			...itemProps,
			ref: forwardedRef,
			onMouseDown: composeEventHandlers(props.onMouseDown, (event) => {
				if (!focusable) event.preventDefault();
				else context.onItemFocus(id);
			}),
			onFocus: composeEventHandlers(props.onFocus, () => context.onItemFocus(id)),
			onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
				if (event.key === "Tab" && event.shiftKey) {
					context.onItemShiftTab();
					return;
				}
				if (event.target !== event.currentTarget) return;
				const focusIntent = getFocusIntent(event, context.orientation, context.dir);
				if (focusIntent !== void 0) {
					if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
					event.preventDefault();
					let candidateNodes = getItems().filter((item) => item.focusable).map((item) => item.ref.current);
					if (focusIntent === "last") candidateNodes.reverse();
					else if (focusIntent === "prev" || focusIntent === "next") {
						if (focusIntent === "prev") candidateNodes.reverse();
						const currentIndex = candidateNodes.indexOf(event.currentTarget);
						candidateNodes = context.loop ? wrapArray$1(candidateNodes, currentIndex + 1) : candidateNodes.slice(currentIndex + 1);
					}
					setTimeout(() => focusFirst$1(candidateNodes));
				}
			}),
			children: typeof children === "function" ? children({
				isCurrentTabStop,
				hasTabStop: currentTabStopId != null
			}) : children
		})
	});
}, "RovingFocusGroupItem"));
var MAP_KEY_TO_FOCUS_INTENT = {
	ArrowLeft: "prev",
	ArrowUp: "prev",
	ArrowRight: "next",
	ArrowDown: "next",
	PageUp: "first",
	Home: "first",
	PageDown: "last",
	End: "last"
};
function getDirectionAwareKey(key, dir) {
	if (dir !== Direction$1.RTL) return key;
	return key === "ArrowLeft" ? "ArrowRight" : key === "ArrowRight" ? "ArrowLeft" : key;
}
__name$2(getDirectionAwareKey, "getDirectionAwareKey");
function getFocusIntent(event, orientation, dir) {
	const key = getDirectionAwareKey(event.key, dir);
	if (orientation === Orientation.Vertical && ["ArrowLeft", "ArrowRight"].includes(key)) return;
	if (orientation === Orientation.Horizontal && ["ArrowUp", "ArrowDown"].includes(key)) return;
	return MAP_KEY_TO_FOCUS_INTENT[key];
}
__name$2(getFocusIntent, "getFocusIntent");
function focusFirst$1(candidates, preventScroll = false) {
	const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
	for (const candidate of candidates) {
		if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
		candidate.focus({ preventScroll });
		if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
	}
}
__name$2(focusFirst$1, "focusFirst");
function wrapArray$1(array, startIndex) {
	return array.map((_, index) => array[(startIndex + index) % array.length]);
}
__name$2(wrapArray$1, "wrapArray");
// node_modules/@radix-ui/react-menu/dist/index.mjs
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var Direction = {
	LTR: "ltr",
	RTL: "rtl"
};
var SELECTION_KEYS = ["Enter", " "];
var FIRST_KEYS = [
	"ArrowDown",
	"PageUp",
	"Home"
];
var LAST_KEYS = [
	"ArrowUp",
	"PageDown",
	"End"
];
var FIRST_LAST_KEYS = [...FIRST_KEYS, ...LAST_KEYS];
var SUB_OPEN_KEYS = {
	ltr: [...SELECTION_KEYS, "ArrowRight"],
	rtl: [...SELECTION_KEYS, "ArrowLeft"]
};
var SUB_CLOSE_KEYS = {
	ltr: ["ArrowLeft"],
	rtl: ["ArrowRight"]
};
var MENU_NAME = "Menu";
var [Collection, useCollection, createCollectionScope] = createCollection(MENU_NAME);
var [createMenuContext, createMenuScope] = createContextScope(MENU_NAME, [
	createCollectionScope,
	createPopperScope,
	createRovingFocusGroupScope
]);
var usePopperScope = createPopperScope();
var useRovingFocusGroupScope = createRovingFocusGroupScope();
var [MenuProvider, useMenuContext] = createMenuContext(MENU_NAME);
var [MenuRootProvider, useMenuRootContext] = createMenuContext(MENU_NAME);
var Menu = /* @__PURE__ */ __name$1((props) => {
	const { __scopeMenu, open = false, children, dir, onOpenChange, modal = true } = props;
	const popperScope = usePopperScope(__scopeMenu);
	const [content, setContent] = import_react.useState(null);
	const isUsingKeyboardRef = import_react.useRef(false);
	const handleOpenChange = useCallbackRef(onOpenChange);
	const direction = useDirection(dir);
	import_react.useEffect(() => {
		const handleKeyDown = /* @__PURE__ */ __name$1(() => {
			isUsingKeyboardRef.current = true;
			document.addEventListener("pointerdown", handlePointer, {
				capture: true,
				once: true
			});
			document.addEventListener("pointermove", handlePointer, {
				capture: true,
				once: true
			});
		}, "handleKeyDown");
		const handlePointer = /* @__PURE__ */ __name$1(() => isUsingKeyboardRef.current = false, "handlePointer");
		document.addEventListener("keydown", handleKeyDown, { capture: true });
		return () => {
			document.removeEventListener("keydown", handleKeyDown, { capture: true });
			document.removeEventListener("pointerdown", handlePointer, { capture: true });
			document.removeEventListener("pointermove", handlePointer, { capture: true });
		};
	}, []);
	import_react.useEffect(() => {
		if (!open) return;
		const handleBlur = /* @__PURE__ */ __name$1(() => handleOpenChange(false), "handleBlur");
		window.addEventListener("blur", handleBlur);
		return () => window.removeEventListener("blur", handleBlur);
	}, [open, handleOpenChange]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popper, {
		...popperScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuProvider, {
			scope: __scopeMenu,
			open,
			onOpenChange: handleOpenChange,
			content,
			onContentChange: setContent,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRootProvider, {
				scope: __scopeMenu,
				onClose: import_react.useCallback(() => handleOpenChange(false), [handleOpenChange]),
				isUsingKeyboardRef,
				dir: direction,
				modal,
				children
			})
		})
	});
}, "Menu");
var MenuAnchor = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuAnchor2(props, forwardedRef) {
	const { __scopeMenu, ...anchorProps } = props;
	const popperScope = usePopperScope(__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperAnchor, {
		...popperScope,
		...anchorProps,
		ref: forwardedRef
	});
}, "MenuAnchor"));
var PORTAL_NAME = "MenuPortal";
var [PortalProvider, usePortalContext] = createMenuContext(PORTAL_NAME, { forceMount: void 0 });
var MenuPortal = /* @__PURE__ */ __name$1((props) => {
	const { __scopeMenu, forceMount, children, container } = props;
	const context = useMenuContext(PORTAL_NAME, __scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalProvider, {
		scope: __scopeMenu,
		forceMount,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, {
				asChild: true,
				container,
				children
			})
		})
	});
}, "MenuPortal");
var CONTENT_NAME$1 = "MenuContent";
var [MenuContentProvider, useMenuContentContext] = createMenuContext(CONTENT_NAME$1);
var MenuContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME$1, props.__scopeMenu);
	const { forceMount = portalContext.forceMount, ...contentProps } = props;
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	const rootContext = useMenuRootContext(CONTENT_NAME$1, props.__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Provider, {
		scope: props.__scopeMenu,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
				scope: props.__scopeMenu,
				children: rootContext.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRootContentModal, {
					...contentProps,
					ref: forwardedRef
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRootContentNonModal, {
					...contentProps,
					ref: forwardedRef
				})
			})
		})
	});
}, "MenuContent"));
var MenuRootContentModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRootContentModal2(props, forwardedRef) {
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	import_react.useEffect(() => {
		const content = ref.current;
		if (content) return hideOthers(content);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentImpl, {
		...props,
		ref: composedRefs,
		trapFocus: context.open,
		disableOutsidePointerEvents: context.open,
		disableOutsideScroll: true,
		onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => event.preventDefault(), { checkForDefaultPrevented: false }),
		onDismiss: () => context.onOpenChange(false)
	});
}, "MenuRootContentModal"));
var MenuRootContentNonModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRootContentNonModal2(props, forwardedRef) {
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentImpl, {
		...props,
		ref: forwardedRef,
		trapFocus: false,
		disableOutsidePointerEvents: false,
		disableOutsideScroll: false,
		onDismiss: () => context.onOpenChange(false)
	});
}, "MenuRootContentNonModal"));
var Slot = createSlot("MenuContent.ScrollLock");
var MenuContentImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuContentImpl2(props, forwardedRef) {
	const { __scopeMenu, loop = false, trapFocus, onOpenAutoFocus, onCloseAutoFocus, disableOutsidePointerEvents, onEntryFocus, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, onDismiss, disableOutsideScroll, ...contentProps } = props;
	const context = useMenuContext(CONTENT_NAME$1, __scopeMenu);
	const rootContext = useMenuRootContext(CONTENT_NAME$1, __scopeMenu);
	const popperScope = usePopperScope(__scopeMenu);
	const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeMenu);
	const getItems = useCollection(__scopeMenu);
	const [currentItemId, setCurrentItemId] = import_react.useState(null);
	const contentRef = import_react.useRef(null);
	const [branchNode, setBranchNode] = import_react.useState(null);
	useFocusScopeBranch(branchNode);
	const { nodes: branchNodes, registry: branchRegistry } = useFocusScopeBranchRegistry();
	const isModal = Boolean(trapFocus || disableOutsideScroll);
	const composedRefs = useComposedRefs(forwardedRef, contentRef, context.onContentChange, setBranchNode);
	const timerRef = import_react.useRef(0);
	const searchRef = import_react.useRef("");
	const pointerGraceTimerRef = import_react.useRef(0);
	const pointerGraceIntentRef = import_react.useRef(null);
	const pointerDirRef = import_react.useRef("right");
	const lastPointerXRef = import_react.useRef(0);
	const shards = import_react.useMemo(() => disableOutsideScroll ? [contentRef, ...branchNodes.map((node) => ({ current: node }))] : [], [
		contentRef,
		branchNodes,
		disableOutsideScroll
	]);
	const ScrollLockWrapper = disableOutsideScroll ? ReactRemoveScroll : import_react.Fragment;
	const scrollLockWrapperProps = disableOutsideScroll ? {
		as: Slot,
		allowPinchZoom: true,
		shards
	} : void 0;
	const handleTypeaheadSearch = /* @__PURE__ */ __name$1((key) => {
		const search = searchRef.current + key;
		const items = getItems().filter((item) => !item.disabled);
		const currentItem = document.activeElement;
		const currentMatch = items.find((item) => item.ref.current === currentItem)?.textValue;
		const nextMatch = getNextMatch(items.map((item) => item.textValue), search, currentMatch);
		const newItem = items.find((item) => item.textValue === nextMatch)?.ref.current;
		function updateSearch(value) {
			searchRef.current = value;
			window.clearTimeout(timerRef.current);
			if (value !== "") timerRef.current = window.setTimeout(() => updateSearch(""), 1e3);
		}
		__name$1(updateSearch, "updateSearch");
		updateSearch(search);
		if (newItem) setTimeout(() => newItem.focus());
	}, "handleTypeaheadSearch");
	import_react.useEffect(() => {
		return () => window.clearTimeout(timerRef.current);
	}, []);
	useFocusGuards();
	const isPointerMovingToSubmenu = import_react.useCallback((event) => {
		return pointerDirRef.current === pointerGraceIntentRef.current?.side && isPointerInGraceArea(event, pointerGraceIntentRef.current?.area);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentProvider, {
		scope: __scopeMenu,
		searchRef,
		onItemEnter: import_react.useCallback((event) => {
			if (isPointerMovingToSubmenu(event)) event.preventDefault();
		}, [isPointerMovingToSubmenu]),
		onItemLeave: import_react.useCallback((event) => {
			if (isPointerMovingToSubmenu(event)) return;
			contentRef.current?.focus();
			setCurrentItemId(null);
		}, [isPointerMovingToSubmenu]),
		onTriggerLeave: import_react.useCallback((event) => {
			if (isPointerMovingToSubmenu(event)) event.preventDefault();
		}, [isPointerMovingToSubmenu]),
		pointerGraceTimerRef,
		onPointerGraceIntentChange: import_react.useCallback((intent) => {
			pointerGraceIntentRef.current = intent;
		}, []),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScopeBranchProvider, {
			registry: isModal ? branchRegistry : null,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollLockWrapper, {
				...scrollLockWrapperProps,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScope, {
					asChild: true,
					trapped: trapFocus,
					branches: branchNodes,
					onMountAutoFocus: composeEventHandlers(onOpenAutoFocus, (event) => {
						event.preventDefault();
						contentRef.current?.focus({ preventScroll: true });
					}),
					onUnmountAutoFocus: onCloseAutoFocus,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DismissableLayer, {
						asChild: true,
						disableOutsidePointerEvents,
						onEscapeKeyDown,
						onPointerDownOutside,
						onFocusOutside,
						onInteractOutside,
						onDismiss,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RovingFocusGroup, {
							asChild: true,
							...rovingFocusGroupScope,
							dir: rootContext.dir,
							orientation: "vertical",
							loop,
							currentTabStopId: currentItemId,
							onCurrentTabStopIdChange: setCurrentItemId,
							onEntryFocus: composeEventHandlers(onEntryFocus, (event) => {
								if (!rootContext.isUsingKeyboardRef.current) event.preventDefault();
							}),
							preventScrollOnEntryFocus: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperContent, {
								role: "menu",
								"aria-orientation": "vertical",
								"data-state": getOpenState(context.open),
								"data-radix-menu-content": "",
								dir: rootContext.dir,
								...popperScope,
								...contentProps,
								ref: composedRefs,
								style: {
									outline: "none",
									...contentProps.style
								},
								onKeyDown: composeEventHandlers(contentProps.onKeyDown, (event) => {
									const isKeyDownInside = event.target.closest("[data-radix-menu-content]") === event.currentTarget;
									const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
									const isCharacterKey = event.key.length === 1;
									if (isKeyDownInside) {
										if (event.key === "Tab") event.preventDefault();
										if (!isModifierKey && isCharacterKey) handleTypeaheadSearch(event.key);
									}
									const content = contentRef.current;
									if (event.target !== content) return;
									if (!FIRST_LAST_KEYS.includes(event.key)) return;
									event.preventDefault();
									const candidateNodes = getItems().filter((item) => !item.disabled).map((item) => item.ref.current);
									if (LAST_KEYS.includes(event.key)) candidateNodes.reverse();
									focusFirst(candidateNodes);
								}),
								onBlur: composeEventHandlers(props.onBlur, (event) => {
									if (!event.currentTarget.contains(event.target)) {
										window.clearTimeout(timerRef.current);
										searchRef.current = "";
									}
								}),
								onPointerMove: composeEventHandlers(props.onPointerMove, whenMouse((event) => {
									const target = event.target;
									const pointerXHasChanged = lastPointerXRef.current !== event.clientX;
									if (event.currentTarget.contains(target) && pointerXHasChanged) {
										const newDir = event.clientX > lastPointerXRef.current ? "right" : "left";
										pointerDirRef.current = newDir;
										lastPointerXRef.current = event.clientX;
									}
								}))
							})
						})
					})
				})
			})
		})
	});
}, "MenuContentImpl"));
var MenuLabel = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuLabel2(props, forwardedRef) {
	const { __scopeMenu, ...labelProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...labelProps,
		ref: forwardedRef
	});
}, "MenuLabel"));
var ITEM_NAME = "MenuItem";
var ITEM_SELECT = "menu.itemSelect";
var MenuItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuItem2(props, forwardedRef) {
	const { disabled = false, onSelect, ...itemProps } = props;
	const ref = import_react.useRef(null);
	const rootContext = useMenuRootContext(ITEM_NAME, props.__scopeMenu);
	const contentContext = useMenuContentContext(ITEM_NAME, props.__scopeMenu);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const isPointerDownRef = import_react.useRef(false);
	const handleSelect = /* @__PURE__ */ __name$1(() => {
		const menuItem = ref.current;
		if (!disabled && menuItem) {
			const itemSelectEvent = new CustomEvent(ITEM_SELECT, {
				bubbles: true,
				cancelable: true
			});
			menuItem.addEventListener(ITEM_SELECT, (event) => onSelect?.(event), { once: true });
			dispatchDiscreteCustomEvent(menuItem, itemSelectEvent);
			if (itemSelectEvent.defaultPrevented) isPointerDownRef.current = false;
			else rootContext.onClose();
		}
	}, "handleSelect");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItemImpl, {
		...itemProps,
		ref: composedRefs,
		disabled,
		onClick: composeEventHandlers(props.onClick, handleSelect),
		onPointerDown: (event) => {
			props.onPointerDown?.(event);
			isPointerDownRef.current = true;
		},
		onPointerUp: composeEventHandlers(props.onPointerUp, (event) => {
			if (!isPointerDownRef.current) event.currentTarget?.click();
		}),
		onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
			if (disabled || event.target !== event.currentTarget) return;
			if (contentContext.searchRef.current !== "" && event.key === " ") return;
			if (SELECTION_KEYS.includes(event.key)) {
				event.currentTarget.click();
				event.preventDefault();
			}
		})
	});
}, "MenuItem"));
var MenuItemImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuItemImpl2(props, forwardedRef) {
	const { __scopeMenu, disabled = false, textValue, ...itemProps } = props;
	const contentContext = useMenuContentContext(ITEM_NAME, __scopeMenu);
	const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeMenu);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const [isFocused, setIsFocused] = import_react.useState(false);
	const [textContent, setTextContent] = import_react.useState("");
	import_react.useEffect(() => {
		const menuItem = ref.current;
		if (menuItem) setTextContent((menuItem.textContent ?? "").trim());
	}, [itemProps.children]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.ItemSlot, {
		scope: __scopeMenu,
		disabled,
		textValue: textValue ?? textContent,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RovingFocusGroupItem, {
			asChild: true,
			...rovingFocusGroupScope,
			focusable: !disabled,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
				role: "menuitem",
				"data-highlighted": isFocused ? "" : void 0,
				"aria-disabled": disabled || void 0,
				"data-disabled": disabled ? "" : void 0,
				...itemProps,
				ref: composedRefs,
				onPointerMove: composeEventHandlers(props.onPointerMove, whenMouse((event) => {
					if (disabled) contentContext.onItemLeave(event);
					else {
						contentContext.onItemEnter(event);
						if (!event.defaultPrevented) event.currentTarget.focus({ preventScroll: true });
					}
				})),
				onPointerLeave: composeEventHandlers(props.onPointerLeave, whenMouse((event) => contentContext.onItemLeave(event))),
				onFocus: composeEventHandlers(props.onFocus, () => setIsFocused(true)),
				onBlur: composeEventHandlers(props.onBlur, () => setIsFocused(false))
			})
		})
	});
}, "MenuItemImpl"));
var MenuCheckboxItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuCheckboxItem2(props, forwardedRef) {
	const { checked = false, onCheckedChange, ...checkboxItemProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicatorProvider, {
		scope: props.__scopeMenu,
		checked,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
			role: "menuitemcheckbox",
			"aria-checked": isIndeterminate(checked) ? "mixed" : checked,
			...checkboxItemProps,
			ref: forwardedRef,
			"data-state": getCheckedState(checked),
			onSelect: composeEventHandlers(checkboxItemProps.onSelect, () => onCheckedChange?.(isIndeterminate(checked) ? true : !checked), { checkForDefaultPrevented: false })
		})
	});
}, "MenuCheckboxItem"));
var [RadioGroupProvider, useRadioGroupContext] = createMenuContext("MenuRadioGroup", {
	value: void 0,
	onValueChange: /* @__PURE__ */ __name$1(() => {}, "onValueChange")
});
var RADIO_ITEM_NAME = "MenuRadioItem";
var MenuRadioItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRadioItem2(props, forwardedRef) {
	const { value, ...radioItemProps } = props;
	const context = useRadioGroupContext(RADIO_ITEM_NAME, props.__scopeMenu);
	const checked = value === context.value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicatorProvider, {
		scope: props.__scopeMenu,
		checked,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
			role: "menuitemradio",
			"aria-checked": checked,
			...radioItemProps,
			ref: forwardedRef,
			"data-state": getCheckedState(checked),
			onSelect: composeEventHandlers(radioItemProps.onSelect, () => context.onValueChange?.(value), { checkForDefaultPrevented: false })
		})
	});
}, "MenuRadioItem"));
var ITEM_INDICATOR_NAME = "MenuItemIndicator";
var [ItemIndicatorProvider, useItemIndicatorContext] = createMenuContext(ITEM_INDICATOR_NAME, { checked: false });
var MenuItemIndicator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuItemIndicator2(props, forwardedRef) {
	const { __scopeMenu, forceMount, ...itemIndicatorProps } = props;
	const indicatorContext = useItemIndicatorContext(ITEM_INDICATOR_NAME, __scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || isIndeterminate(indicatorContext.checked) || indicatorContext.checked === true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
			...itemIndicatorProps,
			ref: forwardedRef,
			"data-state": getCheckedState(indicatorContext.checked)
		})
	});
}, "MenuItemIndicator"));
var MenuSeparator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuSeparator2(props, forwardedRef) {
	const { __scopeMenu, ...separatorProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		role: "separator",
		"aria-orientation": "horizontal",
		...separatorProps,
		ref: forwardedRef
	});
}, "MenuSeparator"));
var [MenuSubProvider, useMenuSubContext] = createMenuContext("MenuSub");
var SUB_TRIGGER_NAME = "MenuSubTrigger";
var MenuSubTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuSubTrigger2(props, forwardedRef) {
	const context = useMenuContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const rootContext = useMenuRootContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const subContext = useMenuSubContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const contentContext = useMenuContentContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const openTimerRef = import_react.useRef(null);
	const { pointerGraceTimerRef, onPointerGraceIntentChange } = contentContext;
	const scope = { __scopeMenu: props.__scopeMenu };
	const clearOpenTimer = import_react.useCallback(() => {
		if (openTimerRef.current) window.clearTimeout(openTimerRef.current);
		openTimerRef.current = null;
	}, []);
	import_react.useEffect(() => clearOpenTimer, [clearOpenTimer]);
	import_react.useEffect(() => {
		const pointerGraceTimer = pointerGraceTimerRef.current;
		return () => {
			window.clearTimeout(pointerGraceTimer);
			onPointerGraceIntentChange(null);
		};
	}, [pointerGraceTimerRef, onPointerGraceIntentChange]);
	const composedRefs = useComposedRefs(forwardedRef, subContext.onTriggerChange);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuAnchor, {
		asChild: true,
		...scope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItemImpl, {
			id: subContext.triggerId,
			"aria-haspopup": "menu",
			"aria-expanded": context.open,
			"aria-controls": context.open ? subContext.contentId : void 0,
			"data-state": getOpenState(context.open),
			...props,
			ref: composedRefs,
			onClick: (event) => {
				props.onClick?.(event);
				if (props.disabled || event.defaultPrevented) return;
				event.currentTarget.focus();
				if (!context.open) context.onOpenChange(true);
			},
			onPointerMove: composeEventHandlers(props.onPointerMove, whenMouse((event) => {
				contentContext.onItemEnter(event);
				if (event.defaultPrevented) return;
				if (!props.disabled && !context.open && !openTimerRef.current) {
					contentContext.onPointerGraceIntentChange(null);
					openTimerRef.current = window.setTimeout(() => {
						context.onOpenChange(true);
						clearOpenTimer();
					}, 100);
				}
			})),
			onPointerLeave: composeEventHandlers(props.onPointerLeave, whenMouse((event) => {
				clearOpenTimer();
				const contentRect = context.content?.getBoundingClientRect();
				if (contentRect) {
					const side = context.content?.dataset.side;
					const rightSide = side === "right";
					const bleed = rightSide ? -5 : 5;
					const contentNearEdge = contentRect[rightSide ? "left" : "right"];
					const contentFarEdge = contentRect[rightSide ? "right" : "left"];
					contentContext.onPointerGraceIntentChange({
						area: [
							{
								x: event.clientX + bleed,
								y: event.clientY
							},
							{
								x: contentNearEdge,
								y: contentRect.top
							},
							{
								x: contentFarEdge,
								y: contentRect.top
							},
							{
								x: contentFarEdge,
								y: contentRect.bottom
							},
							{
								x: contentNearEdge,
								y: contentRect.bottom
							}
						],
						side
					});
					window.clearTimeout(pointerGraceTimerRef.current);
					pointerGraceTimerRef.current = window.setTimeout(() => contentContext.onPointerGraceIntentChange(null), 300);
				} else {
					contentContext.onTriggerLeave(event);
					if (event.defaultPrevented) return;
					contentContext.onPointerGraceIntentChange(null);
				}
			})),
			onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
				if (props.disabled || event.target !== event.currentTarget) return;
				if (contentContext.searchRef.current !== "" && event.key === " ") return;
				if (SUB_OPEN_KEYS[rootContext.dir].includes(event.key)) {
					context.onOpenChange(true);
					context.content?.focus();
					event.preventDefault();
				}
			})
		})
	});
}, "MenuSubTrigger"));
var SUB_CONTENT_NAME = "MenuSubContent";
var MenuSubContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuSubContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME$1, props.__scopeMenu);
	const { forceMount = portalContext.forceMount, align = "start", ...subContentProps } = props;
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	const rootContext = useMenuRootContext(CONTENT_NAME$1, props.__scopeMenu);
	const subContext = useMenuSubContext(SUB_CONTENT_NAME, props.__scopeMenu);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Provider, {
		scope: props.__scopeMenu,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
				scope: props.__scopeMenu,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentImpl, {
					id: subContext.contentId,
					"aria-labelledby": subContext.triggerId,
					...subContentProps,
					ref: composedRefs,
					align,
					side: rootContext.dir === Direction.RTL ? "left" : "right",
					disableOutsidePointerEvents: false,
					disableOutsideScroll: false,
					trapFocus: false,
					onOpenAutoFocus: (event) => {
						if (rootContext.isUsingKeyboardRef.current) ref.current?.focus();
						event.preventDefault();
					},
					onCloseAutoFocus: (event) => event.preventDefault(),
					onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => {
						if (event.target !== subContext.trigger) context.onOpenChange(false);
					}),
					onEscapeKeyDown: composeEventHandlers(props.onEscapeKeyDown, (event) => {
						rootContext.onClose();
						event.preventDefault();
					}),
					onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
						const isKeyDownInside = event.currentTarget.contains(event.target);
						const isCloseKey = SUB_CLOSE_KEYS[rootContext.dir].includes(event.key);
						if (isKeyDownInside && isCloseKey) {
							context.onOpenChange(false);
							subContext.trigger?.focus();
							event.preventDefault();
						}
					})
				})
			})
		})
	});
}, "MenuSubContent"));
function getOpenState(open) {
	return open ? "open" : "closed";
}
__name$1(getOpenState, "getOpenState");
function isIndeterminate(checked) {
	return checked === "indeterminate";
}
__name$1(isIndeterminate, "isIndeterminate");
function getCheckedState(checked) {
	return isIndeterminate(checked) ? "indeterminate" : checked ? "checked" : "unchecked";
}
__name$1(getCheckedState, "getCheckedState");
function focusFirst(candidates) {
	const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
	for (const candidate of candidates) {
		if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
		candidate.focus();
		if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
	}
}
__name$1(focusFirst, "focusFirst");
function wrapArray(array, startIndex) {
	return array.map((_, index) => array[(startIndex + index) % array.length]);
}
__name$1(wrapArray, "wrapArray");
function getNextMatch(values, search, currentMatch) {
	const normalizedSearch = search.length > 1 && Array.from(search).every((char) => char === search[0]) ? search[0] : search;
	const currentMatchIndex = currentMatch ? values.indexOf(currentMatch) : -1;
	let wrappedValues = wrapArray(values, Math.max(currentMatchIndex, 0));
	if (normalizedSearch.length === 1) wrappedValues = wrappedValues.filter((v) => v !== currentMatch);
	const nextMatch = wrappedValues.find((value) => value.toLowerCase().startsWith(normalizedSearch.toLowerCase()));
	return nextMatch !== currentMatch ? nextMatch : void 0;
}
__name$1(getNextMatch, "getNextMatch");
function isPointInPolygon(point, polygon) {
	const { x, y } = point;
	let inside = false;
	for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
		const ii = polygon[i];
		const jj = polygon[j];
		const xi = ii.x;
		const yi = ii.y;
		const xj = jj.x;
		const yj = jj.y;
		if (yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
	}
	return inside;
}
__name$1(isPointInPolygon, "isPointInPolygon");
function isPointerInGraceArea(event, area) {
	if (!area) return false;
	return isPointInPolygon({
		x: event.clientX,
		y: event.clientY
	}, area);
}
__name$1(isPointerInGraceArea, "isPointerInGraceArea");
function whenMouse(handler) {
	return (event) => event.pointerType === "mouse" ? handler(event) : void 0;
}
__name$1(whenMouse, "whenMouse");
// node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var DROPDOWN_MENU_NAME = "DropdownMenu";
var [createDropdownMenuContext, createDropdownMenuScope] = createContextScope(DROPDOWN_MENU_NAME, [createMenuScope]);
var useMenuScope = createMenuScope();
var [DropdownMenuProvider, useDropdownMenuContext] = createDropdownMenuContext(DROPDOWN_MENU_NAME);
var DropdownMenu$1 = /* @__PURE__ */ __name((props) => {
	const { __scopeDropdownMenu, children, dir, open: openProp, defaultOpen, onOpenChange, modal = true } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const triggerRef = import_react.useRef(null);
	const [open, setOpen] = useControllableState({
		prop: openProp,
		defaultProp: defaultOpen ?? false,
		onChange: onOpenChange,
		caller: DROPDOWN_MENU_NAME
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuProvider, {
		scope: __scopeDropdownMenu,
		triggerId: useId(),
		triggerRef,
		contentId: useId(),
		open,
		onOpenChange: setOpen,
		onOpenToggle: import_react.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
		modal,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
			...menuScope,
			open,
			onOpenChange: setOpen,
			dir,
			modal,
			children
		})
	});
}, "DropdownMenu");
var TRIGGER_NAME = "DropdownMenuTrigger";
var DropdownMenuTrigger$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuTrigger2(props, forwardedRef) {
	const { __scopeDropdownMenu, disabled = false, ...triggerProps } = props;
	const context = useDropdownMenuContext(TRIGGER_NAME, __scopeDropdownMenu);
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const composedRefs = useComposedRefs(forwardedRef, context.triggerRef);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuAnchor, {
		asChild: true,
		...menuScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
			type: "button",
			id: context.triggerId,
			"aria-haspopup": "menu",
			"aria-expanded": context.open,
			"aria-controls": context.open ? context.contentId : void 0,
			"data-state": context.open ? "open" : "closed",
			"data-disabled": disabled ? "" : void 0,
			disabled,
			...triggerProps,
			ref: composedRefs,
			onPointerDown: composeEventHandlers(props.onPointerDown, (event) => {
				if (!disabled && event.button === 0 && event.ctrlKey === false) {
					context.onOpenToggle();
					if (!context.open) event.preventDefault();
				}
			}),
			onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
				if (disabled) return;
				if (["Enter", " "].includes(event.key)) context.onOpenToggle();
				if (event.key === "ArrowDown") context.onOpenChange(true);
				if ([
					"Enter",
					" ",
					"ArrowDown"
				].includes(event.key)) event.preventDefault();
			})
		})
	});
}, "DropdownMenuTrigger"));
var DropdownMenuPortal = /* @__PURE__ */ __name((props) => {
	const { __scopeDropdownMenu, ...portalProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPortal, {
		...menuScope,
		...portalProps
	});
}, "DropdownMenuPortal");
var CONTENT_NAME = "DropdownMenuContent";
var DropdownMenuContent$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuContent2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...contentProps } = props;
	const context = useDropdownMenuContext(CONTENT_NAME, __scopeDropdownMenu);
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const hasInteractedOutsideRef = import_react.useRef(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContent, {
		id: context.contentId,
		"aria-labelledby": context.triggerId,
		...menuScope,
		...contentProps,
		ref: forwardedRef,
		onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
			if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
			hasInteractedOutsideRef.current = false;
			event.preventDefault();
		}),
		onInteractOutside: composeEventHandlers(props.onInteractOutside, (event) => {
			const originalEvent = event.detail.originalEvent;
			const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
			const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
			if (!context.modal || isRightClick) hasInteractedOutsideRef.current = true;
		}),
		style: {
			...props.style,
			"--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
			"--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
			"--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "DropdownMenuContent"));
var DropdownMenuLabel$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuLabel2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...labelProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLabel, {
		...menuScope,
		...labelProps,
		ref: forwardedRef
	});
}, "DropdownMenuLabel"));
var DropdownMenuItem$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuItem2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...itemProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
		...menuScope,
		...itemProps,
		ref: forwardedRef
	});
}, "DropdownMenuItem"));
var DropdownMenuCheckboxItem$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuCheckboxItem2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...checkboxItemProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuCheckboxItem, {
		...menuScope,
		...checkboxItemProps,
		ref: forwardedRef
	});
}, "DropdownMenuCheckboxItem"));
var DropdownMenuRadioItem$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuRadioItem2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...radioItemProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRadioItem, {
		...menuScope,
		...radioItemProps,
		ref: forwardedRef
	});
}, "DropdownMenuRadioItem"));
var DropdownMenuItemIndicator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuItemIndicator2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...itemIndicatorProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItemIndicator, {
		...menuScope,
		...itemIndicatorProps,
		ref: forwardedRef
	});
}, "DropdownMenuItemIndicator"));
var DropdownMenuSeparator$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuSeparator2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...separatorProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSeparator, {
		...menuScope,
		...separatorProps,
		ref: forwardedRef
	});
}, "DropdownMenuSeparator"));
var DropdownMenuSubTrigger$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuSubTrigger2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...subTriggerProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSubTrigger, {
		...menuScope,
		...subTriggerProps,
		ref: forwardedRef
	});
}, "DropdownMenuSubTrigger"));
var DropdownMenuSubContent$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuSubContent2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...subContentProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSubContent, {
		...menuScope,
		...subContentProps,
		ref: forwardedRef,
		style: {
			...props.style,
			"--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
			"--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
			"--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "DropdownMenuSubContent"));
// src/components/ui/dropdown-menu.tsx
var DropdownMenu = DropdownMenu$1;
var DropdownMenuTrigger = DropdownMenuTrigger$1;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuSubTrigger$1, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = DropdownMenuSubTrigger$1.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSubContent$1, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = DropdownMenuSubContent$1.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent$1, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = DropdownMenuContent$1.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = DropdownMenuItem$1.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuCheckboxItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	checked,
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = DropdownMenuCheckboxItem$1.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = DropdownMenuRadioItem$1.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = DropdownMenuLabel$1.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = DropdownMenuSeparator$1.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
// src/components/BookingServicesMenu.tsx
function BookingServicesMenu({ booking, clients }) {
	const store = useStore();
	const [open, setOpen] = (0, import_react.useState)(null);
	const [hotel, setHotel] = (0, import_react.useState)({
		city: "Makkah",
		hotelName: "",
		roomType: "",
		checkIn: "",
		checkOut: "",
		nights: ""
	});
	const [flight, setFlight] = (0, import_react.useState)({
		date: "",
		flightNo: "",
		from: "",
		to: "",
		departure: "",
		arrival: ""
	});
	const [transport, setTransport] = (0, import_react.useState)({
		service: "Airport Transfer",
		route: "",
		vehicle: "Private Car",
		date: ""
	});
	function reset() {
		setOpen(null);
	}
	function saveHotel() {
		if (!hotel.hotelName) return;
		store.addHotel(booking.id, {
			city: hotel.city,
			hotelName: hotel.hotelName,
			roomType: hotel.roomType || "1 Quad",
			checkIn: hotel.checkIn,
			checkOut: hotel.checkOut,
			nights: Number(hotel.nights) || 0
		});
		setHotel({
			city: "Makkah",
			hotelName: "",
			roomType: "",
			checkIn: "",
			checkOut: "",
			nights: ""
		});
		reset();
	}
	function saveFlight() {
		if (!flight.flightNo) return;
		store.addFlight(booking.id, { ...flight });
		setFlight({
			date: "",
			flightNo: "",
			from: "",
			to: "",
			departure: "",
			arrival: ""
		});
		reset();
	}
	function saveTransport() {
		if (!transport.route) return;
		store.addTransport(booking.id, { ...transport });
		setTransport({
			service: "Airport Transfer",
			route: "",
			vehicle: "Private Car",
			date: ""
		});
		reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "rounded p-1 hover:bg-accent",
				title: "Add Service",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5 text-primary" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
			align: "end",
			className: "w-56",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
					className: "text-xs",
					children: "Add Service"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onClick: () => setOpen("hotel"),
					className: "gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hotel, { className: "h-3.5 w-3.5 text-primary" }), " Add Hotel"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onClick: () => setOpen("flight"),
					className: "gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "h-3.5 w-3.5 text-primary" }), " Add Flight"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onClick: () => setOpen("transport"),
					className: "gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "h-3.5 w-3.5 text-primary" }), " Add Transport"]
				}),
				booking.hotels?.length || booking.flights?.length || booking.transports?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
						className: "text-xs",
						children: "Manage"
					}),
					booking.hotels?.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => store.deleteHotel(booking.id, h.id),
						className: "gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3 w-3 text-destructive" }),
							" Remove ",
							h.city,
							" — ",
							h.hotelName
						]
					}, h.id)),
					booking.flights?.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => store.deleteFlight(booking.id, f.id),
						className: "gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3 w-3 text-destructive" }),
							" Remove Flight ",
							f.flightNo
						]
					}, f.id)),
					booking.transports?.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => store.deleteTransport(booking.id, t.id),
						className: "gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3 w-3 text-destructive" }),
							" Remove ",
							t.service
						]
					}, t.id))
				] }) : null
			]
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: open === "hotel",
			onOpenChange: (o) => !o && reset(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "bg-card border-border max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add Hotel — ", booking.headId] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "City"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: hotel.city,
								onChange: (e) => setHotel({
									...hotel,
									city: e.target.value
								}),
								placeholder: "Makkah / Madinah",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Room Type"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: hotel.roomType,
								onChange: (e) => setHotel({
									...hotel,
									roomType: e.target.value
								}),
								placeholder: "1 Quad",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Hotel Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: hotel.hotelName,
							onChange: (e) => setHotel({
								...hotel,
								hotelName: e.target.value
							}),
							placeholder: "Noor Al Mashair",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "Check-In"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: hotel.checkIn,
									onChange: (e) => setHotel({
										...hotel,
										checkIn: e.target.value
									}),
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "Check-Out"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: hotel.checkOut,
									onChange: (e) => setHotel({
										...hotel,
										checkOut: e.target.value
									}),
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "Nights"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: hotel.nights,
									onChange: (e) => setHotel({
										...hotel,
										nights: e.target.value
									}),
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveHotel,
							className: "w-full",
							children: "Save Hotel"
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: open === "flight",
			onOpenChange: (o) => !o && reset(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "bg-card border-border max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add Flight — ", booking.headId] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: flight.date,
								onChange: (e) => setFlight({
									...flight,
									date: e.target.value
								}),
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Flight No"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.flightNo,
								onChange: (e) => setFlight({
									...flight,
									flightNo: e.target.value
								}),
								placeholder: "XY638",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "From"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.from,
								onChange: (e) => setFlight({
									...flight,
									from: e.target.value
								}),
								placeholder: "Karachi",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "To"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.to,
								onChange: (e) => setFlight({
									...flight,
									to: e.target.value
								}),
								placeholder: "Jeddah",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Departure"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.departure,
								onChange: (e) => setFlight({
									...flight,
									departure: e.target.value
								}),
								placeholder: "13:15",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Arrival"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.arrival,
								onChange: (e) => setFlight({
									...flight,
									arrival: e.target.value
								}),
								placeholder: "16:05",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveFlight,
							className: "w-full",
							children: "Save Flight"
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: open === "transport",
			onOpenChange: (o) => !o && reset(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "bg-card border-border max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add Transport — ", booking.headId] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Service"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: transport.service,
								onChange: (e) => setTransport({
									...transport,
									service: e.target.value
								}),
								placeholder: "Airport Transfer",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Vehicle"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: transport.vehicle,
								onChange: (e) => setTransport({
									...transport,
									vehicle: e.target.value
								}),
								placeholder: "Private Car",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Route"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: transport.route,
							onChange: (e) => setTransport({
								...transport,
								route: e.target.value
							}),
							placeholder: "JED Airport - Makkah Hotel",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: transport.date,
							onChange: (e) => setTransport({
								...transport,
								date: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveTransport,
							className: "w-full",
							children: "Save Transport"
						})
					]
				})]
			})
		})
	] });
}
function VoucherDownloadMenu({ booking, clients }) {
	const hasAny = (booking.hotels?.length || 0) + (booking.flights?.length || 0) + (booking.transports?.length || 0) > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "rounded p-1 hover:bg-accent",
			title: "Download Vouchers",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		className: "w-56",
		children: [
			!hasAny && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				disabled: true,
				className: "text-xs text-muted-foreground",
				children: "No services added yet"
			}),
			booking.hotels && booking.hotels.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
					className: "text-xs",
					children: "Hotel Vouchers"
				}),
				booking.hotels.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					className: "gap-2 text-xs",
					onClick: () => generateHotelVoucher(booking, clients, [h], { voucherSuffix: `-${i + 1}` }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hotel, { className: "h-3.5 w-3.5 text-primary" }),
						" ",
						h.city,
						" — ",
						h.hotelName
					]
				}, h.id)),
				booking.hotels.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					className: "gap-2 text-xs font-semibold",
					onClick: () => generateHotelVoucher(booking, clients, booking.hotels, {
						transports: booking.transports,
						flights: booking.flights
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" }), " Download All Hotels"]
				})
			] }),
			booking.flights && booking.flights.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				className: "gap-2 text-xs",
				onClick: () => generateFlightVoucher(booking, clients, booking.flights),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "h-3.5 w-3.5 text-primary" }), " Flight Voucher"]
			})] }),
			booking.transports && booking.transports.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				className: "gap-2 text-xs",
				onClick: () => generateTransportVoucher(booking, clients, booking.transports),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "h-3.5 w-3.5 text-primary" }), " Transport Voucher"]
			}),
			hasAny && (booking.hotels?.length || 0) >= 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				className: "gap-2 text-xs font-semibold",
				onClick: () => generateHotelVoucher(booking, clients, booking.hotels || [], {
					transports: booking.transports,
					flights: booking.flights
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" }), " Combined Voucher (Hotel + Flight + Transport)"]
			})] })
		]
	})] });
}
// src/lib/heads.ts
/** Flat, disclosed amounts only — no interest, no compounding. */
function computeHeadBusiness(headId, clients, bookings, entries) {
	const members = clients.filter((c) => c.headId === headId);
	const booking = bookings.find((b) => b.headId === headId);
	const linked = entries.filter((e) => {
		if (e.headId === headId) return true;
		if (e.type === "purchase") return purchaseAllocations(e).some((l) => l.target === "head" && l.headId === headId);
		if (e.type === "supplier_payment") return paymentAllocations(e).some((l) => l.target === "head" && l.headId === headId);
		return false;
	});
	const otherCosts = linked.filter((e) => e.type === "client_charge").reduce((s, e) => s + e.amount, 0);
	const discountEntries = linked.filter((e) => e.type === "client_discount").reduce((s, e) => s + e.amount, 0);
	const bookingDiscount = Number(booking?.discount) || 0;
	const totalDiscount = bookingDiscount + discountEntries;
	const grossBase = booking?.baseAmount ?? (booking ? booking.totalAmount + bookingDiscount : members.reduce((s, c) => s + (c.baseDue ?? c.amountDue), 0));
	const perPerson = members.length ? Math.round(grossBase / members.length) : grossBase;
	const grossSale = perPerson * (members.length || 1) + otherCosts;
	const totalSale = Math.max(0, grossSale - totalDiscount);
	const refunds = linked.filter((e) => e.type === "client_refund").reduce((s, e) => s + e.amount, 0);
	const netReceivable = Math.max(0, totalSale - refunds);
	const supplierRefunds = linked.filter((e) => e.type === "supplier_refund" && e.headId === headId).reduce((s, e) => s + e.amount, 0);
	const allocatedCost = headCostOf(entries, headId);
	const totalPurchase = Math.max(allocatedCost, booking?.totalCost || 0) - supplierRefunds;
	const originalCommission = booking?.commission || 0;
	let commission = originalCommission;
	if (booking && booking.agentId && booking.agentId !== "Direct" && booking.discountSettlement === "agent_commission") commission = Math.max(0, originalCommission - Math.min(originalCommission, bookingDiscount));
	const received = linked.filter((e) => e.type === "client_receive").reduce((s, e) => s + e.amount, 0);
	const supplierPaid = headSupplierPaid(entries, headId);
	const supplierRemaining = Math.max(0, Math.round(totalPurchase - supplierPaid));
	const allocatedPurchases = [];
	entries.forEach((e) => {
		if (e.type !== "purchase") return;
		purchaseAllocations(e).forEach((l) => {
			if (l.target === "head" && l.headId === headId) allocatedPurchases.push({
				entryId: e.id,
				date: e.date,
				supplier: e.referenceName || e.referenceId || "Supplier",
				service: e.serviceCategory || "Purchase",
				share: l.amount,
				ofTotal: e.amount
			});
		});
	});
	const memberList = members.map((c) => ({
		id: c.id,
		name: `${c.firstName} ${c.lastName}`.trim(),
		ageCategory: c.ageCategory,
		amount: c.amountDue,
		received: c.amountPaid,
		pending: Math.max(0, c.amountDue - c.amountPaid),
		status: c.paymentStatus
	}));
	const lead = members[0];
	return {
		headId,
		leadName: lead ? `${lead.firstName} ${lead.lastName}`.trim() : headId,
		members: members.length,
		perPerson,
		otherCosts,
		grossSale,
		discount: totalDiscount,
		totalSale,
		refunds,
		netReceivable,
		totalPurchase,
		commission,
		netProfit: netReceivable - totalPurchase - commission,
		received,
		outstanding: Math.max(0, netReceivable - received),
		supplierPaid,
		supplierRemaining,
		memberList,
		linked,
		allocatedPurchases
	};
}
// src/components/BookingViewDialog.tsx
function Kpi({ label, value, tone = "text-foreground" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border/60 bg-accent/10 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-1 text-sm font-semibold tabular-nums ${tone}`,
			children: value
		})]
	});
}
function Line({ label, value, sign = "", strong, tone = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between py-1.5 text-xs ${strong ? "border-t border-border/60 pt-2 text-sm font-bold" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: strong ? "" : "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `tabular-nums ${tone}`,
			children: [sign, formatCurrency(value)]
		})]
	});
}
/** Professional booking view: Members tab (per-person money) + Business Ledger tab (cost & profit). */
function BookingViewDialog({ headId, onClose }) {
	const store = useStore();
	const [tab, setTab] = (0, import_react.useState)("members");
	const booking = store.bookings.find((b) => b.headId === headId);
	const hb = (0, import_react.useMemo)(() => headId ? computeHeadBusiness(headId, store.clients, store.bookings, store.entries) : null, [
		headId,
		store.clients,
		store.bookings,
		store.entries
	]);
	if (!headId || !hb) return null;
	const linked = hb.linked;
	const gifts = linked.filter((e) => e.type === "gift" || e.type === "expense").reduce((s, e) => s + e.amount, 0);
	const agent = booking?.agentId ? store.agents.find((a) => a.id === booking.agentId) : null;
	const profit = hb.netProfit - gifts;
	const members = store.clients.filter((c) => c.headId === headId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!headId,
		onOpenChange: (o) => {
			if (!o) {
				onClose();
				setTab("members");
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90vh] max-w-3xl overflow-y-auto border-border bg-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex flex-wrap items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: headId
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-normal text-muted-foreground",
						children: [
							hb.leadName,
							" · ",
							booking?.packageType,
							" · ",
							booking?.travelDate,
							" · ",
							agent ? `Agent: ${agent.name}` : "Direct"
						]
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Net Receivable",
							value: formatCurrency(hb.netReceivable),
							tone: "text-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Received",
							value: formatCurrency(hb.received),
							tone: "text-success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Remaining",
							value: formatCurrency(hb.outstanding),
							tone: "text-destructive"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Net Profit",
							value: formatCurrency(profit),
							tone: profit >= 0 ? "text-success" : "text-destructive"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-1 rounded-lg border border-border bg-accent/10 p-1",
					children: ["members", "business"].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(t),
						className: `rounded-md py-2 text-xs font-semibold ${tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
						children: t === "members" ? `Member Details (${members.length})` : "Business Ledger"
					}, t))
				}),
				tab === "members" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [members.map((c) => {
						const refunds = store.entries.filter((e) => e.type === "client_refund" && e.clientId === c.id).reduce((s, e) => s + e.amount, 0);
						const charges = store.entries.filter((e) => e.type === "client_charge" && e.clientId === c.id).reduce((s, e) => s + e.amount, 0);
						const ledger = store.entries.filter((e) => (e.clientId === c.id || e.referenceId === c.id) && [
							"client_receive",
							"client_charge",
							"client_refund"
						].includes(e.type)).sort((a, b) => a.date.localeCompare(b.date));
						const remaining = Math.max(0, c.amountDue - c.amountPaid);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border/60 bg-accent/5 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										children: getClientName(c)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] text-muted-foreground",
										children: [
											c.id,
											" · ",
											c.ageCategory || "Adult",
											" · ",
											c.gender,
											" · ",
											c.passport || "No passport"
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full border px-2 py-0.5 text-[10px] ${c.paymentStatus === "Paid" ? "border-success/40 text-success" : c.paymentStatus === "Partial" ? "border-warning/40 text-warning" : "border-destructive/40 text-destructive"}`,
										children: c.paymentStatus
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Package (per person)",
									value: c.baseDue ?? c.amountDue
								}),
								charges > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Extra charges",
									value: charges,
									sign: "+ "
								}),
								refunds > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Refunds",
									value: refunds,
									sign: "− ",
									tone: "text-destructive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Total Amount",
									value: c.amountDue,
									strong: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Received",
									value: c.amountPaid,
									tone: "text-success"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Remaining",
									value: remaining,
									tone: remaining > 0 ? "text-destructive" : "text-success"
								}),
								ledger.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 border-t border-border/40 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-[10px] uppercase tracking-wider text-muted-foreground",
										children: "Ledger"
									}), ledger.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-[10px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												e.date,
												" · ",
												e.type === "client_receive" ? "Received" : e.type === "client_refund" ? "Refund" : e.chargeCategory || "Charge"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: e.type === "client_receive" ? "text-success" : e.type === "client_refund" ? "text-destructive" : "",
											children: formatCurrency(e.amount)
										})]
									}, e.id))]
								})
							]
						}, c.id);
					}), members.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-6 text-center text-xs text-muted-foreground",
						children: "No members yet."
					})]
				}),
				tab === "business" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-primary/30 bg-primary/5 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Profit & Loss"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: `Sale (${hb.members} × ${formatCurrency(hb.perPerson)})`,
								value: hb.totalSale - hb.otherCosts
							}),
							hb.otherCosts > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Extra charges",
								value: hb.otherCosts,
								sign: "+ "
							}),
							hb.refunds > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Client refunds",
								value: hb.refunds,
								sign: "− "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Net Sale",
								value: hb.netReceivable,
								strong: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Supplier purchases",
								value: hb.totalPurchase,
								sign: "− ",
								tone: "text-warning"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: `Agent commission${agent ? ` (${agent.name})` : ""}`,
								value: hb.commission,
								sign: "− ",
								tone: "text-warning"
							}),
							gifts > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Gifts & expenses",
								value: gifts,
								sign: "− ",
								tone: "text-warning"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Net Profit",
								value: profit,
								strong: true,
								tone: profit >= 0 ? "text-success" : "text-destructive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 border-t border-border/40 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Supplier paid",
									value: hb.supplierPaid,
									tone: "text-success"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Supplier remaining",
									value: hb.supplierRemaining,
									tone: "text-destructive"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border/60 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
								children: "Cost Entries"
							}),
							linked.filter((e) => [
								"purchase",
								"supplier_refund",
								"gift",
								"expense"
							].includes(e.type)).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between border-b border-border/30 py-1.5 text-[11px] last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: e.type === "purchase" ? `Purchase — ${e.referenceName}` : e.type === "supplier_refund" ? `Supplier refund — ${e.referenceName}` : e.note || e.referenceName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: [e.date, e.serviceCategory].filter(Boolean).join(" · ")
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: e.type === "supplier_refund" ? "text-success" : "text-warning",
									children: [
										e.type === "supplier_refund" ? "+" : "−",
										" ",
										formatCurrency(e.amount)
									]
								})]
							}, e.id)),
							!linked.some((e) => [
								"purchase",
								"supplier_refund",
								"gift",
								"expense"
							].includes(e.type)) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-4 text-center text-[11px] text-muted-foreground",
								children: "No costs posted yet."
							})
						]
					})]
				})
			]
		})
	});
}
// src/routes/bookings.tsx?tsr-split=component
var emptyMember = {
	firstName: "",
	lastName: "",
	gender: "Male",
	ageCategory: "Adult",
	nationality: "",
	passport: "",
	cnic: "",
	dateOfBirth: "",
	dateOfIssue: "",
	dateOfExpire: "",
	phone: "",
	email: ""
};
function BookingsPage() {
	const store = useStore();
	const [viewHead, setViewHead] = (0, import_react.useState)(null);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [step, setStep] = (0, import_react.useState)(1);
	const [memberEditOpen, setMemberEditOpen] = (0, import_react.useState)(false);
	const [memberEdit, setMemberEdit] = (0, import_react.useState)(null);
	const [tabFilter, setTabFilter] = (0, import_react.useState)("active");
	const [lossDealsOnly, setLossDealsOnly] = (0, import_react.useState)(false);
	const [sortKey, setSortKey] = (0, import_react.useState)("date_desc");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const today = getPKTDate();
	const activeBookings = (0, import_react.useMemo)(() => store.bookings.filter((b) => !b.serviceCompleted), [store.bookings]);
	const completedBookings = (0, import_react.useMemo)(() => store.bookings.filter((b) => b.serviceCompleted), [store.bookings]);
	const activeCount = activeBookings.length;
	const completedCount = completedBookings.length;
	const allCount = store.bookings.length;
	const lossDealsCount = (0, import_react.useMemo)(() => {
		return store.bookings.filter((b) => computeBookingFinancials(b).isLoss).length;
	}, [store.bookings]);
	const filteredAndSortedBookings = (0, import_react.useMemo)(() => {
		const list = store.bookings.filter((b) => {
			if (tabFilter === "active" && b.serviceCompleted) return false;
			if (tabFilter === "completed" && !b.serviceCompleted) return false;
			if (lossDealsOnly) {
				if (!computeBookingFinancials(b).isLoss) return false;
			}
			if (searchQuery.trim()) {
				const q = searchQuery.toLowerCase().trim();
				const headMatch = b.headId.toLowerCase().includes(q);
				const pkgMatch = b.packageType.toLowerCase().includes(q);
				const agentMatch = b.agentId?.toLowerCase().includes(q) || false;
				const destMatch = b.destination?.toLowerCase().includes(q) || false;
				const clientMatch = store.clients.filter((c) => c.headId === b.headId).some((c) => `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) || c.passport && c.passport.toLowerCase().includes(q));
				if (!headMatch && !pkgMatch && !agentMatch && !destMatch && !clientMatch) return false;
			}
			return true;
		});
		return sortEntities(list, sortKey, {
			date: (b) => b.travelDate || b.createdAt,
			amount: (b) => b.totalAmount,
			name: (b) => b.headId
		});
	}, [
		store.bookings,
		store.clients,
		tabFilter,
		lossDealsOnly,
		sortKey,
		searchQuery
	]);
	const [form, setForm] = (0, import_react.useState)({
		agentId: "",
		supplierId: "",
		totalAmount: "",
		amountReceived: "",
		totalCost: "",
		commission: "",
		discount: "",
		discountSettlement: "agent_commission",
		supplierDiscount: "",
		packageType: "Umrah",
		status: "Pending",
		travelDate: "",
		adults: "1",
		children: "0",
		infants: "0",
		destination: "",
		driveLink: "",
		pricingMode: "total",
		adultPrice: "",
		childPrice: "",
		infantPrice: ""
	});
	const [memberForms, setMemberForms] = (0, import_react.useState)([]);
	const [memberIndex, setMemberIndex] = (0, import_react.useState)(0);
	const [groupMode, setGroupMode] = (0, import_react.useState)("none");
	const [groupId, setGroupId] = (0, import_react.useState)("");
	const [newGroup, setNewGroup] = (0, import_react.useState)({
		name: "",
		pnr: "",
		flightNumber: "",
		date: "",
		description: "",
		totalPax: ""
	});
	function resetForm() {
		setForm({
			agentId: "",
			supplierId: "",
			totalAmount: "",
			amountReceived: "",
			totalCost: "",
			commission: "",
			discount: "",
			discountSettlement: "agent_commission",
			supplierDiscount: "",
			packageType: "Umrah",
			status: "Pending",
			travelDate: "",
			adults: "1",
			children: "0",
			infants: "0",
			destination: "",
			driveLink: "",
			pricingMode: "total",
			adultPrice: "",
			childPrice: "",
			infantPrice: ""
		});
		setMemberForms([]);
		setMemberIndex(0);
		setStep(1);
		setGroupMode("none");
		setGroupId("");
		setNewGroup({
			name: "",
			pnr: "",
			flightNumber: "",
			date: "",
			description: "",
			totalPax: ""
		});
	}
	function goToStep2() {
		const adults = Math.max(0, Number(form.adults) || 0);
		const children = Math.max(0, Number(form.children) || 0);
		const infants = Math.max(0, Number(form.infants) || 0);
		const total = Math.max(1, adults + children + infants);
		const built = [];
		for (let i = 0; i < total; i++) {
			const existing = memberForms[i];
			const category = i < adults ? "Adult" : i < adults + children ? "Child" : "Infant";
			built.push(existing ? {
				...existing,
				ageCategory: category
			} : {
				...emptyMember,
				ageCategory: category
			});
		}
		setMemberForms(built);
		setMemberIndex(0);
		setStep(2);
	}
	function updateMember(index, field, value) {
		const arr = [...memberForms];
		arr[index] = {
			...arr[index],
			[field]: value
		};
		if (index === 0) {
			if ([
				"nationality",
				"phone",
				"email"
			].includes(field)) {
				for (let i = 1; i < arr.length; i++) if (!arr[i][field]) arr[i] = {
					...arr[i],
					[field]: value
				};
			}
		}
		setMemberForms(arr);
	}
	function handleAdd() {
		const headId = store.generateHeadId();
		const today = getPKTDate();
		const adultsCount = memberForms.filter((m) => m.ageCategory === "Adult").length;
		const childrenCount = memberForms.filter((m) => m.ageCategory === "Child").length;
		const infantsCount = memberForms.filter((m) => m.ageCategory === "Infant").length;
		const childPrice = Number(form.childPrice) || 0;
		const infantPrice = Number(form.infantPrice) || 0;
		let adultPrice = 0;
		let computedTotal = 0;
		if (form.pricingMode === "per_person") {
			adultPrice = Number(form.adultPrice) || 0;
			computedTotal = adultPrice * adultsCount + childPrice * childrenCount + infantPrice * infantsCount;
		} else {
			const totalEntered = Number(form.totalAmount) || 0;
			const adultPortion = Math.max(0, totalEntered - childPrice * childrenCount - infantPrice * infantsCount);
			adultPrice = adultsCount > 0 ? Math.round(adultPortion / adultsCount) : 0;
			computedTotal = totalEntered;
		}
		let finalGroupId = groupMode === "existing" ? groupId || void 0 : void 0;
		if (groupMode === "new" && newGroup.name.trim()) finalGroupId = store.addGroup({
			name: newGroup.name.trim(),
			category: "Booking",
			supplierId: form.supplierId || void 0,
			pnr: newGroup.pnr || void 0,
			flightNumber: newGroup.flightNumber || void 0,
			date: newGroup.date || form.travelDate || void 0,
			description: newGroup.description || void 0,
			totalPax: newGroup.totalPax ? Number(newGroup.totalPax) : void 0
		});
		const custDiscount = Number(form.discount) || 0;
		const grossTotal = computedTotal;
		const netCustomerTotal = Math.max(0, grossTotal - custDiscount);
		const bookingId = store.addBooking({
			headId,
			agentId: form.agentId,
			supplierId: form.supplierId,
			baseAmount: grossTotal,
			totalAmount: netCustomerTotal,
			amountReceived: Number(form.amountReceived) || 0,
			totalCost: Number(form.totalCost) || 0,
			commission: Number(form.commission) || 0,
			discount: custDiscount,
			discountSettlement: form.discountSettlement,
			supplierDiscount: Number(form.supplierDiscount) || 0,
			clientIds: [],
			status: form.status,
			packageType: form.packageType,
			travelDate: form.travelDate,
			createdAt: today,
			members: memberForms.length,
			destination: form.destination,
			driveLink: form.driveLink,
			groupId: finalGroupId
		});
		const clientIds = [];
		const membersCount = memberForms.length || 1;
		const childTotal = childPrice * childrenCount;
		const infantTotal = infantPrice * infantsCount;
		const adultNetPortion = Math.max(0, netCustomerTotal - childTotal - infantTotal);
		const adultNetPrice = adultsCount > 0 ? Math.floor(adultNetPortion / adultsCount) : 0;
		const adultRemainder = adultsCount > 0 ? adultNetPortion - adultNetPrice * adultsCount : 0;
		let adultIdx = 0;
		memberForms.forEach((m, i) => {
			let due = 0;
			let baseDue = 0;
			if (m.ageCategory === "Child") {
				due = childPrice;
				baseDue = childPrice;
			} else if (m.ageCategory === "Infant") {
				due = infantPrice;
				baseDue = infantPrice;
			} else {
				due = adultNetPrice + (adultIdx === 0 ? adultRemainder : 0);
				baseDue = adultPrice;
				adultIdx++;
			}
			if (adultsCount === 0) {
				const perMember = Math.floor(netCustomerTotal / membersCount);
				const rem = netCustomerTotal - perMember * membersCount;
				due = perMember + (i === 0 ? rem : 0);
				baseDue = Math.floor(grossTotal / membersCount);
			}
			const cid = store.addClient({
				headId,
				firstName: m.firstName || `Member`,
				lastName: m.lastName || `${i + 1}`,
				gender: m.gender,
				ageCategory: m.ageCategory,
				nationality: m.nationality || memberForms[0]?.nationality || "",
				passport: m.passport,
				cnic: m.cnic,
				dateOfBirth: m.dateOfBirth,
				dateOfIssue: m.dateOfIssue,
				dateOfExpire: m.dateOfExpire,
				phone: m.phone || memberForms[0]?.phone || "",
				email: m.email || memberForms[0]?.email || "",
				packageType: form.packageType,
				paymentStatus: "Unpaid",
				baseDue,
				amountDue: due,
				amountPaid: 0,
				isVip: false,
				destination: form.destination,
				driveLink: form.driveLink
			});
			clientIds.push(cid);
		});
		store.updateBooking(bookingId, { clientIds });
		if (Number(form.amountReceived) > 0) store.addEntry({
			date: today,
			type: "client_receive",
			headId,
			referenceId: headId,
			referenceName: `Booking ${headId}`,
			amount: Number(form.amountReceived),
			note: `Initial payment for ${headId}`
		});
		if (Number(form.totalCost) > 0 && form.supplierId) {
			const supplier = store.suppliers.find((s) => s.id === form.supplierId);
			store.addEntry({
				date: today,
				type: "supplier_payment",
				headId,
				referenceId: form.supplierId,
				referenceName: supplier?.companyName || form.supplierId,
				amount: Number(form.totalCost),
				note: `Supplier cost for ${headId}`
			});
		}
		if (Number(form.commission) > 0 && form.agentId && form.agentId !== "Direct") {
			const agent = store.agents.find((a) => a.id === form.agentId);
			if (agent) store.updateAgent(agent.id, {
				totalSales: agent.totalSales + (Number(form.totalAmount) || 0),
				totalClients: agent.totalClients + memberForms.length,
				commission: agent.commission + (Number(form.commission) || 0)
			});
		}
		if (Number(form.totalCost) > 0 && form.supplierId) {
			const supplier = store.suppliers.find((s) => s.id === form.supplierId);
			if (supplier) store.updateSupplier(supplier.id, { totalPayable: supplier.totalPayable + (Number(form.totalCost) || 0) });
		}
		resetForm();
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		const headId = selected.headId;
		const wanted = {
			Adult: Math.max(0, Number(form.adults) || 0),
			Child: Math.max(0, Number(form.children) || 0),
			Infant: Math.max(0, Number(form.infants) || 0)
		};
		[
			"Adult",
			"Child",
			"Infant"
		].forEach((cat) => {
			const existing = store.clients.filter((c) => c.headId === headId && (c.ageCategory || "Adult") === cat);
			if (existing.length > wanted[cat]) existing.slice(wanted[cat]).forEach((c) => store.deleteClient(c.id));
			else if (existing.length < wanted[cat]) {
				const lead = store.clients.find((c) => c.headId === headId);
				for (let i = existing.length; i < wanted[cat]; i++) store.addClient({
					headId,
					firstName: cat,
					lastName: String(i + 1),
					gender: "Male",
					ageCategory: cat,
					nationality: lead?.nationality || "",
					passport: "",
					cnic: "",
					dateOfBirth: "",
					dateOfIssue: "",
					dateOfExpire: "",
					phone: lead?.phone || "",
					email: lead?.email || "",
					packageType: form.packageType,
					paymentStatus: "Unpaid",
					amountDue: 0,
					amountPaid: 0,
					isVip: false,
					destination: form.destination,
					driveLink: form.driveLink
				});
			}
		});
		const cs = store.clients.filter((c) => c.headId === headId);
		const adults = cs.filter((c) => (c.ageCategory || "Adult") === "Adult");
		const children = cs.filter((c) => c.ageCategory === "Child");
		const infants = cs.filter((c) => c.ageCategory === "Infant");
		const childPrice = Number(form.childPrice) || 0;
		const infantPrice = Number(form.infantPrice) || 0;
		let adultPrice = 0;
		let computedTotal = 0;
		if (form.pricingMode === "per_person") {
			adultPrice = Number(form.adultPrice) || 0;
			computedTotal = adultPrice * adults.length + childPrice * children.length + infantPrice * infants.length;
		} else {
			computedTotal = Number(form.totalAmount) || 0;
			const rem = Math.max(0, computedTotal - childPrice * children.length - infantPrice * infants.length);
			adultPrice = adults.length > 0 ? Math.round(rem / adults.length) : 0;
		}
		let finalGroupId = groupMode === "existing" ? groupId || void 0 : groupMode === "none" ? void 0 : selected.groupId;
		if (groupMode === "new" && newGroup.name.trim()) finalGroupId = store.addGroup({
			name: newGroup.name.trim(),
			category: "Booking",
			supplierId: form.supplierId || void 0,
			pnr: newGroup.pnr || void 0,
			flightNumber: newGroup.flightNumber || void 0,
			date: newGroup.date || form.travelDate || void 0,
			description: newGroup.description || void 0,
			totalPax: newGroup.totalPax ? Number(newGroup.totalPax) : void 0
		});
		const custDiscount = Number(form.discount) || 0;
		const grossTotal = computedTotal;
		const netCustomerTotal = Math.max(0, grossTotal - custDiscount);
		store.updateBooking(selected.id, {
			agentId: form.agentId,
			supplierId: form.supplierId,
			baseAmount: grossTotal,
			totalAmount: netCustomerTotal,
			amountReceived: Number(form.amountReceived) || 0,
			totalCost: Number(form.totalCost) || 0,
			commission: Number(form.commission) || 0,
			discount: custDiscount,
			discountSettlement: form.discountSettlement,
			supplierDiscount: Number(form.supplierDiscount) || 0,
			packageType: form.packageType,
			status: form.status,
			travelDate: form.travelDate,
			destination: form.destination,
			driveLink: form.driveLink,
			groupId: finalGroupId,
			members: cs.length,
			clientIds: cs.map((c) => c.id)
		});
		const childTotal = childPrice * children.length;
		const infantTotal = infantPrice * infants.length;
		const adultNetPortion = Math.max(0, netCustomerTotal - childTotal - infantTotal);
		const adultNetPrice = adults.length > 0 ? Math.floor(adultNetPortion / adults.length) : 0;
		const adultRemainder = adults.length > 0 ? adultNetPortion - adultNetPrice * adults.length : 0;
		let remaining = Number(form.amountReceived) || 0;
		const ordered = [
			...adults,
			...children,
			...infants
		];
		let adultIdx = 0;
		ordered.forEach((c, idx) => {
			let due = 0;
			let baseDue = 0;
			if (c.ageCategory === "Child") {
				due = childPrice;
				baseDue = childPrice;
			} else if (c.ageCategory === "Infant") {
				due = infantPrice;
				baseDue = infantPrice;
			} else {
				due = adultNetPrice + (adultIdx === 0 ? adultRemainder : 0);
				baseDue = adultPrice;
				adultIdx++;
			}
			if (adults.length === 0) {
				const perMember = Math.floor(netCustomerTotal / (ordered.length || 1));
				const rem = netCustomerTotal - perMember * (ordered.length || 1);
				due = perMember + (idx === 0 ? rem : 0);
				baseDue = Math.floor(grossTotal / (ordered.length || 1));
			}
			let paid = 0;
			let status = "Unpaid";
			if (due <= 0) {
				paid = 0;
				status = "Paid";
			} else if (remaining >= due) {
				paid = due;
				remaining -= due;
				status = "Paid";
			} else if (remaining > 0) {
				paid = remaining;
				remaining = 0;
				status = "Partial";
			}
			store.updateClient(c.id, {
				baseDue: c.baseDue ?? baseDue,
				amountDue: due,
				amountPaid: paid,
				paymentStatus: status,
				packageType: form.packageType,
				destination: form.destination
			});
		});
		setEditOpen(false);
	}
	function openEdit(b) {
		const cs = store.clients.filter((c) => c.headId === b.headId);
		const adults = cs.filter((c) => (c.ageCategory || "Adult") === "Adult");
		const children = cs.filter((c) => c.ageCategory === "Child");
		const infants = cs.filter((c) => c.ageCategory === "Infant");
		setSelected(b);
		const grossSale = b.baseAmount ?? (b.discount ? b.totalAmount + b.discount : b.totalAmount);
		setForm({
			agentId: b.agentId,
			supplierId: b.supplierId,
			totalAmount: String(grossSale),
			amountReceived: String(b.amountReceived),
			totalCost: String(b.totalCost || 0),
			commission: String(b.commission || 0),
			discount: b.discount ? String(b.discount) : "",
			discountSettlement: b.discountSettlement || "agent_commission",
			supplierDiscount: b.supplierDiscount ? String(b.supplierDiscount) : "",
			packageType: b.packageType,
			status: b.status,
			travelDate: b.travelDate,
			adults: String(adults.length || b.members || 1),
			children: String(children.length),
			infants: String(infants.length),
			pricingMode: "total",
			adultPrice: String(adults[0]?.baseDue ?? adults[0]?.amountDue ?? 0),
			childPrice: String(children[0]?.baseDue ?? children[0]?.amountDue ?? 0),
			infantPrice: String(infants[0]?.baseDue ?? infants[0]?.amountDue ?? 0),
			destination: b.destination || "",
			driveLink: b.driveLink || ""
		});
		if (b.groupId) {
			setGroupMode("existing");
			setGroupId(b.groupId);
		} else {
			setGroupMode("none");
			setGroupId("");
		}
		setNewGroup({
			name: "",
			pnr: "",
			flightNumber: "",
			date: "",
			description: "",
			totalPax: ""
		});
		setEditOpen(true);
	}
	function downloadInvoice(b) {
		const clients = store.clients.filter((c) => c.headId === b.headId);
		const agent = store.agents.find((a) => a.id === b.agentId);
		const supplier = store.suppliers.find((s) => s.id === b.supplierId);
		generateInvoice(b, clients, agent, supplier);
	}
	function downloadPaymentHistory(b) {
		const fin = computeBookingFinancials(b);
		const related = store.entries.filter((e) => e.headId === b.headId && e.type === "client_receive");
		const totalReceived = related.reduce((s, e) => s + e.amount, 0);
		const stats = [[
			"Gross Package Price",
			formatCurrency(fin.grossSale),
			"ink"
		]];
		if (fin.discount > 0) {
			stats.push([
				"Client Discount",
				`-${formatCurrency(fin.discount)}`,
				"destructive"
			]);
			stats.push([
				"Net Customer Due",
				formatCurrency(fin.clientPayable),
				"ink"
			]);
		}
		stats.push([
			"Received",
			formatCurrency(totalReceived),
			"success"
		]);
		stats.push([
			"Pending Balance",
			formatCurrency(Math.max(0, fin.clientPayable - totalReceived)),
			"destructive"
		]);
		generatePaymentHistory(`Booking ${b.headId}`, [
			["Head ID", b.headId],
			["Package", b.packageType],
			["Travel Date", b.travelDate],
			["Members", String(b.members)]
		], related, stats);
	}
	const step1Fields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 max-h-[55vh] overflow-y-auto pr-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Head ID will be auto-generated"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Agent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
					value: form.agentId,
					onChange: (v) => setForm({
						...form,
						agentId: v
					}),
					placeholder: "Select Agent or Direct",
					options: [{
						value: "Direct",
						label: "Direct (No Agent)"
					}, ...store.agents.map((a) => ({
						value: a.id,
						label: `${a.id} — ${a.name}`,
						hint: a.phone
					}))],
					className: "mt-1"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Supplier"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
					value: form.supplierId,
					onChange: (v) => setForm({
						...form,
						supplierId: v
					}),
					placeholder: "Select Supplier",
					options: store.suppliers.map((s) => ({
						value: s.id,
						label: `${s.id} — ${s.companyName}`,
						hint: s.serviceType
					})),
					className: "mt-1"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Package Type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.packageType,
					onValueChange: (v) => setForm({
						...form,
						packageType: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-8 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: PACKAGE_TYPES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p,
						children: p
					}, p)) })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Status"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.status,
					onValueChange: (v) => setForm({
						...form,
						status: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-8 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Pending",
							children: "Pending"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Confirmed",
							children: "Confirmed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Cancelled",
							children: "Cancelled"
						})
					] })]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Travel Date"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: form.travelDate,
						onChange: (e) => setForm({
							...form,
							travelDate: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Adults"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0",
						value: form.adults,
						onChange: (e) => setForm({
							...form,
							adults: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Children"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0",
						value: form.children,
						onChange: (e) => setForm({
							...form,
							children: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Infants"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0",
						value: form.infants,
						onChange: (e) => setForm({
							...form,
							infants: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border/50 p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs font-semibold",
							children: "Pricing Mode"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1 rounded-md bg-accent/20 p-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setForm({
									...form,
									pricingMode: "total"
								}),
								className: `px-3 py-1 text-[11px] rounded ${form.pricingMode === "total" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
								children: "Total Package"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setForm({
									...form,
									pricingMode: "per_person"
								}),
								className: `px-3 py-1 text-[11px] rounded ${form.pricingMode === "per_person" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
								children: "Per Person"
							})]
						})]
					}),
					form.pricingMode === "total" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Total Amount"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.totalAmount,
								onChange: (e) => setForm({
									...form,
									totalAmount: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Child Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.childPrice,
								onChange: (e) => setForm({
									...form,
									childPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Infant Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.infantPrice,
								onChange: (e) => setForm({
									...form,
									infantPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Adult Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.adultPrice,
								onChange: (e) => setForm({
									...form,
									adultPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Child Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.childPrice,
								onChange: (e) => setForm({
									...form,
									childPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Infant Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.infantPrice,
								onChange: (e) => setForm({
									...form,
									infantPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] })
						]
					}),
					(() => {
						const a = Math.max(0, Number(form.adults) || 0);
						const c = Math.max(0, Number(form.children) || 0);
						const inf = Math.max(0, Number(form.infants) || 0);
						const cp = Number(form.childPrice) || 0;
						const ip = Number(form.infantPrice) || 0;
						let adultEach = 0;
						let total = 0;
						if (form.pricingMode === "per_person") {
							adultEach = Number(form.adultPrice) || 0;
							total = adultEach * a + cp * c + ip * inf;
						} else {
							total = Number(form.totalAmount) || 0;
							const rem = Math.max(0, total - cp * c - ip * inf);
							adultEach = a > 0 ? Math.round(rem / a) : 0;
						}
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3 text-[10px] text-muted-foreground pt-1 border-t border-border/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Adult × ",
									a,
									" @ ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: formatCurrency(adultEach)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Child × ",
									c,
									" @ ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: formatCurrency(cp)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Infant × ",
									inf,
									" @ ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: formatCurrency(ip)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto font-semibold text-foreground",
									children: ["Total: ", formatCurrency(total)]
								})
							]
						});
					})(),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Amount Received (PKR)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: form.amountReceived,
						onChange: (e) => setForm({
							...form,
							amountReceived: e.target.value
						}),
						className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Total Cost (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.totalCost,
					onChange: (e) => setForm({
						...form,
						totalCost: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Commission (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.commission,
					onChange: (e) => setForm({
						...form,
						commission: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			(() => {
				const adultsCount = Math.max(0, Number(form.adults) || 0);
				const childrenCount = Math.max(0, Number(form.children) || 0);
				const infantsCount = Math.max(0, Number(form.infants) || 0);
				const cp = Number(form.childPrice) || 0;
				const ip = Number(form.infantPrice) || 0;
				let sale = 0;
				if (form.pricingMode === "per_person") sale = (Number(form.adultPrice) || 0) * adultsCount + cp * childrenCount + ip * infantsCount;
				else sale = Number(form.totalAmount) || 0;
				const custDiscount = Number(form.discount) || 0;
				const supDiscount = Number(form.supplierDiscount) || 0;
				const rawCost = Number(form.totalCost) || 0;
				const rawComm = Number(form.commission) || 0;
				const netCost = Math.max(0, rawCost - supDiscount);
				const isAgentBooking = Boolean(form.agentId && form.agentId !== "Direct");
				let agentAbsorbed = 0;
				let agencyAbsorbed = custDiscount;
				if (isAgentBooking && form.discountSettlement === "agent_commission") {
					agentAbsorbed = Math.min(rawComm, custDiscount);
					agencyAbsorbed = custDiscount - agentAbsorbed;
				}
				const netComm = Math.max(0, rawComm - agentAbsorbed);
				const netProfit = sale - agencyAbsorbed - netCost - netComm;
				const isLoss = netProfit < 0;
				const lossAmount = Math.abs(netProfit);
				const marginPct = sale > 0 ? netProfit / sale * 100 : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border/80 bg-gradient-to-b from-card/80 to-accent/10 p-3.5 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-border/40 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-foreground",
									children: "Discount & Margin Protection Engine"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: "Settle concessions from agent commission, capture supplier rebates, and isolate loss deals."
								})] })]
							}), isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-rose-500/15 border border-rose-500/40 px-2 py-0.5 text-[10px] font-bold text-rose-400 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3 w-3 text-rose-500 shrink-0" }), "Negative Margin"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-emerald-500/15 border border-emerald-500/40 px-2 py-0.5 text-[10px] font-semibold text-emerald-400 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3 w-3 text-emerald-400 shrink-0" }), "Protected Margin"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-[11px] font-medium flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Customer Concession (PKR)" }), custDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-amber-400 font-mono",
									children: ["-", formatCurrency(custDiscount)]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								value: form.discount,
								onChange: (e) => setForm({
									...form,
									discount: e.target.value
								}),
								placeholder: "e.g. 5000",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-[11px] font-medium flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Supplier Rebate / Disc (PKR)" }), supDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-emerald-400 font-mono",
									children: ["+", formatCurrency(supDiscount)]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								value: form.supplierDiscount,
								onChange: (e) => setForm({
									...form,
									supplierDiscount: e.target.value
								}),
								placeholder: "e.g. 3000",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						isAgentBooking && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border/50 bg-background/50 p-2.5 space-y-1.5 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold text-foreground",
										children: "Discount Settlement Method:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] text-muted-foreground font-mono",
										children: ["Agent Commission: ", formatCurrency(rawComm)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setForm({
											...form,
											discountSettlement: "agent_commission"
										}),
										className: `rounded-md p-2 text-left transition border text-[11px] ${form.discountSettlement === "agent_commission" ? "border-primary bg-primary/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/20 text-muted-foreground hover:bg-accent/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-foreground",
											children: "Settle from Agent Commission"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] text-muted-foreground",
											children: "Protects agency profit — agent absorbs concession."
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setForm({
											...form,
											discountSettlement: "agency_absorbed"
										}),
										className: `rounded-md p-2 text-left transition border text-[11px] ${form.discountSettlement === "agency_absorbed" ? "border-amber-500 bg-amber-500/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/20 text-muted-foreground hover:bg-accent/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-foreground",
											children: "Agency Absorbs Concession"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] text-muted-foreground",
											children: "Agency absorbs full discount; agent keeps commission."
										})]
									})]
								}),
								custDiscount > 0 && form.discountSettlement === "agent_commission" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-blue-400 font-medium",
									children: [
										"🛡️ Agent absorbs ",
										formatCurrency(agentAbsorbed),
										" · Agent net commission becomes ",
										formatCurrency(netComm),
										agencyAbsorbed > 0 && ` (Agency absorbs remaining ${formatCurrency(agencyAbsorbed)})`
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-lg p-2.5 space-y-1.5 ${isLoss ? "border border-rose-500/60 bg-rose-500/10 text-rose-200" : "border border-emerald-500/30 bg-emerald-500/10 text-emerald-200"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex items-center gap-1.5",
										children: isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-4 w-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-400",
											children: "NEGATIVE MARGIN LOSS DEAL"
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-emerald-400",
											children: "Projected Agency Net Margin"
										})] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `font-mono text-sm font-bold ${isLoss ? "text-rose-400" : "text-emerald-400"}`,
										children: [isLoss ? `-${formatCurrency(lossAmount)}` : formatCurrency(netProfit), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] ml-1 font-normal",
											children: [
												"(",
												marginPct.toFixed(1),
												"%)"
											]
										})]
									})]
								}),
								isLoss && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-rose-300 font-medium",
									children: [
										"⚠️ Alert: Costs (",
										formatCurrency(netCost),
										") and Agent Commission (",
										formatCurrency(netComm),
										") exceed the discounted sale price (",
										formatCurrency(sale - agencyAbsorbed),
										")!"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2 text-[10px] text-muted-foreground border-t border-border/30 pt-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Sale: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: formatCurrency(sale)
										})] }),
										custDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Disc: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
											className: "text-amber-400",
											children: ["-", formatCurrency(custDiscount)]
										})] }),
										supDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Sup Rebate: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
											className: "text-emerald-400",
											children: ["+", formatCurrency(supDiscount)]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Net Cost: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: formatCurrency(netCost)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Net Comm: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: formatCurrency(netComm)
										})] })
									]
								})
							]
						})
					]
				});
			})(),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Destination"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.destination,
				onChange: (e) => setForm({
					...form,
					destination: e.target.value
				}),
				placeholder: "Makkah / Madinah",
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Google Drive Link (optional)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.driveLink,
				onChange: (e) => setForm({
					...form,
					driveLink: e.target.value
				}),
				placeholder: "https://drive.google.com/...",
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-primary/40 bg-primary/5 p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
							children: "Group / PNR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted-foreground",
							children: "Link this booking to a shared supplier batch (flight PNR, hotel rooming, etc.)"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1 text-[10px]",
							children: [
								"none",
								"existing",
								"new"
							].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setGroupMode(m),
								className: `rounded px-2 py-1 font-medium transition ${groupMode === m ? "bg-primary text-primary-foreground" : "bg-accent/40 text-muted-foreground hover:bg-accent/60"}`,
								children: m === "none" ? "No Group" : m === "existing" ? "Add to Group" : "+ New Group"
							}, m))
						})]
					}),
					groupMode === "existing" && (() => {
						const list = form.supplierId ? store.groups.filter((g) => !g.supplierId || g.supplierId === form.supplierId) : store.groups;
						const requested = Math.max(1, (Number(form.adults) || 0) + (Number(form.children) || 0) + (Number(form.infants) || 0));
						const selected = list.find((g) => g.id === groupId);
						const used = selected ? computeGroupUsedPax(selected.id) : 0;
						const remaining = selected?.totalPax != null ? Math.max(0, selected.totalPax - used) : null;
						const overflow = selected?.totalPax != null && used + requested > selected.totalPax;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
								value: groupId,
								onChange: setGroupId,
								placeholder: list.length ? "Select existing group..." : "No groups yet — create a new one",
								options: list.map((g) => {
									const u = computeGroupUsedPax(g.id);
									const cap = g.totalPax != null ? ` · ${u}/${g.totalPax} used` : ` · ${u} used`;
									return {
										value: g.id,
										label: `${g.id} — ${g.name}`,
										hint: [
											g.category,
											g.pnr && `PNR ${g.pnr}`,
											g.flightNumber,
											g.date
										].filter(Boolean).join(" · ") + cap
									};
								}),
								className: "mt-1"
							}), selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex flex-wrap items-center gap-3 rounded-md px-3 py-2 text-[11px] ${overflow ? "bg-destructive/15 text-destructive" : "bg-accent/20 text-foreground"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Capacity:" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: selected.totalPax ?? "∞"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: ["Used: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: used
										})]
									}),
									remaining !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: ["Remaining: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: overflow ? "text-destructive" : "text-success",
											children: remaining
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-auto text-muted-foreground",
										children: ["This booking: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: requested
										})]
									}),
									overflow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-full font-semibold",
										children: "⚠ Exceeds group capacity"
									})
								]
							})]
						});
					})(),
					groupMode === "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Group Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: newGroup.name,
									onChange: (e) => setNewGroup({
										...newGroup,
										name: e.target.value
									}),
									placeholder: "Umrah Group Feb-26 / PK-234",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Total Persons (capacity)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "0",
									value: newGroup.totalPax,
									onChange: (e) => setNewGroup({
										...newGroup,
										totalPax: e.target.value
									}),
									placeholder: "e.g. 30",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "PNR"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newGroup.pnr,
										onChange: (e) => setNewGroup({
											...newGroup,
											pnr: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Flight / Ref #"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newGroup.flightNumber,
										onChange: (e) => setNewGroup({
											...newGroup,
											flightNumber: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: newGroup.date,
										onChange: (e) => setNewGroup({
											...newGroup,
											date: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Description"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: newGroup.description,
								onChange: (e) => setNewGroup({
									...newGroup,
									description: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] })
						]
					})
				]
			})
		]
	});
	const currentMember = memberForms[memberIndex];
	const step2Fields = currentMember ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 max-h-[55vh] overflow-y-auto pr-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between rounded-lg bg-accent/20 px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-semibold text-primary",
				children: [
					"Member ",
					memberIndex + 1,
					" of ",
					memberForms.length,
					" ",
					memberIndex === 0 && "(Head)"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1",
				children: memberForms.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-6 rounded-full ${i === memberIndex ? "bg-primary" : i < memberIndex ? "bg-primary/50" : "bg-border"}` }, i))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-border/50 p-3 space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Type"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: currentMember.ageCategory,
						onValueChange: (v) => updateMember(memberIndex, "ageCategory", v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "bg-accent/20 border-border mt-0.5 h-7 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Adult",
								children: "Adult"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Child",
								children: "Child"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Infant",
								children: "Infant"
							})
						] })]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Gender"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: currentMember.gender,
						onValueChange: (v) => updateMember(memberIndex, "gender", v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "bg-accent/20 border-border mt-0.5 h-7 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Male",
								children: "Male"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Female",
								children: "Female"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Custom",
								children: "Custom"
							})
						] })]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "First Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.firstName,
						onChange: (e) => updateMember(memberIndex, "firstName", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Last Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.lastName,
						onChange: (e) => updateMember(memberIndex, "lastName", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Nationality"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.nationality,
						onChange: (e) => updateMember(memberIndex, "nationality", e.target.value),
						placeholder: memberIndex > 0 ? "Auto from Member 1" : "e.g. Pakistani",
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Date of Birth"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: currentMember.dateOfBirth,
						onChange: (e) => updateMember(memberIndex, "dateOfBirth", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Passport Number"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.passport,
						onChange: (e) => updateMember(memberIndex, "passport", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "CNIC"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.cnic,
						onChange: (e) => updateMember(memberIndex, "cnic", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Date of Issue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: currentMember.dateOfIssue,
						onChange: (e) => updateMember(memberIndex, "dateOfIssue", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Date of Expire"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: currentMember.dateOfExpire,
						onChange: (e) => updateMember(memberIndex, "dateOfExpire", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Contact"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.phone,
						onChange: (e) => updateMember(memberIndex, "phone", e.target.value),
						placeholder: memberIndex > 0 ? "Auto from Member 1" : "",
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.email,
						onChange: (e) => updateMember(memberIndex, "email", e.target.value),
						placeholder: memberIndex > 0 ? "Auto from Member 1" : "",
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				})
			]
		})]
	}) : null;
	const editFormFields = step1Fields;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingViewDialog, {
				headId: viewHead,
				onClose: () => setViewHead(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Bookings (Head IDs)",
				subtitle: "Master booking management",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: (o) => {
						setAddOpen(o);
						if (!o) resetForm();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: resetForm,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Booking"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border max-w-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [step === 1 ? "Step 1: Booking Details" : "Step 2: Member Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-muted-foreground",
								children: "(Head ID: Auto-generated)"
							})] }) }),
							step === 1 ? step1Fields : step2Fields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: goToStep2,
									className: "w-full",
									children: "Next → Member Details"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => {
										if (memberIndex === 0) setStep(1);
										else setMemberIndex(memberIndex - 1);
									},
									className: "flex-1",
									children: memberIndex === 0 ? "← Booking Details" : "← Previous Member"
								}), memberIndex < memberForms.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => setMemberIndex(memberIndex + 1),
									className: "flex-1",
									children: "Next Member →"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: handleAdd,
									className: "flex-1",
									children: "Create Booking"
								})] })
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupSeatStrip, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 p-1 bg-accent/20 rounded-xl border border-border/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTabFilter("active"),
							className: `px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${tabFilter === "active" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Active Bookings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `px-1.5 py-0.2 rounded-full text-[10px] font-mono ${tabFilter === "active" ? "bg-primary-foreground/20 text-primary-foreground" : "bg-accent text-muted-foreground"}`,
								children: activeCount
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTabFilter("completed"),
							className: `px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${tabFilter === "completed" ? "bg-emerald-600 text-white shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Completed / Fulfilled" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.2 rounded-full text-[10px] font-mono ${tabFilter === "completed" ? "bg-white/20 text-white" : "bg-accent text-muted-foreground"}`,
									children: completedCount
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTabFilter("all"),
							className: `px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${tabFilter === "all" ? "bg-accent text-foreground shadow-sm font-semibold" : "text-muted-foreground hover:text-foreground"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "All Records" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-muted-foreground font-mono",
								children: [
									"(",
									allCount,
									")"
								]
							})]
						}),
						lossDealsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLossDealsOnly((prev) => !prev),
							className: `px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 border ml-1 ${lossDealsOnly ? "bg-rose-500/25 text-rose-300 border-rose-500/60 shadow-sm" : "bg-background/40 text-rose-400 border-rose-500/30 hover:bg-rose-500/10"}`,
							title: "Filter to isolate negative-margin loss bookings immediately",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3.5 w-3.5 text-rose-500 animate-pulse" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Loss Deals" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.2 rounded-full text-[10px] font-mono ${lossDealsOnly ? "bg-rose-500 text-white" : "bg-rose-500/20 text-rose-400"}`,
									children: lossDealsCount
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-w-[200px] flex-1 sm:flex-initial",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Search ID, client, passport...",
							className: "h-8 pl-8 text-xs bg-background/50 border-border/60"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBar, {
						value: sortKey,
						onChange: setSortKey,
						label: "Sort by:"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Head ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Package"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Members"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Agent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Total"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Received"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Pending"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Profit Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Fulfillment"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Travel"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filteredAndSortedBookings.map((b) => {
							const pending = b.totalAmount - b.amountReceived;
							const clients = store.clients.filter((c) => c.headId === b.headId);
							computeBookingProfit(b);
							const isEarned = b.profitStatus === "earned";
							const isFulfilled = Boolean(b.serviceCompleted);
							const isPastTravel = Boolean(b.travelDate && b.travelDate < today);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 transition-colors hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold text-primary",
										children: b.headId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: b.packageType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: clients.length
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground",
										children: b.agentId || "Direct"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 font-mono",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: formatCurrency(b.totalAmount) }), b.discount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-amber-400 font-sans",
											children: ["Disc: -", formatCurrency(b.discount)]
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-success font-mono",
										children: formatCurrency(b.amountReceived)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-destructive font-mono",
										children: formatCurrency(pending)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: (() => {
											const fin = computeBookingFinancials(b);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col gap-1 items-start",
												children: [
													fin.isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono font-bold text-xs text-rose-400 flex items-center gap-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3 w-3 text-rose-500 shrink-0" }),
															"-",
															formatCurrency(fin.lossAmount)
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "rounded bg-rose-500/15 border border-rose-500/30 px-1.5 py-0.5 text-[9px] font-bold text-rose-400 uppercase tracking-wider",
														children: [
															"Loss Deal (",
															fin.marginPercent.toFixed(1),
															"%)"
														]
													})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-mono font-bold text-xs text-foreground",
														children: formatCurrency(fin.netProfit)
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-muted-foreground font-mono",
														children: [
															"(",
															fin.marginPercent.toFixed(1),
															"%)"
														]
													})] }),
													fin.discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-amber-400/90 font-mono",
														children: [
															"Disc: ",
															formatCurrency(fin.discount),
															" ",
															b.discountSettlement === "agent_commission" ? "(Agent)" : "(Agency)"
														]
													}),
													fin.supplierDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-emerald-400/90 font-mono",
														children: ["Rebate: +", formatCurrency(fin.supplierDiscount)]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => {
															store.toggleBookingProfitStatus(b.id);
															toast.success(isEarned ? `Reverted ${b.headId} to Unearned Profit` : `Converted ${b.headId} to Earned Actual Profit`);
														},
														className: `rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider transition ${isEarned ? "bg-success/20 text-success border border-success/40 hover:bg-success/30" : "bg-warning/20 text-warning border border-warning/40 hover:bg-warning/30"}`,
														title: "Click to toggle between Earned and Unearned",
														children: isEarned ? "✓ Earned" : "⏳ Unearned"
													})
												]
											});
										})()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: isFulfilled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold text-emerald-400 flex items-center gap-1 w-fit",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3 shrink-0" }), "Completed"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													store.toggleBookingCompleted(b.id);
													toast.success(`Reopened ${b.headId} back to Active Bookings`);
												},
												className: "text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 transition",
												title: "Reopen into Active bookings",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-2.5 w-2.5" }), " Reopen Active"]
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [isPastTravel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 text-[10px] font-bold text-amber-400 flex items-center gap-1 w-fit",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3 w-3 shrink-0" }), "Travelled"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded bg-accent/40 px-2 py-0.5 text-[10px] font-medium text-muted-foreground block w-fit",
												children: "Active Trip"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												variant: "outline",
												onClick: () => {
													store.toggleBookingCompleted(b.id);
													toast.success(`Marked ${b.headId} as Completed / Fulfilled`);
												},
												className: "h-6 px-2 text-[10px] gap-1 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-colors",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-2.5 w-2.5 text-emerald-500" }), "Mark Fulfilled"]
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: b.status })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground text-xs",
										children: b.travelDate
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setViewHead(b.headId),
													className: "rounded p-1 hover:bg-accent",
													title: "View booking",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3.5 w-3.5 text-primary" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => downloadInvoice(b),
													className: "rounded p-1 hover:bg-accent",
													title: "Download Invoice",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-3.5 w-3.5 text-success" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => downloadPaymentHistory(b),
													className: "rounded p-1 hover:bg-accent",
													title: "Payment History PDF",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingServicesMenu, {
													booking: b,
													clients
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoucherDownloadMenu, {
													booking: b,
													clients
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openEdit(b),
													className: "rounded p-1 hover:bg-accent",
													title: "Edit booking (completed bookings can be modified anytime)",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => store.deleteBooking(b.id),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
												})
											]
										})
									})
								]
							}, b.id);
						}), filteredAndSortedBookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 12,
							className: "px-4 py-8 text-center text-xs text-muted-foreground",
							children: tabFilter === "active" ? "No active departures found. All bookings are currently fulfilled or filtered." : tabFilter === "completed" ? "No completed / fulfilled bookings yet." : "No bookings match your current search and filters."
						}) })] })]
					})
				})
			}),
			filteredAndSortedBookings.map((b) => {
				const clients = store.clients.filter((c) => c.headId === b.headId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: b.headId
								}),
								" — Clients (",
								clients.length,
								")"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									"Supplier: ",
									b.supplierId,
									" | Destination: ",
									b.destination || "—"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								className: "h-7 gap-1 text-[11px]",
								onClick: () => {
									const head = store.clients.find((c) => c.headId === b.headId);
									setMemberEdit({
										id: "",
										headId: b.headId,
										firstName: "",
										lastName: "",
										gender: "Male",
										ageCategory: "Adult",
										nationality: head?.nationality || "",
										passport: "",
										cnic: "",
										dateOfBirth: "",
										dateOfIssue: "",
										dateOfExpire: "",
										phone: head?.phone || "",
										email: head?.email || "",
										packageType: b.packageType,
										paymentStatus: "Unpaid",
										amountDue: 0,
										amountPaid: 0,
										isVip: false,
										destination: b.destination
									});
									setMemberEditOpen(true);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Add Member"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setMemberEdit({ ...c });
								setMemberEditOpen(true);
							},
							className: "flex items-center justify-between rounded-lg border border-border/50 bg-accent/10 px-4 py-3 text-left transition-colors hover:bg-accent/30 hover:border-primary/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium truncate",
										children: getClientName(c)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[9px] px-1.5 py-0.5 rounded-full uppercase tracking-wide ${c.ageCategory === "Child" ? "bg-warning/20 text-warning" : c.ageCategory === "Infant" ? "bg-blue-500/20 text-blue-400" : "bg-primary/20 text-primary"}`,
										children: c.ageCategory || "Adult"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										c.id,
										" · ",
										c.passport || "—"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										formatCurrency(c.amountPaid),
										" / ",
										formatCurrency(c.amountDue)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })]
							})]
						}, c.id))
					})]
				}, b.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Booking — ", selected?.headId] }) }),
						editFormFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: memberEditOpen,
				onOpenChange: setMemberEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
							memberEdit && !memberEdit.id ? "Add New Member" : "Edit Member",
							memberEdit && memberEdit.id ? ` — ${getClientName(memberEdit)}` : "",
							memberEdit && memberEdit.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-muted-foreground",
								children: memberEdit.id
							})
						] }) }),
						memberEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 max-h-[60vh] overflow-y-auto pr-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: memberEdit.ageCategory || "Adult",
										onValueChange: (v) => setMemberEdit({
											...memberEdit,
											ageCategory: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Adult",
												children: "Adult"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Child",
												children: "Child"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Infant",
												children: "Infant"
											})
										] })]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Gender"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: memberEdit.gender,
										onValueChange: (v) => setMemberEdit({
											...memberEdit,
											gender: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Male",
												children: "Male"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Female",
												children: "Female"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Custom",
												children: "Custom"
											})
										] })]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "First Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.firstName,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											firstName: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Last Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.lastName,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											lastName: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Nationality"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.nationality,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											nationality: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date of Birth"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: memberEdit.dateOfBirth || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											dateOfBirth: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Passport"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.passport,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											passport: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "CNIC"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.cnic || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											cnic: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date of Issue"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: memberEdit.dateOfIssue || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											dateOfIssue: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date of Expire"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: memberEdit.dateOfExpire || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											dateOfExpire: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Contact"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.phone,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											phone: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.email || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											email: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Amount Due"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: memberEdit.amountDue,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											amountDue: Number(e.target.value) || 0
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Amount Paid"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: memberEdit.amountPaid,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											amountPaid: Number(e.target.value) || 0
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "vip",
										type: "checkbox",
										checked: memberEdit.isVip,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											isVip: e.target.checked
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "vip",
										className: "text-xs",
										children: "Mark as VIP"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								if (!memberEdit) return;
								const paid = memberEdit.amountPaid;
								const due = memberEdit.amountDue;
								const status = paid >= due && due > 0 ? "Paid" : paid > 0 ? "Partial" : "Unpaid";
								if (!memberEdit.id) {
									const { id: _omit, ...rest } = memberEdit;
									const newId = store.addClient({
										...rest,
										paymentStatus: status
									});
									const booking = store.bookings.find((bk) => bk.headId === memberEdit.headId);
									if (booking) store.updateBooking(booking.id, {
										clientIds: [...booking.clientIds, newId],
										members: (booking.members || booking.clientIds.length) + 1
									});
								} else store.updateClient(memberEdit.id, {
									...memberEdit,
									paymentStatus: status
								});
								setMemberEditOpen(false);
							},
							className: "w-full",
							children: "Save Member"
						})
					]
				})
			})
		]
	});
}
export { BookingsPage as component };
