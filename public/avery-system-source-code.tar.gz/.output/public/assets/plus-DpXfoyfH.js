import { g as createLucideIcon } from "./index-BgfHyeon.js";
// node_modules/lucide-react/dist/esm/icons/plus.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "plus",
	size: 24,
	node: [["path", {
		d: "M5 12h14",
		key: "1ays0h"
	}], ["path", {
		d: "M12 5v14",
		key: "s699le"
	}]]
};
__iconData.node;
var Plus = createLucideIcon(__iconData);
export { Plus as t };
