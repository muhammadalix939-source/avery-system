import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime, x as SERVICE_TYPES } from "./store-DLjJF6C7.js";
import { t as DetailDialog } from "./DetailDialog-BQz-pf5v.js";
import { t as Download } from "./download-CEfpC1QR.js";
import { t as Eye } from "./eye-CC3nCxz_.js";
import { t as Pencil } from "./pencil-B3wEbWek.js";
import { t as Plus } from "./plus-DpXfoyfH.js";
import { t as Trash } from "./trash-YMvfXcpp.js";
import { c as generateSupplierLedger } from "./pdf-S7DRzVmW.js";
import { n as PageHeader, r as motion } from "./clsx-Cbd36OJ7.js";
import { t as Button } from "./button-Z-9RZnLG.js";
import { t as Input } from "./input-mqPdBZ5K.js";
import { t as Label } from "./label-C_GFC7te.js";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-Bb6Qejxv.js";
import { t as StatusBadge } from "./StatusBadge-6vwJ3trL.js";
import { n as Checkbox, t as StatementDialog } from "./StatementDialog-C7VKb__5.js";
// src/routes/suppliers.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SuppliersPage() {
	const store = useStore();
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [detailOpen, setDetailOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [stmtOpen, setStmtOpen] = (0, import_react.useState)(false);
	const [stmtSupplier, setStmtSupplier] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		companyName: "",
		contactPerson: "",
		phone: "",
		email: "",
		serviceTypes: ["Hotel"],
		totalPayable: "",
		totalPaid: "",
		openingPayable: "",
		openingPaid: ""
	});
	const resetSupplierForm = () => setForm({
		companyName: "",
		contactPerson: "",
		phone: "",
		email: "",
		serviceTypes: ["Hotel"],
		totalPayable: "",
		totalPaid: "",
		openingPayable: "",
		openingPaid: ""
	});
	function toggleService(service) {
		const next = form.serviceTypes.includes(service) ? form.serviceTypes.filter((item) => item !== service) : [...form.serviceTypes, service];
		setForm({
			...form,
			serviceTypes: next.length ? next : [service]
		});
	}
	function handleAdd() {
		store.addSupplier({
			companyName: form.companyName,
			contactPerson: form.contactPerson,
			phone: form.phone,
			email: form.email,
			serviceType: form.serviceTypes.join(", "),
			totalPayable: Number(form.totalPayable) || 0,
			totalPaid: Number(form.totalPaid) || 0,
			openingPayable: Number(form.openingPayable) || 0,
			openingPaid: Number(form.openingPaid) || 0
		});
		resetSupplierForm();
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		store.updateSupplier(selected.id, {
			companyName: form.companyName,
			contactPerson: form.contactPerson,
			phone: form.phone,
			email: form.email,
			serviceType: form.serviceTypes.join(", "),
			totalPayable: Number(form.totalPayable) || 0,
			totalPaid: Number(form.totalPaid) || 0,
			openingPayable: Number(form.openingPayable) || 0,
			openingPaid: Number(form.openingPaid) || 0
		});
		setEditOpen(false);
	}
	function openEdit(s) {
		setSelected(s);
		setForm({
			companyName: s.companyName,
			contactPerson: s.contactPerson,
			phone: s.phone,
			email: s.email,
			serviceTypes: s.serviceType.split(",").map((item) => item.trim()).filter(Boolean),
			totalPayable: String(s.totalPayable),
			totalPaid: String(s.totalPaid),
			openingPayable: String(s.openingPayable || 0),
			openingPaid: String(s.openingPaid || 0)
		});
		setEditOpen(true);
	}
	function openStmt(s) {
		setStmtSupplier(s);
		setStmtOpen(true);
	}
	function downloadLedger(s, range) {
		const supplierEntries = store.entries.filter((e) => e.referenceId === s.id);
		generateSupplierLedger(s, supplierEntries, range);
	}
	const stmtGroups = stmtSupplier ? store.groups.filter((g) => !g.supplierId || g.supplierId === stmtSupplier.id).map((g) => ({
		id: g.id,
		label: `${g.id} — ${g.name}`,
		hint: [
			g.category,
			g.pnr && `PNR ${g.pnr}`,
			g.flightNumber,
			g.date
		].filter(Boolean).join(" · ")
	})) : [];
	const relatedEntries = selected ? store.entries.filter((e) => e.referenceId === selected.id) : [];
	const formFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Company Name"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.companyName,
				onChange: (e) => setForm({
					...form,
					companyName: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Contact Person"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.contactPerson,
				onChange: (e) => setForm({
					...form,
					contactPerson: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Phone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.phone,
					onChange: (e) => setForm({
						...form,
						phone: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.email,
					onChange: (e) => setForm({
						...form,
						email: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Service Types"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-2 gap-2 rounded-lg border border-border/50 bg-accent/10 p-3 sm:grid-cols-3",
				children: SERVICE_TYPES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: form.serviceTypes.includes(s),
						onCheckedChange: () => toggleService(s)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s })]
				}, s))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Total Payable (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.totalPayable,
					onChange: (e) => setForm({
						...form,
						totalPayable: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Total Paid (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.totalPaid,
					onChange: (e) => setForm({
						...form,
						totalPaid: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 border-t border-border/30 pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs text-warning",
					children: "Opening Payable (carry-forward)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.openingPayable,
					onChange: (e) => setForm({
						...form,
						openingPayable: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs text-warning",
					children: "Opening Paid"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.openingPaid,
					onChange: (e) => setForm({
						...form,
						openingPaid: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Supplier Management",
				subtitle: `${store.suppliers.length} suppliers`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: setAddOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: resetSupplierForm,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add Supplier"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add New Supplier" }) }),
							formFields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleAdd,
								className: "w-full",
								children: "Add Supplier"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Company"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Contact"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Service"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Payable"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Remaining"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: store.suppliers.map((s) => {
							const payable = s.totalPayable + (s.openingPayable || 0);
							const paid = s.totalPaid + (s.openingPaid || 0);
							const remaining = payable - paid;
							const status = remaining <= 0 ? "Paid" : paid > 0 ? "Partial" : "Unpaid";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 transition-colors hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold text-primary",
										children: s.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-medium",
										children: s.companyName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: s.contactPerson
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: s.phone
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: s.serviceType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatCurrency(payable) }), (s.openingPayable || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] text-muted-foreground",
											children: [
												"incl. ",
												formatCurrency(s.openingPayable || 0),
												" B/F"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 text-success",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatCurrency(paid) }), (s.openingPaid || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] text-muted-foreground",
											children: [
												"incl. ",
												formatCurrency(s.openingPaid || 0),
												" B/F"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-destructive",
										children: formatCurrency(remaining)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => {
														setSelected(s);
														setDetailOpen(true);
													},
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3.5 w-3.5 text-primary" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openStmt(s),
													className: "rounded p-1 hover:bg-accent",
													title: "Download Statement",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openEdit(s),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => store.deleteSupplier(s.id),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
												})
											]
										})
									})
								]
							}, s.id);
						}) })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-4 md:grid-cols-2",
				children: store.suppliers.map((s, i) => {
					const payable = s.totalPayable + (s.openingPayable || 0);
					const paid = s.totalPaid + (s.openingPaid || 0);
					const remaining = payable - paid;
					const paidPercent = payable > 0 ? Math.min(100, Math.round(paid / payable * 100)) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: i * .1 },
						className: "glass-card rounded-xl p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-semibold",
									children: s.companyName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: s.serviceType
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: s.id
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-2 h-2 overflow-hidden rounded-full bg-accent/30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-primary transition-all",
									style: { width: `${paidPercent}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2 border-t border-border/50 pt-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] uppercase text-muted-foreground",
											children: "Payable"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-primary",
											children: formatCurrency(payable)
										}),
										(s.openingPayable || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] text-muted-foreground",
											children: [
												"incl. ",
												formatCurrency(s.openingPayable || 0),
												" B/F"
											]
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] uppercase text-muted-foreground",
											children: "Paid"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-success",
											children: formatCurrency(paid)
										}),
										(s.openingPaid || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[9px] text-muted-foreground",
											children: [
												"incl. ",
												formatCurrency(s.openingPaid || 0),
												" B/F"
											]
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase text-muted-foreground",
										children: "Remaining"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold text-destructive",
										children: formatCurrency(remaining)
									})] })
								]
							})
						]
					}, s.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Supplier — ", selected?.id] }) }),
						formFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailDialog, {
				open: detailOpen,
				onOpenChange: setDetailOpen,
				type: "supplier",
				data: selected,
				entries: relatedEntries,
				allClients: store.clients,
				allBookings: store.bookings
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementDialog, {
				open: stmtOpen,
				onOpenChange: setStmtOpen,
				title: `Supplier Statement — ${stmtSupplier?.companyName || ""}`,
				subtitle: "Choose date range, all-time, or filter by group. Includes hotel/flight/visa/transport sections.",
				groups: stmtGroups,
				onDownload: (range) => stmtSupplier && downloadLedger(stmtSupplier, range)
			})
		]
	});
}
export { SuppliersPage as component };
