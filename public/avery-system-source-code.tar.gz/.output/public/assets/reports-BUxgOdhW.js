import { a as __toESM } from "./rolldown-runtime-DQp2zzRu.js";
import { A as require_react_dom, T as formatCurrency, a as useStore, j as require_react, k as require_jsx_runtime } from "./store-DLjJF6C7.js";
import { t as DollarSign } from "./dollar-sign-KRXdzSMz.js";
import { t as TrendingUp } from "./trending-up-CdHn1ffe.js";
import { g as createLucideIcon, i as Users, l as Receipt, m as BookOpen, r as Wallet } from "./index-BgfHyeon.js";
import { n as PageHeader, r as motion, t as clsx } from "./clsx-Cbd36OJ7.js";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-Bb6Qejxv.js";
import { a as topProfitableBookings, i as profitByPackage, n as expenseBreakdown, r as monthlyTrend, t as computeTotals } from "./reports-Fx3YLxZs.js";
import { $ as getValueByDataKey, A as selectAxisWithScale, B as useChartHeight, C as CartesianLabelListContextProvider, Ct as svgPropertiesAndEvents, D as arrayTooltipSearcher, E as Tooltip, Et as svgPropertiesNoEventsFromUnknown, F as Curve, G as useIsPanorama, H as useChartWidth, I as propsAreEqual, J as selectChartWidth, K as selectChartViewBox, L as setLegendSettings, M as selectUnfilteredCartesianItems, N as DefaultZIndexes, O as ZIndexLayer, P as selectChartDataWithIndexesIfNotInPanoramaPosition4, Q as getTooltipNameProp, R as setLegendSize, S as isClipDot, St as Surface, T as Cell, Tt as svgPropertiesNoEvents, U as useMargin, V as useChartLayout, W as ResponsiveContainer, X as getBandSizeOfAxis, Y as selectMargin, Z as getCateCoordinateOfLine, _ as useAnimationCallbacks, _t as isNumber, a as XAxis, at as useAppSelector, b as SetTooltipEntrySettings, bt as round, c as useNeedsClip, ct as adaptEventHandlers, d as useActiveTooltipDataPoints, dt as constant_default, et as isCategoricalAxis, f as usePlotArea, ft as useLegendPortal, g as AnimatedItems, gt as isNullish, h as RegisterGraphicalItemId, ht as interpolate, i as YAxis, it as useAppDispatch, j as selectTicksOfGraphicalItem, k as selectActiveTooltipIndex, l as SetErrorBarContext, lt as adaptEventsOfChild, m as SetCartesianGraphicalItem, mt as isOutsidePosition, n as BarChart, nt as selectLegendPayload, o as Bar, ot as getUniqPayload, p as Pie, pt as getCartesianPosition, q as selectChartHeight, r as CartesianChart, rt as createSelector, s as GraphicalItemClipPath, st as resolveDefaultProps, t as PieChart, tt as useElementOffset, u as CartesianGrid, ut as withPath, v as matchByIndex, vt as noop, w as LabelListFromLabelProp, wt as svgPropertiesAndEventsFromUnknown, x as Shape, xt as Layer, y as SetLegendPayload, yt as upperFirst, z as selectChartLayout } from "./PieChart-BN5tTl0f.js";
// node_modules/lucide-react/dist/esm/icons/activity.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$3 = {
	name: "activity",
	size: 24,
	node: [["path", {
		d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
		key: "169zse"
	}]]
};
__iconData$3.node;
var Activity = createLucideIcon(__iconData$3);
// node_modules/lucide-react/dist/esm/icons/award.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$2 = {
	name: "award",
	size: 24,
	node: [["path", {
		d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
		key: "1yiouv"
	}], ["circle", {
		cx: "12",
		cy: "8",
		r: "6",
		key: "1vp47v"
	}]]
};
__iconData$2.node;
var Award = createLucideIcon(__iconData$2);
// node_modules/lucide-react/dist/esm/icons/percent.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData$1 = {
	name: "percent",
	size: 24,
	node: [
		["line", {
			x1: "19",
			x2: "5",
			y1: "5",
			y2: "19",
			key: "1x9vlm"
		}],
		["circle", {
			cx: "6.5",
			cy: "6.5",
			r: "2.5",
			key: "4mh3h7"
		}],
		["circle", {
			cx: "17.5",
			cy: "17.5",
			r: "2.5",
			key: "1mdrzq"
		}]
	]
};
__iconData$1.node;
var Percent = createLucideIcon(__iconData$1);
// node_modules/lucide-react/dist/esm/icons/piggy-bank.mjs
/**
* @license lucide-react v1.61.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var __iconData = {
	name: "piggy-bank",
	size: 24,
	node: [
		["path", {
			d: "M11 17h3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a3.16 3.16 0 0 0 2-2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-1a5 5 0 0 0-2-4V3a4 4 0 0 0-3.2 1.6l-.3.4H11a6 6 0 0 0-6 6v1a5 5 0 0 0 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1z",
			key: "1piglc"
		}],
		["path", {
			d: "M16 10h.01",
			key: "1m94wz"
		}],
		["path", {
			d: "M2 8v1a2 2 0 0 0 2 2h1",
			key: "1env43"
		}]
	]
};
__iconData.node;
var PiggyBank = createLucideIcon(__iconData);
// node_modules/d3-shape/src/math.js
var cos = Math.cos;
var sin = Math.sin;
var sqrt = Math.sqrt;
var pi = Math.PI;
pi / 2;
var tau = 2 * pi;
// node_modules/d3-shape/src/symbol/circle.js
var circle_default = { draw(context, size) {
	const r = sqrt(size / pi);
	context.moveTo(r, 0);
	context.arc(0, 0, r, 0, tau);
} };
// node_modules/d3-shape/src/symbol/cross.js
var cross_default = { draw(context, size) {
	const r = sqrt(size / 5) / 2;
	context.moveTo(-3 * r, -r);
	context.lineTo(-r, -r);
	context.lineTo(-r, -3 * r);
	context.lineTo(r, -3 * r);
	context.lineTo(r, -r);
	context.lineTo(3 * r, -r);
	context.lineTo(3 * r, r);
	context.lineTo(r, r);
	context.lineTo(r, 3 * r);
	context.lineTo(-r, 3 * r);
	context.lineTo(-r, r);
	context.lineTo(-3 * r, r);
	context.closePath();
} };
// node_modules/d3-shape/src/symbol/diamond.js
var tan30 = sqrt(1 / 3);
var tan30_2 = tan30 * 2;
var diamond_default = { draw(context, size) {
	const y = sqrt(size / tan30_2);
	const x = y * tan30;
	context.moveTo(0, -y);
	context.lineTo(x, 0);
	context.lineTo(0, y);
	context.lineTo(-x, 0);
	context.closePath();
} };
// node_modules/d3-shape/src/symbol/square.js
var square_default = { draw(context, size) {
	const w = sqrt(size);
	const x = -w / 2;
	context.rect(x, x, w, w);
} };
// node_modules/d3-shape/src/symbol/star.js
var ka = .8908130915292852;
var kr = sin(pi / 10) / sin(7 * pi / 10);
var kx = sin(tau / 10) * kr;
var ky = -cos(tau / 10) * kr;
var star_default = { draw(context, size) {
	const r = sqrt(size * ka);
	const x = kx * r;
	const y = ky * r;
	context.moveTo(0, -r);
	context.lineTo(x, y);
	for (let i = 1; i < 5; ++i) {
		const a = tau * i / 5;
		const c = cos(a);
		const s = sin(a);
		context.lineTo(s * r, -c * r);
		context.lineTo(c * x - s * y, s * x + c * y);
	}
	context.closePath();
} };
// node_modules/d3-shape/src/symbol/triangle.js
var sqrt3 = sqrt(3);
var triangle_default = { draw(context, size) {
	const y = -sqrt(size / (sqrt3 * 3));
	context.moveTo(0, y * 2);
	context.lineTo(-sqrt3 * y, -y);
	context.lineTo(sqrt3 * y, -y);
	context.closePath();
} };
// node_modules/d3-shape/src/symbol/wye.js
var c = -.5;
var s = sqrt(3) / 2;
var k = 1 / sqrt(12);
var a = (k / 2 + 1) * 3;
var wye_default = { draw(context, size) {
	const r = sqrt(size / a);
	const x0 = r / 2, y0 = r * k;
	const x1 = x0, y1 = r * k + r;
	const x2 = -x1, y2 = y1;
	context.moveTo(x0, y0);
	context.lineTo(x1, y1);
	context.lineTo(x2, y2);
	context.lineTo(c * x0 - s * y0, s * x0 + c * y0);
	context.lineTo(c * x1 - s * y1, s * x1 + c * y1);
	context.lineTo(c * x2 - s * y2, s * x2 + c * y2);
	context.lineTo(c * x0 + s * y0, c * y0 - s * x0);
	context.lineTo(c * x1 + s * y1, c * y1 - s * x1);
	context.lineTo(c * x2 + s * y2, c * y2 - s * x2);
	context.closePath();
} };
// node_modules/d3-shape/src/symbol.js
function Symbol$1(type, size) {
	let context = null, path = withPath(symbol);
	type = typeof type === "function" ? type : constant_default(type || circle_default);
	size = typeof size === "function" ? size : constant_default(size === void 0 ? 64 : +size);
	function symbol() {
		let buffer;
		if (!context) context = buffer = path();
		type.apply(this, arguments).draw(context, +size.apply(this, arguments));
		if (buffer) return context = null, buffer + "" || null;
	}
	symbol.type = function(_) {
		return arguments.length ? (type = typeof _ === "function" ? _ : constant_default(_), symbol) : type;
	};
	symbol.size = function(_) {
		return arguments.length ? (size = typeof _ === "function" ? _ : constant_default(+_), symbol) : size;
	};
	symbol.context = function(_) {
		return arguments.length ? (context = _ == null ? null : _, symbol) : context;
	};
	return symbol;
}
// node_modules/recharts/es6/shape/Symbols.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var _excluded$4 = [
	"type",
	"size",
	"sizeType"
];
function _extends$6() {
	return _extends$6 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$6.apply(null, arguments);
}
function ownKeys$5(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$5(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$5(Object(t), !0).forEach(function(r) {
			_defineProperty$5(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$5(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$5(e, r, t) {
	return (r = _toPropertyKey$5(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$5(t) {
	var i = _toPrimitive$5(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$5(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$4(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose$4(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose$4(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
var symbolFactories = {
	symbolCircle: circle_default,
	symbolCross: cross_default,
	symbolDiamond: diamond_default,
	symbolSquare: square_default,
	symbolStar: star_default,
	symbolTriangle: triangle_default,
	symbolWye: wye_default
};
var RADIAN = Math.PI / 180;
var getSymbolFactory = (type) => {
	return symbolFactories["symbol".concat(upperFirst(type))] || circle_default;
};
var calculateAreaSize = (size, sizeType, type) => {
	if (sizeType === "area") return size;
	switch (type) {
		case "cross": return 5 * size * size / 9;
		case "diamond": return .5 * size * size / Math.sqrt(3);
		case "square": return size * size;
		case "star":
			var angle = 18 * RADIAN;
			return 1.25 * size * size * (Math.tan(angle) - Math.tan(angle * 2) * Math.tan(angle) ** 2);
		case "triangle": return Math.sqrt(3) * size * size / 4;
		case "wye": return (21 - 10 * Math.sqrt(3)) * size * size / 8;
		default: return Math.PI * size * size / 4;
	}
};
var registerSymbol = (key, factory) => {
	symbolFactories["symbol".concat(upperFirst(key))] = factory;
};
/**
* Renders a symbol from a set of predefined shapes.
*/
var Symbols = (_ref) => {
	var _ref$type = _ref.type, type = _ref$type === void 0 ? "circle" : _ref$type, _ref$size = _ref.size, size = _ref$size === void 0 ? 64 : _ref$size, _ref$sizeType = _ref.sizeType, sizeType = _ref$sizeType === void 0 ? "area" : _ref$sizeType;
	var props = _objectSpread$5(_objectSpread$5({}, _objectWithoutProperties$4(_ref, _excluded$4)), {}, {
		type,
		size,
		sizeType
	});
	var realType = "circle";
	if (typeof type === "string") realType = type;
	/**
	* Calculate the path of curve
	* @return {String} path
	*/
	var getPath = () => {
		var symbolFactory = getSymbolFactory(realType);
		var s = Symbol$1().type(symbolFactory).size(calculateAreaSize(size, sizeType, realType))();
		if (s === null) return;
		return s;
	};
	var className = props.className, cx = props.cx, cy = props.cy;
	var filteredProps = svgPropertiesAndEvents(props);
	if (isNumber(cx) && isNumber(cy) && isNumber(size)) return /*#__PURE__*/ import_react.createElement("path", _extends$6({}, filteredProps, {
		className: clsx("recharts-symbols", className),
		transform: "translate(".concat(cx, ", ").concat(cy, ")"),
		d: getPath()
	}));
	return null;
};
Symbols.registerSymbol = registerSymbol;
// node_modules/recharts/es6/component/DefaultLegendContent.js
function _extends$5() {
	return _extends$5 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$5.apply(null, arguments);
}
function ownKeys$4(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$4(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$4(Object(t), !0).forEach(function(r) {
			_defineProperty$4(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$4(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$4(e, r, t) {
	return (r = _toPropertyKey$4(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$4(t) {
	var i = _toPrimitive$4(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$4(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var SIZE = 32;
var defaultLegendContentDefaultProps = {
	align: "center",
	iconSize: 14,
	inactiveColor: "#ccc",
	layout: "horizontal",
	verticalAlign: "middle",
	labelStyle: {}
};
function getStrokeDasharray$1(input) {
	if (typeof input === "object" && input !== null && "strokeDasharray" in input) return String(input.strokeDasharray);
}
function Icon(_ref) {
	var data = _ref.data, iconType = _ref.iconType, inactiveColor = _ref.inactiveColor;
	var halfSize = SIZE / 2;
	var sixthSize = SIZE / 6;
	var thirdSize = SIZE / 3;
	var color = data.inactive ? inactiveColor : data.color;
	var preferredIcon = iconType !== null && iconType !== void 0 ? iconType : data.type;
	if (preferredIcon === "none") return null;
	if (preferredIcon === "plainline") return /*#__PURE__*/ import_react.createElement("line", {
		strokeWidth: 4,
		fill: "none",
		stroke: color,
		strokeDasharray: getStrokeDasharray$1(data.payload),
		x1: 0,
		y1: halfSize,
		x2: SIZE,
		y2: halfSize,
		className: "recharts-legend-icon"
	});
	if (preferredIcon === "line") return /*#__PURE__*/ import_react.createElement("path", {
		strokeWidth: 4,
		fill: "none",
		stroke: color,
		d: "M0,".concat(halfSize, "h").concat(thirdSize, "\n            A").concat(sixthSize, ",").concat(sixthSize, ",0,1,1,").concat(2 * thirdSize, ",").concat(halfSize, "\n            H").concat(SIZE, "M").concat(2 * thirdSize, ",").concat(halfSize, "\n            A").concat(sixthSize, ",").concat(sixthSize, ",0,1,1,").concat(thirdSize, ",").concat(halfSize),
		className: "recharts-legend-icon"
	});
	if (preferredIcon === "rect") return /*#__PURE__*/ import_react.createElement("path", {
		stroke: "none",
		fill: color,
		d: "M0,".concat(SIZE / 8, "h").concat(SIZE, "v").concat(SIZE * 3 / 4, "h").concat(-SIZE, "z"),
		className: "recharts-legend-icon"
	});
	if (/*#__PURE__*/ import_react.isValidElement(data.legendIcon)) {
		var iconProps = _objectSpread$4({}, data);
		delete iconProps.legendIcon;
		return /*#__PURE__*/ import_react.cloneElement(data.legendIcon, iconProps);
	}
	return /*#__PURE__*/ import_react.createElement(Symbols, {
		fill: color,
		cx: halfSize,
		cy: halfSize,
		size: SIZE,
		sizeType: "diameter",
		type: preferredIcon
	});
}
function Items(props) {
	var payload = props.payload, iconSize = props.iconSize, layout = props.layout, formatter = props.formatter, inactiveColor = props.inactiveColor, iconType = props.iconType, labelStyle = props.labelStyle;
	var viewBox = {
		x: 0,
		y: 0,
		width: SIZE,
		height: SIZE
	};
	var itemStyle = {
		display: layout === "horizontal" ? "inline-block" : "block",
		marginRight: 10,
		whiteSpace: "nowrap"
	};
	var svgStyle = {
		display: "inline-block",
		verticalAlign: "middle",
		marginRight: 4
	};
	return payload.map((entry, i) => {
		var _finalLabelStyle$whit, _finalLabelStyle$over;
		var finalFormatter = entry.formatter || formatter;
		var className = clsx({
			"recharts-legend-item": true,
			["legend-item-".concat(i)]: true,
			inactive: entry.inactive
		});
		if (entry.type === "none") return null;
		var finalLabelStyle = typeof labelStyle === "object" ? _objectSpread$4({}, labelStyle) : {};
		finalLabelStyle.color = entry.inactive ? inactiveColor : finalLabelStyle.color || entry.color;
		(_finalLabelStyle$whit = finalLabelStyle.whiteSpace) !== null && _finalLabelStyle$whit !== void 0 || (finalLabelStyle.whiteSpace = "normal");
		(_finalLabelStyle$over = finalLabelStyle.overflowWrap) !== null && _finalLabelStyle$over !== void 0 || (finalLabelStyle.overflowWrap = "break-word");
		var finalValue = finalFormatter ? finalFormatter(entry.value, entry, i) : entry.value;
		return /*#__PURE__*/ import_react.createElement("li", _extends$5({
			className,
			style: itemStyle,
			key: "legend-item-".concat(i)
		}, adaptEventsOfChild(props, entry, i)), /*#__PURE__*/ import_react.createElement(Surface, {
			width: iconSize,
			height: iconSize,
			viewBox,
			style: svgStyle,
			"aria-label": entry.value == null ? "legend icon" : "".concat(entry.value, " legend icon")
		}, /*#__PURE__*/ import_react.createElement(Icon, {
			data: entry,
			iconType,
			inactiveColor
		})), /*#__PURE__*/ import_react.createElement("span", {
			className: "recharts-legend-item-text",
			style: finalLabelStyle
		}, finalValue));
	});
}
/**
* This component is by default rendered inside the {@link Legend} component. You would not use it directly.
*
* You can use this component to customize the content of the legend,
* or you can provide your own completely independent content.
*/
var DefaultLegendContent = (outsideProps) => {
	var props = resolveDefaultProps(outsideProps, defaultLegendContentDefaultProps);
	var payload = props.payload, layout = props.layout, align = props.align;
	if (!payload || !payload.length) return null;
	var finalStyle = {
		padding: 0,
		margin: 0,
		textAlign: layout === "horizontal" ? align : "left"
	};
	return /*#__PURE__*/ import_react.createElement("ul", {
		className: "recharts-default-legend",
		style: finalStyle
	}, /*#__PURE__*/ import_react.createElement(Items, _extends$5({}, props, { payload })));
};
// node_modules/recharts/es6/context/legendPayloadContext.js
/**
* Use this hook in Legend, or anywhere else where you want to read the current Legend items.
* @return all Legend items ready to be rendered
*/
function useLegendPayload() {
	return useAppSelector(selectLegendPayload);
}
// node_modules/recharts/es6/state/selectors/selectLegendArea.js
var selectLegendArea = createSelector([
	selectChartWidth,
	selectChartHeight,
	selectMargin
], (chartWidth, chartHeight, margin) => {
	return {
		x: margin.left || 0,
		y: margin.top || 0,
		width: Math.max(chartWidth - (margin.left || 0) - (margin.right || 0), 0),
		height: Math.max(chartHeight - (margin.top || 0) - (margin.bottom || 0), 0)
	};
});
// node_modules/recharts/es6/cartesian/cartesianPositionToCSSTranslate.js
/**
* CalculatedCartesianPosition returns horizontalAnchor and verticalAnchor
* which work directly with an SVG text element
* but for use in HTML context we have to translate them into CSS transform(translate)
* so this is what this function is doing.
*
* horizontalPosition is type: type TextAnchor = 'start' | 'middle' | 'end' | 'inherit'
* verticalPosition is type: type TextVerticalAnchor = 'start' | 'middle' | 'end'
*
* @param horizontalPosition as returned from {@link getCartesianPosition}
* @param verticalPosition as returned from {@link getCartesianPosition}
* @return CSS transform string
*/
function cartesianPositionToCSSTranslate(horizontalPosition, verticalPosition) {
	var _verticalValues$verti;
	if (horizontalPosition === "start" && verticalPosition === "start") return "";
	var horizontalValues = {
		start: "0",
		middle: "-50%",
		end: "-100%"
	};
	var verticalValues = {
		start: "0",
		middle: "-50%",
		end: "-100%"
	};
	var x = horizontalPosition === "inherit" ? "0" : horizontalValues[horizontalPosition];
	var y = (_verticalValues$verti = verticalValues[verticalPosition]) !== null && _verticalValues$verti !== void 0 ? _verticalValues$verti : "0";
	return "translate(".concat(x, ", ").concat(y, ")");
}
// node_modules/recharts/es6/component/Legend.js
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
var _excluded$3 = ["contextPayload"];
function _extends$4() {
	return _extends$4 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$4.apply(null, arguments);
}
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function ownKeys$3(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$3(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$3(Object(t), !0).forEach(function(r) {
			_defineProperty$3(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$3(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$3(e, r, t) {
	return (r = _toPropertyKey$3(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$3(t) {
	var i = _toPrimitive$3(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$3(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$3(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose$3(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose$3(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
function defaultUniqBy(entry) {
	return entry.value;
}
function LegendContent(props) {
	var contextPayload = props.contextPayload, otherProps = _objectWithoutProperties$3(props, _excluded$3);
	var finalPayload = getUniqPayload(contextPayload, props.payloadUniqBy, defaultUniqBy);
	var contentProps = _objectSpread$3(_objectSpread$3({}, otherProps), {}, { payload: finalPayload });
	if (/*#__PURE__*/ import_react.isValidElement(props.content)) return /*#__PURE__*/ import_react.cloneElement(props.content, contentProps);
	if (typeof props.content === "function") return /*#__PURE__*/ import_react.createElement(props.content, contentProps);
	return /*#__PURE__*/ import_react.createElement(DefaultLegendContent, contentProps);
}
function getLayoutForPosition(position) {
	if (position === "left" || position === "right" || position === "insideLeft" || position === "insideRight") return "vertical";
	return "horizontal";
}
function selectPositionViewBox(state, position) {
	if (position == null) return null;
	return isOutsidePosition(position) ? selectLegendArea(state) : selectChartViewBox(state);
}
function getOutsidePositionOffset(position, offset, box) {
	if (position === "top") return { top: box.height + offset };
	if (position === "bottom") return { top: -box.height - offset };
	if (position === "left") return { left: box.width + offset };
	if (position === "right") return { left: -box.width - offset };
	return {};
}
function getDefaultPosition(style, props, margin, chartWidth, chartHeight, box) {
	var layout = props.layout, align = props.align, verticalAlign = props.verticalAlign;
	var hPos, vPos;
	if (!style || (style.left === void 0 || style.left === null) && (style.right === void 0 || style.right === null)) {
		if (align === "center" && layout === "vertical") hPos = { left: ((chartWidth || 0) - box.width) / 2 };
		else hPos = align === "right" ? { right: margin && margin.right || 0 } : { left: margin && margin.left || 0 };
	}
	if (!style || (style.top === void 0 || style.top === null) && (style.bottom === void 0 || style.bottom === null)) {
		if (verticalAlign === "middle") vPos = { top: ((chartHeight || 0) - box.height) / 2 };
		else vPos = verticalAlign === "bottom" ? { bottom: margin && margin.bottom || 0 } : { top: margin && margin.top || 0 };
	}
	return _objectSpread$3(_objectSpread$3({}, hPos), vPos);
}
function LegendSettingsDispatcher(_ref) {
	var align = _ref.align, layout = _ref.layout, verticalAlign = _ref.verticalAlign, itemSorter = _ref.itemSorter, position = _ref.position, offset = _ref.offset;
	var dispatch = useAppDispatch();
	(0, import_react.useLayoutEffect)(() => {
		dispatch(setLegendSettings({
			align,
			layout,
			verticalAlign,
			itemSorter,
			position,
			offset
		}));
	}, [
		dispatch,
		align,
		layout,
		verticalAlign,
		itemSorter,
		position,
		offset
	]);
	return null;
}
function LegendSizeDispatcher(_ref2) {
	var width = _ref2.width, height = _ref2.height;
	var dispatch = useAppDispatch();
	(0, import_react.useLayoutEffect)(() => {
		dispatch(setLegendSize({
			width,
			height
		}));
	}, [
		dispatch,
		width,
		height
	]);
	(0, import_react.useLayoutEffect)(() => {
		return () => {
			dispatch(setLegendSize({
				width: 0,
				height: 0
			}));
		};
	}, [dispatch]);
	return null;
}
function getWidthOrHeight(layout, height, width, maxWidth) {
	if (layout === "vertical" && height != null) return { height };
	if (layout === "horizontal") return { width: width || maxWidth };
	return null;
}
var legendDefaultProps = {
	align: "center",
	iconSize: 14,
	inactiveColor: "#ccc",
	itemSorter: "value",
	labelStyle: {},
	layout: "auto",
	verticalAlign: "bottom",
	offset: 0
};
/**
* @consumes CartesianChartContext
* @consumes PolarChartContext
*/
function LegendImpl(outsideProps) {
	var _props$offset, _props$offset2, _positionViewBox$widt, _positionViewBox$widt2, _positionViewBox$heig, _positionViewBox$heig2, _outsidePositionOffse, _outsidePositionOffse2;
	var props = resolveDefaultProps(outsideProps, legendDefaultProps);
	var layout = outsideProps.layout && outsideProps.layout !== "auto" ? outsideProps.layout : getLayoutForPosition(props.position);
	var contextPayload = useLegendPayload();
	var legendPortalFromContext = useLegendPortal();
	var margin = useMargin();
	var positionViewBox = useAppSelector((state) => selectPositionViewBox(state, props.position));
	var widthFromProps = props.width, heightFromProps = props.height, wrapperStyle = props.wrapperStyle, portalFromProps = props.portal;
	var shouldReportDimensions = portalFromProps == null && (props.position == null || isOutsidePosition(props.position));
	var _useElementOffset2 = _slicedToArray(useElementOffset([contextPayload]), 2), lastBoundingBox = _useElementOffset2[0], updateBoundingBox = _useElementOffset2[1];
	var chartWidth = useChartWidth();
	var chartHeight = useChartHeight();
	if (chartWidth == null || chartHeight == null || props.position != null && positionViewBox == null) return null;
	var widthOrHeight = getWidthOrHeight(layout, heightFromProps, widthFromProps, chartWidth - ((margin === null || margin === void 0 ? void 0 : margin.left) || 0) - ((margin === null || margin === void 0 ? void 0 : margin.right) || 0));
	var positionResult = props.position == null ? null : getCartesianPosition({
		viewBox: positionViewBox !== null && positionViewBox !== void 0 ? positionViewBox : {
			x: 0,
			y: 0,
			width: chartWidth,
			height: chartHeight
		},
		position: props.position,
		offset: (_props$offset = props.offset) !== null && _props$offset !== void 0 ? _props$offset : 0
	});
	var outsidePositionOffset = getOutsidePositionOffset(props.position, (_props$offset2 = props.offset) !== null && _props$offset2 !== void 0 ? _props$offset2 : 0, lastBoundingBox);
	var positionMaxWidth = layout === "vertical" ? ((_positionViewBox$widt = positionViewBox === null || positionViewBox === void 0 ? void 0 : positionViewBox.width) !== null && _positionViewBox$widt !== void 0 ? _positionViewBox$widt : 0) / 2 : (_positionViewBox$widt2 = positionViewBox === null || positionViewBox === void 0 ? void 0 : positionViewBox.width) !== null && _positionViewBox$widt2 !== void 0 ? _positionViewBox$widt2 : 0;
	var positionMaxHeight = layout === "horizontal" ? ((_positionViewBox$heig = positionViewBox === null || positionViewBox === void 0 ? void 0 : positionViewBox.height) !== null && _positionViewBox$heig !== void 0 ? _positionViewBox$heig : 0) / 2 : (_positionViewBox$heig2 = positionViewBox === null || positionViewBox === void 0 ? void 0 : positionViewBox.height) !== null && _positionViewBox$heig2 !== void 0 ? _positionViewBox$heig2 : 0;
	var positionStyle = positionResult ? {
		width: "max-content",
		height: "max-content",
		maxWidth: positionMaxWidth,
		maxHeight: positionMaxHeight,
		overflowY: "auto",
		top: positionResult.y + ((_outsidePositionOffse = outsidePositionOffset.top) !== null && _outsidePositionOffse !== void 0 ? _outsidePositionOffse : 0),
		left: positionResult.x + ((_outsidePositionOffse2 = outsidePositionOffset.left) !== null && _outsidePositionOffse2 !== void 0 ? _outsidePositionOffse2 : 0),
		transform: cartesianPositionToCSSTranslate(positionResult.horizontalAnchor, positionResult.verticalAnchor)
	} : getDefaultPosition(wrapperStyle, props, margin, chartWidth, chartHeight, lastBoundingBox);
	var outerStyle = portalFromProps ? wrapperStyle : _objectSpread$3(_objectSpread$3({
		position: "absolute",
		width: (widthOrHeight === null || widthOrHeight === void 0 ? void 0 : widthOrHeight.width) || widthFromProps || "auto",
		height: (widthOrHeight === null || widthOrHeight === void 0 ? void 0 : widthOrHeight.height) || heightFromProps || "auto"
	}, positionStyle), wrapperStyle);
	var legendPortal = portalFromProps !== null && portalFromProps !== void 0 ? portalFromProps : legendPortalFromContext;
	if (legendPortal == null || contextPayload == null) return null;
	var legendElement = /*#__PURE__*/ import_react.createElement("div", {
		className: "recharts-legend-wrapper",
		style: outerStyle,
		ref: updateBoundingBox
	}, /*#__PURE__*/ import_react.createElement(LegendSettingsDispatcher, {
		layout,
		align: props.align,
		verticalAlign: props.verticalAlign,
		itemSorter: props.itemSorter,
		position: props.position,
		offset: props.offset
	}), shouldReportDimensions && /*#__PURE__*/ import_react.createElement(LegendSizeDispatcher, lastBoundingBox), /*#__PURE__*/ import_react.createElement(LegendContent, _extends$4({}, props, { layout }, widthOrHeight, {
		margin,
		chartWidth,
		chartHeight,
		contextPayload
	})));
	return /*#__PURE__*/ (0, import_react_dom.createPortal)(legendElement, legendPortal);
}
var Legend = /*#__PURE__*/ import_react.memo(LegendImpl, propsAreEqual);
Legend.displayName = "Legend";
// node_modules/recharts/es6/shape/Dot.js
function _extends$3() {
	return _extends$3 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$3.apply(null, arguments);
}
/**
* Renders a dot in the chart.
*
* This component accepts X and Y coordinates in pixels.
* If you need to position the rectangle based on your chart's data,
* consider using the {@link ReferenceDot} component instead.
*
* @param props
* @constructor
*/
var Dot = (props) => {
	var cx = props.cx, cy = props.cy, r = props.r, className = props.className;
	var layerClass = clsx("recharts-dot", className);
	if (isNumber(cx) && isNumber(cy) && isNumber(r)) return /*#__PURE__*/ import_react.createElement("circle", _extends$3({}, svgPropertiesNoEvents(props), adaptEventHandlers(props), {
		className: layerClass,
		cx,
		cy,
		r
	}));
	return null;
};
// node_modules/recharts/es6/component/Dots.js
var _excluded$2 = ["points"];
function ownKeys$2(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$2(Object(t), !0).forEach(function(r) {
			_defineProperty$2(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$2(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$2(e, r, t) {
	return (r = _toPropertyKey$2(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$2(t) {
	var i = _toPrimitive$2(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$2(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends$2() {
	return _extends$2 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$2.apply(null, arguments);
}
function _objectWithoutProperties$2(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose$2(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose$2(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
function DotItem(_ref) {
	var option = _ref.option, dotProps = _ref.dotProps, className = _ref.className;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(option)) return /*#__PURE__*/ (0, import_react.cloneElement)(option, dotProps);
	if (typeof option === "function") return option(dotProps);
	var finalClassName = clsx(className, typeof option !== "boolean" ? option.className : ""), _ref2 = dotProps !== null && dotProps !== void 0 ? dotProps : {};
	_ref2.points;
	var props = _objectWithoutProperties$2(_ref2, _excluded$2);
	return /*#__PURE__*/ import_react.createElement(Dot, _extends$2({}, props, { className: finalClassName }));
}
function shouldRenderDots(points, dot) {
	if (points == null) return false;
	if (dot) return true;
	return points.length === 1;
}
function Dots(_ref3) {
	var points = _ref3.points, dot = _ref3.dot, className = _ref3.className, dotClassName = _ref3.dotClassName, dataKey = _ref3.dataKey, baseProps = _ref3.baseProps, needClip = _ref3.needClip, clipPathId = _ref3.clipPathId, _ref3$zIndex = _ref3.zIndex, zIndex = _ref3$zIndex === void 0 ? DefaultZIndexes.scatter : _ref3$zIndex;
	if (!shouldRenderDots(points, dot)) return null;
	var clipDot = isClipDot(dot);
	var customDotProps = svgPropertiesAndEventsFromUnknown(dot);
	var dots = points.map((entry, i) => {
		var _entry$x, _entry$y;
		var dotProps = _objectSpread$2(_objectSpread$2(_objectSpread$2({ r: 3 }, baseProps), customDotProps), {}, {
			index: i,
			cx: (_entry$x = entry.x) !== null && _entry$x !== void 0 ? _entry$x : void 0,
			cy: (_entry$y = entry.y) !== null && _entry$y !== void 0 ? _entry$y : void 0,
			dataKey,
			value: entry.value,
			payload: entry.payload,
			points
		});
		return /*#__PURE__*/ import_react.createElement(DotItem, {
			key: "dot-".concat(i),
			option: dot,
			dotProps,
			className: dotClassName
		});
	});
	var layerProps = {};
	if (needClip && clipPathId != null) layerProps.clipPath = "url(#clipPath-".concat(clipDot ? "" : "dots-").concat(clipPathId, ")");
	return /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex }, /*#__PURE__*/ import_react.createElement(Layer, _extends$2({ className }, layerProps), dots));
}
// node_modules/recharts/es6/component/ActivePoints.js
function ownKeys$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1(Object(t), !0).forEach(function(r) {
			_defineProperty$1(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$1(e, r, t) {
	return (r = _toPropertyKey$1(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$1(t) {
	var i = _toPrimitive$1(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$1(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var ActivePoint = (_ref) => {
	var point = _ref.point, childIndex = _ref.childIndex, mainColor = _ref.mainColor, activeDot = _ref.activeDot, dataKey = _ref.dataKey, clipPath = _ref.clipPath;
	if (activeDot === false || point.x == null || point.y == null) return null;
	var dotProps = _objectSpread$1(_objectSpread$1(_objectSpread$1({}, {
		index: childIndex,
		dataKey,
		cx: point.x,
		cy: point.y,
		r: 4,
		fill: mainColor !== null && mainColor !== void 0 ? mainColor : "none",
		strokeWidth: 2,
		stroke: "#fff",
		payload: point.payload,
		value: point.value
	}), svgPropertiesNoEventsFromUnknown(activeDot)), adaptEventHandlers(activeDot));
	var dot;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(activeDot)) dot = /*#__PURE__*/ (0, import_react.cloneElement)(activeDot, dotProps);
	else if (typeof activeDot === "function") dot = activeDot(dotProps);
	else dot = /*#__PURE__*/ import_react.createElement(Dot, dotProps);
	return /*#__PURE__*/ import_react.createElement(Layer, {
		className: "recharts-active-dot",
		clipPath
	}, dot);
};
function ActivePoints(_ref2) {
	var points = _ref2.points, mainColor = _ref2.mainColor, activeDot = _ref2.activeDot, itemDataKey = _ref2.itemDataKey, clipPath = _ref2.clipPath, _ref2$zIndex = _ref2.zIndex, zIndex = _ref2$zIndex === void 0 ? DefaultZIndexes.activeDot : _ref2$zIndex;
	var activeTooltipIndex = useAppSelector(selectActiveTooltipIndex);
	var activeDataPoints = useActiveTooltipDataPoints();
	if (points == null || activeDataPoints == null) return null;
	var activePoint = points.find((p) => activeDataPoints.includes(p.payload));
	if (isNullish(activePoint)) return null;
	return /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex }, /*#__PURE__*/ import_react.createElement(ActivePoint, {
		point: activePoint,
		childIndex: Number(activeTooltipIndex),
		mainColor,
		dataKey: itemDataKey,
		activeDot,
		clipPath
	}));
}
// node_modules/recharts/es6/cartesian/LineDrawShape.js
var _excluded$1 = [
	"animationElapsedTime",
	"isAnimating",
	"isEntrance",
	"visibleLength",
	"strokeDasharray",
	"connectNulls"
];
function _extends$1() {
	return _extends$1 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$1.apply(null, arguments);
}
function _objectWithoutProperties$1(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose$1(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose$1(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
/**
* Reads the total length of an SVG path element, returning 0 if the element
* is null or the measurement fails (e.g. in JSDOM).
*/
function getTotalLength$1(path) {
	try {
		return path && path.getTotalLength && path.getTotalLength() || 0;
	} catch (_unused) {
		return 0;
	}
}
/**
* Generates a simple stroke-dasharray string for animating a line draw effect.
*
* Uses `totalLength` as the gap (instead of `totalLength - length`) to prevent a floating-point
* precision artifact: when fractional dash and gap values are serialized to a string attribute
* and reparsed by the SVG renderer, their sum can differ from the actual path length by a ULP,
* causing the dasharray pattern to repeat and render a phantom dot at the path endpoint
* with round or square strokeLinecap.
*
* @param totalLength The total length of the SVG path
* @param length The currently visible portion of the path
* @returns A stroke-dasharray string like "50px 200px"
*/
function generateSimpleStrokeDasharray(totalLength, length) {
	return "".concat(length, "px ").concat(totalLength, "px");
}
/**
* Normalizes a dash pattern to the even-length sequence used by SVG renderers.
* Odd-length stroke-dasharray values repeat once, so "5" behaves like "5 5".
*
* @param lines Array of dash/gap lengths to repeat
* @returns An even-length dash pattern
*/
function normalizeDashPattern(lines) {
	return lines.length % 2 !== 0 ? [...lines, ...lines] : lines;
}
/**
* Repeats a dash pattern array a given number of times.
*
* @param lines Array of dash/gap lengths to repeat
* @param count Number of times to repeat the pattern
* @returns A new array with the pattern repeated `count` times
*/
function repeat(lines, count) {
	var result = [];
	for (var i = 0; i < count; ++i) result.push(...lines);
	return result;
}
/**
* Computes a stroke-dasharray string for animating a custom-dashed line draw effect.
*
* Given a user-specified dash pattern (e.g. `"7,3"`), this function builds a dasharray
* that reveals exactly `length` pixels of that pattern, followed by a gap of `totalLength`
* to hide the remainder of the path.
*
* Like {@link generateSimpleStrokeDasharray}, the trailing gap uses `totalLength` rather than
* `totalLength - length` to avoid floating-point precision artifacts with round/square strokeLinecap.
*
* @param length The currently visible portion of the path
* @param totalLength The total length of the SVG path
* @param lines The user-specified dash pattern as an array of numbers (e.g. [7, 3])
* @returns A stroke-dasharray string incorporating the custom dash pattern
*/
function getStrokeDasharray(length, totalLength, lines) {
	var normalizedLines = normalizeDashPattern(lines);
	var lineLength = normalizedLines.reduce((pre, next) => pre + next, 0);
	if (!lineLength) return generateSimpleStrokeDasharray(totalLength, length);
	var count = Math.floor(length / lineLength);
	var remainLength = length % lineLength;
	var remainLines = [];
	for (var i = 0, sum = 0; i < normalizedLines.length; sum += (_normalizedLines$i = normalizedLines[i]) !== null && _normalizedLines$i !== void 0 ? _normalizedLines$i : 0, ++i) {
		var _normalizedLines$i;
		var lineValue = normalizedLines[i];
		if (lineValue != null && sum + lineValue > remainLength) {
			remainLines = [...normalizedLines.slice(0, i), remainLength - sum];
			break;
		}
	}
	var emptyLines = remainLines.length % 2 === 0 ? [0, totalLength] : [totalLength];
	return [
		...repeat(normalizedLines, count),
		...remainLines,
		...emptyLines
	].map((line) => "".concat(line, "px")).join(", ");
}
/**
* Computes the animated stroke-dasharray for a line's entrance animation.
*
* @param userStrokeDasharray The user-specified stroke-dasharray (e.g. "5,3"), if any
* @param totalLength Total SVG path length
* @param visibleLength How much of the path should be visible
* @returns A stroke-dasharray string for the current animation frame
*/
function computeAnimatedStrokeDasharray(userStrokeDasharray, totalLength, visibleLength) {
	if (userStrokeDasharray) return getStrokeDasharray(visibleLength, totalLength, "".concat(userStrokeDasharray).split(/[,\s]+/gim).map((num) => parseFloat(num)));
	return generateSimpleStrokeDasharray(totalLength, visibleLength);
}
/**
* The default shape for Line. During the entrance animation, the line is progressively
* revealed using the `strokeDasharray` SVG attribute: the visible portion grows from
* 0 to the full path length as `animationElapsedTime` progresses from 0 to 1.
*
* This is the built-in shape for Line. It is automatically used when no custom `shape` prop
* is provided. You can import and reuse it as a starting point for custom shapes,
* or use it as a reference for building your own.
*
* The animation progress props (`animationElapsedTime`, `isAnimating`, `isEntrance`) are available
* for custom shapes that want to add their own effects on top.
*
* @example
* ```tsx
* import { Line, LineDrawShape } from 'recharts';
*
* // Use the default shape explicitly (same as providing no shape prop)
* <Line dataKey="value" shape={LineDrawShape} />
* ```
*
* @see {@link https://recharts.github.io/en-US/guide/animations Animation guide}
*
* @since 3.9
*/
function LineDrawShape(props) {
	props.animationElapsedTime;
	props.isAnimating;
	props.isEntrance;
	var visibleLength = props.visibleLength, userStrokeDasharray = props.strokeDasharray, connectNulls = props.connectNulls, curveProps = _objectWithoutProperties$1(props, _excluded$1);
	var finalConnectNulls = connectNulls !== null && connectNulls !== void 0 ? connectNulls : false;
	var strokeDasharray;
	if (visibleLength != null) {
		var _pathRef$current;
		var pathRef = curveProps.pathRef;
		strokeDasharray = computeAnimatedStrokeDasharray(userStrokeDasharray, getTotalLength$1((_pathRef$current = pathRef === null || pathRef === void 0 ? void 0 : pathRef.current) !== null && _pathRef$current !== void 0 ? _pathRef$current : null), visibleLength);
	} else if (userStrokeDasharray != null) strokeDasharray = String(userStrokeDasharray);
	return /*#__PURE__*/ import_react.createElement(Curve, _extends$1({}, curveProps, {
		connectNulls: finalConnectNulls,
		strokeDasharray
	}));
}
// node_modules/recharts/es6/cartesian/useAnimatedLineLength.js
/**
* Tracks the animated visible length of a Line's SVG path across data changes.
*
* Invariants:
* 1. The visible length only grows (monotonically non-decreasing with animationElapsedTime).
* 2. The visible length changes continuously — no jumps when data changes mid-animation.
*    This is achieved by tracking the maximum animated length in pixels and using it
*    as the starting point for the next animation.
* 3. Once the line reaches 100% visibility, it never becomes partially visible again.
*    In that case the hook returns `null`, meaning no animation stroke-dasharray is needed.
*
* @param points The current set of points for the line. When this reference changes,
*   the hook detects a data change and starts a new animation from the current visible length.
* @returns A stable callback `(animationElapsedTime, totalLength) => number | null` where:
*   - `animationElapsedTime` is the animation progress (0 to 1)
*   - `totalLength` is the current total length of the SVG path in pixels
*   - returns the visible length in pixels, or `null` if the line is fully visible
*/
function useAnimatedLineLength(points) {
	var startingLengthRef = (0, import_react.useRef)(0);
	var maxAnimatedLengthRef = (0, import_react.useRef)(0);
	var reachedFullRef = (0, import_react.useRef)(false);
	var prevPointsRef = (0, import_react.useRef)(points);
	if (prevPointsRef.current !== points) {
		startingLengthRef.current = maxAnimatedLengthRef.current;
		prevPointsRef.current = points;
	}
	return (0, import_react.useCallback)((animationElapsedTime, totalLength) => {
		if (reachedFullRef.current) return null;
		var visibleLength = Math.min(round(startingLengthRef.current + animationElapsedTime * totalLength), totalLength);
		if (animationElapsedTime > 0 && totalLength > 0) {
			maxAnimatedLengthRef.current = Math.max(maxAnimatedLengthRef.current, visibleLength);
			if (visibleLength >= totalLength) {
				reachedFullRef.current = true;
				return null;
			}
		}
		return visibleLength;
	}, []);
}
// node_modules/recharts/es6/state/selectors/lineSelectors.js
var selectXAxisWithScale = (state, xAxisId, _yAxisId, isPanorama) => selectAxisWithScale(state, "xAxis", xAxisId, isPanorama);
var selectXAxisTicks = (state, xAxisId, _yAxisId, isPanorama) => selectTicksOfGraphicalItem(state, "xAxis", xAxisId, isPanorama);
var selectYAxisWithScale = (state, _xAxisId, yAxisId, isPanorama) => selectAxisWithScale(state, "yAxis", yAxisId, isPanorama);
var selectYAxisTicks = (state, _xAxisId, yAxisId, isPanorama) => selectTicksOfGraphicalItem(state, "yAxis", yAxisId, isPanorama);
var selectBandSize = createSelector([
	selectChartLayout,
	selectXAxisWithScale,
	selectYAxisWithScale,
	selectXAxisTicks,
	selectYAxisTicks
], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks) => {
	if (isCategoricalAxis(layout, "xAxis")) return getBandSizeOfAxis(xAxis, xAxisTicks, false);
	return getBandSizeOfAxis(yAxis, yAxisTicks, false);
});
var pickLineId = (_state, _xAxisId, _yAxisId, _isPanorama, id) => id;
function isLineSettings(item) {
	return item.type === "line";
}
var selectSynchronisedLineSettings = createSelector([selectUnfilteredCartesianItems, pickLineId], (graphicalItems, id) => graphicalItems.filter(isLineSettings).find((x) => x.id === id));
var selectLinePoints = createSelector([
	selectChartLayout,
	selectXAxisWithScale,
	selectYAxisWithScale,
	selectXAxisTicks,
	selectYAxisTicks,
	selectSynchronisedLineSettings,
	selectBandSize,
	selectChartDataWithIndexesIfNotInPanoramaPosition4
], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks, lineSettings, bandSize, _ref) => {
	var chartData = _ref.chartData, dataStartIndex = _ref.dataStartIndex, dataEndIndex = _ref.dataEndIndex;
	if (lineSettings == null || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || xAxisTicks.length === 0 || yAxisTicks.length === 0 || bandSize == null || layout !== "horizontal" && layout !== "vertical") return;
	var dataKey = lineSettings.dataKey, data = lineSettings.data;
	var displayedData;
	if (data != null && data.length > 0) displayedData = data;
	else displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
	if (displayedData == null) return;
	return computeLinePoints({
		layout,
		xAxis,
		yAxis,
		xAxisTicks,
		yAxisTicks,
		dataKey,
		bandSize,
		displayedData
	});
});
// node_modules/recharts/es6/util/getRadiusAndStrokeWidthFromDot.js
function getRadiusAndStrokeWidthFromDot(dot) {
	var props = svgPropertiesNoEventsFromUnknown(dot);
	var defaultR = 3;
	var defaultStrokeWidth = 2;
	if (props != null) {
		var r = props.r, strokeWidth = props.strokeWidth;
		var realR = Number(r);
		var realStrokeWidth = Number(strokeWidth);
		if (Number.isNaN(realR) || realR < 0) realR = defaultR;
		if (Number.isNaN(realStrokeWidth) || realStrokeWidth < 0) realStrokeWidth = defaultStrokeWidth;
		return {
			r: realR,
			strokeWidth: realStrokeWidth
		};
	}
	return {
		r: defaultR,
		strokeWidth: defaultStrokeWidth
	};
}
// node_modules/recharts/es6/cartesian/Line.js
var _excluded = ["id"];
var _excluded2 = [
	"type",
	"layout",
	"connectNulls",
	"needClip",
	"shape",
	"strokeDasharray"
];
var _excluded3 = [
	"activeDot",
	"animateNewValues",
	"animationBegin",
	"animationDuration",
	"animationEasing",
	"connectNulls",
	"dot",
	"hide",
	"isAnimationActive",
	"label",
	"legendType",
	"xAxisId",
	"yAxisId",
	"id"
];
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
function _objectWithoutProperties(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
/**
* Internal props, combination of external props + defaultProps + private Recharts state
*/
/**
* External props, intended for end users to fill in
*/
function getTotalLength(mainCurve) {
	try {
		return mainCurve && mainCurve.getTotalLength && mainCurve.getTotalLength() || 0;
	} catch (_unused) {
		return 0;
	}
}
/**
* Compute the average x-shift between matched pairs (prev → next).
* This tells us the overall direction and magnitude of the data movement.
*/
function averageShift(items) {
	var total = 0;
	var count = 0;
	for (var item of items) if (item.status === "matched" && item.prev.x != null && item.next.x != null) {
		total += item.next.x - item.prev.x;
		count++;
	}
	return count > 0 ? total / count : 0;
}
var defaultLineAnimateItems = (items, animationElapsedTime) => {
	if (items == null) return [];
	if (animationElapsedTime === 1) return items.flatMap((item) => item.status === "removed" ? [] : [item.next]);
	var shift = averageShift(items);
	var result = [];
	for (var item of items) if (item.status === "matched") result.push(_objectSpread(_objectSpread({}, item.next), {}, {
		x: interpolate(item.prev.x, item.next.x, animationElapsedTime),
		y: interpolate(item.prev.y, item.next.y, animationElapsedTime)
	}));
	else if (item.status === "added") {
		if (item.next.x != null) {
			var entryX = item.next.x - shift;
			result.push(_objectSpread(_objectSpread({}, item.next), {}, {
				x: interpolate(entryX, item.next.x, animationElapsedTime),
				y: item.next.y
			}));
		} else result.push(item.next);
	} else if (item.status === "removed") {
		if (item.prev.x != null) {
			var exitX = item.prev.x + shift;
			result.push(_objectSpread(_objectSpread({}, item.prev), {}, {
				x: interpolate(item.prev.x, exitX, animationElapsedTime),
				y: item.prev.y
			}));
		}
	}
	return result;
};
var defaultLineProps = {
	activeDot: true,
	animateNewValues: true,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease",
	animationInterpolateFn: defaultLineAnimateItems,
	animationMatchBy: matchByIndex,
	connectNulls: false,
	dot: true,
	fill: "#fff",
	hide: false,
	isAnimationActive: "auto",
	label: false,
	legendType: "line",
	shape: LineDrawShape,
	stroke: "#3182bd",
	strokeWidth: 1,
	xAxisId: 0,
	yAxisId: 0,
	zIndex: DefaultZIndexes.line,
	type: "linear"
};
/**
* Because of naming conflict, we are forced to ignore certain (valid) SVG attributes.
*/
var computeLegendPayloadFromAreaData = (props) => {
	var dataKey = props.dataKey, name = props.name, stroke = props.stroke, legendType = props.legendType;
	return [{
		inactive: props.hide,
		dataKey,
		type: legendType,
		color: stroke,
		value: getTooltipNameProp(name, dataKey),
		payload: props
	}];
};
var SetLineTooltipEntrySettings = /*#__PURE__*/ import_react.memo((_ref) => {
	var dataKey = _ref.dataKey, data = _ref.data, stroke = _ref.stroke, strokeWidth = _ref.strokeWidth, fill = _ref.fill, name = _ref.name, hide = _ref.hide, unit = _ref.unit, formatter = _ref.formatter, tooltipType = _ref.tooltipType, id = _ref.id;
	var tooltipEntrySettings = {
		dataDefinedOnItem: data,
		getPosition: noop,
		settings: {
			stroke,
			strokeWidth,
			fill,
			dataKey,
			nameKey: void 0,
			name: getTooltipNameProp(name, dataKey),
			hide,
			type: tooltipType,
			color: stroke,
			unit,
			formatter,
			graphicalItemId: id
		}
	};
	return /*#__PURE__*/ import_react.createElement(SetTooltipEntrySettings, { tooltipEntrySettings });
});
function LineDotsWrapper(_ref2) {
	var clipPathId = _ref2.clipPathId, points = _ref2.points, props = _ref2.props;
	var dot = props.dot, dataKey = props.dataKey, needClip = props.needClip;
	props.id;
	var propsWithoutId = _objectWithoutProperties(props, _excluded);
	var lineProps = svgPropertiesNoEvents(propsWithoutId);
	return /*#__PURE__*/ import_react.createElement(Dots, {
		points,
		dot,
		className: "recharts-line-dots",
		dotClassName: "recharts-line-dot",
		dataKey,
		baseProps: lineProps,
		needClip,
		clipPathId
	});
}
function LineLabelListProvider(_ref3) {
	var showLabels = _ref3.showLabels, children = _ref3.children, points = _ref3.points;
	var labelListEntries = (0, import_react.useMemo)(() => {
		return points === null || points === void 0 ? void 0 : points.map((point) => {
			var _point$x, _point$y;
			var viewBox = {
				x: (_point$x = point.x) !== null && _point$x !== void 0 ? _point$x : 0,
				y: (_point$y = point.y) !== null && _point$y !== void 0 ? _point$y : 0,
				width: 0,
				lowerWidth: 0,
				upperWidth: 0,
				height: 0
			};
			return _objectSpread(_objectSpread({}, viewBox), {}, {
				value: point.value,
				payload: point.payload,
				viewBox,
				parentViewBox: void 0,
				fill: void 0
			});
		});
	}, [points]);
	return /*#__PURE__*/ import_react.createElement(CartesianLabelListContextProvider, { value: showLabels ? labelListEntries : void 0 }, children);
}
function StaticCurve(_ref4) {
	var clipPathId = _ref4.clipPathId, pathRef = _ref4.pathRef, points = _ref4.points, props = _ref4.props, animationElapsedTime = _ref4.animationElapsedTime, isAnimating = _ref4.isAnimating, isEntrance = _ref4.isEntrance, visibleLength = _ref4.visibleLength;
	var type = props.type, layout = props.layout, connectNulls = props.connectNulls, needClip = props.needClip, shape = props.shape, strokeDasharray = props.strokeDasharray, others = _objectWithoutProperties(props, _excluded2);
	var curveProps = _objectSpread(_objectSpread({}, svgPropertiesAndEvents(others)), {}, {
		fill: "none",
		className: "recharts-line-curve",
		clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : void 0,
		points,
		type,
		layout,
		connectNulls,
		strokeDasharray: strokeDasharray !== null && strokeDasharray !== void 0 ? strokeDasharray : props.strokeDasharray,
		pathRef,
		animationElapsedTime,
		isAnimating,
		isEntrance: props.animateNewValues ? isEntrance : false,
		visibleLength
	});
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, (points === null || points === void 0 ? void 0 : points.length) > 1 && /*#__PURE__*/ import_react.createElement(Shape, {
		option: shape,
		DefaultShape: defaultLineProps.shape,
		shapeProps: curveProps
	}), /*#__PURE__*/ import_react.createElement(LineDotsWrapper, {
		points,
		clipPathId,
		props
	}));
}
function CurveWithAnimation(_ref5) {
	var clipPathId = _ref5.clipPathId, props = _ref5.props, pathRef = _ref5.pathRef, previousPointsRef = _ref5.previousPointsRef;
	var points = props.points, isAnimationActive = props.isAnimationActive, animationBegin = props.animationBegin, animationDuration = props.animationDuration, animationEasing = props.animationEasing, animationMatchBy = props.animationMatchBy, animationInterpolateFn = props.animationInterpolateFn, layout = props.layout;
	var totalLength = getTotalLength(pathRef.current);
	var _useAnimationCallback = useAnimationCallbacks(props.onAnimationStart, props.onAnimationEnd), isAnimating = _useAnimationCallback.isAnimating, handleAnimationStart = _useAnimationCallback.handleAnimationStart, handleAnimationEnd = _useAnimationCallback.handleAnimationEnd;
	var showLabels = !isAnimating;
	var getVisibleLength = useAnimatedLineLength(points);
	var shouldUpdatePreviousRef = (0, import_react.useCallback)((animationElapsedTime) => animationElapsedTime > 0 && totalLength > 0, [totalLength]);
	return /*#__PURE__*/ import_react.createElement(LineLabelListProvider, {
		points,
		showLabels
	}, props.children, /*#__PURE__*/ import_react.createElement(AnimatedItems, {
		animationInput: points,
		animationIdPrefix: "recharts-line-",
		items: points,
		previousItemsRef: previousPointsRef,
		isAnimationActive,
		animationBegin,
		animationDuration,
		animationEasing,
		onAnimationStart: handleAnimationStart,
		onAnimationEnd: handleAnimationEnd,
		animationInterpolateFn,
		animationMatchBy,
		shouldUpdatePreviousRef,
		layout
	}, (stepData, animationElapsedTime, isEntrance) => {
		var animationActive = isAnimating || animationElapsedTime < 1;
		var visibleLength = animationActive ? getVisibleLength(animationElapsedTime, totalLength) : null;
		return /*#__PURE__*/ import_react.createElement(StaticCurve, {
			props,
			points: stepData,
			clipPathId,
			pathRef,
			animationElapsedTime,
			isAnimating: animationActive,
			isEntrance,
			visibleLength
		});
	}), /*#__PURE__*/ import_react.createElement(LabelListFromLabelProp, { label: props.label }));
}
function RenderCurve(_ref6) {
	var clipPathId = _ref6.clipPathId, props = _ref6.props;
	var previousPointsRef = (0, import_react.useRef)(null);
	var pathRef = (0, import_react.useRef)(null);
	return /*#__PURE__*/ import_react.createElement(CurveWithAnimation, {
		props,
		clipPathId,
		previousPointsRef,
		pathRef
	});
}
var errorBarDataPointFormatter = (dataPoint, dataKey) => {
	var _dataPoint$x, _dataPoint$y;
	return {
		x: (_dataPoint$x = dataPoint.x) !== null && _dataPoint$x !== void 0 ? _dataPoint$x : void 0,
		y: (_dataPoint$y = dataPoint.y) !== null && _dataPoint$y !== void 0 ? _dataPoint$y : void 0,
		value: dataPoint.value,
		errorVal: getValueByDataKey(dataPoint.payload, dataKey)
	};
};
var LineWithState = class extends import_react.Component {
	render() {
		var _this$props = this.props, hide = _this$props.hide, dot = _this$props.dot, points = _this$props.points, className = _this$props.className, xAxisId = _this$props.xAxisId, yAxisId = _this$props.yAxisId, top = _this$props.top, left = _this$props.left, width = _this$props.width, height = _this$props.height, id = _this$props.id, needClip = _this$props.needClip, zIndex = _this$props.zIndex;
		if (hide) return null;
		var layerClass = clsx("recharts-line", className);
		var clipPathId = id;
		var _getRadiusAndStrokeWi = getRadiusAndStrokeWidthFromDot(dot), r = _getRadiusAndStrokeWi.r, strokeWidth = _getRadiusAndStrokeWi.strokeWidth;
		var clipDot = isClipDot(dot);
		var dotSize = r * 2 + strokeWidth;
		var activePointsClipPath = needClip ? "url(#clipPath-".concat(clipDot ? "" : "dots-").concat(clipPathId, ")") : void 0;
		return /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex }, /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, needClip && /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement(GraphicalItemClipPath, {
			clipPathId,
			xAxisId,
			yAxisId
		}), !clipDot && /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-dots-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
			x: left - dotSize / 2,
			y: top - dotSize / 2,
			width: width + dotSize,
			height: height + dotSize
		}))), /*#__PURE__*/ import_react.createElement(SetErrorBarContext, {
			xAxisId,
			yAxisId,
			data: points,
			dataPointFormatter: errorBarDataPointFormatter,
			errorBarOffset: 0
		}, /*#__PURE__*/ import_react.createElement(RenderCurve, {
			props: this.props,
			clipPathId
		}))), /*#__PURE__*/ import_react.createElement(ActivePoints, {
			activeDot: this.props.activeDot,
			points,
			mainColor: this.props.stroke,
			itemDataKey: this.props.dataKey,
			clipPath: activePointsClipPath
		}));
	}
};
function LineImpl(props) {
	var _resolveDefaultProps = resolveDefaultProps(props, defaultLineProps), activeDot = _resolveDefaultProps.activeDot, animateNewValues = _resolveDefaultProps.animateNewValues, animationBegin = _resolveDefaultProps.animationBegin, animationDuration = _resolveDefaultProps.animationDuration, animationEasing = _resolveDefaultProps.animationEasing, connectNulls = _resolveDefaultProps.connectNulls, dot = _resolveDefaultProps.dot, hide = _resolveDefaultProps.hide, isAnimationActive = _resolveDefaultProps.isAnimationActive, label = _resolveDefaultProps.label, legendType = _resolveDefaultProps.legendType, xAxisId = _resolveDefaultProps.xAxisId, yAxisId = _resolveDefaultProps.yAxisId, id = _resolveDefaultProps.id, everythingElse = _objectWithoutProperties(_resolveDefaultProps, _excluded3);
	var needClip = useNeedsClip(xAxisId, yAxisId).needClip;
	var plotArea = usePlotArea();
	var layout = useChartLayout();
	var isPanorama = useIsPanorama();
	var points = useAppSelector((state) => selectLinePoints(state, xAxisId, yAxisId, isPanorama, id));
	if (layout !== "horizontal" && layout !== "vertical" || points == null || plotArea == null) return null;
	var height = plotArea.height, width = plotArea.width, left = plotArea.x, top = plotArea.y;
	return /*#__PURE__*/ import_react.createElement(LineWithState, _extends({}, everythingElse, {
		id,
		connectNulls,
		dot,
		activeDot,
		animateNewValues,
		animationBegin,
		animationDuration,
		animationEasing,
		isAnimationActive,
		hide,
		label,
		legendType,
		xAxisId,
		yAxisId,
		points,
		layout,
		height,
		width,
		left,
		top,
		needClip
	}));
}
function computeLinePoints(_ref7) {
	var layout = _ref7.layout, xAxis = _ref7.xAxis, yAxis = _ref7.yAxis, xAxisTicks = _ref7.xAxisTicks, yAxisTicks = _ref7.yAxisTicks, dataKey = _ref7.dataKey, bandSize = _ref7.bandSize;
	return _ref7.displayedData.map((entry, index) => {
		var value = getValueByDataKey(entry, dataKey);
		if (layout === "horizontal") {
			var _x = getCateCoordinateOfLine({
				axis: xAxis,
				ticks: xAxisTicks,
				bandSize,
				entry,
				index
			});
			var _y = isNullish(value) ? null : yAxis.scale.map(value);
			return {
				x: _x,
				y: _y !== null && _y !== void 0 ? _y : null,
				value,
				payload: entry
			};
		}
		var x = isNullish(value) ? null : xAxis.scale.map(value);
		var y = getCateCoordinateOfLine({
			axis: yAxis,
			ticks: yAxisTicks,
			bandSize,
			entry,
			index
		});
		if (x == null || y == null) return null;
		return {
			x,
			y,
			value,
			payload: entry
		};
	}).filter(Boolean);
}
function LineFn(outsideProps) {
	var props = resolveDefaultProps(outsideProps, defaultLineProps);
	var isPanorama = useIsPanorama();
	return /*#__PURE__*/ import_react.createElement(RegisterGraphicalItemId, {
		id: props.id,
		type: "line"
	}, (id) => /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(SetLegendPayload, { legendPayload: computeLegendPayloadFromAreaData(props) }), /*#__PURE__*/ import_react.createElement(SetLineTooltipEntrySettings, {
		dataKey: props.dataKey,
		data: props.data,
		stroke: props.stroke,
		strokeWidth: props.strokeWidth,
		fill: props.fill,
		name: props.name,
		hide: props.hide,
		unit: props.unit,
		formatter: props.formatter,
		tooltipType: props.tooltipType,
		id
	}), /*#__PURE__*/ import_react.createElement(SetCartesianGraphicalItem, {
		type: "line",
		id,
		data: props.data,
		xAxisId: props.xAxisId,
		yAxisId: props.yAxisId,
		zAxisId: 0,
		dataKey: props.dataKey,
		hide: props.hide,
		isPanorama
	}), /*#__PURE__*/ import_react.createElement(LineImpl, _extends({}, props, { id }))));
}
/**
* @provides LabelListContext
* @provides ErrorBarContext
* @consumes CartesianChartContext
*/
var Line = /*#__PURE__*/ import_react.memo(LineFn, propsAreEqual);
Line.displayName = "Line";
// node_modules/recharts/es6/chart/LineChart.js
var allowedTooltipTypes = ["axis"];
/**
* @consumes ResponsiveContainerContext
* @provides CartesianViewBoxContext
* @provides CartesianChartContext
*/
var LineChart = /*#__PURE__*/ (0, import_react.forwardRef)((props, ref) => {
	return /*#__PURE__*/ import_react.createElement(CartesianChart, {
		chartName: "LineChart",
		defaultTooltipEventType: "axis",
		validateTooltipEventTypes: allowedTooltipTypes,
		tooltipPayloadSearcher: arrayTooltipSearcher,
		categoricalChartProps: props,
		ref
	});
});
// src/routes/reports.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"oklch(0.8 0.12 80)",
	"oklch(0.7 0.15 155)",
	"oklch(0.6 0.15 280)",
	"oklch(0.7 0.18 30)",
	"oklch(0.65 0.13 200)",
	"oklch(0.75 0.14 320)",
	"oklch(0.7 0.12 100)"
];
function KpiCard({ title, value, sub, icon: Icon, accent, onClick, delay = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
		type: "button",
		onClick,
		initial: {
			opacity: 0,
			y: 16
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .4,
			delay
		},
		whileHover: { y: -2 },
		className: "glass-card glass-card-hover w-full rounded-xl p-5 text-left transition-all",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-2xl font-bold ${accent || "gold-text"}`,
						children: value
					}),
					sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: sub
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-primary" })
			})]
		})
	});
}
function ReportsPage() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const store = useStore();
	const [drill, setDrill] = (0, import_react.useState)(null);
	const [pkgFilter, setPkgFilter] = (0, import_react.useState)("All");
	const [agentFilter, setAgentFilter] = (0, import_react.useState)("All");
	const filteredBookings = (0, import_react.useMemo)(() => store.bookings.filter((b) => (pkgFilter === "All" || b.packageType === pkgFilter) && (agentFilter === "All" || b.agentId === agentFilter)), [
		store.bookings,
		pkgFilter,
		agentFilter
	]);
	const headFilter = (0, import_react.useMemo)(() => new Set(filteredBookings.map((b) => b.headId)), [filteredBookings]);
	const filteredEntries = (0, import_react.useMemo)(() => {
		if (pkgFilter === "All" && agentFilter === "All") return store.entries;
		return store.entries.filter((e) => !e.headId || headFilter.has(e.headId));
	}, [
		store.entries,
		headFilter,
		pkgFilter,
		agentFilter
	]);
	const input = (0, import_react.useMemo)(() => ({
		bookings: filteredBookings,
		clients: store.clients,
		agents: store.agents,
		suppliers: store.suppliers,
		entries: filteredEntries,
		opening: store.opening
	}), [
		filteredBookings,
		store.clients,
		store.agents,
		store.suppliers,
		filteredEntries,
		store.opening
	]);
	const t = (0, import_react.useMemo)(() => computeTotals(input), [input]);
	const byPkg = (0, import_react.useMemo)(() => profitByPackage(input), [input]);
	const trend = (0, import_react.useMemo)(() => monthlyTrend(input), [input]);
	const expCats = (0, import_react.useMemo)(() => expenseBreakdown(input), [input]);
	const topBookings = (0, import_react.useMemo)(() => topProfitableBookings(input, 5), [input]);
	const openDrill = (title, rows) => setDrill({
		title,
		rows,
		total: rows.reduce((s, r) => s + r.amount, 0)
	});
	const drillRevenue = () => openDrill("Total Revenue — Client Receipts", filteredEntries.filter((e) => e.type === "client_receive").map((e) => ({
		label: e.referenceName,
		sub: e.headId,
		date: e.date,
		amount: e.amount
	})));
	const drillCost = () => openDrill("Total Cost — Purchases & Booking Costs", [...filteredEntries.filter((e) => e.type === "purchase").map((e) => ({
		label: e.referenceName + (e.serviceCategory ? ` · ${e.serviceCategory}` : ""),
		sub: e.headId,
		date: e.date,
		amount: e.amount
	})), ...filteredBookings.filter((b) => !filteredEntries.some((e) => e.type === "purchase" && e.headId === b.headId)).map((b) => ({
		label: `Booking ${b.headId}`,
		sub: b.packageType,
		date: b.createdAt,
		amount: b.totalCost || 0
	}))]);
	const drillExpenses = () => openDrill("Expenses", filteredEntries.filter((e) => e.type === "expense").map((e) => ({
		label: e.referenceName,
		sub: e.note,
		date: e.date,
		amount: e.amount
	})));
	const drillSupplierPaid = () => openDrill("Supplier Payments", filteredEntries.filter((e) => e.type === "supplier_payment").map((e) => ({
		label: e.referenceName,
		sub: e.note,
		date: e.date,
		amount: e.amount
	})));
	const drillCommissionPaid = () => openDrill("Commissions Paid", filteredEntries.filter((e) => e.type === "agent_commission").map((e) => ({
		label: e.referenceName,
		sub: e.note,
		date: e.date,
		amount: e.amount
	})));
	const drillCommissionEarned = () => openDrill("Commissions Earned (per Booking)", filteredBookings.filter((b) => (b.commission || 0) > 0).map((b) => ({
		label: `Booking ${b.headId}`,
		sub: b.packageType,
		date: b.createdAt,
		amount: b.commission || 0
	})));
	const drillPending = () => openDrill("Pending Receivables", filteredBookings.filter((b) => b.totalAmount - b.amountReceived > 0).map((b) => ({
		label: `Booking ${b.headId}`,
		sub: `${b.packageType} · received ${formatCurrency(b.amountReceived)}`,
		date: b.createdAt,
		amount: b.totalAmount - b.amountReceived
	})));
	const drillSupplierPayable = () => openDrill("Supplier Payable", store.suppliers.map((s) => {
		const payable = s.totalPayable + (s.openingPayable || 0) - (s.totalPaid + (s.openingPaid || 0));
		return {
			label: s.companyName,
			sub: s.serviceType,
			amount: Math.max(0, payable)
		};
	}).filter((r) => r.amount > 0));
	const hasData = store.bookings.length > 0 || store.entries.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Financial Reports",
				subtitle: "Executive analytics, profitability & cash flow — click any card for details"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card flex flex-wrap items-center gap-3 rounded-xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
						children: "Filters"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: pkgFilter,
						onChange: (e) => setPkgFilter(e.target.value),
						className: "rounded-md border border-border bg-background px-3 py-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "All",
							children: "All Packages"
						}), Array.from(new Set(store.bookings.map((b) => b.packageType))).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p,
							children: p
						}, p))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: agentFilter,
						onChange: (e) => setAgentFilter(e.target.value),
						className: "rounded-md border border-border bg-background px-3 py-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "All",
							children: "All Agents"
						}), store.agents.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.id,
							children: a.name
						}, a.id))]
					}),
					(pkgFilter !== "All" || agentFilter !== "All") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setPkgFilter("All");
							setAgentFilter("All");
						},
						className: "rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground hover:bg-accent",
						children: "Reset"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Total Revenue",
						value: formatCurrency(t.totalRevenue),
						sub: "Client receipts + opening",
						icon: DollarSign,
						onClick: drillRevenue,
						delay: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Total Cost",
						value: formatCurrency(t.totalCost),
						sub: "Purchases + booking cost",
						icon: TrendingUp,
						onClick: drillCost,
						delay: .03
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Gross Profit",
						value: formatCurrency(t.grossProfit),
						sub: "Revenue − Cost",
						icon: PiggyBank,
						accent: t.grossProfit >= 0 ? "text-success" : "text-destructive",
						delay: .06
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Net Profit",
						value: formatCurrency(t.netProfit),
						sub: "After expenses & commission",
						icon: Award,
						accent: t.netProfit >= 0 ? "text-success" : "text-destructive",
						delay: .09
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Profit Margin",
						value: `${t.margin.toFixed(2)}%`,
						sub: "Net Profit / Revenue",
						icon: Percent,
						accent: t.margin >= 0 ? "text-success" : "text-destructive",
						delay: .12
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Cash on Hand",
						value: formatCurrency(t.cashOnHand),
						sub: "Net liquidity",
						icon: Wallet,
						delay: .15
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Pending Receivables",
						value: formatCurrency(t.pending),
						sub: "Click to view bookings",
						icon: Activity,
						onClick: drillPending,
						delay: .18
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Supplier Payable",
						value: formatCurrency(t.supplierPayable),
						sub: "Outstanding to suppliers",
						icon: Users,
						onClick: drillSupplierPayable,
						delay: .21
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Expenses",
						value: formatCurrency(t.expenses),
						sub: "Operating expenses",
						icon: Receipt,
						onClick: drillExpenses,
						delay: .24
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Commission Earned",
						value: formatCurrency(t.commissionEarned),
						sub: "Across all bookings",
						icon: Award,
						onClick: drillCommissionEarned,
						delay: .27
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Commission Paid",
						value: formatCurrency(t.commissionPaid),
						sub: "Outflow to agents",
						icon: Wallet,
						onClick: drillCommissionPaid,
						delay: .3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Supplier Paid",
						value: formatCurrency(t.supplierPaid),
						sub: "Outflow to suppliers",
						icon: Wallet,
						onClick: drillSupplierPaid,
						delay: .33
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Avg Profit / Booking",
						value: formatCurrency(t.avgProfitPerBooking),
						icon: BookOpen,
						delay: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Avg Ticket Size",
						value: formatCurrency(t.avgTicketSize),
						sub: "Per booking",
						icon: DollarSign,
						delay: .05
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Avg Revenue / Client",
						value: formatCurrency(t.avgRevenuePerClient),
						icon: Users,
						delay: .1
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Collection Efficiency",
						value: `${t.collectionEfficiency.toFixed(1)}%`,
						sub: "Received / Booked",
						icon: Percent,
						delay: .15
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-4 text-sm font-semibold",
					children: "Profit Breakdown by Package Type"
				}), byPkg.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No bookings yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: 260,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: byPkg,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								strokeDasharray: "3 3",
								stroke: "oklch(0.28 0.01 260)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "packageType",
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11,
								tickFormatter: (v) => `${(v / 1e3).toFixed(0)}k`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "oklch(0.17 0.01 260)",
									border: "1px solid oklch(0.28 0.01 260)",
									borderRadius: 8
								},
								formatter: (v) => formatCurrency(Number(v))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "revenue",
								fill: "oklch(0.8 0.12 80)",
								name: "Revenue",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "cost",
								fill: "oklch(0.6 0.15 280)",
								name: "Cost",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "profit",
								fill: "oklch(0.7 0.15 155)",
								name: "Profit",
								radius: [
									4,
									4,
									0,
									0
								]
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[260px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
					children: "Loading chart..."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Package"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Bookings"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Revenue"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Cost"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Profit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Margin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Avg Profit"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: byPkg.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/50 hover:bg-accent/30",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-medium",
									children: r.packageType
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.bookings
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-primary",
									children: formatCurrency(r.revenue)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: formatCurrency(r.cost)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-3 py-2 ${r.profit >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(r.profit)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2",
									children: [r.margin.toFixed(1), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: formatCurrency(r.avgProfit)
								})
							]
						}, r.packageType)) })]
					})
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-4 text-sm font-semibold",
					children: "Monthly Performance Trend"
				}), trend.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No transactions yet."
				}) : mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: 280,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data: trend,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								strokeDasharray: "3 3",
								stroke: "oklch(0.28 0.01 260)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "month",
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11,
								tickFormatter: (v) => `${(v / 1e3).toFixed(0)}k`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "oklch(0.17 0.01 260)",
									border: "1px solid oklch(0.28 0.01 260)",
									borderRadius: 8
								},
								formatter: (v) => formatCurrency(Number(v))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "revenue",
								stroke: "oklch(0.8 0.12 80)",
								strokeWidth: 2,
								dot: false,
								name: "Revenue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "cost",
								stroke: "oklch(0.6 0.15 280)",
								strokeWidth: 2,
								dot: false,
								name: "Cost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "profit",
								stroke: "oklch(0.7 0.15 155)",
								strokeWidth: 2,
								dot: false,
								name: "Profit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "expenses",
								stroke: "oklch(0.7 0.18 30)",
								strokeWidth: 2,
								dot: false,
								name: "Expenses"
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[280px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
					children: "Loading trend..."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-1 text-sm font-semibold",
							children: "Cash Flow Statement"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-[11px] text-muted-foreground",
							children: "Real money movement only — unpaid purchases are excluded (they sit in Supplier Payable)."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
							className: "w-full text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Opening Cash / Bank"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.openingCash)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b border-border",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold text-success",
										colSpan: 2,
										children: "Inflows"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Client Receipts (gross)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.liveReceived + t.clientRefunds)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Less: Refunds to Clients"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-2 py-2 text-right text-destructive",
										children: ["− ", formatCurrency(t.clientRefunds)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold",
										children: "Net Cash Received"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right font-semibold text-success",
										children: formatCurrency(t.liveReceived)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b border-border",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold text-destructive",
										colSpan: 2,
										children: "Outflows"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Supplier Payments"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.supplierPaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Expenses (live)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.expenses - t.openingExpenses)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Commission Paid"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.commissionPaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold",
										children: "Total Outflows"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right font-semibold text-destructive",
										children: formatCurrency(t.supplierPaid + (t.expenses - t.openingExpenses) + t.commissionPaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-3 text-base font-bold",
									children: "Closing Cash on Hand"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-2 py-3 text-right text-base font-bold ${t.cashOnHand >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(t.cashOnHand)
								})] })
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-lg border border-border/60 bg-accent/10 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Profit Reconciliation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
								className: "w-full text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"Revenue (live ",
											formatCurrency(t.liveReceived),
											" + B/F ",
											formatCurrency(t.openingRevenue),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.totalRevenue)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"− Cost of Sales (live ",
											formatCurrency(t.totalCost - t.openingCost),
											" + B/F ",
											formatCurrency(t.openingCost),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.totalCost)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-border/50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1 font-semibold",
											children: "= Gross Profit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `py-1 text-right font-semibold ${t.grossProfit >= 0 ? "text-success" : "text-destructive"}`,
											children: formatCurrency(t.grossProfit)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"− Expenses (incl. B/F ",
											formatCurrency(t.openingExpenses),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.expenses)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"− Agent Commission earned (incl. B/F ",
											formatCurrency(t.openingCommission),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.commissionEarned)
									})] }),
									t.openingProfit !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1",
										children: "+ Manual profit adjustment"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.openingProfit)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1.5 text-sm font-bold",
											children: "= Net Profit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `py-1.5 text-right text-sm font-bold ${t.netProfit >= 0 ? "text-success" : "text-destructive"}`,
											children: formatCurrency(t.netProfit)
										})]
									})
								] })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: "Expense Breakdown"
					}), expCats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "No expenses recorded."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: 200,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
							data: expCats,
							dataKey: "amount",
							nameKey: "category",
							cx: "50%",
							cy: "50%",
							innerRadius: 45,
							outerRadius: 75,
							stroke: "none",
							children: expCats.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: COLORS[i % COLORS.length] }, i))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							contentStyle: {
								background: "oklch(0.17 0.01 260)",
								border: "1px solid oklch(0.28 0.01 260)",
								borderRadius: 8
							},
							formatter: (v) => formatCurrency(Number(v))
						})] })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[200px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
						children: "Loading chart..."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
						className: "mt-3 w-full text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: expCats.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-2 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-2 inline-block h-2 w-2 rounded-full align-middle",
										style: { background: COLORS[i % COLORS.length] }
									}), r.category]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-2 text-right",
									children: formatCurrency(r.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-2 py-2 text-right text-xs text-muted-foreground",
									children: [r.pct.toFixed(1), "%"]
								})
							]
						}, r.category)) })
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: "Agent Performance"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Agent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Sales"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Earned"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Outstanding"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [store.agents.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-2 py-3 text-xs text-muted-foreground",
							children: "No agents."
						}) }), store.agents.map((a) => {
							const sales = a.totalSales + (a.openingSales || 0);
							const earned = a.commission + (a.openingCommission || 0);
							const paid = a.paidCommission + (a.openingPaidCommission || 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-medium",
										children: a.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-primary",
										children: formatCurrency(sales)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: formatCurrency(earned)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-success",
										children: formatCurrency(paid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-destructive",
										children: formatCurrency(Math.max(0, earned - paid))
									})
								]
							}, a.id);
						})] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: "Supplier Spend"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Supplier"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Payable"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Remaining"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [store.suppliers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 4,
							className: "px-2 py-3 text-xs text-muted-foreground",
							children: "No suppliers."
						}) }), store.suppliers.map((s) => {
							const payable = s.totalPayable + (s.openingPayable || 0);
							const paid = s.totalPaid + (s.openingPaid || 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-medium",
										children: s.companyName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: formatCurrency(payable)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-success",
										children: formatCurrency(paid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-destructive",
										children: formatCurrency(Math.max(0, payable - paid))
									})
								]
							}, s.id);
						})] })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-4 text-sm font-semibold",
					children: "Top 5 Most Profitable Bookings"
				}), topBookings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No bookings yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Head ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Package"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Revenue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Cost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Profit"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: topBookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/50 hover:bg-accent/30",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2 font-medium",
								children: b.headId
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: b.packageType
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2 text-primary",
								children: formatCurrency(b.totalAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: formatCurrency(b._cost)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `px-2 py-2 ${b._profit >= 0 ? "text-success" : "text-destructive"}`,
								children: formatCurrency(b._profit)
							})
						]
					}, b.id)) })]
				})]
			}),
			!hasData && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass-card rounded-xl p-10 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No data yet. Add bookings or entries to see live financial reports."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!drill,
				onOpenChange: (o) => !o && setDrill(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: drill?.title }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-h-[60vh] overflow-y-auto",
						children: [drill && drill.rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-8 text-center text-sm text-muted-foreground",
							children: "No records."
						}), drill && drill.rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2",
										children: "Date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2",
										children: "Reference"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2",
										children: "Detail"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2 text-right",
										children: "Amount"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [drill.rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-xs text-muted-foreground",
										children: r.date || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-medium",
										children: r.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-xs text-muted-foreground",
										children: r.sub || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right text-primary",
										children: formatCurrency(r.amount)
									})
								]
							}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "bg-accent/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 3,
									className: "px-2 py-3 font-semibold",
									children: "Total"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-3 text-right font-bold gold-text",
									children: formatCurrency(drill.total)
								})]
							})] })]
						})]
					})]
				})
			})
		]
	});
}
export { ReportsPage as component };
