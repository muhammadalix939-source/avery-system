import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as Package, B as Landmark, G as FileCheckCorner, I as Lock, L as LockOpen, Q as Compass, T as Plane, _t as BuildingComplex, f as Trash, g as ShieldCheck, gt as Bus, ht as Calculator, it as CircleAlert, k as Pencil, m as Sparkles, n as Wallet, q as Download, rt as CircleCheck, t as X, ut as Check, w as Plus, wt as ArrowRightLeft, xt as Banknote, y as Search } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as formatCurrency, a as entryDirection, f as getPKTDate, i as computeGroupUsedPax, o as useStore, r as computeAccountBalance, w as getClientName } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { t as Input } from "./input-CqV36rr2.mjs";
import { t as Label } from "./label-BYIfJH-v.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BBv8eX6f.mjs";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { s as generatePaymentReceipt } from "./pdf-DqNVIsfR.mjs";
import { a as paymentAllocations, c as splitEqual, l as validateAllocations, n as autoBalanceLast, o as purchaseAllocations, s as rebalanceEqual } from "./allocations-CV2mwFEX.mjs";
import { n as SearchableSelect, t as GroupSeatStrip } from "./SearchableSelect-CBJWeT4R.mjs";
import { n as sortEntities, t as SortBar } from "./SortBar-CcXdcaV6.mjs";
// node_modules/.nitro/vite/services/ssr/assets/entries-cI-vtBQL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AllocationEditor({ total, value, onChange, mode, heads, agents, groups = [], clients = [], allocationMode: controlledMode, onAllocationModeChange }) {
	const [localMode, setLocalMode] = (0, import_react.useState)("equal");
	const allocMode = controlledMode ?? localMode;
	const setAllocMode = (m) => {
		setLocalMode(m);
		onAllocationModeChange?.(m);
		if (m === "equal" && mode === "purchase") onChange(rebalanceEqual(value, total));
	};
	(0, import_react.useEffect)(() => {
		if (allocMode === "equal" && mode === "purchase" && value.length > 0) {
			if (value.reduce((s, l) => s + (l.amount || 0), 0) !== total) onChange(rebalanceEqual(value, total));
		}
	}, [
		total,
		allocMode,
		mode
	]);
	const allocatedSum = value.reduce((s, l) => s + (l.amount || 0), 0);
	const remaining = total - allocatedSum;
	const isBalanced = remaining === 0;
	const addPurchaseLine = (target) => {
		const lines = [...value];
		const newId = `A${lines.length + 1}`;
		let newLine;
		if (target === "head") newLine = {
			id: newId,
			target: "head",
			headId: heads[0]?.id || "",
			amount: 0
		};
		else if (target === "agent") newLine = {
			id: newId,
			target: "agent",
			agentId: agents[0]?.id || "",
			amount: 0,
			saleAmount: 0
		};
		else newLine = {
			id: newId,
			target: "office",
			amount: 0
		};
		const next = [...lines, newLine];
		if (allocMode === "equal") onChange(rebalanceEqual(next, total));
		else onChange(autoBalanceLast(next, total));
	};
	const addPaymentLine = (target) => {
		const lines = [...value];
		const newId = `P${lines.length + 1}`;
		let newLine;
		if (target === "head") newLine = {
			id: newId,
			target: "head",
			headId: heads[0]?.id || "",
			amount: 0
		};
		else if (target === "group") newLine = {
			id: newId,
			target: "group",
			groupId: groups[0]?.id || "",
			amount: 0
		};
		else if (target === "agent") newLine = {
			id: newId,
			target: "agent",
			agentId: agents[0]?.id || "",
			amount: 0
		};
		else newLine = {
			id: newId,
			target: "unallocated",
			amount: 0
		};
		const next = [...lines, newLine];
		if (allocMode === "equal") {
			const splits = splitEqual(total, next.length);
			onChange(next.map((l, i) => ({
				...l,
				amount: splits[i]
			})));
		} else {
			const otherSum = lines.reduce((s, l) => s + (l.amount || 0), 0);
			newLine.amount = Math.max(0, total - otherSum);
			onChange([...lines, newLine]);
		}
	};
	const removeLine = (index) => {
		const next = value.filter((_, i) => i !== index);
		if (allocMode === "equal" && mode === "purchase") onChange(rebalanceEqual(next, total));
		else onChange(next);
	};
	const updateLine = (index, patch) => {
		onChange(value.map((l, i) => i === index ? {
			...l,
			...patch
		} : l));
	};
	const handleAutoBalance = () => {
		if (mode === "purchase") onChange(autoBalanceLast(value, total));
		else {
			if (value.length === 0) return;
			const otherSum = value.slice(0, -1).reduce((s, l) => s + (l.amount || 0), 0);
			const remainder = Math.max(0, total - otherSum);
			onChange(value.map((l, i) => i === value.length - 1 ? {
				...l,
				amount: remainder
			} : l));
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-lg border border-primary/40 bg-primary/5 p-3 sm:p-4 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-primary/20 pb-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 rounded-md border border-border bg-accent/20 p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAllocMode("equal"),
						className: `rounded px-2.5 py-1 text-[11px] font-semibold transition ${allocMode === "equal" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: "Equal (Auto)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAllocMode("manual"),
						className: `rounded px-2.5 py-1 text-[11px] font-semibold transition ${allocMode === "manual" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: "Manual Shares"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-1.5 font-mono text-[11px]",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded bg-accent/40 px-2 py-0.5 text-foreground",
							children: ["Total: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: formatCurrency(total) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded bg-accent/40 px-2 py-0.5 text-foreground",
							children: ["Allocated: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: formatCurrency(allocatedSum) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `flex items-center gap-1 rounded px-2 py-0.5 font-semibold ${isBalanced ? "bg-success/20 text-success border border-success/30" : "bg-destructive/20 text-destructive border border-destructive/30"}`,
							children: [
								isBalanced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-3 w-3" }),
								"Remaining: ",
								remaining > 0 ? `+${formatCurrency(remaining)}` : formatCurrency(remaining)
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2.5",
				children: [value.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "py-3 text-center text-xs text-muted-foreground",
					children: [
						"No allocation lines yet. Add targets below to split this ",
						mode === "purchase" ? "purchase" : "payment",
						"."
					]
				}), value.map((line, idx) => {
					const costLine = line;
					const isAgent = line.target === "agent";
					const isHead = line.target === "head";
					const isGroup = line.target === "group";
					const isOffice = line.target === "office" || line.target === "unallocated";
					const headMembers = isHead && costLine.headId ? clients.filter((c) => c.headId === costLine.headId) : [];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 rounded-lg border border-border/60 bg-background/70 p-2.5 shadow-sm sm:flex-row sm:items-center sm:gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between sm:justify-start gap-1.5 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${isHead ? "bg-primary/20 text-primary border border-primary/30" : isAgent ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" : isGroup ? "bg-amber-500/20 text-amber-300 border border-amber-500/30" : "bg-muted text-muted-foreground border border-border"}`,
									children: line.target === "head" ? "Client Head" : line.target === "agent" ? "Agent" : line.target === "group" ? "Group / PNR" : "Office"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1 sm:hidden",
									children: [mode === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Toggle lock",
										onClick: () => updateLine(idx, { locked: !costLine.locked }),
										className: `p-1.5 rounded active-press ${costLine.locked ? "text-primary" : "text-muted-foreground"}`,
										children: costLine.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "h-3.5 w-3.5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Remove line",
										onClick: () => removeLine(idx),
										className: "p-1.5 rounded text-destructive hover:bg-destructive/15 active-press",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5" })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 grid grid-cols-1 sm:grid-cols-2 gap-2 min-w-0",
								children: [
									isHead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
										value: costLine.headId || "",
										onChange: (v) => updateLine(idx, {
											headId: v,
											clientId: void 0
										}),
										placeholder: "Select client head...",
										options: heads.map((h) => ({
											value: h.id,
											label: `${h.id} — ${h.name}`
										})),
										className: "h-8 text-xs"
									}), headMembers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
										value: costLine.clientId || "",
										onChange: (v) => updateLine(idx, { clientId: v || void 0 }),
										placeholder: "Whole Head (All)",
										options: [{
											value: "",
											label: "Whole Head (Shared)"
										}, ...headMembers.map((m) => ({
											value: m.id,
											label: `${m.id} — ${m.name}`
										}))],
										className: "h-8 text-xs"
									})] }),
									isAgent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
										value: line.agentId || "",
										onChange: (v) => updateLine(idx, { agentId: v }),
										placeholder: "Select agent...",
										options: agents.map((a) => ({
											value: a.id,
											label: `${a.id} — ${a.name}`
										})),
										className: "h-8 text-xs"
									}), mode === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: costLine.forClientName || "",
										onChange: (e) => updateLine(idx, { forClientName: e.target.value }),
										placeholder: "Passenger name",
										className: "h-8 text-xs bg-accent/20 border-border"
									})] }),
									isGroup && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
										value: line.groupId || "",
										onChange: (v) => updateLine(idx, { groupId: v }),
										placeholder: "Select group...",
										options: groups.map((g) => ({
											value: g.id,
											label: `${g.id} — ${g.name}`,
											hint: [g.category, g.pnr && `PNR ${g.pnr}`].filter(Boolean).join(" · ")
										})),
										className: "h-8 text-xs"
									}),
									isOffice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center text-xs text-muted-foreground px-2 py-1 italic",
										children: mode === "purchase" ? "Office / Stock inventory" : "Unallocated supplier payment"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 shrink-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[9px] text-muted-foreground",
											children: "Share PKR"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "0",
											step: "1",
											readOnly: allocMode === "equal",
											value: line.amount !== void 0 ? line.amount : "",
											onChange: (e) => {
												const v = Math.round(Number(e.target.value) || 0);
												const patch = { amount: v };
												if (isAgent && costLine.saleAmount === costLine.amount) patch.saleAmount = v;
												updateLine(idx, patch);
											},
											className: `h-8 text-xs text-right font-mono ${allocMode === "equal" ? "bg-accent/40 font-semibold cursor-not-allowed" : "bg-accent/20 border-border"}`
										})]
									}),
									mode === "purchase" && isAgent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-28",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[9px] text-muted-foreground",
											children: "Sale to Agent"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "0",
											step: "1",
											value: costLine.saleAmount !== void 0 ? costLine.saleAmount : costLine.amount,
											onChange: (e) => updateLine(idx, { saleAmount: Math.round(Number(e.target.value) || 0) }),
											className: "h-8 text-xs text-right font-mono bg-accent/20 border-border"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "hidden sm:flex items-center gap-1 pt-3.5",
										children: [mode === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Toggle lock",
											onClick: () => updateLine(idx, { locked: !costLine.locked }),
											className: `p-1.5 rounded transition ${costLine.locked ? "text-primary hover:bg-primary/10" : "text-muted-foreground hover:text-foreground"}`,
											children: costLine.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "h-3.5 w-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Remove line",
											onClick: () => removeLine(idx),
											className: "p-1.5 rounded text-destructive hover:bg-destructive/15 transition active-press",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5" })
										})]
									})
								]
							}),
							mode === "purchase" && isAgent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full sm:w-auto sm:ml-auto flex items-center justify-between sm:justify-end gap-2 text-[10px] text-muted-foreground border-t sm:border-t-0 border-border/40 pt-1.5 sm:pt-0",
								children: (() => {
									const c = costLine.amount || 0;
									const p = (costLine.saleAmount !== void 0 ? costLine.saleAmount : c) - c;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono",
										children: ["Profit: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: p >= 0 ? "text-success" : "text-destructive",
											children: formatCurrency(p)
										})]
									});
								})()
							}),
							mode === "purchase" && isHead && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full sm:w-auto sm:ml-auto flex items-center gap-1.5 text-[10px] text-muted-foreground border-t sm:border-t-0 border-border/40 pt-1.5 sm:pt-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: !!costLine.billClient,
										onChange: (e) => updateLine(idx, { billClient: e.target.checked }),
										className: "rounded border-border text-primary"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Also bill client" })]
								})
							})
						]
					}, line.id || idx);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-primary/20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: mode === "purchase" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPurchaseLine("head"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Head"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPurchaseLine("agent"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Agent"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPurchaseLine("office"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Office / Stock"]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPaymentLine("head"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Head"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPaymentLine("group"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Group"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPaymentLine("agent"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Agent"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => addPaymentLine("unallocated"),
							className: "h-7 text-[11px] gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Unallocated"]
						})
					] })
				}), allocMode === "manual" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "ghost",
					onClick: handleAutoBalance,
					className: "h-7 text-[11px] gap-1 text-primary hover:bg-primary/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3 w-3" }), " Auto-balance last"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] text-muted-foreground leading-relaxed",
				children: mode === "purchase" ? "Head shares post directly as cost to that Head's Business View. Agent shares post as Other Sale in the agent's ledger with disclosed profit." : "Head lines credit that Head's supplier payments. Group lines are prorated among the group's heads by their purchase cost share."
			})
		]
	});
}
var typeLabels = {
	client_receive: "Client Payment Received",
	purchase: "Purchase from Supplier",
	supplier_payment: "Supplier Payment",
	agent_commission: "Agent Commission",
	expense: "Expense",
	client_charge: "Extra Charge to Client",
	client_refund: "Refund to Client",
	supplier_refund: "Refund from Supplier",
	other_sale: "Other Sale",
	gift: "Gift & Expense",
	drawing: "Owner Drawing",
	agent_receive: "Agent Payment Received",
	client_discount: "Client Discount / Concession",
	supplier_discount: "Supplier Discount / Rebate",
	jv: "Journal Voucher (JV) / Settlement"
};
var typeColors = {
	client_receive: "text-success",
	purchase: "text-warning",
	supplier_payment: "text-destructive",
	agent_commission: "text-warning",
	expense: "text-destructive",
	client_charge: "text-primary",
	client_refund: "text-destructive",
	supplier_refund: "text-success",
	other_sale: "text-success",
	gift: "text-destructive",
	drawing: "text-destructive",
	agent_receive: "text-success",
	client_discount: "text-amber-400",
	supplier_discount: "text-emerald-400",
	jv: "text-primary font-medium"
};
/** Money that flows INTO the business (shown with a + sign). */
var INFLOW_TYPES = [
	"client_receive",
	"supplier_refund",
	"other_sale",
	"agent_receive"
];
/** Entries where real money moves — these capture account + instrument details. */
var MONEY_TYPES = [
	"client_receive",
	"agent_receive",
	"supplier_payment",
	"agent_commission",
	"expense",
	"client_refund",
	"supplier_refund",
	"drawing",
	"jv"
];
var METHODS = [
	"Cash",
	"Cheque",
	"Bank Transfer",
	"Online / Wallet"
];
var CHARGE_CATEGORIES = [
	"Embassy / Send-to-Embassy Fee",
	"Visa Fee",
	"Ticket Change / Reissue",
	"Excess Baggage",
	"Hotel Upgrade",
	"Transport Extra",
	"Insurance",
	"Service / Processing Charge",
	"Late Payment Charge",
	"Other Charge"
];
var SERVICE_CATEGORIES = [
	"Hotel",
	"Flight",
	"Visa",
	"Transport",
	"Package",
	"Ziyarah",
	"Insurance",
	"Other"
];
function buildDetailsPayload(cat, d) {
	const num = (v) => v === "" || v == null ? void 0 : Number(v) || 0;
	const str = (v) => typeof v === "string" && v.trim() ? v.trim() : void 0;
	const pax = {
		adults: num(d.adults),
		children: num(d.children),
		infants: num(d.infants),
		adultPrice: num(d.adultPrice),
		childPrice: num(d.childPrice),
		infantPrice: num(d.infantPrice)
	};
	if (cat === "Flight") return {
		...pax,
		ticketNumber: str(d.ticketNumber),
		pnr: str(d.pnr),
		sector: str(d.sector),
		tripType: d.tripType,
		departureDate: str(d.departureDate),
		returnDate: str(d.returnDate),
		multiCityRoute: str(d.multiCityRoute),
		airline: str(d.airline),
		flightNumber: str(d.flightNumber),
		cabinClass: str(d.cabinClass),
		description: str(d.description)
	};
	if (cat === "Hotel") return {
		hotelName: str(d.hotelName),
		city: str(d.city),
		roomType: str(d.roomType),
		rooms: num(d.rooms),
		perNight: num(d.perNight),
		nights: num(d.nights),
		checkIn: str(d.checkIn),
		checkOut: str(d.checkOut),
		mealPlan: str(d.mealPlan),
		confirmationNo: str(d.confirmationNo),
		description: str(d.description)
	};
	if (cat === "Visa") return {
		...pax,
		visaType: str(d.visaType),
		country: str(d.country),
		reference: str(d.reference),
		applicantNames: str(d.applicantNames),
		description: str(d.description)
	};
	if (cat === "Transport") return {
		...pax,
		route: str(d.route),
		vehicle: str(d.vehicle),
		pickupDate: str(d.pickupDate),
		driverName: str(d.driverName),
		driverPhone: str(d.driverPhone),
		voucherNo: str(d.voucherNo),
		description: str(d.description)
	};
	if (cat === "Package") return {
		...pax,
		packageName: str(d.packageName),
		packageType: d.packageType,
		destinationCountry: str(d.destinationCountry),
		destinationCity: str(d.destinationCity),
		isMultiCity: d.isMultiCity,
		packageDurationDays: num(d.packageDurationDays),
		packageDurationNights: num(d.packageDurationNights),
		packageInclusions: Array.isArray(d.packageInclusions) ? d.packageInclusions : void 0,
		startDate: str(d.startDate),
		endDate: str(d.endDate),
		description: str(d.description)
	};
	if (cat === "Ziyarah") return {
		...pax,
		city: str(d.city),
		ziyarahSites: str(d.ziyarahSites),
		vehicle: str(d.vehicle),
		guideName: str(d.guideName),
		description: str(d.description)
	};
	return {
		...pax,
		description: str(d.description)
	};
}
function EntriesPage() {
	const store = useStore();
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("all");
	const [form, setForm] = (0, import_react.useState)({
		date: "",
		type: "client_receive",
		headId: "",
		referenceId: "",
		referenceName: "",
		amount: "",
		note: ""
	});
	const [serviceCategory, setServiceCategory] = (0, import_react.useState)("");
	const [extra, setExtra] = (0, import_react.useState)({
		clientId: "",
		chargeCategory: "",
		refundOf: "",
		refundReason: ""
	});
	const [pf, setPf] = (0, import_react.useState)({
		for: "",
		agentId: "",
		clientName: "",
		saleAmount: ""
	});
	const [purchaseAllocationsState, setPurchaseAllocationsState] = (0, import_react.useState)([]);
	const [purchaseAllocMode, setPurchaseAllocMode] = (0, import_react.useState)("equal");
	const [payAllocMode, setPayAllocMode] = (0, import_react.useState)("simple");
	const [paymentAllocationsState, setPaymentAllocationsState] = (0, import_react.useState)([]);
	const [splitViewEntry, setSplitViewEntry] = (0, import_react.useState)(null);
	const [entryToDelete, setEntryToDelete] = (0, import_react.useState)(null);
	const [groupMode, setGroupMode] = (0, import_react.useState)("none");
	const [groupId, setGroupId] = (0, import_react.useState)("");
	const [refs, setRefs] = (0, import_react.useState)({
		agentId: "",
		paidBy: ""
	});
	const emptyPay = {
		method: "Cash",
		accountId: "",
		chequeNo: "",
		chequeDate: "",
		bankName: "",
		txnRef: "",
		collectedBy: ""
	};
	const [pay, setPay] = (0, import_react.useState)(emptyPay);
	const [methodFilter, setMethodFilter] = (0, import_react.useState)("all");
	const [accountFilter, setAccountFilter] = (0, import_react.useState)("all");
	const [sortKey, setSortKey] = (0, import_react.useState)("date_desc");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const emptyJv = {
		jvType: "account_transfer",
		toAccountId: "",
		targetBalance: "",
		direction: "out"
	};
	const [jv, setJv] = (0, import_react.useState)(emptyJv);
	const [newGroup, setNewGroup] = (0, import_react.useState)({
		name: "",
		pnr: "",
		flightNumber: "",
		date: "",
		description: "",
		totalPax: ""
	});
	const emptyDetails = {
		ticketNumber: "",
		pnr: "",
		sector: "",
		tripType: "One Way",
		departureDate: "",
		returnDate: "",
		multiCityRoute: "",
		airline: "",
		flightNumber: "",
		cabinClass: "Economy",
		hotelName: "",
		city: "",
		roomType: "Quad",
		mealPlan: "Room Only",
		confirmationNo: "",
		rooms: "",
		perNight: "",
		nights: "",
		checkIn: "",
		checkOut: "",
		visaType: "Umrah",
		country: "Saudi Arabia",
		reference: "",
		applicantNames: "",
		route: "",
		vehicle: "Private Sedan",
		pickupDate: "",
		driverName: "",
		driverPhone: "",
		voucherNo: "",
		packageName: "",
		packageType: "International",
		destinationCountry: "Saudi Arabia",
		destinationCity: "Makkah + Madinah",
		isMultiCity: true,
		packageDurationDays: "",
		packageDurationNights: "",
		packageInclusions: [
			"Hotel",
			"Visa",
			"Transport"
		],
		startDate: "",
		endDate: "",
		adults: "",
		children: "",
		infants: "",
		adultPrice: "",
		childPrice: "",
		infantPrice: "",
		ziyarahSites: "",
		guideName: "",
		description: ""
	};
	const [details, setDetails] = (0, import_react.useState)(emptyDetails);
	const [autoTotal, setAutoTotal] = (0, import_react.useState)(true);
	const supplierGroups = (0, import_react.useMemo)(() => {
		if (!form.referenceId) return store.groups;
		return store.groups.filter((g) => !g.supplierId || g.supplierId === form.referenceId);
	}, [store.groups, form.referenceId]);
	const validationCtx = (0, import_react.useMemo)(() => {
		const headsSet = new Set(store.clients.map((c) => c.headId));
		const agentsSet = new Set(store.agents.map((a) => a.id));
		const membersMap = /* @__PURE__ */ new Map();
		store.clients.forEach((c) => {
			if (!membersMap.has(c.headId)) membersMap.set(c.headId, /* @__PURE__ */ new Set());
			membersMap.get(c.headId).add(c.id);
		});
		return {
			heads: headsSet,
			agents: agentsSet,
			membersOf: (headId) => membersMap.get(headId) || /* @__PURE__ */ new Set()
		};
	}, [store.clients, store.agents]);
	function computeAutoAmount(cat, d) {
		if (cat === "Hotel") {
			const r = Number(d.rooms) || 0, pn = Number(d.perNight) || 0, n = Number(d.nights) || 0;
			return r > 0 && pn > 0 && n > 0 ? r * pn * n : null;
		}
		if (!cat) return null;
		const a = Number(d.adults) || 0, c = Number(d.children) || 0, i = Number(d.infants) || 0;
		const ap = Number(d.adultPrice) || 0, cp = Number(d.childPrice) || 0, ip = Number(d.infantPrice) || 0;
		if (a + c + i + ap + cp + ip === 0) return null;
		return a * ap + c * cp + i * ip;
	}
	function setDetailField(k, v) {
		const next = {
			...details,
			[k]: v
		};
		setDetails(next);
		if (autoTotal && form.type === "purchase") {
			const auto = computeAutoAmount(serviceCategory, next);
			if (auto !== null) setForm((f) => ({
				...f,
				amount: String(auto)
			}));
		}
	}
	/** Entry types that may be tagged to a Group / PNR */
	const groupTaggable = form.type === "purchase" || form.type === "supplier_payment" || form.type === "supplier_refund" || form.type === "expense";
	const filtered = (0, import_react.useMemo)(() => {
		const list = store.entries.filter((e) => typeFilter === "all" || e.type === typeFilter).filter((e) => methodFilter === "all" || MONEY_TYPES.includes(e.type) && e.paymentMethod === methodFilter).filter((e) => {
			if (accountFilter === "all") return true;
			const acc = store.accounts.find((a) => a.id === accountFilter);
			if (!acc) return true;
			if (acc.openingDate && e.date < acc.openingDate) return false;
			return e.accountId === accountFilter || e.type === "jv" && e.toAccountId === accountFilter;
		}).filter((e) => {
			if (!searchQuery.trim()) return true;
			const q = searchQuery.toLowerCase().trim();
			const idMatch = e.id.toLowerCase().includes(q);
			const headMatch = e.headId?.toLowerCase().includes(q) || false;
			const refMatch = e.referenceName?.toLowerCase().includes(q) || false;
			const noteMatch = e.note?.toLowerCase().includes(q) || false;
			const drawerMatch = e.drawerName?.toLowerCase().includes(q) || false;
			const methodMatch = e.paymentMethod?.toLowerCase().includes(q) || false;
			return idMatch || headMatch || refMatch || noteMatch || drawerMatch || methodMatch;
		});
		return sortEntities(list, sortKey, {
			date: (e) => e.date,
			amount: (e) => e.amount,
			name: (e) => e.referenceName || e.drawerName || e.id
		});
	}, [
		store.entries,
		store.accounts,
		typeFilter,
		methodFilter,
		accountFilter,
		searchQuery,
		sortKey
	]);
	function validateEntryForm() {
		const amt = Number(form.amount);
		if (!amt || amt <= 0) {
			toast.error("Please enter a valid amount greater than 0");
			return false;
		}
		if ([
			"purchase",
			"supplier_payment",
			"supplier_refund",
			"supplier_discount"
		].includes(form.type) && !form.referenceId) {
			toast.error("Please select a Supplier");
			return false;
		}
		if ([
			"client_receive",
			"client_charge",
			"client_refund",
			"client_discount"
		].includes(form.type) && !form.headId) {
			toast.error("Please select a Client Head");
			return false;
		}
		if (form.type === "agent_receive" && !form.referenceId) {
			toast.error("Please select an Agent");
			return false;
		}
		if (form.type === "drawing" && !form.referenceName?.trim()) {
			toast.error("Please enter the Drawer / Partner name");
			return false;
		}
		if (MONEY_TYPES.includes(form.type)) {
			if (form.type === "jv") {
				if (!pay.accountId) {
					toast.error("Select the primary/source account");
					return false;
				}
				if (jv.jvType === "account_transfer" && !jv.toAccountId) {
					toast.error("Select the destination account");
					return false;
				}
				if (jv.jvType === "account_transfer" && pay.accountId === jv.toAccountId) {
					toast.error("Source and destination accounts must be different");
					return false;
				}
				return true;
			}
			if (pay.method === "Cheque" && !pay.chequeNo) {
				toast.error("Enter the cheque number");
				return false;
			}
			if ((pay.method === "Bank Transfer" || pay.method === "Online / Wallet") && !pay.txnRef) {
				toast.error("Enter the transaction / reference number");
				return false;
			}
		}
		return true;
	}
	function handleAdd() {
		if (!validateEntryForm()) return;
		let finalGroupId = groupMode === "existing" ? groupId : void 0;
		if (groupMode === "new" && newGroup.name.trim()) finalGroupId = store.addGroup({
			name: newGroup.name.trim(),
			category: serviceCategory || "Other",
			supplierId: form.referenceId || void 0,
			pnr: newGroup.pnr || void 0,
			flightNumber: newGroup.flightNumber || void 0,
			date: newGroup.date || void 0,
			description: newGroup.description || void 0,
			totalPax: newGroup.totalPax ? Number(newGroup.totalPax) : void 0
		});
		let finalAllocations = void 0;
		let finalAllocMode = void 0;
		if (form.type === "purchase") {
			const amt = Number(form.amount) || 0;
			if (pf.for === "split") {
				const valRes = validateAllocations(purchaseAllocationsState, amt, validationCtx);
				if (!valRes.ok) {
					toast.error(valRes.errors[0] || "Invalid allocations");
					return;
				}
				finalAllocations = purchaseAllocationsState;
				finalAllocMode = purchaseAllocMode;
			} else if (pf.for === "client") {
				if (!form.headId) {
					toast.error("Please select a client head");
					return;
				}
				finalAllocations = [{
					id: "A1",
					target: "head",
					headId: form.headId,
					...extra.clientId ? { clientId: extra.clientId } : {},
					amount: amt
				}];
				finalAllocMode = "manual";
			} else if (pf.for === "agent") {
				if (!pf.agentId) {
					toast.error("Please select an agent");
					return;
				}
				const saleAmt = pf.saleAmount ? Number(pf.saleAmount) : amt;
				finalAllocations = [{
					id: "A1",
					target: "agent",
					agentId: pf.agentId,
					...pf.clientName ? { forClientName: pf.clientName } : {},
					amount: amt,
					saleAmount: saleAmt
				}];
				finalAllocMode = "manual";
			} else {
				finalAllocations = [{
					id: "A1",
					target: "office",
					amount: amt
				}];
				finalAllocMode = "manual";
			}
		}
		if (form.type === "supplier_payment" && payAllocMode === "split") {
			const amt = Number(form.amount) || 0;
			const sum = paymentAllocationsState.reduce((s, p) => s + (p.amount || 0), 0);
			if (sum !== amt) {
				toast.error(`Payment allocations sum (${formatCurrency(sum)}) must equal total payment (${formatCurrency(amt)})`);
				return;
			}
		}
		const nonOffice = (finalAllocations || []).filter((a) => a.target !== "office");
		let singlePurchasedFor = void 0;
		let singleHeadId = void 0;
		let singleAgentId = void 0;
		let singleForClientName = void 0;
		let singleSaleAmount = void 0;
		if (form.type === "purchase" && nonOffice.length === 1) {
			const one = nonOffice[0];
			if (one.target === "head") {
				singlePurchasedFor = "client";
				singleHeadId = one.headId;
			} else if (one.target === "agent") {
				singlePurchasedFor = "agent";
				singleAgentId = one.agentId;
				singleForClientName = one.forClientName;
				singleSaleAmount = one.saleAmount;
			}
		}
		const supplierTypes = [
			"purchase",
			"supplier_payment",
			"supplier_refund",
			"supplier_discount"
		];
		let finalRefName = form.referenceName;
		if (supplierTypes.includes(form.type) && form.referenceId) {
			const sp = store.suppliers.find((s) => s.id === form.referenceId);
			if (sp) finalRefName = sp.companyName;
		} else if (form.type === "agent_receive" || form.type === "agent_commission") {
			const ag = store.agents.find((a) => a.id === form.referenceId);
			if (ag) finalRefName = ag.name;
		}
		store.addEntry({
			date: form.date || getPKTDate(),
			type: form.type,
			headId: form.type === "purchase" ? singleHeadId || "" : form.headId,
			referenceId: form.referenceId,
			referenceName: finalRefName,
			amount: Number(form.amount) || 0,
			note: form.note,
			serviceCategory: serviceCategory || void 0,
			purchaseDetails: form.type === "purchase" ? buildDetailsPayload(serviceCategory, details) : void 0,
			groupId: groupTaggable ? finalGroupId : void 0,
			purchasedFor: form.type === "purchase" ? singlePurchasedFor : void 0,
			forClientName: form.type === "purchase" ? singleForClientName : void 0,
			saleAmount: form.type === "purchase" ? singleSaleAmount : void 0,
			agentId: form.type === "purchase" ? singleAgentId : refs.agentId || void 0,
			allocations: form.type === "purchase" ? finalAllocations : void 0,
			allocationMode: form.type === "purchase" ? finalAllocMode : void 0,
			paymentAllocations: form.type === "supplier_payment" && payAllocMode === "split" ? paymentAllocationsState : void 0,
			paidBy: refs.paidBy || void 0,
			clientId: extra.clientId || void 0,
			drawerId: form.type === "drawing" ? form.referenceId || void 0 : void 0,
			drawerName: form.type === "drawing" ? form.referenceName || void 0 : void 0,
			chargeCategory: form.type === "client_charge" || form.type === "drawing" ? extra.chargeCategory || void 0 : void 0,
			refundOf: extra.refundOf || void 0,
			paymentMethod: MONEY_TYPES.includes(form.type) ? pay.method : void 0,
			accountId: MONEY_TYPES.includes(form.type) ? pay.accountId || void 0 : void 0,
			chequeNo: MONEY_TYPES.includes(form.type) && pay.method === "Cheque" ? pay.chequeNo || void 0 : void 0,
			chequeDate: MONEY_TYPES.includes(form.type) && pay.method === "Cheque" ? pay.chequeDate || void 0 : void 0,
			bankName: MONEY_TYPES.includes(form.type) && pay.method !== "Cash" ? pay.bankName || void 0 : void 0,
			txnRef: MONEY_TYPES.includes(form.type) && pay.method !== "Cash" ? pay.txnRef || void 0 : void 0,
			collectedBy: MONEY_TYPES.includes(form.type) ? pay.collectedBy || void 0 : void 0,
			direction: form.type === "jv" ? jv.direction : MONEY_TYPES.includes(form.type) ? entryDirection(form.type) : void 0,
			refundReason: extra.refundReason || void 0,
			jvType: form.type === "jv" ? jv.jvType : void 0,
			toAccountId: form.type === "jv" && jv.jvType === "account_transfer" ? jv.toAccountId || void 0 : void 0,
			targetBalance: form.type === "jv" && jv.targetBalance ? Number(jv.targetBalance) : void 0
		});
		setForm({
			date: "",
			type: "client_receive",
			headId: "",
			referenceId: "",
			referenceName: "",
			amount: "",
			note: ""
		});
		setPf({
			for: "",
			agentId: "",
			clientName: "",
			saleAmount: ""
		});
		setPurchaseAllocationsState([]);
		setPurchaseAllocMode("equal");
		setPayAllocMode("simple");
		setPaymentAllocationsState([]);
		setServiceCategory("");
		setDetails(emptyDetails);
		setExtra({
			clientId: "",
			chargeCategory: "",
			refundOf: "",
			refundReason: ""
		});
		setGroupMode("none");
		setGroupId("");
		setNewGroup({
			name: "",
			pnr: "",
			flightNumber: "",
			date: "",
			description: "",
			totalPax: ""
		});
		setRefs({
			agentId: "",
			paidBy: ""
		});
		setPay(emptyPay);
		setJv(emptyJv);
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		if (!validateEntryForm()) return;
		let finalGroupId = groupMode === "existing" ? groupId : groupMode === "none" ? void 0 : selected.groupId;
		if (groupMode === "new" && newGroup.name.trim()) finalGroupId = store.addGroup({
			name: newGroup.name.trim(),
			category: serviceCategory || "Other",
			supplierId: form.referenceId || void 0,
			pnr: newGroup.pnr || void 0,
			flightNumber: newGroup.flightNumber || void 0,
			date: newGroup.date || void 0,
			description: newGroup.description || void 0,
			totalPax: newGroup.totalPax ? Number(newGroup.totalPax) : void 0
		});
		let finalAllocations = void 0;
		let finalAllocMode = void 0;
		if (form.type === "purchase") {
			const amt = Number(form.amount) || 0;
			if (pf.for === "split") {
				const valRes = validateAllocations(purchaseAllocationsState, amt, validationCtx);
				if (!valRes.ok) {
					toast.error(valRes.errors[0] || "Invalid allocations");
					return;
				}
				finalAllocations = purchaseAllocationsState;
				finalAllocMode = purchaseAllocMode;
			} else if (pf.for === "client") {
				if (!form.headId) {
					toast.error("Please select a client head");
					return;
				}
				finalAllocations = [{
					id: "A1",
					target: "head",
					headId: form.headId,
					...extra.clientId ? { clientId: extra.clientId } : {},
					amount: amt
				}];
				finalAllocMode = "manual";
			} else if (pf.for === "agent") {
				if (!pf.agentId) {
					toast.error("Please select an agent");
					return;
				}
				const saleAmt = pf.saleAmount ? Number(pf.saleAmount) : amt;
				finalAllocations = [{
					id: "A1",
					target: "agent",
					agentId: pf.agentId,
					...pf.clientName ? { forClientName: pf.clientName } : {},
					amount: amt,
					saleAmount: saleAmt
				}];
				finalAllocMode = "manual";
			} else {
				finalAllocations = [{
					id: "A1",
					target: "office",
					amount: amt
				}];
				finalAllocMode = "manual";
			}
		}
		if (form.type === "supplier_payment" && payAllocMode === "split") {
			const amt = Number(form.amount) || 0;
			const sum = paymentAllocationsState.reduce((s, p) => s + (p.amount || 0), 0);
			if (sum !== amt) {
				toast.error(`Payment allocations sum (${formatCurrency(sum)}) must equal total payment (${formatCurrency(amt)})`);
				return;
			}
		}
		const nonOffice = (finalAllocations || []).filter((a) => a.target !== "office");
		let singlePurchasedFor = void 0;
		let singleHeadId = void 0;
		let singleAgentId = void 0;
		let singleForClientName = void 0;
		let singleSaleAmount = void 0;
		if (form.type === "purchase" && nonOffice.length === 1) {
			const one = nonOffice[0];
			if (one.target === "head") {
				singlePurchasedFor = "client";
				singleHeadId = one.headId;
			} else if (one.target === "agent") {
				singlePurchasedFor = "agent";
				singleAgentId = one.agentId;
				singleForClientName = one.forClientName;
				singleSaleAmount = one.saleAmount;
			}
		}
		const supplierTypes = [
			"purchase",
			"supplier_payment",
			"supplier_refund",
			"supplier_discount"
		];
		let finalRefName = form.referenceName;
		if (supplierTypes.includes(form.type) && form.referenceId) {
			const sp = store.suppliers.find((s) => s.id === form.referenceId);
			if (sp) finalRefName = sp.companyName;
		} else if (form.type === "agent_receive" || form.type === "agent_commission") {
			const ag = store.agents.find((a) => a.id === form.referenceId);
			if (ag) finalRefName = ag.name;
		}
		store.updateEntry(selected.id, {
			date: form.date,
			type: form.type,
			headId: form.type === "purchase" ? singleHeadId || "" : form.headId,
			referenceId: form.referenceId,
			referenceName: finalRefName,
			amount: Number(form.amount) || 0,
			note: form.note,
			serviceCategory: serviceCategory || void 0,
			purchaseDetails: form.type === "purchase" ? buildDetailsPayload(serviceCategory, details) : void 0,
			groupId: groupTaggable ? finalGroupId : void 0,
			purchasedFor: form.type === "purchase" ? singlePurchasedFor : void 0,
			forClientName: form.type === "purchase" ? singleForClientName : void 0,
			saleAmount: form.type === "purchase" ? singleSaleAmount : void 0,
			agentId: form.type === "purchase" ? singleAgentId : refs.agentId || void 0,
			allocations: form.type === "purchase" ? finalAllocations : void 0,
			allocationMode: form.type === "purchase" ? finalAllocMode : void 0,
			paymentAllocations: form.type === "supplier_payment" && payAllocMode === "split" ? paymentAllocationsState : void 0,
			paidBy: refs.paidBy || void 0,
			clientId: extra.clientId || void 0,
			drawerId: form.type === "drawing" ? form.referenceId || void 0 : void 0,
			drawerName: form.type === "drawing" ? form.referenceName || void 0 : void 0,
			chargeCategory: form.type === "client_charge" || form.type === "drawing" ? extra.chargeCategory || void 0 : void 0,
			refundOf: extra.refundOf || void 0,
			paymentMethod: MONEY_TYPES.includes(form.type) ? pay.method : void 0,
			accountId: MONEY_TYPES.includes(form.type) ? pay.accountId || void 0 : void 0,
			chequeNo: MONEY_TYPES.includes(form.type) && pay.method === "Cheque" ? pay.chequeNo || void 0 : void 0,
			chequeDate: MONEY_TYPES.includes(form.type) && pay.method === "Cheque" ? pay.chequeDate || void 0 : void 0,
			bankName: MONEY_TYPES.includes(form.type) && pay.method !== "Cash" ? pay.bankName || void 0 : void 0,
			txnRef: MONEY_TYPES.includes(form.type) && pay.method !== "Cash" ? pay.txnRef || void 0 : void 0,
			collectedBy: MONEY_TYPES.includes(form.type) ? pay.collectedBy || void 0 : void 0,
			direction: form.type === "jv" ? jv.direction : MONEY_TYPES.includes(form.type) ? entryDirection(form.type) : void 0,
			refundReason: extra.refundReason || void 0,
			jvType: form.type === "jv" ? jv.jvType : void 0,
			toAccountId: form.type === "jv" && jv.jvType === "account_transfer" ? jv.toAccountId || void 0 : void 0,
			targetBalance: form.type === "jv" && jv.targetBalance ? Number(jv.targetBalance) : void 0
		});
		setPurchaseAllocationsState([]);
		setPurchaseAllocMode("equal");
		setPayAllocMode("simple");
		setPaymentAllocationsState([]);
		setEditOpen(false);
	}
	function openEdit(e) {
		setSelected(e);
		setForm({
			date: e.date,
			type: e.type,
			headId: e.headId,
			referenceId: e.referenceId,
			referenceName: e.referenceName,
			amount: String(e.amount),
			note: e.note
		});
		setServiceCategory(e.serviceCategory || "");
		setExtra({
			clientId: e.clientId || "",
			chargeCategory: e.chargeCategory || "",
			refundOf: e.refundOf || "",
			refundReason: e.refundReason || ""
		});
		setRefs({
			agentId: e.agentId || "",
			paidBy: e.paidBy || ""
		});
		setPay({
			method: e.paymentMethod || "Cash",
			accountId: e.accountId || "",
			chequeNo: e.chequeNo || "",
			chequeDate: e.chequeDate || "",
			bankName: e.bankName || "",
			txnRef: e.txnRef || "",
			collectedBy: e.collectedBy || ""
		});
		setJv({
			jvType: e.jvType || "account_transfer",
			toAccountId: e.toAccountId || "",
			targetBalance: e.targetBalance != null ? String(e.targetBalance) : "",
			direction: e.direction || (e.type === "jv" ? "out" : entryDirection(e.type))
		});
		if (e.type === "purchase") {
			const allocs = purchaseAllocations(e);
			setPurchaseAllocationsState(allocs);
			setPurchaseAllocMode(e.allocationMode || "equal");
			if (allocs.length > 1) setPf({
				for: "split",
				agentId: "",
				clientName: "",
				saleAmount: ""
			});
			else if (allocs.length === 1) {
				const a = allocs[0];
				if (a.target === "office") setPf({
					for: "",
					agentId: "",
					clientName: "",
					saleAmount: ""
				});
				else if (a.target === "head") {
					setPf({
						for: "client",
						agentId: "",
						clientName: "",
						saleAmount: ""
					});
					setExtra((x) => ({
						...x,
						clientId: a.clientId || ""
					}));
				} else if (a.target === "agent") setPf({
					for: "agent",
					agentId: a.agentId || "",
					clientName: a.forClientName || "",
					saleAmount: a.saleAmount != null ? String(a.saleAmount) : ""
				});
			} else setPf({
				for: "",
				agentId: "",
				clientName: "",
				saleAmount: ""
			});
		} else {
			setPf({
				for: "",
				agentId: "",
				clientName: "",
				saleAmount: ""
			});
			setPurchaseAllocationsState([]);
			setPurchaseAllocMode("equal");
		}
		if (e.type === "supplier_payment") {
			const pAllocs = paymentAllocations(e);
			setPaymentAllocationsState(pAllocs);
			if (e.paymentAllocations && e.paymentAllocations.length > 1) setPayAllocMode("split");
			else setPayAllocMode("simple");
		} else {
			setPayAllocMode("simple");
			setPaymentAllocationsState([]);
		}
		if (e.groupId) {
			setGroupMode("existing");
			setGroupId(e.groupId);
		} else {
			setGroupMode("none");
			setGroupId("");
		}
		setNewGroup({
			name: "",
			pnr: "",
			flightNumber: "",
			date: "",
			description: "",
			totalPax: ""
		});
		const d = e.purchaseDetails || {};
		setDetails({
			ticketNumber: d.ticketNumber || "",
			pnr: d.pnr || "",
			sector: d.sector || "",
			tripType: d.tripType || "One Way",
			departureDate: d.departureDate || "",
			returnDate: d.returnDate || "",
			multiCityRoute: d.multiCityRoute || "",
			airline: d.airline || "",
			flightNumber: d.flightNumber || "",
			cabinClass: d.cabinClass || "Economy",
			hotelName: d.hotelName || "",
			city: d.city || "",
			roomType: d.roomType || "Quad",
			mealPlan: d.mealPlan || "Room Only",
			confirmationNo: d.confirmationNo || "",
			rooms: d.rooms != null ? String(d.rooms) : "",
			perNight: d.perNight != null ? String(d.perNight) : "",
			nights: d.nights != null ? String(d.nights) : "",
			checkIn: d.checkIn || "",
			checkOut: d.checkOut || "",
			visaType: d.visaType || "Umrah",
			country: d.country || "Saudi Arabia",
			reference: d.reference || "",
			applicantNames: d.applicantNames || "",
			route: d.route || "",
			vehicle: d.vehicle || "Private Sedan",
			pickupDate: d.pickupDate || "",
			driverName: d.driverName || "",
			driverPhone: d.driverPhone || "",
			voucherNo: d.voucherNo || "",
			packageName: d.packageName || "",
			packageType: d.packageType || "International",
			destinationCountry: d.destinationCountry || "Saudi Arabia",
			destinationCity: d.destinationCity || "Makkah + Madinah",
			isMultiCity: d.isMultiCity ?? true,
			packageDurationDays: d.packageDurationDays != null ? String(d.packageDurationDays) : "",
			packageDurationNights: d.packageDurationNights != null ? String(d.packageDurationNights) : "",
			packageInclusions: d.packageInclusions || [
				"Hotel",
				"Visa",
				"Transport"
			],
			startDate: d.startDate || "",
			endDate: d.endDate || "",
			adults: d.adults != null ? String(d.adults) : "",
			children: d.children != null ? String(d.children) : "",
			infants: d.infants != null ? String(d.infants) : "",
			adultPrice: d.adultPrice != null ? String(d.adultPrice) : "",
			childPrice: d.childPrice != null ? String(d.childPrice) : "",
			infantPrice: d.infantPrice != null ? String(d.infantPrice) : "",
			ziyarahSites: d.ziyarahSites || "",
			guideName: d.guideName || "",
			description: d.description || ""
		});
		setAutoTotal(false);
		setEditOpen(true);
	}
	const totalReceived = store.entries.filter((e) => e.type === "client_receive" || e.type === "agent_receive").reduce((s, e) => s + e.amount, 0) - store.entries.filter((e) => e.type === "client_refund").reduce((s, e) => s + e.amount, 0);
	const totalPaid = store.entries.filter((e) => e.type === "supplier_payment" || e.type === "agent_commission" || e.type === "expense" || e.type === "drawing").reduce((s, e) => s + e.amount, 0) - store.entries.filter((e) => e.type === "supplier_refund").reduce((s, e) => s + e.amount, 0);
	const totalPurchases = store.entries.filter((e) => e.type === "purchase").reduce((s, e) => s + e.amount, 0);
	function updateFormType(type) {
		setForm({
			...form,
			type,
			referenceId: "",
			referenceName: "",
			headId: ""
		});
		setExtra({
			clientId: "",
			chargeCategory: "",
			refundOf: "",
			refundReason: ""
		});
		setRefs({
			agentId: "",
			paidBy: ""
		});
		setGroupMode("none");
		setGroupId("");
	}
	function updateReferenceId(refId) {
		let name = "";
		if (form.type === "client_receive" || form.type === "client_charge" || form.type === "client_refund" || form.type === "client_discount") {
			if (store.bookings.find((b) => b.headId === refId)) {
				const headClient = store.clients.find((c) => c.headId === refId);
				name = headClient ? getClientName(headClient) : refId;
			}
			setForm({
				...form,
				referenceId: refId,
				referenceName: name || form.referenceName,
				headId: refId
			});
			setExtra((x) => ({
				...x,
				clientId: ""
			}));
		} else if (form.type === "supplier_payment" || form.type === "purchase" || form.type === "supplier_refund" || form.type === "supplier_discount") {
			name = store.suppliers.find((s) => s.id === refId)?.companyName || "";
			setForm({
				...form,
				referenceId: refId,
				referenceName: name || form.referenceName
			});
		} else if (form.type === "agent_commission" || form.type === "agent_receive") {
			name = store.agents.find((a) => a.id === refId)?.name || "";
			setForm({
				...form,
				referenceId: refId,
				referenceName: name || form.referenceName
			});
		} else setForm({
			...form,
			referenceId: refId
		});
	}
	const formFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Entry Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: form.type,
				onValueChange: (v) => updateFormType(v),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "bg-accent/20 border-border mt-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "client_receive",
						children: "Client Payment Received"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "purchase",
						children: "Purchase from Supplier"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "supplier_payment",
						children: "Supplier Payment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "agent_commission",
						children: "Agent Commission"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "expense",
						children: "Expense"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "client_charge",
						children: "Extra Charge to Client (Embassy / Service Fee)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "client_refund",
						children: "Refund to Client"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "client_discount",
						children: "Client Discount / Concession (Reduces Client Due)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "supplier_refund",
						children: "Refund from Supplier"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "supplier_discount",
						children: "Supplier Discount / Rebate (Reduces Payable)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "agent_receive",
						children: "Agent Payment Received"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "drawing",
						children: "Owner / Partner Drawing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "jv",
						children: "Journal Voucher (JV) / Account Settlement"
					})
				] })]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "date",
				value: form.date,
				onChange: (e) => setForm({
					...form,
					date: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1"
			})] }),
			form.type === "jv" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 rounded-xl border border-primary/40 bg-primary/5 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-primary/20 pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { className: "h-3.5 w-3.5" }), "Journal Voucher (JV) & Settlement"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "Transfer between accounts, reconcile balances, or adjust missing figures."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold text-primary",
							children: "Double-Entry"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Settlement Type"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 mt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setJv({
								...jv,
								jvType: "account_transfer",
								direction: "out"
							}),
							className: `rounded-lg border p-2 text-xs text-left transition-colors flex items-center gap-2 ${jv.jvType === "account_transfer" ? "border-primary bg-primary/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/10 text-muted-foreground hover:bg-accent/20"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { className: "h-4 w-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground",
								children: "Account Transfer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground",
								children: "Move funds from A to B"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setJv({
								...jv,
								jvType: "reconciliation_adjustment"
							}),
							className: `rounded-lg border p-2 text-xs text-left transition-colors flex items-center gap-2 ${jv.jvType === "reconciliation_adjustment" ? "border-primary bg-primary/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/10 text-muted-foreground hover:bg-accent/20"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "h-4 w-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground",
								children: "Find Missing Figure"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground",
								children: "Reconcile & balance cash/bank"
							})] })]
						})]
					})] }),
					jv.jvType === "account_transfer" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "From Account (Source Outflow)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: pay.accountId,
									onChange: (v) => setPay({
										...pay,
										accountId: v
									}),
									placeholder: "Select source account...",
									options: store.accounts.map((a) => ({
										value: a.id,
										label: `${a.name} (${a.type})`,
										hint: `Bal: ${formatCurrency(computeAccountBalance(a.id))}`
									})),
									className: "mt-1"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "To Account (Destination Inflow)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: jv.toAccountId,
									onChange: (v) => setJv({
										...jv,
										toAccountId: v
									}),
									placeholder: "Select destination account...",
									options: store.accounts.filter((a) => a.id !== pay.accountId).map((a) => ({
										value: a.id,
										label: `${a.name} (${a.type})`,
										hint: `Bal: ${formatCurrency(computeAccountBalance(a.id))}`
									})),
									className: "mt-1"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Transfer Instrument / Channel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-1 rounded-md border border-border bg-accent/10 p-1 mt-1",
								children: METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPay({
										...pay,
										method: m
									}),
									className: `rounded px-1 py-1 text-[10px] font-semibold ${pay.method === m ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
									children: m
								}, m))
							})] }),
							pay.method !== "Cash" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Reference / Cheque No / Slip No"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: pay.txnRef || pay.chequeNo,
									onChange: (e) => setPay({
										...pay,
										txnRef: e.target.value,
										chequeNo: e.target.value
									}),
									placeholder: "e.g. Deposit Slip 48291",
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Transferred / Handled By"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: pay.collectedBy,
									onChange: (e) => setPay({
										...pay,
										collectedBy: e.target.value
									}),
									placeholder: "Staff / manager name",
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] })]
							})
						]
					}),
					jv.jvType === "reconciliation_adjustment" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 rounded-lg border border-primary/20 bg-background/60 p-3 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Account to Balance & Reconcile"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
							value: pay.accountId,
							onChange: (v) => setPay({
								...pay,
								accountId: v
							}),
							placeholder: "Select account...",
							options: store.accounts.map((a) => ({
								value: a.id,
								label: `${a.name} (${a.type})`,
								hint: `System: ${formatCurrency(computeAccountBalance(a.id))}`
							})),
							className: "mt-1"
						})] }), pay.accountId && (() => {
							const sysBal = computeAccountBalance(pay.accountId);
							const targetBal = jv.targetBalance !== "" ? Number(jv.targetBalance) : null;
							const diff = targetBal !== null ? targetBal - sysBal : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2.5 border-t border-border/50 pt-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs rounded-md bg-accent/20 p-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Current System Balance:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-foreground font-mono text-sm",
											children: formatCurrency(sysBal)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs",
											children: "Actual Physical / Counted Balance (PKR)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground",
											children: "Enter physical count or bank statement"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: jv.targetBalance,
										onChange: (e) => setJv({
											...jv,
											targetBalance: e.target.value
										}),
										placeholder: `e.g. ${sysBal}`,
										className: "bg-accent/20 border-border mt-1 h-8 text-xs font-mono font-bold"
									})] }),
									jv.targetBalance !== "" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg border border-primary/30 bg-primary/10 p-3 space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-semibold text-foreground",
													children: "Calculated Missing Figure:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-sm font-bold font-mono ${diff >= 0 ? "text-success" : "text-destructive"}`,
													children: diff >= 0 ? `+${formatCurrency(diff)} (Missing Inflow)` : `${formatCurrency(diff)} (Missing Outflow)`
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-muted-foreground",
												children: diff > 0 ? "System was short — an inflow adjustment of this missing amount will bring the balance to your target." : diff < 0 ? "System had excess — an outflow adjustment of this missing amount will bring the balance to your target." : "System balance already matches your counted figure perfectly!"
											}),
											diff !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "button",
												size: "sm",
												onClick: () => {
													setForm({
														...form,
														amount: String(Math.abs(diff)),
														note: `Reconciliation adjustment: balanced to target ${formatCurrency(Number(jv.targetBalance))}. Missing figure of ${formatCurrency(Math.abs(diff))} posted.`,
														referenceName: "Account Reconciliation"
													});
													setJv({
														...jv,
														direction: diff > 0 ? "in" : "out"
													});
													toast.success(`Missing figure of ${formatCurrency(Math.abs(diff))} auto-filled into entry!`);
												},
												className: "w-full h-8 text-xs font-semibold gap-2 mt-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "h-3.5 w-3.5" }),
													"Auto-Fill Missing Figure (",
													formatCurrency(Math.abs(diff)),
													")"
												]
											})
										]
									})
								]
							});
						})()]
					})
				]
			}),
			form.type === "client_receive" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Head ID" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
				value: form.headId,
				onChange: (v) => updateReferenceId(v),
				placeholder: "Search Head ID...",
				options: store.bookings.map((b) => ({
					value: b.headId,
					label: `${b.headId} — ${b.packageType}`,
					hint: `${b.travelDate} · Net Due: ${formatCurrency(b.totalAmount)} (Bal: ${formatCurrency(Math.max(0, b.totalAmount - b.amountReceived))})`
				})),
				className: "mt-1"
			})] }),
			(form.type === "client_charge" || form.type === "client_refund") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-primary/40 bg-primary/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
						children: form.type === "client_charge" ? "Charge Details" : "Client Refund Details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Head ID (Booking)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.headId,
						onChange: (v) => updateReferenceId(v),
						placeholder: "Search Head ID...",
						options: store.bookings.map((b) => ({
							value: b.headId,
							label: `${b.headId} — ${b.packageType}`,
							hint: `${b.travelDate} · ${formatCurrency(b.totalAmount)}`
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Member (optional — defaults to head member)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: extra.clientId,
						onChange: (v) => {
							const c = store.clients.find((x) => x.id === v);
							setExtra({
								...extra,
								clientId: v
							});
							if (c) setForm((f) => ({
								...f,
								referenceName: getClientName(c)
							}));
						},
						placeholder: form.headId ? "Select member..." : "Select a Head ID first",
						options: store.clients.filter((c) => c.headId === form.headId).map((c) => ({
							value: c.id,
							label: `${c.id} — ${getClientName(c)}`,
							hint: `${c.ageCategory || "Adult"} · Due ${formatCurrency(c.amountDue)}`
						})),
						className: "mt-1"
					})] }),
					form.type === "client_charge" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Charge Type"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: extra.chargeCategory,
							onValueChange: (v) => setExtra({
								...extra,
								chargeCategory: v
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "bg-accent/20 border-border mt-1 h-8 text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Embassy fee / Visa fee / Other" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: CHARGE_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c,
								children: c
							}, c)) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[10px] text-muted-foreground",
							children: "This amount is added to the member's due and to the booking total automatically."
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Refund Against (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
							value: extra.refundOf,
							onChange: (v) => setExtra({
								...extra,
								refundOf: v
							}),
							placeholder: "Link to the original receipt...",
							options: store.entries.filter((e) => e.type === "client_receive" && (!form.headId || e.headId === form.headId)).map((e) => ({
								value: e.id,
								label: `${e.id} — ${formatCurrency(e.amount)}`,
								hint: `${e.date} · ${e.referenceName}`
							})),
							className: "mt-1"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Reason"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: extra.refundReason,
							onChange: (e) => setExtra({
								...extra,
								refundReason: e.target.value
							}),
							placeholder: "Visa rejected / trip cancelled...",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted-foreground",
							children: "Refunds are deducted from the head's received amount everywhere."
						})
					] })
				]
			}),
			form.type === "client_discount" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-amber-500/40 bg-amber-500/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-amber-400",
						children: "Client Discount / Concession Details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Head ID (Booking)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.headId,
						onChange: (v) => updateReferenceId(v),
						placeholder: "Search Head ID...",
						options: store.bookings.map((b) => ({
							value: b.headId,
							label: `${b.headId} — ${b.packageType}`,
							hint: `${b.travelDate} · Net: ${formatCurrency(b.totalAmount)}`
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Specific Member (optional — leaves unassigned to lead)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: extra.clientId,
						onChange: (v) => {
							const c = store.clients.find((x) => x.id === v);
							setExtra({
								...extra,
								clientId: v
							});
							if (c) setForm((f) => ({
								...f,
								referenceName: getClientName(c)
							}));
						},
						placeholder: form.headId ? "Select member..." : "Select a Head ID first",
						options: store.clients.filter((c) => c.headId === form.headId).map((c) => ({
							value: c.id,
							label: `${c.id} — ${getClientName(c)}`,
							hint: `${c.ageCategory || "Adult"} · Due ${formatCurrency(c.amountDue)} (Bal: ${formatCurrency(Math.max(0, c.amountDue - c.amountPaid))})`
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: "This concession directly reduces the client's balance due and the booking total sale without requiring physical cash withdrawal."
					})
				]
			}),
			form.type === "supplier_discount" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-emerald-500/40 bg-emerald-500/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-emerald-400",
						children: "Supplier Discount / Rebate Details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Supplier"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.referenceId,
						onChange: (v) => updateReferenceId(v),
						placeholder: "Search Supplier...",
						options: store.suppliers.map((s) => ({
							value: s.id,
							label: `${s.id} — ${s.companyName}`,
							hint: s.serviceType
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Link to Booking / Head ID (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.headId,
						onChange: (v) => setForm({
							...form,
							headId: v
						}),
						placeholder: "Tag rebate to a specific booking...",
						options: store.bookings.map((b) => ({
							value: b.headId,
							label: `${b.headId} — ${b.packageType}`,
							hint: b.travelDate
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: "Rebates and volume discounts directly reduce your Accounts Payable to this supplier and lower your cost of sales."
					})
				]
			}),
			form.type === "supplier_refund" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-success/40 bg-success/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-success",
						children: "Supplier Refund Details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Supplier"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.referenceId,
						onChange: (v) => updateReferenceId(v),
						placeholder: "Search Supplier...",
						options: store.suppliers.map((s) => ({
							value: s.id,
							label: `${s.id} — ${s.companyName}`,
							hint: s.serviceType
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Refund Against Purchase (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: extra.refundOf,
						onChange: (v) => setExtra({
							...extra,
							refundOf: v
						}),
						placeholder: "Select the original purchase...",
						options: store.entries.filter((e) => e.type === "purchase" && (!form.referenceId || e.referenceId === form.referenceId)).map((e) => ({
							value: e.id,
							label: `${e.id} — ${formatCurrency(e.amount)}`,
							hint: [
								e.date,
								e.serviceCategory,
								e.headId
							].filter(Boolean).join(" · ")
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Link to Head ID (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.headId,
						onChange: (v) => setForm({
							...form,
							headId: v
						}),
						placeholder: "Tag this refund to a booking...",
						options: store.bookings.map((b) => ({
							value: b.headId,
							label: `${b.headId} — ${b.packageType}`,
							hint: b.travelDate
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Reason"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: extra.refundReason,
						onChange: (e) => setExtra({
							...extra,
							refundReason: e.target.value
						}),
						placeholder: "Cancelled ticket / unused room night...",
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: "This credit reduces the supplier's payable in statements automatically."
					})
				]
			}),
			(form.type === "supplier_payment" || form.type === "purchase") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Supplier" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.referenceId,
						onChange: (v) => updateReferenceId(v),
						placeholder: "Search Supplier...",
						options: store.suppliers.map((s) => ({
							value: s.id,
							label: `${s.id} — ${s.companyName}`,
							hint: s.serviceType
						})),
						className: "mt-1"
					})] }),
					form.type === "supplier_payment" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 rounded-lg border border-primary/40 bg-primary/5 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Payment Allocation (who / where it belongs)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-1 rounded-md border border-border bg-accent/10 p-0.5",
								children: [["simple", "Simple Tagging"], ["split", "Split Payment"]].map(([m, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setPayAllocMode(m);
										if (m === "split" && paymentAllocationsState.length === 0) {
											const amt = Number(form.amount) || 0;
											if (groupId) setPaymentAllocationsState([{
												id: "P1",
												target: "group",
												groupId,
												amount: amt
											}]);
											else if (form.headId) setPaymentAllocationsState([{
												id: "P1",
												target: "head",
												headId: form.headId,
												amount: amt
											}]);
											else if (refs.agentId) setPaymentAllocationsState([{
												id: "P1",
												target: "agent",
												agentId: refs.agentId,
												amount: amt
											}]);
											else setPaymentAllocationsState([{
												id: "P1",
												target: "unallocated",
												amount: amt
											}]);
										}
									},
									className: `rounded px-2 py-1 text-[10px] font-semibold transition ${payAllocMode === m ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
									children: l
								}, m))
							})]
						}), payAllocMode === "simple" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Group / PNR (optional)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: groupMode === "existing" ? groupId : "",
									onChange: (v) => {
										setGroupMode(v ? "existing" : "none");
										setGroupId(v);
									},
									placeholder: supplierGroups.length ? "Pay against a group..." : "No groups yet",
									options: supplierGroups.map((g) => ({
										value: g.id,
										label: `${g.id} — ${g.name}`,
										hint: [
											g.category,
											g.pnr && `PNR ${g.pnr}`,
											g.date
										].filter(Boolean).join(" · ")
									})),
									className: "mt-1"
								}),
								(() => {
									const sel = groupMode === "existing" ? store.groups.find((g) => g.id === groupId) : null;
									if (!sel) return null;
									const bill = store.entries.filter((e) => e.type === "purchase" && e.groupId === sel.id).reduce((s, e) => s + e.amount, 0) - store.entries.filter((e) => e.type === "supplier_refund" && e.groupId === sel.id).reduce((s, e) => s + e.amount, 0);
									const paid = store.entries.filter((e) => e.type === "supplier_payment" && e.groupId === sel.id && e.id !== selected?.id).reduce((s, e) => s + e.amount, 0);
									const thisPay = Number(form.amount) || 0;
									const remaining = bill - paid - thisPay;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-wrap items-center gap-3 rounded-md bg-accent/20 px-3 py-2 text-[11px]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: ["Group Bill: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: "text-foreground",
													children: formatCurrency(bill)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: ["Paid: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: "text-success",
													children: formatCurrency(paid)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: ["This payment: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: "text-foreground",
													children: formatCurrency(thisPay)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "ml-auto text-muted-foreground",
												children: ["Remaining: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: remaining > 0 ? "text-destructive" : "text-success",
													children: formatCurrency(remaining)
												})]
											})
										]
									});
								})()
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Agent Reference (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: refs.agentId,
									onChange: (v) => setRefs({
										...refs,
										agentId: v
									}),
									placeholder: "Which agent's business...",
									options: store.agents.map((a) => ({
										value: a.id,
										label: `${a.id} — ${a.name}`,
										hint: a.phone
									})),
									className: "mt-1"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Head ID (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: form.headId,
									onChange: (v) => setForm({
										...form,
										headId: v
									}),
									placeholder: "Tag to a booking...",
									options: store.bookings.map((b) => ({
										value: b.headId,
										label: `${b.headId} — ${b.packageType}`,
										hint: b.travelDate
									})),
									className: "mt-1"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Paid By / Handed Over By"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: refs.paidBy,
								onChange: (e) => setRefs({
									...refs,
									paidBy: e.target.value
								}),
								placeholder: "Office cash / Bank transfer / Agent Ahmed",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground",
								children: "Group-tagged payments show up in that group's settlement progress, and the agent reference appears in the agent's ledger."
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllocationEditor, {
								mode: "payment",
								total: Number(form.amount) || 0,
								value: paymentAllocationsState,
								onChange: setPaymentAllocationsState,
								heads: Array.from(new Map(store.clients.map((c) => [c.headId, c])).values()).map((c) => ({
									id: c.headId,
									name: `${c.headId} — ${getClientName(c)}`
								})),
								agents: store.agents.map((a) => ({
									id: a.id,
									name: `${a.id} — ${a.name}`
								})),
								groups: supplierGroups.map((g) => ({
									id: g.id,
									name: `${g.id} — ${g.name}`,
									pnr: g.pnr,
									category: g.category
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Paid By / Handed Over By"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: refs.paidBy,
								onChange: (e) => setRefs({
									...refs,
									paidBy: e.target.value
								}),
								placeholder: "Office cash / Bank transfer / Agent Ahmed",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						})]
					}),
					form.type === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 rounded-lg border border-primary/40 bg-primary/5 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Purchase For (whose account)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-1 rounded-md border border-border bg-accent/10 p-1",
								children: [
									["", "Office / Stock"],
									["client", "Client"],
									["agent", "Agent"],
									["split", "Split Allocation"]
								].map(([v, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setPf({
											...pf,
											for: v
										});
										if (v !== "client") setForm((f) => ({
											...f,
											headId: v === "agent" ? "" : f.headId
										}));
										if (v === "split" && purchaseAllocationsState.length === 0) {
											const amt = Number(form.amount) || 0;
											if (form.headId) setPurchaseAllocationsState([{
												id: "A1",
												target: "head",
												headId: form.headId,
												amount: amt
											}]);
											else {
												const firstHead = store.clients[0]?.headId || "";
												setPurchaseAllocationsState([{
													id: "A1",
													target: "head",
													headId: firstHead,
													amount: amt
												}]);
											}
										}
									},
									className: `rounded px-2 py-1.5 text-[11px] font-semibold transition ${pf.for === v ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
									children: l
								}, v))
							}),
							pf.for === "" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground",
								children: "General agency inventory / office cost. Not attributed to any specific client booking or agent."
							}),
							pf.for === "client" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Client (Head ID / Name) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: form.headId,
									onChange: (v) => {
										setForm({
											...form,
											headId: v
										});
										setExtra({
											...extra,
											clientId: ""
										});
									},
									placeholder: "Search client head...",
									options: Array.from(new Map(store.clients.map((c) => [c.headId, c])).values()).map((c) => ({
										value: c.headId,
										label: `${c.headId} — ${getClientName(c)}`,
										hint: c.id
									})),
									className: "mt-1"
								})] }),
								form.headId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Member (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: extra.clientId,
									onChange: (v) => setExtra({
										...extra,
										clientId: v
									}),
									placeholder: "Whole head",
									options: store.clients.filter((c) => c.headId === form.headId).map((c) => ({
										value: c.id,
										label: `${c.id} — ${getClientName(c)}`
									})),
									className: "mt-1"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-muted-foreground",
									children: [
										"Posts to this client's ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Business Ledger" }),
										" as cost (reduces booking profit). The client's personal balance is ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "not" }),
										" changed."
									]
								})
							] }),
							pf.for === "agent" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Agent *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
									value: pf.agentId,
									onChange: (v) => setPf({
										...pf,
										agentId: v
									}),
									placeholder: "Search agent...",
									options: store.agents.map((a) => ({
										value: a.id,
										label: `${a.id} — ${a.name}`
									})),
									className: "mt-1"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Client Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: pf.clientName,
										onChange: (e) => setPf({
											...pf,
											clientName: e.target.value
										}),
										placeholder: "Passenger / client name",
										className: "bg-accent/20 border-border mt-1 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Sale to Agent (PKR)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: pf.saleAmount,
										onChange: (e) => setPf({
											...pf,
											saleAmount: e.target.value
										}),
										placeholder: form.amount || "Same as cost",
										className: "bg-accent/20 border-border mt-1 h-8 text-xs"
									})] })]
								}),
								(() => {
									const cost = Number(form.amount) || 0;
									const sale = Number(pf.saleAmount) || cost;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-3 rounded-md bg-accent/20 px-3 py-2 text-[11px]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: ["Cost: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: "text-foreground",
													children: formatCurrency(cost)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: ["Other Sale: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: "text-primary",
													children: formatCurrency(sale)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "ml-auto text-muted-foreground",
												children: ["Profit: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: sale - cost >= 0 ? "text-success" : "text-destructive",
													children: formatCurrency(sale - cost)
												})]
											})
										]
									});
								})(),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-muted-foreground",
									children: [
										"Added to the agent's ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Other Sale" }),
										" and his Business Ledger receivable."
									]
								})
							] }),
							pf.for === "split" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllocationEditor, {
									mode: "purchase",
									total: Number(form.amount) || 0,
									value: purchaseAllocationsState,
									onChange: setPurchaseAllocationsState,
									allocationMode: purchaseAllocMode,
									onAllocationModeChange: setPurchaseAllocMode,
									heads: Array.from(new Map(store.clients.map((c) => [c.headId, c])).values()).map((c) => ({
										id: c.headId,
										name: `${c.headId} — ${getClientName(c)}`
									})),
									agents: store.agents.map((a) => ({
										id: a.id,
										name: `${a.id} — ${a.name}`
									})),
									clients: store.clients.map((c) => ({
										id: c.id,
										headId: c.headId,
										name: getClientName(c)
									}))
								})
							})
						]
					}),
					form.type === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Service Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: serviceCategory,
							onValueChange: (v) => {
								setServiceCategory(v);
								const auto = computeAutoAmount(v, details);
								if (autoTotal && auto !== null) setForm((f) => ({
									...f,
									amount: String(auto)
								}));
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "bg-accent/20 border-border mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select Service Category" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: SERVICE_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c,
								children: c === "Package" ? "Package (Holiday / Umrah / Tour)" : c
							}, c)) })]
						})] }),
						serviceCategory === "Flight" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 p-3.5 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-primary/20 pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "h-4 w-4" }), "Flight & Ticket Details"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "Detailed Airline & PNR Record"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Trip Type"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-1.5 mt-1",
									children: [
										"One Way",
										"Round Trip",
										"Multi-City"
									].map((tt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setDetailField("tripType", tt),
										className: `rounded px-2 py-1 text-xs font-medium transition ${details.tripType === tt ? "bg-primary text-primary-foreground font-semibold shadow-sm" : "bg-accent/20 text-muted-foreground hover:bg-accent/40"}`,
										children: tt
									}, tt))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Ticket Number *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.ticketNumber,
											onChange: (e) => setDetailField("ticketNumber", e.target.value),
											placeholder: "e.g. 214-9847291042",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-mono"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "PNR / Booking Ref *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.pnr,
											onChange: (e) => setDetailField("pnr", e.target.value.toUpperCase()),
											placeholder: "e.g. PK-87YTR",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-mono font-semibold"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Sector / Route *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.sector,
											onChange: (e) => setDetailField("sector", e.target.value.toUpperCase()),
											placeholder: "e.g. KHI - JED - KHI",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-semibold"
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Airline"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.airline,
											onChange: (e) => setDetailField("airline", e.target.value),
											placeholder: "Saudia / PIA / Emirates",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Flight Number(s)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.flightNumber,
											onChange: (e) => setDetailField("flightNumber", e.target.value),
											placeholder: "SV-701 / SV-702",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Cabin Class"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: details.cabinClass,
											onValueChange: (v) => setDetailField("cabinClass", v),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
												"Economy",
												"Premium Economy",
												"Business",
												"First Class"
											].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: c,
												children: c
											}, c)) })]
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Departure Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: details.departureDate,
										onChange: (e) => setDetailField("departureDate", e.target.value),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), details.tripType === "Round Trip" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Return Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: details.returnDate,
										onChange: (e) => setDetailField("returnDate", e.target.value),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								details.tripType === "Multi-City" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Multi-City Routing Details"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: details.multiCityRoute,
									onChange: (e) => setDetailField("multiCityRoute", e.target.value),
									placeholder: "KHI → IST → LHR → DXB → KHI",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border/50 bg-background/50 p-2.5 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
											children: "Passenger Breakdown & Fare"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Adults"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.adults,
													onChange: (e) => setDetailField("adults", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Children"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.children,
													onChange: (e) => setDetailField("children", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Infants"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.infants,
													onChange: (e) => setDetailField("infants", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Adult Rate (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.adultPrice,
													onChange: (e) => setDetailField("adultPrice", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Child Rate (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.childPrice,
													onChange: (e) => setDetailField("childPrice", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Infant Rate (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.infantPrice,
													onChange: (e) => setDetailField("infantPrice", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] })
											]
										})
									]
								})
							]
						}),
						serviceCategory === "Hotel" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 p-3.5 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-primary/20 pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildingComplex, { className: "h-4 w-4" }), "Hotel Booking Details"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "Rooms & Nightly Rates"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Hotel Name *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.hotelName,
										onChange: (e) => setDetailField("hotelName", e.target.value),
										placeholder: "Dar Al Taqwa / Swissotel / Pullman",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "City *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.city,
										onChange: (e) => setDetailField("city", e.target.value),
										placeholder: "Makkah / Madinah / Dubai / Istanbul",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Room Type"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: details.roomType,
											onValueChange: (v) => setDetailField("roomType", v),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
												"Quad (4-Bed)",
												"Triple (3-Bed)",
												"Double (2-Bed)",
												"Single (1-Bed)",
												"Sharing (Bed-by-Bed)",
												"Family Suite"
											].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: r,
												children: r
											}, r)) })]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Meal Plan"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: details.mealPlan,
											onValueChange: (v) => setDetailField("mealPlan", v),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
												"Room Only (RO)",
												"Bed & Breakfast (BB)",
												"Half Board (HB)",
												"Full Board (FB)",
												"Sahur / Iftar (Ramadan)"
											].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: m,
												children: m
											}, m)) })]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Confirmation / Voucher #"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.confirmationNo,
											onChange: (e) => setDetailField("confirmationNo", e.target.value),
											placeholder: "e.g. HTL-98214",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-mono"
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Number of Rooms *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "1",
											value: details.rooms,
											onChange: (e) => setDetailField("rooms", e.target.value),
											placeholder: "1",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Nights *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "1",
											value: details.nights,
											onChange: (e) => setDetailField("nights", e.target.value),
											placeholder: "5",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Rate Per Night (PKR) *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											value: details.perNight,
											onChange: (e) => setDetailField("perNight", e.target.value),
											placeholder: "35000",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Check-in Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: details.checkIn,
										onChange: (e) => setDetailField("checkIn", e.target.value),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Check-out Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: details.checkOut,
										onChange: (e) => setDetailField("checkOut", e.target.value),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								})
							]
						}),
						serviceCategory === "Package" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 p-3.5 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-primary/20 pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "h-4 w-4" }), "Holiday & Umrah Package Builder"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded bg-primary/15 px-2 py-0.5 text-[10px] font-semibold text-primary",
										children: "All-in-One Package"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Package Scope"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 gap-2",
										children: ["International", "Domestic"].map((ps) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setDetailField("packageType", ps),
											className: `rounded-lg border p-2 text-xs text-left transition-colors flex items-center justify-between ${details.packageType === ps ? "border-primary bg-primary/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/10 text-muted-foreground hover:bg-accent/20"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ps === "International" ? "✈ International (Umrah / Tours)" : "🏔 Domestic (Pakistan / Northern Areas)" }), details.packageType === ps && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-primary" })]
										}, ps))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Destination Country *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.destinationCountry,
										onChange: (e) => setDetailField("destinationCountry", e.target.value),
										placeholder: details.packageType === "Domestic" ? "Pakistan" : "Saudi Arabia / UAE / Turkey / Azerbaijan",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-semibold"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "City / Multi-City Combo *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.destinationCity,
										onChange: (e) => setDetailField("destinationCity", e.target.value),
										placeholder: "e.g. Makkah + Madinah / Hunza + Skardu / Baku + Gabala",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-semibold"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[9px] text-muted-foreground",
										children: "Quick City Combos:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1",
										children: (details.packageType === "Domestic" ? [
											"Hunza + Skardu",
											"Naran + Kagan + Swat",
											"Murree + Bhurban",
											"Gwadar Beach"
										] : [
											"Makkah + Madinah",
											"Dubai + Abu Dhabi",
											"Istanbul + Antalya",
											"Baku + Gabala",
											"Kuala Lumpur + Langkawi",
											"Bangkok + Phuket"
										]).map((combo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setDetailField("destinationCity", combo),
											className: "rounded bg-accent/30 hover:bg-accent/60 px-2 py-0.5 text-[10px] text-muted-foreground transition",
											children: ["+ ", combo]
										}, combo))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Package Title / Name"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.packageName,
											onChange: (e) => setDetailField("packageName", e.target.value),
											placeholder: "e.g. 15-Day VIP Executive Umrah Package",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Duration (Days)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: "1",
										value: details.packageDurationDays,
										onChange: (e) => setDetailField("packageDurationDays", e.target.value),
										placeholder: "e.g. 15",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Start Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: details.startDate,
										onChange: (e) => setDetailField("startDate", e.target.value),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "End Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: details.endDate,
										onChange: (e) => setDetailField("endDate", e.target.value),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 border-t border-border/40 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Package Inclusions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-1.5",
										children: [
											"Flight Tickets",
											"Hotel Accommodation",
											"Visa Processing",
											"Private Transport",
											"Guided Ziyarah",
											"Daily Breakfast",
											"Travel Insurance"
										].map((inc) => {
											const active = details.packageInclusions.includes(inc);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setDetailField("packageInclusions", active ? details.packageInclusions.filter((x) => x !== inc) : [...details.packageInclusions, inc]);
												},
												className: `rounded px-2 py-1 text-[10px] text-left flex items-center justify-between border transition ${active ? "border-primary bg-primary/20 font-semibold text-primary" : "border-border/50 bg-accent/10 text-muted-foreground"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: inc }), active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3 shrink-0" })]
											}, inc);
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border/50 bg-background/50 p-2.5 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
											children: "Passenger Breakdown & Package Rates"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Adults Count"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.adults,
													onChange: (e) => setDetailField("adults", e.target.value),
													placeholder: "2",
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-semibold"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Children Count"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.children,
													onChange: (e) => setDetailField("children", e.target.value),
													placeholder: "0",
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-semibold"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Infants Count"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.infants,
													onChange: (e) => setDetailField("infants", e.target.value),
													placeholder: "0",
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-semibold"
												})] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Adult Rate (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.adultPrice,
													onChange: (e) => setDetailField("adultPrice", e.target.value),
													placeholder: "150000",
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Child Rate (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.childPrice,
													onChange: (e) => setDetailField("childPrice", e.target.value),
													placeholder: "120000",
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Infant Rate (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.infantPrice,
													onChange: (e) => setDetailField("infantPrice", e.target.value),
													placeholder: "40000",
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] })
											]
										}),
										(() => {
											const a = Number(details.adults) || 0, c = Number(details.children) || 0, i = Number(details.infants) || 0;
											const ap = Number(details.adultPrice) || 0, cp = Number(details.childPrice) || 0, ip = Number(details.infantPrice) || 0;
											const sum = a * ap + c * cp + i * ip;
											if (sum === 0) return null;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between rounded bg-primary/10 px-2 py-1.5 text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted-foreground",
													children: [
														"Total Pax: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: a + c + i }),
														" (Adults: ",
														a,
														", Child: ",
														c,
														", Inf: ",
														i,
														")"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-primary font-bold",
													children: ["Auto-Calc Total: ", formatCurrency(sum)]
												})]
											});
										})()
									]
								})
							]
						}),
						serviceCategory === "Visa" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 p-3.5 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-primary/20 pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "h-4 w-4" }), "Visa Processing Details"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "MOFA / Application Status"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Country *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.country,
											onChange: (e) => setDetailField("country", e.target.value),
											placeholder: "Saudi Arabia / UAE / Turkey",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Visa Type"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.visaType,
											onChange: (e) => setDetailField("visaType", e.target.value),
											placeholder: "Umrah eVisa / Tourist / Work",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Reference / MOFA #"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.reference,
											onChange: (e) => setDetailField("reference", e.target.value),
											placeholder: "e.g. MOFA-89104",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-mono"
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Applicant Names / Passports (comma separated)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: details.applicantNames,
									onChange: (e) => setDetailField("applicantNames", e.target.value),
									placeholder: "e.g. Ali Khan (AB123456), Fatima Bibi (XY789012)",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border/50 bg-background/50 p-2.5 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
											children: "Visa Pax & Fees"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Adults"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.adults,
													onChange: (e) => setDetailField("adults", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Children"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.children,
													onChange: (e) => setDetailField("children", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Infants"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: "0",
													value: details.infants,
													onChange: (e) => setDetailField("infants", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Adult Visa Fee (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.adultPrice,
													onChange: (e) => setDetailField("adultPrice", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Child Visa Fee (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.childPrice,
													onChange: (e) => setDetailField("childPrice", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Infant Visa Fee (PKR)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													value: details.infantPrice,
													onChange: (e) => setDetailField("infantPrice", e.target.value),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] })
											]
										})
									]
								})
							]
						}),
						serviceCategory === "Transport" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 p-3.5 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-primary/20 pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bus, { className: "h-4 w-4" }), "Transport & Transfer Details"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "Vehicles & Routes"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Route *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.route,
										onChange: (e) => setDetailField("route", e.target.value),
										placeholder: "JED Airport → Makkah → Madinah → MED",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Vehicle Type *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.vehicle,
										onChange: (e) => setDetailField("vehicle", e.target.value),
										placeholder: "GMC Yukon / Sedan / Coaster / Bus 49",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Pickup Date & Time"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.pickupDate,
											onChange: (e) => setDetailField("pickupDate", e.target.value),
											placeholder: "2026-04-10 14:00",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Driver Name & Phone"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.driverName,
											onChange: (e) => setDetailField("driverName", e.target.value),
											placeholder: "Tariq (+966-50...)",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Voucher / Booking #"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: details.voucherNo,
											onChange: (e) => setDetailField("voucherNo", e.target.value),
											placeholder: "TR-7821",
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs font-mono"
										})] })
									]
								})
							]
						}),
						(serviceCategory === "Ziyarah" || serviceCategory === "Insurance" || serviceCategory === "Other") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-primary/40 bg-primary/5 p-3.5 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between border-b border-primary/20 pb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "h-4 w-4" }),
											serviceCategory,
											" Details"
										]
									})
								}),
								serviceCategory === "Ziyarah" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "City"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.city,
										onChange: (e) => setDetailField("city", e.target.value),
										placeholder: "Makkah / Madinah / Taif",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Sites / Route"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: details.ziyarahSites,
										onChange: (e) => setDetailField("ziyarahSites", e.target.value),
										placeholder: "Cave Hira, Jabal Thawr, Uhud, Quba",
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Description & Special Notes"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: details.description,
									onChange: (e) => setDetailField("description", e.target.value),
									placeholder: "Additional details...",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Adults"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "0",
											value: details.adults,
											onChange: (e) => setDetailField("adults", e.target.value),
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Children"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "0",
											value: details.children,
											onChange: (e) => setDetailField("children", e.target.value),
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Infants"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "0",
											value: details.infants,
											onChange: (e) => setDetailField("infants", e.target.value),
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] })
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Link to Head ID (optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
							value: form.headId,
							onChange: (v) => setForm({
								...form,
								headId: v
							}),
							placeholder: "Tag this purchase to a booking...",
							options: store.bookings.map((b) => ({
								value: b.headId,
								label: `${b.headId} — ${b.packageType}`,
								hint: b.travelDate
							})),
							className: "mt-1"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-primary/40 bg-primary/5 p-3 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
										children: "Group / PNR"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex gap-1 text-[10px]",
										children: [
											"none",
											"existing",
											"new"
										].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setGroupMode(m),
											className: `rounded px-2 py-1 font-medium transition ${groupMode === m ? "bg-primary text-primary-foreground" : "bg-accent/40 text-muted-foreground hover:bg-accent/60"}`,
											children: m === "none" ? "Custom (No group)" : m === "existing" ? "Add to Group" : "+ New Group"
										}, m))
									})]
								}),
								groupMode === "existing" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
										value: groupId,
										onChange: setGroupId,
										placeholder: supplierGroups.length ? "Select existing group..." : "No groups yet — create a new one",
										options: supplierGroups.map((g) => {
											const u = computeGroupUsedPax(g.id);
											const cap = g.totalPax != null ? ` · ${u}/${g.totalPax} used` : ` · ${u} used`;
											return {
												value: g.id,
												label: `${g.id} — ${g.name}`,
												hint: [
													g.category,
													g.pnr && `PNR ${g.pnr}`,
													g.flightNumber,
													g.date
												].filter(Boolean).join(" · ") + cap
											};
										}),
										className: "mt-1"
									}), (() => {
										const sel = supplierGroups.find((g) => g.id === groupId);
										if (!sel) return null;
										const used = computeGroupUsedPax(sel.id);
										const req = (Number(details.adults) || 0) + (Number(details.children) || 0) + (Number(details.infants) || 0);
										const remaining = sel.totalPax != null ? Math.max(0, sel.totalPax - used) : null;
										const overflow = sel.totalPax != null && used + req > sel.totalPax;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `flex flex-wrap items-center gap-3 rounded-md px-3 py-2 text-[11px] ${overflow ? "bg-destructive/15 text-destructive" : "bg-accent/20 text-foreground"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Capacity:" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold",
													children: sel.totalPax ?? "∞"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted-foreground",
													children: ["Used: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "text-foreground",
														children: used
													})]
												}),
												remaining !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted-foreground",
													children: ["Remaining: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: overflow ? "text-destructive" : "text-success",
														children: remaining
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "ml-auto text-muted-foreground",
													children: ["This entry: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "text-foreground",
														children: req
													})]
												})
											]
										});
									})()]
								}),
								groupMode === "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-[10px]",
												children: "Group Name"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: newGroup.name,
												onChange: (e) => setNewGroup({
													...newGroup,
													name: e.target.value
												}),
												placeholder: "Umrah Group Feb-26 / PK-234 Batch",
												className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-[10px]",
												children: "Total Persons (capacity)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												min: "0",
												value: newGroup.totalPax,
												onChange: (e) => setNewGroup({
													...newGroup,
													totalPax: e.target.value
												}),
												placeholder: "e.g. 30",
												className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "PNR"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: newGroup.pnr,
													onChange: (e) => setNewGroup({
														...newGroup,
														pnr: e.target.value
													}),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Flight / Ref #"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: newGroup.flightNumber,
													onChange: (e) => setNewGroup({
														...newGroup,
														flightNumber: e.target.value
													}),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px]",
													children: "Date"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													value: newGroup.date,
													onChange: (e) => setNewGroup({
														...newGroup,
														date: e.target.value
													}),
													className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
												})] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-[10px]",
											children: "Description"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: newGroup.description,
											onChange: (e) => setNewGroup({
												...newGroup,
												description: e.target.value
											}),
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
										})] })
									]
								})
							]
						})
					] })
				]
			}),
			form.type === "agent_commission" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Agent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
				value: form.referenceId,
				onChange: (v) => updateReferenceId(v),
				placeholder: "Search Agent...",
				options: store.agents.map((a) => ({
					value: a.id,
					label: `${a.id} — ${a.name}`,
					hint: a.phone
				})),
				className: "mt-1"
			})] }),
			form.type === "expense" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Expense Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.referenceName,
				onChange: (e) => setForm({
					...form,
					referenceName: e.target.value
				}),
				placeholder: "Office Rent, Utilities...",
				className: "bg-accent/20 border-border mt-1"
			})] }),
			form.type === "agent_receive" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-success/40 bg-success/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-success",
						children: "Payment received from agent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Agent *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.referenceId,
						onChange: (v) => updateReferenceId(v),
						placeholder: "Search Agent...",
						options: store.agents.map((a) => ({
							value: a.id,
							label: `${a.id} — ${a.name}`,
							hint: a.phone
						})),
						className: "mt-1"
					})] }),
					form.referenceId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Against Head ID (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
						value: form.headId,
						onChange: (v) => setForm({
							...form,
							headId: v
						}),
						placeholder: "General / on-account",
						options: store.bookings.filter((b) => b.agentId === form.referenceId).map((b) => ({
							value: b.headId,
							label: `${b.headId} — ${b.packageType}`,
							hint: b.travelDate
						})),
						className: "mt-1"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: "Reduces the agent's Business Account remaining balance. Shows in his statement under Receipts."
					})
				]
			}),
			form.type === "drawing" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-destructive/40 bg-destructive/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold uppercase tracking-wider text-destructive",
							children: "Owner / Partner Drawing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: "Linked to Partner Equity"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Select Registered Partner / Drawer *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
							value: form.referenceId,
							onChange: (v) => {
								const d = store.drawers.find((x) => x.id === v);
								setForm({
									...form,
									referenceId: v,
									referenceName: d?.name || form.referenceName
								});
							},
							placeholder: "Select registered partner...",
							options: store.drawers.map((d) => ({
								value: d.id,
								label: `${d.name} (${d.sharePercent || 0}% Equity)`,
								hint: d.role || d.phone || d.id
							})),
							className: "mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Or Partner Name (manual / new)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.referenceName,
							onChange: (e) => setForm({
								...form,
								referenceName: e.target.value
							}),
							placeholder: "Partner / Drawer Name",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs font-medium"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Purpose / Withdrawal Category"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: extra.chargeCategory,
						onChange: (e) => setExtra({
							...extra,
							chargeCategory: e.target.value
						}),
						placeholder: "e.g. Monthly Partner Drawing, Personal Expense, Profit Distribution",
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: "A drawing is not an expense — it does not reduce business operational profit, it reduces cash/bank balances and the partner's equity. See partner-wise cards in Accounts."
					})
				]
			}),
			MONEY_TYPES.includes(form.type) && form.type !== "jv" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-lg border border-primary/40 bg-primary/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
						children: entryDirection(form.type) === "in" ? "Received In — payment details" : "Paid From — payment details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-1 rounded-md border border-border bg-accent/10 p-1",
						children: METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setPay({
								...pay,
								method: m
							}),
							className: `rounded px-1 py-1.5 text-[10px] font-semibold ${pay.method === m ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
							children: m
						}, m))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Account"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
							value: pay.accountId,
							onChange: (v) => setPay({
								...pay,
								accountId: v
							}),
							placeholder: store.accounts.length ? "Select account" : "No accounts yet",
							options: store.accounts.map((a) => ({
								value: a.id,
								label: `${a.name} (${a.type})`,
								hint: a.number
							})),
							className: "mt-1"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: entryDirection(form.type) === "in" ? "Collected By" : "Paid By / Handed To"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pay.collectedBy,
							onChange: (e) => setPay({
								...pay,
								collectedBy: e.target.value
							}),
							placeholder: "Staff / person name",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] })]
					}),
					pay.method === "Cheque" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Cheque No *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pay.chequeNo,
								onChange: (e) => setPay({
									...pay,
									chequeNo: e.target.value
								}),
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Cheque Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: pay.chequeDate,
								onChange: (e) => setPay({
									...pay,
									chequeDate: e.target.value
								}),
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Bank"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pay.bankName,
								onChange: (e) => setPay({
									...pay,
									bankName: e.target.value
								}),
								placeholder: "HBL / Meezan",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })
						]
					}),
					(pay.method === "Bank Transfer" || pay.method === "Online / Wallet") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: pay.method === "Bank Transfer" ? "Bank Name" : "Wallet (JazzCash / Easypaisa)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pay.bankName,
							onChange: (e) => setPay({
								...pay,
								bankName: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-[10px]",
							children: "Transaction / Ref No *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pay.txnRef,
							onChange: (e) => setPay({
								...pay,
								txnRef: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount (PKR)" }), form.type === "purchase" && serviceCategory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5 text-[10px] text-muted-foreground cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: autoTotal,
						onChange: (e) => setAutoTotal(e.target.checked),
						className: "rounded"
					}), "Auto-calc"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "number",
				value: form.amount,
				onChange: (e) => {
					setAutoTotal(false);
					setForm({
						...form,
						amount: e.target.value
					});
				},
				placeholder: "100000",
				className: "bg-accent/20 border-border mt-1"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.note,
				onChange: (e) => setForm({
					...form,
					note: e.target.value
				}),
				placeholder: "What this payment is for...",
				className: "bg-accent/20 border-border mt-1"
			})] })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Entries & Ledger",
				subtitle: "All financial transactions",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: setAddOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: () => {
								setForm({
									date: getPKTDate(),
									type: "client_receive",
									headId: "",
									referenceId: "",
									referenceName: "",
									amount: "",
									note: ""
								});
								setDetails(emptyDetails);
								setServiceCategory("");
								setAutoTotal(true);
								setExtra({
									clientId: "",
									chargeCategory: "",
									refundOf: "",
									refundReason: ""
								});
								setGroupMode("none");
								setGroupId("");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Entry"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border max-h-[90vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add New Entry" }) }),
							formFields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleAdd,
								className: "w-full",
								children: "Submit Entry"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupSeatStrip, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-muted-foreground",
							children: "Total Received"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-bold text-success",
							children: formatCurrency(totalReceived)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-muted-foreground",
							children: "Total Purchases"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-bold text-warning",
							children: formatCurrency(totalPurchases)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-muted-foreground",
							children: "Total Paid Out"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-bold text-destructive",
							children: formatCurrency(totalPaid)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-muted-foreground",
							children: "Net Balance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-bold text-primary",
							children: formatCurrency(totalReceived - totalPaid)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-3.5 w-3.5 text-primary" }), "Live Accounts & Clean Cash Balances"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground",
						children: "Transactions are strictly recorded on or after each account's opening date. Legacy entries before opening date do not pollute cash."
					})] }), accountFilter !== "all" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setAccountFilter("all"),
						className: "h-7 text-xs gap-1 border-primary/40 text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" }), " Clear Account Filter"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3",
					children: store.accounts.map((acc) => {
						const bal = computeAccountBalance(acc.id);
						const active = accountFilter === acc.id;
						const Icon = acc.type === "Cash" ? Banknote : acc.type === "Bank" ? Landmark : Wallet;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setAccountFilter(active ? "all" : acc.id),
							className: `glass-card rounded-xl p-4 text-left transition-all relative overflow-hidden ${active ? "ring-2 ring-primary border-primary bg-primary/10" : "hover:border-primary/40"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-lg bg-primary/15 p-2 text-primary",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-foreground",
											children: acc.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-muted-foreground",
											children: acc.number || acc.type
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded bg-accent/40 px-1.5 py-0.5 text-[9px] font-medium text-muted-foreground",
										children: acc.type
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-baseline justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase tracking-wider text-muted-foreground",
										children: "Live Balance"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-base font-bold font-mono ${bal >= 0 ? "text-success" : "text-destructive"}`,
										children: formatCurrency(bal)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1.5 flex items-center justify-between border-t border-border/40 pt-1.5 text-[9px] text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Effective Date:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-foreground",
										children: acc.openingDate || "2026-01-01"
									})]
								})
							]
						}, acc.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-[220px] flex-1 sm:flex-initial",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: searchQuery,
								onChange: (e) => setSearchQuery(e.target.value),
								placeholder: "Search ID, reference, partner, note...",
								className: "h-8 pl-8 text-xs bg-background/50 border-border/60"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: methodFilter,
							onValueChange: setMethodFilter,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "h-8 text-xs bg-background/50 border-border/60 w-[140px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All Methods" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
								className: "border-border bg-card",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									children: "All Channels"
								}), METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: m,
									className: "text-xs",
									children: m
								}, m))]
							})]
						}),
						(typeFilter !== "all" || methodFilter !== "all" || accountFilter !== "all" || searchQuery) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => {
								setTypeFilter("all");
								setMethodFilter("all");
								setAccountFilter("all");
								setSearchQuery("");
							},
							className: "h-8 text-xs text-muted-foreground hover:text-foreground",
							children: "Reset Filters"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground font-mono",
						children: [filtered.length, " entries"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBar, {
						value: sortKey,
						onChange: setSortKey,
						label: "Sort by:"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"all",
					"client_receive",
					"client_charge",
					"purchase",
					"supplier_payment",
					"agent_commission",
					"expense",
					"client_refund",
					"supplier_refund",
					"agent_receive",
					"drawing",
					"jv"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTypeFilter(t),
					className: `rounded-lg px-3.5 py-1.5 text-xs font-medium transition-all ${typeFilter === t ? "bg-primary text-primary-foreground shadow-sm" : "bg-accent/30 text-muted-foreground hover:bg-accent/50"}`,
					children: t === "all" ? "All Entries" : typeLabels[t]
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Head ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Reference"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Amount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Details & Note"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filtered.map((e) => {
							const pd = e.purchaseDetails;
							const isJv = e.type === "jv";
							const isIn = INFLOW_TYPES.includes(e.type) || isJv && e.direction === "in";
							const isCharge = e.type === "client_charge";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 transition-colors hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold text-primary",
										children: e.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-xs",
										children: e.date
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-md bg-accent/30 px-2 py-1 text-[10px] font-semibold uppercase ${typeColors[e.type]}`,
											children: typeLabels[e.type]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: e.type === "purchase" && e.allocations && e.allocations.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col gap-1 items-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setSplitViewEntry(e),
												className: "inline-flex items-center gap-1 rounded bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 text-[10px] font-bold text-amber-400 hover:bg-amber-500/25 transition cursor-pointer",
												title: "Click to view full allocation breakdown",
												children: ["Split ×", e.allocations.length]
											}), e.headId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-muted-foreground",
												children: e.headId
											})]
										}) : e.type === "supplier_payment" && e.paymentAllocations && e.paymentAllocations.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col gap-1 items-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setSplitViewEntry(e),
												className: "inline-flex items-center gap-1 rounded bg-sky-500/15 border border-sky-500/30 px-1.5 py-0.5 text-[10px] font-bold text-sky-400 hover:bg-sky-500/25 transition cursor-pointer",
												title: "Click to view full payment split breakdown",
												children: ["Split ×", e.paymentAllocations.length]
											}), e.headId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-muted-foreground",
												children: e.headId
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground text-xs",
											children: e.headId || "—"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium",
											children: e.referenceName || (isJv ? "Journal Voucher" : "—")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: e.referenceId
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: `px-4 py-3 font-semibold font-mono ${isIn ? "text-success" : isCharge ? "text-primary" : "text-destructive"}`,
										children: [isIn ? "+" : isCharge ? "" : "-", formatCurrency(e.amount)]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 text-xs max-w-[280px]",
										children: [
											e.allocationOf && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mb-1 rounded bg-primary/10 border border-primary/30 px-2 py-0.5 text-[10px] text-primary flex items-center gap-1 w-fit",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3 w-3 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["System-linked charge to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: e.allocationOf })] })]
											}),
											e.type === "purchase" && pd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mb-1 space-y-0.5",
												children: [
													e.serviceCategory === "Flight" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded bg-sky-500/10 border border-sky-500/30 px-2 py-1 text-[10px] text-sky-400 flex flex-wrap gap-1.5 items-center",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-bold flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "h-3 w-3" }), " Flight:"]
															}),
															pd.tripType && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "bg-sky-500/20 px-1 rounded",
																children: pd.tripType
															}),
															pd.pnr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["PNR: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																className: "text-foreground",
																children: pd.pnr
															})] }),
															pd.ticketNumber && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Tkt: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																className: "text-foreground",
																children: pd.ticketNumber
															})] }),
															pd.sector && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Route: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																className: "text-foreground",
																children: pd.sector
															})] }),
															pd.airline && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																"(",
																pd.airline,
																")"
															] })
														]
													}),
													e.serviceCategory === "Hotel" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded bg-amber-500/10 border border-amber-500/30 px-2 py-1 text-[10px] text-amber-400 flex flex-wrap gap-1.5 items-center",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-bold flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildingComplex, { className: "h-3 w-3" }), " Hotel:"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-foreground font-semibold",
																children: pd.hotelName || "Hotel"
															}),
															pd.city && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																"(",
																pd.city,
																")"
															] }),
															pd.rooms && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [pd.rooms, " Rms"] }),
															pd.nights && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [pd.nights, " Nts"] }),
															pd.mealPlan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																"[",
																pd.mealPlan,
																"]"
															] })
														]
													}),
													e.serviceCategory === "Package" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded bg-emerald-500/10 border border-emerald-500/30 px-2 py-1 text-[10px] text-emerald-400 flex flex-wrap gap-1.5 items-center",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-bold flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "h-3 w-3" }), " Package:"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-foreground font-semibold",
																children: pd.packageName || pd.destinationCity || "Holiday Tour"
															}),
															pd.packageType && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "bg-emerald-500/20 px-1 rounded",
																children: pd.packageType
															}),
															pd.destinationCountry && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pd.destinationCountry }),
															pd.packageDurationDays && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																"(",
																pd.packageDurationDays,
																" Days)"
															] })
														]
													}),
													e.serviceCategory === "Visa" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded bg-purple-500/10 border border-purple-500/30 px-2 py-1 text-[10px] text-purple-400 flex flex-wrap gap-1.5 items-center",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-bold flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "h-3 w-3" }), " Visa:"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																pd.country,
																" (",
																pd.visaType,
																")"
															] }),
															pd.reference && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Ref: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																className: "text-foreground",
																children: pd.reference
															})] })
														]
													}),
													e.serviceCategory === "Transport" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded bg-indigo-500/10 border border-indigo-500/30 px-2 py-1 text-[10px] text-indigo-400 flex flex-wrap gap-1.5 items-center",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-bold flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bus, { className: "h-3 w-3" }), " Transport:"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pd.route }),
															pd.vehicle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																"(",
																pd.vehicle,
																")"
															] })
														]
													})
												]
											}),
											isJv && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mb-1 rounded bg-primary/10 border border-primary/30 px-2 py-1 text-[10px] text-primary",
												children: e.jvType === "account_transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { className: "h-3 w-3 shrink-0" }),
														"Transfer: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: store.accounts.find((a) => a.id === e.accountId)?.name || e.accountId }),
														" → ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: store.accounts.find((a) => a.id === e.toAccountId)?.name || e.toAccountId })
													]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "h-3 w-3 shrink-0" }),
														"Reconciliation Adjustment (",
														store.accounts.find((a) => a.id === e.accountId)?.name || e.accountId,
														")",
														e.targetBalance != null && ` · Target: ${formatCurrency(e.targetBalance)}`
													]
												})
											}),
											e.type === "drawing" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mb-1 rounded bg-destructive/10 border border-destructive/30 px-2 py-0.5 text-[10px] text-destructive flex items-center gap-1.5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-3 w-3 shrink-0" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Partner Drawing: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "text-foreground",
														children: e.drawerName || e.referenceName || "Partner"
													})] }),
													e.chargeCategory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-muted-foreground",
														children: [
															"(",
															e.chargeCategory,
															")"
														]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-muted-foreground truncate",
												children: [
													e.chargeCategory,
													e.refundReason,
													e.note
												].filter(Boolean).join(" · ")
											}),
											MONEY_TYPES.includes(e.type) && !isJv && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-0.5 text-[10px] text-primary/80",
												children: [
													e.paymentMethod || (e.accountId ? "Cash" : "Old entry (before accounts)"),
													store.accounts.find((a) => a.id === e.accountId)?.name,
													e.chequeNo && `Chq ${e.chequeNo}`,
													e.bankName,
													e.txnRef && `Ref ${e.txnRef}`,
													e.collectedBy && `by ${e.collectedBy}`
												].filter(Boolean).join(" · ")
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: e.allocationOf ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1 text-[11px] text-muted-foreground italic",
											title: `System-managed charge linked to ${e.allocationOf}. Edit or delete parent purchase.`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Auto" })]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => generatePaymentReceipt(e),
													className: "rounded p-1 hover:bg-accent",
													title: "Download Receipt",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openEdit(e),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setEntryToDelete(e),
													className: "rounded p-1 hover:bg-accent",
													title: "Delete Entry",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
												})
											]
										})
									})
								]
							}, e.id);
						}) })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Entry — ", selected?.id] }) }),
						formFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: splitViewEntry !== null,
				onOpenChange: (open) => {
					if (!open) setSplitViewEntry(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-xl max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Allocation Breakdown — ", splitViewEntry?.id] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `text-xs px-2 py-0.5 rounded font-semibold uppercase ${splitViewEntry ? typeColors[splitViewEntry.type] : ""}`,
							children: splitViewEntry ? typeLabels[splitViewEntry.type] : ""
						})]
					}) }), splitViewEntry && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between rounded-lg bg-accent/20 p-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Reference: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: splitViewEntry.referenceName || splitViewEntry.referenceId || "—" })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Date: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: splitViewEntry.date })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Total: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "font-mono text-primary text-sm",
										children: formatCurrency(splitViewEntry.amount)
									})] })
								]
							}),
							splitViewEntry.type === "purchase" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto rounded-lg border border-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border bg-accent/30 text-left uppercase text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5",
												children: "Line"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5",
												children: "Target"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5",
												children: "Beneficiary / Passenger"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5 text-right",
												children: "Cost Share"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5 text-right",
												children: "Agent Sale"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5 text-center",
												children: "Billed?"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-border/40",
										children: purchaseAllocations(splitViewEntry).map((line, idx) => {
											const isAgent = line.target === "agent";
											const isHead = line.target === "head";
											const headName = isHead ? store.clients.find((c) => c.headId === line.headId) ? getClientName(store.clients.find((c) => c.headId === line.headId)) : line.headId : "";
											const memberName = line.clientId ? store.clients.find((c) => c.id === line.clientId)?.name : "";
											const agentName = isAgent ? store.agents.find((a) => a.id === line.agentId)?.name || line.agentId : "";
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-accent/10",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5 font-mono text-muted-foreground",
														children: line.id || `A${idx + 1}`
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${line.target === "head" ? "bg-amber-500/20 text-amber-400" : line.target === "agent" ? "bg-sky-500/20 text-sky-400" : "bg-muted text-muted-foreground"}`,
															children: line.target === "head" ? "Head" : line.target === "agent" ? "Agent" : "Office"
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-2.5",
														children: [
															isHead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "font-medium text-foreground",
																children: [
																	line.headId,
																	" — ",
																	headName
																]
															}), memberName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "text-[10px] text-muted-foreground",
																children: ["Member: ", memberName]
															})] }),
															isAgent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "font-medium text-foreground",
																children: agentName
															}), line.forClientName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "text-[10px] text-muted-foreground",
																children: ["Pax: ", line.forClientName]
															})] }),
															line.target === "office" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-muted-foreground italic",
																children: "General Agency / Stock"
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5 text-right font-mono font-medium text-destructive",
														children: formatCurrency(line.amount)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5 text-right font-mono",
														children: isAgent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-primary font-medium",
															children: formatCurrency(line.saleAmount ?? line.amount)
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: `text-[10px] ${(line.saleAmount ?? line.amount) - line.amount >= 0 ? "text-success" : "text-destructive"}`,
															children: [formatCurrency((line.saleAmount ?? line.amount) - line.amount), " profit"]
														})] }) : "—"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5 text-center",
														children: line.billClient ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "rounded bg-primary/20 text-primary px-1.5 py-0.5 text-[10px] font-semibold",
															children: "Yes"
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-muted-foreground text-[10px]",
															children: "No"
														})
													})
												]
											}, line.id || idx);
										})
									})]
								})
							}),
							splitViewEntry.type === "supplier_payment" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto rounded-lg border border-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border bg-accent/30 text-left uppercase text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5",
												children: "Line"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5",
												children: "Target"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5",
												children: "Details"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-2.5 text-right",
												children: "Payment Amount"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-border/40",
										children: paymentAllocations(splitViewEntry).map((line, idx) => {
											const grp = line.groupId ? store.groups.find((g) => g.id === line.groupId) : null;
											const head = line.headId ? store.clients.find((c) => c.headId === line.headId) : null;
											const agent = line.agentId ? store.agents.find((a) => a.id === line.agentId) : null;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-accent/10",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5 font-mono text-muted-foreground",
														children: line.id || `P${idx + 1}`
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${line.target === "group" ? "bg-purple-500/20 text-purple-400" : line.target === "head" ? "bg-amber-500/20 text-amber-400" : line.target === "agent" ? "bg-sky-500/20 text-sky-400" : "bg-muted text-muted-foreground"}`,
															children: line.target
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-2.5",
														children: [
															line.target === "group" && (grp ? `${grp.name} (${grp.id})` : line.groupId),
															line.target === "head" && (head ? `${line.headId} — ${getClientName(head)}` : line.headId),
															line.target === "agent" && (agent ? `${agent.name} (${agent.id})` : line.agentId),
															line.target === "unallocated" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-muted-foreground italic",
																children: "General / Unallocated Balance"
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-2.5 text-right font-mono font-medium text-success",
														children: formatCurrency(line.amount)
													})
												]
											}, line.id || idx);
										})
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setSplitViewEntry(null),
									children: "Close"
								})
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: entryToDelete !== null,
				onOpenChange: (open) => {
					if (!open) setEntryToDelete(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2 text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-5 w-5" }), "Confirm Delete Entry"]
					}) }), entryToDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground leading-relaxed",
								children: "Are you sure you want to delete this ledger entry? All linked supplier balances, client statements, and account balances will be safely recalculated without corrupting other records."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border border-border/60 bg-accent/20 p-3 space-y-1.5 font-mono",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground font-sans",
											children: "Entry ID:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: entryToDelete.id
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground font-sans",
											children: "Date:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: entryToDelete.date
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground font-sans",
											children: "Type:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `font-sans font-semibold ${typeColors[entryToDelete.type]}`,
											children: typeLabels[entryToDelete.type]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground font-sans",
											children: "Amount:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-foreground",
											children: formatCurrency(entryToDelete.amount)
										})]
									}),
									entryToDelete.referenceName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground font-sans",
											children: "Party / Ref:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: entryToDelete.referenceName
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									className: "flex-1",
									onClick: () => setEntryToDelete(null),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "destructive",
									className: "flex-1 gap-1.5",
									onClick: () => {
										store.deleteEntry(entryToDelete.id);
										setEntryToDelete(null);
										toast.success(`Entry ${entryToDelete.id} deleted successfully`);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-4 w-4" }), " Delete Entry"]
								})]
							})
						]
					})]
				})
			})
		]
	});
}
export { EntriesPage as component };
