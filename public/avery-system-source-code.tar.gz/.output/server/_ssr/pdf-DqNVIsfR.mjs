import { C as formatCurrency, w as getClientName } from "./router-2ATn7EQ0.mjs";
import { t as E } from "../_libs/jspdf.mjs";
import { t as autoTable } from "../_libs/jspdf-autotable.mjs";
// node_modules/.nitro/vite/services/ssr/assets/pdf-DqNVIsfR.js
var AVERY_LOGO_JPEG = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAH0AfQDASIAAhEBAxEB/8QAHQABAAIDAQEBAQAAAAAAAAAAAAYHBAUIAwECCf/EAE8QAAIBAwIEAwUEBwIKBgsAAAABAgMEBQYRBxIhMRNBURQiYXGBCBUykRYjQlKhsfAkwRclM2JygrLR4fE0Q2N0s+IYJic1N2RzkpPC0v/EABwBAQACAwEBAQAAAAAAAAAAAAAFBgIDBAEHCP/EAEIRAAIBAwICBwYDBgUEAQUAAAABAgMEESExBRITIkFRYXGBBhQykaGxwdHwFSNCUnLhMzQ1krIkJVNiFkOCosLx/9oADAMBAAIRAxEAPwD+noAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbS7tdQ3gAHj7ZZ87p+1UeaPdc63R9V1avtc0n/ro0+80Vpzr5oy5Jdx6gKSaTTTT7bA2pqSyjEAA9AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANDq7W2C0XZK6y9xtUqJ+DQh1qVWvJL+99DRc3NG0pOtXkoxXazOnTnWkoU1ls3spRinKUkklu2/IhWoOLWmMPUlZ2FSWUvU+V0bbryv4y7fluRKhHX3FqrG4q1KmE0/J9IRTTrR8n16y+fRfPysHTmg9NaXpR9hsISrpe9cVfeqS9er7fQrK4lxPjX+mx6Ol/5JrV/0x/F6eTJN21tZf5l80v5V2eb/IiSzvFfU6csbiaGHtZdVVrPZ8vqm93v9F3I3Rwut9V5uOPx+ppXtlQm1d5CM5qlGaezhH99pdOnZtk4vbi/4hZSpicXdTt9P2dRwvLqk9pXVRPrSg/3U+jf0JnYY+yxdnSsMfbU6FvRioU6cFsooiqPAP2zV5qtac6Sesm/ja3UFso971z/AA951zv/AHKOIwjGT7EtvN9r8Pn3EOtuGELenKMs5dVns0nV692t9/N9v5+pDrvC1sXkqtpcRi5UJLmdNtb+m2/Rb7+np3LpnKMIOcnsord/IqrLVpZHLXNzFylTqy6Nrpy+S2XR/wB5C+2XB+G8Jp0vdI8s5N6Zb0Xm324OjhN5cXMpdK8pL6kwscHZXWPpX1nf39PxaffxW2m/gun8DIpWeftXL2LMwvKa/YuI+8vRbpfz3MPQ98vDrY6c25RfiR3fk+6/r1JNVoQqp77xl5Sj0a+pOcG4dbcR4dC7tI8lTaXLKUXld2G0s74cWtewjLutUoV5UqjyuzKT0+/1NVDUFa1fh5rHVbVrvWj71L57919UbW3ube7pRr2teFWnLtKEt0zGdxUt5+z5CMZUp+7CsltF79OWS8n/AAZh3OnlTqO6wtzKxr93GPWnP4OPb6rqSttdcSt03B9NGPxRklGrH5dWXg+3sbOeUKM9+q3s94v8V9fI3INRY51+0rGZeirS8f4Ou9OqvWMv7u5tyeseIUOI0+eg9tGno0+5rdM5atGdF4kvyfkAAdprAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABpdYapsNH4G4zd9LdUo7U6afWpN9or6mm4r07WlKtVeIxWWzOnTlVmoQWWzV8Q+IdhofHx2grrJ3PuWtpF+9Jvza77fzIlovhhkc5kP0z4j1HdXdWXiULOb3jTW+65l2X+iunqanS3D/U2s6s+JGYvla5WrWjXx9OrT5qajF9pRfaPovr5li47XCtLmnh9ZWv3Rfy6Qqzf9luH6wqdk+/uvZlHp1Y8Vuo3fFk4UXrTT+B+Mn3vdJ4TW2VvOSg7Sk6Vo05/xNb+nh4oldOnClCNOnBRjFbJJbJIhmrclc57KQ0Bha0qdS4p+LkrmnLZ29v5xT/el2X1N7qfUVtpzA3OaqbVPDjtShHr4lR9IRXru2jE0RgK2GxcrvIy8TJ5KftV5UfV88uvJ8oroixX8ne1Y8NovEWsza7IdkV4z28En4EdbpUYO5nutI+ff6ffBucbjrPE2NHHWFCNKhQgoQjFdkjJAJqEI0oqEFhLRI4pScm5S3Zp9VX07PEzjR38au1Sppd22/L6EBr2FzjqytriPK4xjJx27+j9fNry7Esvakc3q2jj49aWPg51Ov7XTuvy6njr/HJ0qGUik/DfJPfpsn2e/T+mfJ/aa3q8XdxxGD6lGSgvFL4n/ua9Cx8OqRtXCg95rL/D6GixGSWOydC6k2qalyuX+Y+j336dO++5Zqakk090ynKlWTW6jukuuyfp16Lrv1XTv9SytJZJZLDUpvdTo/qpp9012/gbPYDiPR16ljJ6SXMvNb/NfY843b5jGsuzR/gbepTp1qcqVWCnCa2lFrdNGHaOpY1Vj60pTpy3dvUk921+436ry9V8jOPK6t43VF0pNxfeMk9nFrsz6Le2spNXNv8A4kdv/ZdsX4PsfY8PvTgac0upLZ/TxPLI420yltK1u6alGXZ+cX6p+TNPaZO7wN7DE5ys6lCtLltLyX7T/cm/KX8ze2tWVWntUSVSD5ZpPzPLKY22y9jVsLuO9Oqtt13i/Jr4kfd2Tu1HiXDny1seSkv5Jr6d8WbqVVQ/c1tY/bxX61MruCNabyN7Y3lTS2ak5XFBc1rXa6V6Pl1/eXmSUkeG8QhxKh0sVhp4lF7xkt0/1saq9F0J8r1XY+9d4ABIGkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN7LdlM3XNxe4lSsPE59O6bknNRfu1qu/bfz3a+iXxJvxV1TLSejby9oS2urhezWy/wC0n03+i3Z84U6UWk9HWlrWj/a7le03MvNzl1S7b9FsiscUj+1b+nwz/wCnHr1PH+WPq9Wu7XsJS1fulvK6/ifVj+LJfCEKcFCnFRjFbJJbJL0PC/x1jlLadnkbSlcUKi2lCpFNMyD5KSjFyk9klu2WSUISg4SSa7uwjFJp5T1KkvtE3FfWtPDaSzFe1tcVSheVaVw3Xt6Vbd+HGMJPotvJdF5bE1t8rrXHRjTzOn6N9FbJ3FhWSb6d/Dl17+jZ80Fbzq2l9qCtKUquYu6lwm32pJ8tNL4cq3+pKCr8I4Suh97oTlSdRuSUccvLnqrlaa+HHc9ewlLy7fP0NRKSjprvnt1WHua+zzdrd7RlSuKFRrfkrUZRff5bGRd31C0sq19KadOjFybXXsZBC+JeUq0rK1wVm5+0ZKqobwfZbr8S7uLb6/Dc7+JXdfhVhUr1ZqTSwsRw8vRdrzr3JHNb0o3VeNOCwnvrnTt7DP0TbVKlvc5y438bIVXNLd7Rhvul39WzdZexjksdXspf9ZBpP0fkz9420jYWFvZRaao04w3S2T2XkvIyD3hvCYW/C42NXti+bzl8X1ZjcXDqXDrR79PTYpqSdGs6Mqa3UnGS/d69d/h36Eg4f5WdvkZ4+ttGncJqO/T31u9vqt/y+Jja7x8Mbl3c78tG4Xi7f53aX931ZHqF5Kzv6F3SlGMqE4yTcOyXluvXz29T4tSlW4HxJN/FSl88PX0a+jLfKMb620/iX6+pd4PGyu6V9aUbyjJOFaCmuvqex+gKVWFenGrTeVJJryZR5RcW4vdGPW3o14V1+GXuT+HozIPzUgqkJQbaUltuu6PzbTlOkvEac17stvVdznpQ6CtKC+GXWXg/4vno/NyZk3zRT7jSaww9xf2Cv8ZtDJY9utbT+K7x+Ka6bGfgMvSzmKoZGmtnUjtOL7wmukov5M2BEMa5ad1lcYfl2s8vF3VD0jVX44r037kRdx/ZfEYXkPgrNQn/AFfwS/8A1fodlL/qKDpP4o6ry7V+PzJeACxnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVHxKa1ZxM0zohe9Qtpe3XMU++3vJflEtxLZbLyKh0c/vjjpqjJyUpfd1BWsXJr3e0dl8OjLeK57P/AL+VzevedRpf0x0iSXEf3apUV/DFfN6sGq1VWq0dO38qLkpyoSpxce6cvd3XVeptTWZ6NOrTsrWpCUlWvaS93y5W59fh7hK8Sb9zqKLw2ml5vRfVnHbY6aLeyefkZOJs1jsZaWEe1vRhS/JJGUAddOEaUFCOyWEapScm5PtBX2FvP0s4h3l9CUZ2eGTo03tv+s7PZ/z6+hItd5+Om9LX+T3aqRpunS22/HLou5q+E+Gq4vSdG6u6bjdZGTua2/d79Fv9F/ErPFP+48Ut+Hr4YfvJemkV8+wkrZdBa1Lh7vqr13+hMwAWkjCK8RcZ7Zg3e04rxbKSqp9vd81v/SKrm3TUVGScU+XddWt+m/fy37f39C+rmhTurepb1YpwqRcWmt11KEy1Kpi72vi6jjGUJum477JLyS39U9/L8S9T5H7ecO6C9jdxWlRa+a/NY+TLXwKvz0nRf8P2ZZfDDKq4xVTF1G/EtZc0d/OEuvT4enwaJoUVobMTxOpLS4qb+FV/U1PRKXRvt+8luXqnut0Wr2I4j73w/wB3k+tTePR6r8V6EXxq36G451tLX17QYsKip5KpbuT/AF1NVopvzT5ZbfnH8zKPKpbQqXFK63anSUop+sZbbr80n9C3ThzNPtT/ALfZkSnjJ6kP4k0qlrjbXUVsqnjYm6p1nyedPfaW68+hMDXajsPvLA39ltu6tvNRXq9un8SP41a++WFWkt8NrzWq+qR0WdToq8JPbOvk9H9DNtq8Lq3pXNKSlCrCM4tdmmtz0I3w7yP3npDH1nPmnTp+DPo+kovZrqSQ6OHXPvlpSuP5op/NGuvT6GrKn3NoAA7DUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAc9aJ1gtJ8Q9T5TL2VSpYXV47e5vacXL2eXM+Vy/zXs/y8y/7K9tMjbU7yxuKdehVipQqU5KUZJ/FFV8HbelcZ3XNvdW0akJ5JKcakVJSTc3s0/mSapw6+6LqeR0Pl62FrT96Vr/lLOo/jSfSPzjs/n0KP7NyvraxjWpx6SnJyzHaSak1pnR5xnDaee0neJqhUuHCT5ZJLXdPRb9q+pNDXZJU55DGU6ktv185RXrJU5f8TV22d1PYQUNQ6blV5Vs7jHT8WLfryPaS8/UzKeTw+WvLWtSv1Tq2lWT8KpFwlJuDjy7S2/e8ifrX9vdQVLm5Zc0XiS5XpJN6PGdF2ZI6NvUpNyxlYeq1Wz7jcgKUZLeLTXwPzUqU6UJVas4whFbuUnskiYbSWXsceOwr7iJg8prfNY3TNpSlDH2s43V9Xl0j36RXrLbf8yeTq2eNtU61WnQoUYqO8pKKSXRFV64474zD1KuP0pSpX1ym1O4lLajF9ntt+Jr8vIq+nca74p5R0aU7q9lJpt821CkuvVr8Mf8Agz57V4/bcPuqs7NOtWqPdfCktIxXa8LfG77Sxw4dVuKMFW6kIr18W+712LrzHGzR2OnOhY1qmQrxfKlSW1Ny9OZ/Xt6ERv8Ajhqe8caWFwdvRc1tFyU6spP4bLb16bPsbbS3AfH2UI1tSX87ur03pUW4w6Ppu+7/AIIsfGadweHgoY3F21Db9qNNcz+vc3QtfaXivXrVVRi+xaP6a/ORqlV4Za6Qhzvve369Cr7HUfFnMR2o4+rFTbfOqPIo7Pt16dv6ZptVYjVVvH741DRe9fenvKS6vZ9H5dkn1X5bdb6NHrXDffmnLuzjFOrGPi0t1+3Hqjn4n7H1Pc51JXE6k4ptJ7Nrwbb2zjUytuLxVaMVTjGL0eNygYVVTmqtOrVdSO+2y2/Cu/8AzLt0fq+eUwtGvcY+6kqS8KVaEedScdlvsuq7+foyh7hzU50nTUWml7u63W/n6dd18N9vMsPgzqCVLKXWGuXKELuKqUoya6VFvzL6rYqPsxeVLTiEIwnyKfVb0a12yn4+T8SY4rQVW3cmsuOv5lt2t9aXsOe1rxmvNJ9V9D3PKraW9Z806a5vKa6SX1XUUlXhNwm1Kmorlm372+73TW3pt1+Z9poSuIvkrpPxjlL1Tzj5v0KVJQesPqep+asFUpTg+0otM/R+aslCnOcn0jFtnRL4WYrchPCNOlp+8tf2KGRuYQ+XO2TggnCCsrjAXteEnKFTJXE4tpdnL4E7IT2aeeFUfL8WdvEv83PzAAJ04QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACqtBp4ji9rLDTqy2vOS+imuVS5tn0XwT2+JapVWsl+i3GDTmqX7ttlqU8bcS7LmfSP8AOP5Fqlf4Biiq9n2wqS0/9Zar55JHiHX6Ot/NFfNaMHyVOnJpyhFtdt12PpFOIHEXC8P8cri+kq13WTVtaxltKo/V+kfVkvd3NCzoutcPEV3nHRpTrTUKay2bPUWpMDo3F1MnlrinbUYbtQilzTfpGK6tnNPEHi/ntc1J2NtP2TFt/q7ejL3qi37za7+XwRG9Vat1LxBy0brIurd1JOUaNpS6xgm+kIx8326+ZdXDPhDitM+x5nWXhV8pdy2tbOcekJNeaf4pbLr6HzW84lee0lX3a1/d0VvnRY7OZ+PZFdvfuWeja0OFQ6Wt1pv9afiyOcNuBt5noUc1qvxLWxltOFsntUrLff3vOK/j8i/8ViMZhLOnj8VZUrW3praMKcUkZiSS2SBeOEcBteEQ/drM+2T39O5eHzyQN5xCtey67xHu/W4ABNnCA+q2AAOc+I+Hlp/U13QhLkp1p+003u0uWb2e3/Pp6bGkxWSqYfJ2+Qt5clW1rqonF8m63+Pk49Pq0W7xuwUbrBUs9Qp/r7CXK5JPfkl067LfZPr6epSVVeJHnc9+ffp+F9/P0XwPg/HuHvhXEZ0Y6LOY+T1Xy29C+8Prq7toylvszq/H3tDJWNC/tpKVK4pxqQa9GtzIK14Iag9twVXA16vNWx8uaG/nTl1X5Pcso+ycF4guJ2NO57WtfNaP6/Qpd5bu1rypd23l2A1+or5Y3A5C+c1B0bapJSa32fK9v4mwIHxmybtdIyxVB73OXrQtKUVJJyTfXbf+uplxe5VnYVazeMRePN6L64FnS6a4hDva/ue/B60na6EsqlTm5rqdS4fN3XNJsmpg4KwjisNY46K/6Nbwpv5pLf8AiZxlwq3dpY0aEt4xSfnjX6nl3UVavOou1sAAkDnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAITxg01W1Hou4dlKUb3GzV/bOPR88N912flubnQ2oXqnSmOzcqbhUuKMfFi12mukvpub1pSTjJJprZplZ8UeL+G4f2U8LiPCr5fk5adCCXJbprpKe3bp2X9xA3vRcLuZcTqz5YuPK12yafVx44yv0yQoKd3SVrCOWnlPuT39Da8TuJ+M4e4zfaNzk7hNW9sn26fil6JfxOXLm81RxB1G6tepPIZK9lywik+i36RS/ZS3+CMvB4HV/FTUdWVF17u5rzTu7qr1hSW6W8n26ei+iOneHnC/AcPrNK1hG4yFSKVe7nFc0vhH92PwKa4X/thc83wUYv0X5y+3gTnNb8EpY+Ko/16IjvD7hjhuF2Franz86dxk6FvKpUqv8NCO27hDf5Jbmo4P3+U15rTJa0zNZ1I2dLwbaGz5aXO+0U+n4V16eZi8d+KOOq2stF4K8jXqTkpXtWlJSjFJ7+H36vfbfy+JkfZqy1l7Fl8PKrGN068biMG1vOPLs2uu76/zOiFSz/a9vw61f7mm8t/zTw3lvteUkvVLsNUo1/cqlzVXXlp5Rz9C7QAfSCsAAAAAAGNk7Cjk8dc4+vHeFxSlTfw3Xc5UykamIyV1jK0oxlbVJUZbySb2fd7+uyb+Z1o5KKcpNJJbts5Z4lX9nf63ydxZVVNKrtFqC2ey25l9U+qPnPt9b0sUa/8eq8Wt/o/uWT2eqSzOHZo/X9fY/WgdTy01q+0v3NqhUkqNw9tk6b6b7d3t38+x1HGUZxU4NOMlumvNHGMrlfiUeaW+27Xnt59f63L84LcRbfMYulpbLVnDI2UVCi6k9/HpLts33a7M4fYri0bStKzrPEZ6r+rbHqvqsdp0ccs3Vgq8Fqt/L+xaZV+Qq/prxatMbSpKpYaai69aT6x8d7bL57/AMmS7XmraGkNPV8k+WdzP9Va0t+s6j7dO+y7s1/C7SlbTeAdzklzZTKTd1eTkve5n1UX8k/zbLfxSX7SvaXDYaxi1Op5L4YvzfZ3akLar3ahK5lu+rHze79ETIAFlI0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGNf5OwxdCdzf3dOjThFybk+uy9F3f0Mk/DoUJT8SVGDl+84rc1VlVcGqLSl46r5JrPzRlDlz19io9XcSNbamhLE8LdNX1SFXeLydWi4Q6PZ8nN2+b+hHtLfZtyF5dvK69zXPKpJznQoScpTk315pv6ep0BsvQFfl7OQu6yr8RqOq12fDFeSWv117ckkuJyow6O2ioLv3fz/sRfS95ojEX1bROnHb211ZR5qltGLjLb1bfWXf8AiZeo9I2+pvcvMxlrei48sqNrc+FCXz2W/wDE1HEDQMtROhqDAV/YdRYz37S5j0VTb/q5+sWfjQnEilqKvV09n7R4vUNl7txaVWl4jX7VP1XZ/UKpThU/ZnEYJQb6jWkZL+XfSS7u37+OEpR96t5NtfFnVp9/ivHsNLU+ztw7SlUqTyvKk5Sbu/rv+Hc97DgFofHV4XuOu8xb1odYVaV64yS+aRZRh07mNtdRx9Z7c65qEn2kl3j81/I2VeCcKoSjz0Uk3jOuj7O3t2XjhdqMY8QvJp4mzGw+AliGv8eZS8io8qhdVozXz/CnubUAm6FvTtodHSWF+u84Z1JVHzS3AANxgAAAR3LaKtc1Snb3+bzMqU+bmhC75E0/L3UuhG3wE0FLvHI9Vs17U9vy22LGBD1OAcNqvmqUk345/M7IX9zTWITaRXH+ALQXM5f4y3fX/pX/AAPC74K8O8Hb1MvXu8na07WLqSq+2NOCXXvtuWLkslYYiyq5DJXVO3t6MeadSpLZJFayo5PjDk4zrQrWekLWpzQT3hO/kn0f+j/XftC8T4fwu0xQt7dTrS+GOvzeukV9Tttrm7rZqVKjUFu/wXia3h7p2+1pnFqjLXV/XweMrP7ppXs+eU2u0n6pd9++/n0Zcp5Wtrb2VvTtLSjClRpRUYQgtlFLyR6k3wbhUeFW/I3mb1k+9/ktkcV7du7qc20VsvD8+8AAlzjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABF9Z8P8AEawhTuJynZZO2fNbX1BJVacl23f7S+DJQDnurSje0nRrx5ovsNlKtOhNTpvDKwtuIOpNCXUcRxOsJTtG1Ghm7WDlSmv+1S/A/Vk8n9z6qxe9teU7i3qpTp17er1jJdVKMl2aM+vb0LqlK3uaFOrSmuWUJxUoyXo0+5XuT4SPH3ksxw8zlfT9425SoJudtVfmnDsv4kJUtr6xg6SXT0Xpyy+NLuy9JLzwzvjUt7iSk/3c+9fD8t16ZRKcdk8ljqqxmpFFy32oX0I7U6y8ubyhP4dn5G9TT6plafpfxJ01SVDWOiVl7ddJ3eLkpc0fV0n/ACMnD8XNAxn7PWvrrFNtJUb2jOEYtvy3XT+Rrs+NUKElQr1HFd1TMZLwbekvPOe/L1Pa1jVmuenHP9OqfotV5fYsIGlttbaRu4Opbakx04p7Nq4j3/M9nqnTaaTz1gt/W4h/vJxX9pJZVWP+5fmcLt6q3i/kzaAjOR4maCxcXK81RYx5W4tQnzvdfCO5o6nGKyv5uhpTTOYzNXqlKFB0qe/xlL+uhyVuO8OoaSrJvuXWfyjlm2Fhc1NVB48dF82WERbVXEXAaXatHKpf5Gp7tKytF4lWTfbdLsvmR+WG4rawmvvnK2+msdJre3sn4lxKPo59l/xJRpfQWmtJRlPF2PNc1P8AK3VZ89ap85PqcjvOI8R6tpT6KP8APNa+kPxehuVG2tta0uZ90dvWX5Eas9Hai1ve0c1xCnGjZ0mp22HpP3Yv1qv9p/AsOjRpW9KFChTjTp00oxjFbJJeSR+wSFhwyjw9OUcynL4pPWT833dyWhz3F1O4wnpFbJbIAAkTmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABiXuIxWSSjkMbbXKT3Xi0oz2e23mvizLBhUpwqx5ZpNeOp7GTi8xeCKV+FXDy428TSeP3XmqS3/M8lwh4c77/AKKWL89nDpv6kwBxPhFg3l0If7V+R0K8uVtUfzZo7TQ2jrFr2XTONp7dv7NF7fLddOxuqdKnRjyUqcYRXlFbI/QOmja0Lf8AwYKPkkvsap1alT45N+bAAN5rAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKg4ocZ7nROucRgrTwp2a5J5JcnNPlnLZJPy2ju/yLcoVqdxRhcUZqVOpFTjJdmmt0yPteJULyvVt6XxU3h/29dH4nTWtalCnCpPaWqP2AfKnO4SVNpT2fK323O9vCycx9BU2vNU8ZtFWdXL0rDB5LHUW5ValGjUU6cfWUebt6vsVp/6UOuG3tjsVsns/1E2vz5/6fQrNx7VWlpPo69OcZdzivzJWlwivWjz05Ra8zqQFOcNNfcV+I1Gtf0LbB2ePoz8N16lGo3Ka7xSU/L1Lds1dxtaSv50pXCivFdJNQcvPZPrsSnDuKQ4lHnpQko97SSflqzkubSVq+WclnuTPYAEmcoBDda3fEnFWt5ldMLD3VC3i6kbatSn4rikt1zKSTfd/kVRpvjtxP1XmKWDwuExVa5rtqPNSnGMUu7k+bols9/yK/d+0VvZVugrU5qT20WuuNNdckjR4bVrw6SEo47ddvM6JBrMDDUcLWX6SXFjVrtpx9kpyhGK26p8ze/U9czTzdS05cDcWlG55l71zTlOHL59E09yXjcOVDpuSX9OnN8s4+pxOmlPk5l59hnAobXXFzitoDLRxuYxOHnCtHnoV6VKo4VIru/xdGvQ02L+0PxEzN/bY3HYfFVri6lGnSgqcvek/Je+V6p7X2VKo6U4TUlpjlWc/Mko8GuJx54uLXmdJAp16u+0D3joWwS8049f/ABA9W/aCe3LobH9+u6f/APf9fz6P/klL/wAFX/Z/c1/syf8APD/ci4gc/Z/jTxY0xVVHPaXs7KUvwyqW1Tkl8pKez8/PyLm0Rn6uqNKYzP16cKdW8o884w7KSbT2+G6N/DuP2vE68rekpKSWessdqXe+813PD61rTVWeGnpo8m7AMfIRv52dWOMq0aVy1+rnWg5QT+KTTZMVJOEXJLOOxbvwRxRXM0jIBS3ELiTxU4eV6byNhhK9pcPahc06VTaTS6xa590/7iMY77ROvMnfUMdbYvFOvcVI04J05pbvt15u25Wa3tdZW9R0qsJqS7Gln7kpT4PcVYqcGmn4nSAK3jecet9pYjTO3qq0/wDeYN9rvi3pijK51FoW2u7eD3nWsKzlyx+K6tf8Dqn7QUqS56tGpGK7XB4X1NUeHTm8QnFvu5kWsCtdM8fNFZydO2yMq2HuanTlul+rT/010Xdd9u5ZFOpTqwjUpTjOElvGUXumvVMkLHidpxKPNazUvDtXmnqjmr21a2eKscH6AInrCtxGtHK60jSxd1Rik/Z68JeK/XZ8yT+CNt5de50+l5JS8IrL88GNGl00uXKXnoSwHON99ofXuNvKuPyGIx1vcUZeHUpyoVN4y9GnJfl8vXp76f498QdSZa1w+PxmJlXu6ip0+anNdX5/j7LYri9s+HyfKozz5L8yTfBLlLLax5nQ4MDCwzcbNff9a0qXL2b9mhKMF07e82++5nloo1HWpqbi457Hv67kTOPJJxznyABEdaXfELGW9xktMrE3FChTdR0K9OfibJddmpJN9+nwNN5dqypdK4Sku3lWWvHdaGdGl00+RNLzJcDnPF/aA4iZi9pY7H4PG3F1XkoU6VOlUcm/Po5Lt/Wxc+lJa/rKNxq77qoxnBv2e1hPnhLy3k20/PsRVh7RW/EqnJb05vveFhebyddxw2rax5qskvXUkoALAR4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPG9vLfH2de+uqihRt6cqtSXpGK3Z7FZ8es5XtNKUtNY5SnfahrxsqUYrd8r/ABf3L6nDxK8XD7Spcv8AhWnnsl8zotaDua0aS7X/AP05Z1fqGvqjUuQ1FcKcpXlzKcVJPpD9nuvRdjqjgDrB6q0Fb29zVUrzEv2Sr1W7il7kunqun0K4478L7bT+jMHlcXaxj91042V24pPm5uqm9l197fr8fyi32edWy03rynjrq45bTMR9mnutkqnV02/q2v8AmfNeG1K/AuLRjc6c2FLylh59Hu/Blpu40+I2TlS7NvT+x10AD6wU487q2oXttVtLqlGpRrQdOcJLdSi1s0cP8QNLVNG6wyeCnGcKdCs5W8t+sqMtnDb6dOn7vY7kKM+05o93eLs9ZWlBSnZP2a62S60pP3ZP5S6f6xUPbDh/vNorqC61P/i9/lv8yb4Jc9FX6KW0vuYn2XNT0Xb5PSVaqlNT9st47rqn0ml9eV/Uv44c4falqaP1bjdQ06j5aNRKulu+ak+klt37eXwXodv21xSu7eldUJqdKtCNSEl5xa3TMfY2/wCntHayesHp5P8Avn6Djlt0dZVVtL7o9AAXEhDUawy9DA6XymXuGuS2tak+vm9tkvzaKt+zbpX2fEXmsruivGyk3Cg3BLakn1a+b/lt5GZx9y11f08Nw7xNR+1565j4sYvqqUX5/Xr/AKrLPwWItsDh7PDWi2pWdGFGPTbfZd/qVjo1xLjfO11aC/8Ayl+S+qJbmdrYcvbUf0X9/oZwALORJSH2orehPC4WtJJVYXNRRl6LlXTuU7wmc3xH07Ccdkr6Lfx6P+9f1uXL9qFSeAxCi3v7RVfdeUY/1/v7FOcJNo8R9PJp7u+jv73fpLZ7f18Ox8k9oFjjssd8PtEuXDv9OXlL7s7P2XoNkAfWymms1Jp3Gapw9zhcrbxqUbiDju11g/KUX5NPqmiL8GaFxjtJTwd3Hatir2vaT69+WXR7PtummTs86VtbUJ1KlC3p05Vpc9Rxik5y223e3d7EdVsIyvad7DCaTT8U9vkzpjcNUJUHs2mvBnoACROYqz7R1GnU4eupLl5qd3Scd0n33T7nPWiIf+uGGjttte0V1e/7fr+X8joj7Rn/AMOai323u6KfXy5jnbRK21fhtvO9o9veX4l/Xc+R+1i/7tL/AO37IuXB/wDJL1O2RKMZJxkk01s0/NAH1vsKacwcfdC2emdQW+XxFvGjaZNTnOnGPuwqx25tvTdPt/A2v2feI15bZaOicrcynZ3XM7JzbfhVF1cE/R9dl5fUk32mnb/o1iueKdb2uXI/SPJ73/6lI8OqVaprzBeDJ87vqfVdOm+7+a23R8j4g/2Px2UrXRJp4Xik2vJ5+Rcrde/cPSra6P6bM7SAQPrpTSoOPfDelm8XLV+JoOOSx8N6ygutakn3a83Hv8voc/afzV1pvM2WcsZRlWs6kasU30ez7P5rp8vkdvyjGcXCcVKMls01umjk/jLoOWi9Tyq2dHlxmQ3q27iltD96H033+T+B809sOEe7VVxCgsKT62OyXY/X7+ZaeC3nSwdtU3W3l3en28jp7TWoMfqnCWmcxtVToXVNT2T6xl5xfo090bM5o4B8QXgc1+i+RqqNhk5/qpTlsqVfbZbb+Uui+ex0uW72f4suLWinL446S8+/yf3yuwheI2bs6zivheq8v7AifFDU9HS+j764517Vc05W9tT7uc5Lbt8FuyVVKkKVOVWpJRhBOUm30SXmU3jqNTjBxAlm63v6awU+W2i4vlrz9fju+vy29Rx29nRpK0t9atXqx8F2y8khYUIzm61T4Iav8F6mw4GcN4aaxX6SZSh/jG/jvTjJdaNJ9vq+5awSSSSWyQO7hnD6XC7aNvS7N33vtf68jRdXM7uq6s+36IAA7znAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUFqnr3jnVu372P0dQ8OG3Z3Ev8Ac9//ALV6Fi6z1DS0ppfJagquP9joSnBS7Sn2ivrJoiXAjBVcdoqObvW3e56rK/rSfdp9I/w6/Ur/ABL/AKy/oWK2X7yXlHSK9WSVr+4t6lx2vqr13+hMNXaettVabyGAuorlvKEqabX4Zbe6/o9jhetb3eAy07acVQubG4lFrlSanCfR9/Jpfz27nf5yf9o/STwOtnm7Sj4dtmafi7xXTxoraa+vSX1ZCe2tjz04Xsezqvye31yvUkOA3GJSoPt1X4/rwOj9Aaopax0hjc/T2U7iilWjuny1Y9Jrp8UyQnO/2XNYuNa/0TdVvcnvd2cX2XlOK+mzOiCxcAv/ANo2EKrfWWj81+aw/UiuI2/utxKC23Xkwa7UeDs9S4K+wN/DmoX1CVGfw3XRr4p7P6GxBLVKcasHTmsprD8mckZOElKO6OCc7iLnBZm8w15FRr2lxKlLzfMn3S79Vs+3mjqX7POr5ak0PDHXVaM7rESVvLqt3S23g2vluvoV79prRvsOWttX2lCKoZCKt7ppdqq/DJ9PNL80RfgHrCOl9dW9rcXDhZZaHstXd+6pt/q2/lLp/rHyiwnL2f4z0dR9VPlf9L2f2ZcLmK4lY88d8ZXmt190ddnyUlGLlJpJLdt+R9IVxh1S9KaFv7mhOUbu7j7Jbcu/Nzz6brb0W7PqN5dQsredxPaKb/t67FSoUpV6kacd2yF8Pqa19xcz+u6051bDFf2LH7p8qkum63+HM/8AWLpIfwm0x+imhcdYVaUYXNaHtNxtHZ+JPrs/Potl9CYEdwG1lb2anV+Oo3OXnLX6LCOniNVVK7jD4Y9VeSAAJo4SkftRpSwOGTW+1xVaXl+GJTnCPb/CTp1xl0V7Hpv5bS/rv/xuP7Ue33Bh+aW39oq/yj8CitC2mRyGsMTZYXIqwvqt1GNC56N05Pfrtt8Nu3wPkntE2uNzaWdYf8Ylz4Ys8PSfdL7s7jEpKKcpNJJbtvyKqWgOML/FxV22XlQ/8prNQcLuL+QsKlOPEqV22mvAk5UVJNdt4r+aLzU4xewi5Rs5t+a/DL+hXo2VFtJ1o/U3+kdYx1TxWz1vZ3Lq2OOsI29JxlvCUlUXNJfV7b/Ask58+zfjr3Earz2MyNCVG5tbVUqkJfstVF0Xw6/10Ogzz2XrzubKVap8Upyb9We8VpxpV1CGyS+wABYyMKu+0b04dTaa3V3R29e5zrol76sw+273vKP4e23OvT+tnt8Dov7RnTh3N/8AzlH+Zzbpj2x6hxvsHhu59qp+AqnWLnvuvpv0fzZ8j9rNOLSfhH7IuXBv8mvU7iDaim29ku7KzzuoeM+DxtzlZ6ewdxStabqTjRqzlJpd2o93sikM5xl1zqiErTIZd29nUkvFpWUOR+Hv7yb83t8S4XvtZRslyyozUsaKSUfxf2ZC2/B6lxqpxx4PJv8A7QGtbfUuft8Hiayr22M3jOdOacZ1ZdJJdfLtv8yQ8BeGF/Rvoa1z9pOhGkmrKjVXvSbW3icu3TZbpef5ImvDzhjw4tMfaaiw1osjK4pqrSubl87juuyXZbbtFjJJdEji4Z7P1by6XFb+SfM1JKOq8MvuWmEs+ZvuuJQo0fc7dNY0bf1+YABeSABGuImj6OttMXWHbhC428S2qSjvyVF2+j7P5klBouband0ZUKqzGSwzZSqyozVSG6OGLy0r4y+r2d1TnQr0JulNPvGS6fTZ+fzOp+DWvlrTTUaF9XhLKY5KjcJPrOO3u1Nvj2fxTK/+0RoKVvcU9bYujtTrNU76MV0U+nLN/PbZsq7Q+sMhojUVDO2cfEcYyp1aM58sasH3i3+Wz9UvifJrSvX9l+KOFT4Vo/GL2a+6+XeXCvThxa0Uob7rwfd+vM6D4u6mvripa8OdNy58pmdo12v+poPu36b7P6E20lpmy0jgLXBWK3hQj7833qTf4pP4tkH4P6dv7+rd8StS+/ksy3K2jJJ+BQfkvmkl8kviWgX3g1Cd3Vlxa4WJT0gv5Ydnq93/AHK7ezjRgrOntHd98v7bAAFjI0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHyc404SqTkoxim235IN41YKc4+V7/Ud/p/hniWvGy9x4teT32hTW6Te3kurfyPa14acX7O1o2trxPpUaVCmqUIRodFFLZd4mLwtUdc8TtScQq0XO2s5ew2Dl5Lqt/nyrs/3i6Cn2HDqXGp1eI120pSajiTXVjotu/BN3NzKxjC1glosvKT1epUlPh9xrXSfFSl38qH/k/vIzxL4UcSMlpmre5zWFHNQxcZXMaPg8s9kvecdkk3t16+nQ6BPzUhCrTlTqRUozTi0/NM7a/szaVqcoc0tV2ybWezTPeaKfFa0JqWI/JHCGkNQXGktU2Get6rUrSvGcl+9B/iT+abO6cbkLTK4+3ydhXjWt7qnGrTnF7qUWt0cT8UNLVNGa2yWFUN6Earr27Xd06nWO3yW6+h0F9mzWMc7o+en7is5XWHnyrm7ujJvk/Jpr6FX9kruVlezsa2nNp5Sj/bPyRLcaoqvQjcw1x9mW8AD6WVUjnELStLWekchgaij4lWm50JP9mrHrF/n0+pxG1dWF9KMnKFzaVmn6xmn8u6a/gd/nJ/2idGU9O6z++bWhyWmaj4q2W68Zf5SPw36MoPtrw/MYX0Vt1Zfg/uvkWPgNzhyt5ea/E6J4a6rpaz0bjs3CcXVlTVKul5VY9Jfx6/UgGsqk+IPGTE6Lpw58dp1Rv719Wufvyvrt5RX1ZAOAXEq00jHL4nM3EaVpUt5XdupS2XiwX4Fv5yW3zaLM4BYSvXsMrxByj57/AFFdTnGTXVUYye35tv8AJHttfvjtvbWDeXnNTyhjf+rT1PKtsuH1Ktx2fw+cvy1LZABfSugAAFI/ake2Aw+3d3NXbr/mxKb4S1N+JGnYtcq9tj03+D+L9F+Rcf2pVvp7D/8Aeav5csSmeEu/+ErTm6i/7fBvqvR7Pp6/T5Hyb2g/12XnD/jEuXDv9OXlL7s7VAB9ZKaRPGaSr43iNlNUUYxVpkbCnTls0n4ymt+nfst9yWA1GqdS2elsU8ldpylOpChQpL8VWrJ7Riv68jgjTt+FUalTOIZlJ+urx+COhyqXc4x3eEl6bG3B8pylKEZSWzaTa9GfTuTysnOVd9o1pcOp8yb3vKHp6nOehtnq3De/3vKL2Wz5mpLdrp137b/A6L+0e9uHM+3W8od/mc6aFlzavxC5d37bRbSbez5l/Wz+Z8l9rP8AVpeUfsi5cH/ya9Tt2UYyTjJJprZp+Zybxr0FPRmqHeWlBfduScq1vJL8E905Q6+ndfB/A6yI/rvSNnrbTd1grraM6i56FXbrSqr8Ml9S9e0fCFxW06i/eR1j4969fvgr/DL33Ot1vhej/P0KL4A8SI4PJvSGWuUrC+nvbTm1tRrv9nf0l/Pb1OlDhfKY7IafytfG5Cm6NxZVXSlt3Ul2/ktuv+46h4J8Q46z06rC/r82VxsYwrc3SVSn2jU/ufxXxK57H8ZcJfs2u/6fPtj+K9fAk+NWKf8A1VP1/MscAH0QrQAABEeLkYy4b55TgpJWu+zW/wC0jjiEopbvrumtk+jXn6P4nZHFpb8OM8tt97V/7SOOFOS2kve6dvRv+Xf+tj5b7b/6hD+hf8pFt4B/l5f1fgjt/SkeXS+IjtttY0P9hG1NXpRt6YxLa6+xUf8AYRtD6PYf5Wl/TH7Iq9f/ABZebAAOs1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArDjzxDttIaVq4i1uF96ZaDo0YR6yhTfSc36dOi+LJ5qCxzWQslb4PNLGVnNOVbwFVfL5pJ9E/iU5m/s0ZHUGQnkstr+4vK9R7znXtud7eSW8umxXuOVeIVKUrayot8yw5Zilh74y857NljsJLh8LaM1VuJpY7MP66YJh9n6ztLXhhjalrs3cTq1aj6fi52tvokkWMVTpHg/qvRFCdpp/iNWpW9SXPKjUs41Ib+qTfTt5bd2Wlawr07alTuayq1owiqlRR5VKW3V7eW7N/A+npWsLavRcHBJZzFp+WG3ru8o13/RzrSq05qSb8cr5o9ADEy1vkbrH1qGKv42V1NJU68qSqKD378r6PoS9SThBySy12LGX4LOF82cUUpNJvBRH2rMJaxt8PqKG0a8pTtKi2/FH8S/Lr/Aqzg7rd6F1naZGvVl7Bc/2a8T3bVOX7XX0ai/lv6l36r4B53Wt5G91FxCuLqdNONNO1UYwW+/SKlsvyNHH7J9FJb6xqb+e1rFL8t/kfNL/AIVxS4v5XttQcNU1rHdY1+LterLXb3lnTtlb1amdMPR/kX/Qr0bmjC4t6kalOpFShKL3Uk+zR+yudF8NdXaLp29jZ8Qatxj6U1KVtXtFNcvnGLct4r09Cxj6BYXFxcU83NJ05LxTT8sN/XBWrinTpyxSnzL1XzygQDjhpD9LtBXlOjTUruwTu6Hk/dXvLf4x3/gT8+ThGpCVOaTjJNNPzRsvrWN9bzt57SWPyfo9Ty3rO3qxqx7GcEYLEXWbzNnhLKm/Hu7iFGG726yez/Lu/wDlv3ZhsXa4TFWmIsoKFC0oxowSW3RLYq/QvAz9EuIN3qy4vbevaJ1ZWNCMGpU3N9G9+nRNrp6/AtwrPspwirw+NStcRxNvC8l+b+xK8ZvYXLjCk8xWvr/b8QAC4EIADWahsc3kLDwMBmo4y5503Xlbqt7vpyvp6GutOVODnGLk12LGX82l9TKEVKSTePF/2Kb+1Pf2ixeGxvPGVxKrVq8m63UNorcpXh3krTE67wOSvZqnQtr2nOpJvpFdU3v5rruy9NQfZ1yWpshPK5nX1xd3U+nPVtk+VekVzdF17GA/sr0V+DVsk/8Aui+Hx+Z8y4lwri99fSvI27WWsLMexJL+LwLXa3llb26oOpnfsfb6F80bihc041betTqwkt1KEk0167o/blGK5pNJLzZR1H7NuRtYeHacR8pQi+8aXPBbfKM18PyPV/Z5zjioy4n5iUU/wSlUcdvlz9S2rinF+XWy1/riQrtLPOlfT+lln6j1xpbStnO8zWZt6Kh2pqalUk/SMV1bKQxWs7vi7xgxMeWpRxOMnK5o23N0cYLfnn6yb5Vt5Jm1l9l+FV81fWNSpJ997VNP17yJbwz4LWfDvMXGYjl531SrRdGKlRUeTeSbe+/w22Im5p8a4tcU6dzR5KKkm0mnon265fyO2lKws6UpUp808PGj+mhZQBi5Shf3NhWoYu9jaXU1tTrSp+IoPfvy+ZeJycIuSWcdi3fhrhfNkBFZaTeCrPtMZG2t9C0MfUntVu7yHIlHme0U238F2W/xXqc7aVvqeO1BjLyrFeHb3VKckn2Skn0/peZ0JqfgPmNY333hqHXle6qqKhH+yxUYR6dIxT2X5Gnf2WbZtN6rqb+e1ul+XXofMOMcK4rxS8lcxt2k8YWY9ixr1i12N5Z2lBUpVM9+j/IvmnOFWEalOSlGSTTT3TR9INpPRGr9LxtbL9OZ3mPt5JOhWtItumn+FSbbROT6JY3Fa4p5r0nTkuxtP5Yb088FZr04U5YpyUl6/iik/tDcPIX1ktb4yg3cWvLC9jDo50uyn812fw+RSGkNW5DRWorXPY+bbpPapDfpUpv8UH6/8F6bHbFxQo3VCpbXFNTpVYuE4yXSUWtmikL/AOzBjq95cVrPUdWhQqTk6dLwOZwj5R5m+uxSfaD2cuZ3iu+HxzzavDSxLv1a3388k9w3idJUOguntp35Xd6Ft6X1TiNX4ejmsNcKpRqrrF9JU5ecZLyZtyn9McDM5pC6leYHX9xbTm/fjG2ThNf50W9mWnhrbKWljGjmMjC+uU3zVo0lTTXl7qLVwq7vqsVTvqDjJL4sxafyeU35Y8SIu6NvBuVCpld2ufsZoB8kpOLUXs2uj9GTJxEL4zXtvZcNs37RUhB1qCo0+dpKU5SWyOPoxW23Jtt295v6ef8ABnUGruDuptbunHP8QatWlRnz06ULSMIRfrsn1fz3I7H7LtKLT/SuW6W3/RVt9FufNOPcO4pxi6VeFu1FJJZcc7t69bxLTw66tLKj0cqibbzs/wAi2OH+RtsporC3lrVjUhKzpR3T7OMUmvnuiQFYaU4U6s0ZB2+E4hVY285c86Fa0jUg38N37v0LNpKcaUI1ZqU1FKUktt35suvB6ty7eNK6pOEopLOYtPGmmG3818yBvIUlUcqU1JNvv0+aP0ACWOQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxco7iOOuZ2lfwa0KUpQnyqWzS37PuR3hjnsrqjSdvn8vcwqVbuU9o06ajCCjJx6bdXvtv19SSZL/AN3XX/0Z/wCyyF8D3vw1xb+Nb/xZERVlL9q048zxySeMvGU4pPG3a/1g7IJe6SljXmWvo/yMeGvMxgdbXGF1NTcsNcVlQsr7kjFQqtJ8k9tu/NtvsTDUdXJUsb4mIuY0a/i04qUoqS5XJJ9/gzU3umsdqelncTkqSlSrV48s+XeVOfhx2lFvs0RrA6nvsTXqcOtYVorI2kqMrG6m9lfUfESi116yXbYg1eXFpRqU7iT5J8/JLLzGSbSi3vrjMX6Hf0NOtOM6SXNHl5ljRppa4+/zJ5laGbq0rKjir+NGXjL2mtOnGTdJRe+y7bt8pFJZ3UcuIX6ExzDjRjj/AGx3Hs9NzcuZLl7bbfQny7FdRX/t1k15YJJ//kJTitJ050pxnJc1SMX1pJYxto+3fO/iclnJTU04rSLey3JpiaWXpUrm2yl4q841X4NeNNR3ptLbdLpunvv5Eb0bl9Q6hu85RvctGEcVkaljBU7eK51H9p779fkTUrrQNpf18jrP2PKezc2drpbUYzcXt36/3mF/GdC4tqMHOSbnlKTTemVl5WceLye27jUpVZyST07NtcdzJxi6eUp068MpcwryVaXgzjT5f1ey23XrvuRPBZ/O5nV2oNPPLqnTxMoeG40IOTUt9lLp1Jfi7ednYULOtVjOtSpxVRrzl5vb4vcq3BvN0eIOv7rA+BO6hGlKFGtTclUkovZJprbqvia+IVJUY2us8NvmSk+b4W8NprLTXnoZ20VUdXbRLDwsbpZ8CbaT1Pe5XI5XA5WjTV5iqqg6tJNQqwfaWz7P1Ri8Q8/qXTNG0yuBtle0adRu8tXFbujFNylF990j04c1cNkcXXzuPnKd5f1nK/c5bzjWj0lDb9lJ77L4m6yDg8rjqU9nz+N0fmuTr/MUnXuOERbqvmk1iSeqTmksvtaTw/HcS6OneNcmiTyn3pa+Wux6YnLWeoMTSyeLuN6VzT3hNLrF+jT80/IxtK18ldYiNzlbqNevOpUXNGmoRUVJpbJfIhV5VrcKNSO+lKT0pl6ijVTfSxuH0Ut32g/67E30tcULrBW1zbVo1aVTnlGcWmpLnl1TRssL2pdXcKNfMakIy5ll4bzDEktmmm2u7XuMbihGlRc6esZNYfb25Xmu01+v9SZDTWDd5ibT2m6c0+T92lHrUl9Ir+JvcdfUclYUL+3f6u4pxqR+G67GilK5y+XyKWPjcWdGk7BS8RLeT2dTo18Uv9U1XC+9ubSlktHZKpF3WGuHGC36ujLrF/16mFDiNT9p8sm+jqZjHKaScO5vR83W2zsj2dtH3XKS5o4b11w/y0+bNnm6+psZh8tmJZSjTduqlW1pKgnFQX4VN92/kY+n7nVGb07i89TzUHUulTq1aPs8ORwcveSe266f3my129tHZh+lnUfn+6/QxuGb30Bgv+5Uzx2zfEvdelny9Hn45fFzYzvj028D3pF7r0vLHPNjZbY2MHiZqHM6as8beYm9jR9qvqVlUjOnGS2qPZSW66NfkSjIZG2wuKrZPI1mqNrSdSrPbq0l6LzZBuNqcsLhIrfrnLPp67VEz1430b2rw8uZWbko0q1GpX5er8JS6/x2Pa95VtKt7Vi2+SMWk22k8Ps9NcCnQhWhQg9OZtN9u6JPYV8tm8bb5Kncfd6uaaq06XhKclGWzXM29t9vT1MXD6nuqufudL5y1p299Rh41CpTf6u5pfvRT6przXXszdYy5o3mNtbu2qKdKtRhOEl2aaRBtSUru54vaYjZdrexuKty15U29lv83vsbLmVS0p0bmlUcm5QTy8qSlhPC2T1yuXHyMKUY1pTpyikkm14Y137e7Uz9f6nzmlLrGXuNt3e2lWc1d2sYJy8OK3c4y7ppeXUkdvkqOawiyWHu1y3FFzo1UlLZ7dOj6dH5GHmqdOpn8JGpFSUncRafZp0+qIjc1YcJ8q+aM46Wyk5by7xsa77b+kX/AF2681a7r2V3XqVJN0HJRer6jcItST3SbeHjbRm2FGnXowjFYqYz/Vq9PPTTv2J5g53dXEWla/uPGr1aUak58iit5LfbZem+xH9Zaxr6cyWLt6NGUrepWTvanJvGFOT5Y9fJ77v6Ehw1SnPDWVWEk4O2pST8tuREQyOPvNW4HNuliFUWTlJW1V1lFpU+lJ7Nbrqm/qzZxG4rwsKVG2k+klFPOHJ9VJ9mXrLli2+xswtqdN15TqpcqeOxLV/gsteRPE1JKUXun1TITmM/nbPiRitNUL7axyFtUuZrwYNw5Htyp7b7P+9mTwvz1bOaUt4XtVSvse3Z3S36qcOnX6bGqzvJ/hp09vHeX3TcbP09/wD5md7e+92Vvc0ZNKc6eza0ckmnj1TPKFDoq9SlNZ5Yy+i0f4lhGPkZ3dOwuJWEFK5VOXgp9ufbpv8ADcyG0mk2t32BYKkekg4J4zplbojovlaZB9S5PU+nvuKi83GpWyl9TsqzdtT5Ybxbco9N+689yR2dDOW2Vau8h7XYzoe7vSjGUKql132S6NdvqRnihu7zSKW3XPUej/0ZE7IGzoN39anzyxDkx1pPda5y3nPj6EhWmlbwlyrMubOi7yHW+Uz17rXK6bWXjRoWtvTuKTjQg5rnfZ7rql1X0PfTOpsldaiy2lMzRpu4xqjVp3FKLUa1KSWzkvKXXql0NByZqHFHUtzhJ2rrrEW3JTrxclOa3aj0a5V179TccOLvH5izus44cuXrVfCyUZb706sUlypPtHomiPsrirK8jSjOWekqZ5pNxcItrlSbeq07njLOmvShGi5uKxyx2Wqbxq/B6kvqVIUacqtSSjCEXKTb2SS7simidV5HOX+XxuYto29e1uPEtoecraSTg3/XmZ2srirLH08PaLnucnUVCEFNRlyd6jTafaO/5oh+pq9/prXGG1bdY32PH1F923EoV1NPmfuNxW3X8+x18V4lUtrqE4N9HTa59HhqWjy0sLlWJa95ptLaNWlKMl1pJ8u2dO7z1XobXUeos7p3XWGs7rIL7jy85Ut/ChzU6y/DBvbfle/fuSLVd/d4/C1auPrOneVJQpW+0VJupKSSWzT382/gmavidp+pqLSNxCzlGN3ZSjfWs/SdN838Umjz03qC01tHEXtvOFSnbW6uq6T3Ua73govzTTUn1Xp6GNStVtritZc7zVw6bbba5urLGv8AD8WnYexhCrShX5V1MqWi1xqs+exm6qvsrp/Rl1lIZFyvLCh406rpQ2qNd047bJfI8MLV1JmtL2uYp5pwu7m28WMPZ6fJztdF232+p68Soqegs5CT2UrOa39DC0jj8pcaMwHs2WdONOlQnOPhpeJBNNxcurXT0+R7d9J+0egjzyj0WcRm1rzYz8S7PN+DPKSj7r0jwnz7teGcbG7zt3kLDTFzfUa3Jd21s6vNyKW84x3aa7dTH0HlL/OaTxuZyddVbi+oqvLaCio7+SSPbV/LPSmW/aXsdZPbz9179jXcK3vw70++bm3safU7YykuKxp8zcVTzu8N8yWcbZwaWk7Nyws83d4bEqB8jKMlzRaa9UfSaTzqjhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPG9oTurStbQq+FKrCUFPl5uXdbb7eZqNF6WpaMwNHT9ve1LmhbuTpzqQSl70nJ77dH1ZvQaJW1KVZXDXWSaTy9nvpsbFVkoOmno9TW4nEVsbcX1xUvnX9treO4uHKoPlS2j1fTZGNqLSOJ1JcY69vaXLdYy5hc29aK96Li93H5M3YNbsbeVB28o5g9cPL1bzu9d9TJXFRVOlT1/S+wI6tHwWs3rNZCfju1Vp4Phrk8NPfvvvuSIGyvbUrnl6VZ5WmtWtVs9DGnVnSzyvdYfkHvs+V7PyexH9PaUqadq5OtQytSvLKXUryr4tKO0aku+223T4EgBjXs6NxONSonmOcNNrGdHs0ewrTpxcI7PfbsMDFY2vYzuq13fzu61zV5+eUFDkgkkoJLyXXr8TUYLRUcHqXL6ljk6lepmHF1qUqaUYcvbl2ZJgYe4W/U6vwNtavd7vfXOXvnc994qdbX4lh6Lb9dxobTSVDGZy5zWJvatrG9fNc2qipUqk/wB/bun8jLvcRWu8vZZWN/KmrJTSoqmmp86Slu99/JbbfxNmDyPD7aMHTjHEW+bCbSznOVrprrhaZPXc1XLmb1xjs2xj7GNk8ZZZiwr4zI28K9tcQdOpCS3TTMXBYKlp3AWuBx1ZqnZ0vBoznHdpeW68zZg3O2pSq9O11scue3D1x816dhgqs1Do86ZzjxNbp/EVMJjVY1r6V5PxJ1JVpwUZScpOT3S6d2a+Wj6cdYPWNvfzo1526tqtGNNclSC7c3Xdv4/BEhlOEIuU5KKXdt7IQnCpFThJSi+qae6ZolYW0oU6DWkMOKy8rGz3z8zNXFVSlNPWWU/HJg57FvN4i6xPtLt1dU3TlUjBSlFPvsn03PPTWEWnMLa4SF069OzpqlTnKHLJxXrs+rNmHJR6yaXzN3utLp/ecdfGM5e2c4xtuYdLPo+iz1c59SO6z0dS1lb2VtcX07aFldQu48lNScpwfTfd9je1rWjdWs7O8pwrU6sHCpGUfdmmuq2PTxIfvr8z6mpLdPdHkbWhGrOql1p4T1bzjRabfQ9dWbjGDekdvU0mG05W0/QlY4zJz9iUnKjQr0/E8FP9mMt0+X0T32M6zxFraXlfI9al3cqMalaXflXaK9EvRGXUq0qS5qtSMF6yex9jKMlzRkmvVGqjY2tFqNNfDsstpdmibaWmiwtFojKderPLk999N/PvNZfYeve5ixyayEqcLHncaKppqbktm299+3bY981hrDUGLucPk6Cq211TdOcWvXzXxXdGZKcIfikl82fU01un0NqtaH7yOM8/xJtvOmNn4YWhj0s+q8/Dt9/ua2ph6n3BHBW19Ojy2qtfHUU5pKHLzL0fmZOMso43HW2PjPnjbUoUlLbbmUVtv/AyFOMvwyT29GfPFp9vEj+YhQo05qpHfHKtXt3b4/E8dSclyvbOfUjmntGfo9nMnmbfK1akcrVdatbOmlTjP1js+n13P3faPV7q+01fLJThWs7eVtSoqlFw5ZPdtt9d+rJEnv1Q7dWaFwu0jRVFR6qlzLV6POc79+vdnU2u7rObm3q1jZbbGvp4uv8AeqydzkJVlCk6dKj4cYxg21vJPvv02NgfIyjLrGSfyZ9OqhRp0U+j7Xl6t5fm8mmc5TxzdhoNT6VepLjG155Kdt92XcLykoUoy5px3Wzb8tn5G+ipKKUmm9urS23Z9BjTtaVKrOtBdaeMvL1xt+keyqznFQb0WxoLDSsrLU95qd5OdWrfUoUalJ0koKMe23Xf89+58o6Pt7HUtxqXF3ta1qXsVG7oJKVKs0ukmn2l8USAGhcLtVHlUf4ubd55nu085We02O6qt5z2Y2W3cayphZ1s/QzlW9clbUZ0aVDw1yrma3lv35um3yZ46t0zb6tw1TC3VeVGnUnCbnGKck4vdbb9vmbkGyVjQnTqUpRzGeXLV6507+5Y0MVXqRlGaesdjGsLSdpY0rOtXdd0oKnzyjs5JLbqjWaU0jjNIWt1a4yO0Lq6qXMumzXM91Hv2RvAZKzoqUJ8usE1F66J6P7dp5008SjnSW5rtQ4dZ/D3OHncOhTuoeHUnGKk+Xz23MbH4G8xeEo4WxzEqcbekqVOr4EXJJLo+r2N0DCrYUK1Xp5J82MZUpLTfGjR7GvUhDo1tnOyepqq+CVXTs9PxvJxVSg6Eq7ipSe62lLZ9N3u/gY2I0zc4PTlvpzH5mrCna0PApVnRi6iW3R+m/0N8DF8Ot3JSSaajyrDkur3aNHvvNTDWdM52W54WFpGwsqFlCcpqjBQ5pd5bLu/i+57gHZCEacVCKwlojTJuTywADI8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIhrrIVMTksDf3lZQxEbqdO9cl7icoNQcvLZP19TI0lQniKWQlfX1ONte31W4sac5cqhRe2yW/k3u/qYGKu7fV2d1Pp/P0ozVlVVvQoTXag4r9ZHfzb8/ka3E39W3zK4eatdtWhb1o17G6l1jXprrGm9+1RbrdenzKVK55Lz35LqzlJRz2TWIYl3KSjldz1euhNqnmj0D3ik3/T8WV3tZwyyE1JKUWmn2aMPJ4q3yvs8bpt06FZVuTym0mkn8N3v9DM7AuFWjCvDo6qynuuwhozcHzReGVjZ7T43XuPnCLtYYqE1Ra3hzPb3uXtv369yY5e5sdFadymXpU34VCNS78NPf3ml0Xom/Ly3IfY1N+PN/H0w9P+ZL9eYKrqXSGVwlBJ1bm3lGmm9t5rqv4orNjQVO3uq1CC6SM6nLprtovLwJW4lmrRhUfVcYZP1pSlc3uAssjm4wrXt5SjXqtxTUebqox9Ek0RvVt9X0HqLF5y0quOJylzGzv7dveEZy/BUiv2X0e+3c3nD3LrK6VsYVdoXdnSja3VF9JUqsFytNeXY1fEnEz1PcYLTlvCpKX3hTvLiUOipUae+7b8t20l8Ty5p05cIp3Ft/iLkcX2uTaT13beql365FJuN5KnV+HXK7Ma/bsPDjbWq0NEupQbVR3lvBST2aTns9n5fH4E5soqFlQgkklSitvoQrjTZXN5oS4nbUnUdrcULmaS3ahCe8nt57LqTDFXlve4u1vbatCpSq0YzjOL3i1t6khQjGPGK7a1cIfeWfwOepl2VPH80vsjW6Us6dlTykYdXLJXEm/g30X0XQiGkqdvkOJWsrO8pQrUaTpKnCa3jDeEd+Xft9Cc4FTnb3N04OMLm6q1ae/nDfZP67br4MrbB4OjmeImvbfxZ0q8lSjTnCbjyvkWze3fr/AHkPdUlG2sujpqXWeIvRPMZPGz38jroyzUruUsaLL7tYkj4f1clSzupMR49e4xNldKNlUrScnFtbyhGT7pPoZGrdS2eC1Ph7fPVZ2+JuaVXetJ7UfHTXKqj9Nm9t/Pb0PTh/qCre2VTA5ajG2y+Kk6NxR7c6XaovVM3eQeGylzU05k6FG4dSgqzo1UmpwbcW0vht/E67WlGvwmnTo1FlvRSWmebPRtb4Xw48PQ1VpOF3KVSOmNcb4xjmXnufqxtbN3U8pj61OVG5ppSVOW8JST6SW3Ts2bAguB01+iGtI43TaqU8Lc2c61xbOTdO3qJpRcevTfr0+DJ0SvCZ81KUXTUHGTTSeVnduO2jz6PKOS7iozTUuZNLGd8eIABKHKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYN1g8Re3Ub26x1CpcRWyquHvbem/fY/d3iMXfUqdG8x9vWhRalTjOmmoP1XoZYOZ2du3JunHMt9Fr595s6Wpp1nptrsIxUUoxWyXRIAHQkksI1mHHD4uF/LKQsKMbya2lXUdptejffbp2MwAwp0qdLPRxSzq8LGplKUpfE8mKsXj43c7+FpThcVFtOrBcsp/Nrv8AU9qVtQoOUqVNRlPrKXdv5vuz0BjG3owlzxgk984WT1zk1hs+SjGcXCcVKMls01umjAttP4azhKla4+lSpybbpwTUOvf3e38DYAVbajXadWCljvSYjUnBYi2gkkuVLZLpsYdth8XZ3VS+tbCjSuK3+UqwglKfzfmZgMp0adRpzim1tpt5dx4pyimk9zHnjbCpeRyE7Oi7mC5Y1uRc6Xpv3PzdYvH3tendXNpTqVqPSnUa96K9E++xlAwlbUZJqUE03l6LV977z1VJpppvQ86NvQt0/BpRhzd2l1fzfmegBthCNOPLBYXgYtuTywADI8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/9k=";
var COMPANY = "AVERY INTERNATIONAL TRAVEL & TOURS";
var SLOGAN = "Umrah · Hajj · Ziyarah · International & Domestic Tours · Visas · Transport";
var TAGLINE = "Curated journeys. Trusted service. Worldwide reach.";
var COMPANY_ADDR = "IBM Center, Paper Market, Office 204, Karachi, Pakistan";
var COMPANY_PHONE = "0330-2793701  ·  0310-2326386  ·  0322-3241659";
var COMPANY_EMAIL = "averyinternationaltraveltours@gmail.com";
var NAVY = [
	11,
	24,
	56
];
var GOLD = [
	176,
	137,
	52
];
var GOLD_LT = [
	212,
	178,
	102
];
var IVORY = [
	252,
	249,
	241
];
var ROW_ALT = [
	247,
	243,
	232
];
var INK = [
	22,
	28,
	44
];
var MUTED = [
	110,
	110,
	120
];
var WHITE = [
	255,
	255,
	255
];
var SUCCESS = [
	22,
	110,
	60
];
var DANGER = [
	170,
	35,
	35
];
var fontCache = null;
var fontLoadPromise = null;
async function loadPdfFonts(doc) {
	if (typeof window === "undefined") return;
	if (!fontCache) {
		if (!fontLoadPromise) fontLoadPromise = (async () => {
			try {
				const results = await Promise.all([
					{
						file: "LibreBaskerville-Regular.ttf",
						name: "LibreBaskerville",
						style: "normal",
						url: "/fonts/LibreBaskerville-Regular.ttf"
					},
					{
						file: "LibreBaskerville-Bold.ttf",
						name: "LibreBaskerville",
						style: "bold",
						url: "/fonts/LibreBaskerville-Bold.ttf"
					},
					{
						file: "IBMPlexSans-Regular.ttf",
						name: "IBMPlexSans",
						style: "normal",
						url: "/fonts/IBMPlexSans-Regular.ttf"
					},
					{
						file: "IBMPlexSans-Bold.ttf",
						name: "IBMPlexSans",
						style: "bold",
						url: "/fonts/IBMPlexSans-Bold.ttf"
					}
				].map(async (f) => {
					const res = await fetch(f.url);
					if (!res.ok) throw new Error(`HTTP ${res.status}`);
					const buf = await res.arrayBuffer();
					const bytes = new Uint8Array(buf);
					let binary = "";
					const chunkSize = 32768;
					for (let i = 0; i < bytes.length; i += chunkSize) binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunkSize)));
					return {
						file: f.file,
						b64: btoa(binary),
						name: f.name,
						style: f.style
					};
				}));
				fontCache = {};
				for (const r of results) fontCache[r.file] = {
					b64: r.b64,
					name: r.name,
					style: r.style
				};
			} catch (e) {
				console.warn("Could not load custom brand fonts for PDF, using system fallbacks:", e);
			}
		})();
		await fontLoadPromise;
	}
	if (fontCache) for (const [file, info] of Object.entries(fontCache)) try {
		doc.addFileToVFS(file, info.b64);
		doc.addFont(file, info.name, info.style);
	} catch {}
}
if (typeof window !== "undefined") loadPdfFonts(new E()).catch(() => {});
function hasFont(doc, name) {
	try {
		const list = doc.getFontList();
		return Boolean(list && list[name]);
	} catch {
		return false;
	}
}
function setSerif(doc, style = "bold") {
	if (hasFont(doc, "LibreBaskerville")) doc.setFont("LibreBaskerville", style === "italic" ? "normal" : style);
	else doc.setFont("times", style);
}
function setSans(doc, style = "normal") {
	if (hasFont(doc, "IBMPlexSans")) doc.setFont("IBMPlexSans", style === "italic" ? "normal" : style);
	else doc.setFont("helvetica", style);
}
var PAGE_TOP = 24;
var PAGE_BOTTOM = 266;
var framed = /* @__PURE__ */ new WeakMap();
function markFramed(doc) {
	const set = framed.get(doc) || /* @__PURE__ */ new Set();
	set.add(doc.getCurrentPageInfo().pageNumber);
	framed.set(doc, set);
}
/** Ivory background + gold double border + slim navy strip for continuation pages. */
function pageFrame(doc) {
	const n = doc.getCurrentPageInfo().pageNumber;
	if (framed.get(doc)?.has(n)) return;
	doc.setFillColor(...IVORY);
	doc.rect(0, 0, 210, 297, "F");
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.8);
	doc.rect(8, 8, 194, 281);
	doc.setLineWidth(.2);
	doc.rect(10, 10, 190, 277);
	doc.setFillColor(...NAVY);
	doc.rect(10, 10, 190, 8, "F");
	doc.setFillColor(...GOLD);
	doc.rect(10, 18, 190, .5, "F");
	setSerif(doc, "bold");
	doc.setFontSize(8);
	doc.setTextColor(...GOLD_LT);
	doc.text(COMPANY, 14, 15.4);
	setSans(doc, "normal");
	doc.setFontSize(7);
	doc.text("Statement (continued)", 196, 15.4, { align: "right" });
	doc.setTextColor(...INK);
	markFramed(doc);
}
/** Start a new framed page when the next block (height `need`) would cross the footer. */
function ensureSpace(doc, y, need) {
	if (y + need <= PAGE_BOTTOM) return y;
	doc.addPage();
	pageFrame(doc);
	return PAGE_TOP;
}
function header(doc, title) {
	markFramed(doc);
	doc.setFillColor(...IVORY);
	doc.rect(0, 0, 210, 297, "F");
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.8);
	doc.rect(8, 8, 194, 281);
	doc.setLineWidth(.2);
	doc.rect(10, 10, 190, 277);
	doc.setFillColor(...NAVY);
	doc.rect(10, 10, 190, 26, "F");
	doc.setFillColor(...GOLD);
	doc.rect(10, 36, 190, .8, "F");
	try {
		doc.addImage(AVERY_LOGO_JPEG, "JPEG", 13, 12, 22, 22, void 0, "FAST");
	} catch {}
	doc.setTextColor(...GOLD_LT);
	setSerif(doc, "bold");
	doc.setFontSize(14);
	doc.text(COMPANY, 38, 21.5);
	setSerif(doc, "italic");
	doc.setFontSize(7.5);
	doc.setTextColor(...WHITE);
	doc.text(SLOGAN, 38, 27.5);
	doc.setFontSize(6.5);
	doc.setTextColor(...GOLD_LT);
	doc.text(TAGLINE, 38, 32);
	setSerif(doc, "bold");
	doc.setFontSize(10);
	doc.setTextColor(...WHITE);
	doc.text(title.toUpperCase(), 196, 22, { align: "right" });
	setSans(doc, "normal");
	doc.setFontSize(7.5);
	doc.setTextColor(...GOLD_LT);
	const now = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
		day: "2-digit",
		month: "long",
		year: "numeric"
	});
	doc.text(`Issued: ${now}`, 196, 28, { align: "right" });
	doc.setTextColor(...INK);
}
function footer(doc) {
	const pages = doc.getNumberOfPages();
	for (let i = 1; i <= pages; i++) {
		doc.setPage(i);
		doc.setDrawColor(...GOLD);
		doc.setLineWidth(.4);
		doc.line(14, 273, 196, 273);
		doc.setLineWidth(.15);
		doc.line(14, 274.4, 196, 274.4);
		setSerif(doc, "bold");
		doc.setFontSize(8);
		doc.setTextColor(...NAVY);
		doc.text(COMPANY, 14, 279);
		setSans(doc, "normal");
		doc.setFontSize(7);
		doc.setTextColor(...MUTED);
		doc.text(COMPANY_ADDR, 14, 283);
		doc.text(`${COMPANY_PHONE}   ·   ${COMPANY_EMAIL}`, 14, 287);
		setSerif(doc, "italic");
		doc.setTextColor(...GOLD);
		doc.setFontSize(7.5);
		doc.text("Your journey begins with trust.", 196, 283, { align: "right" });
		setSans(doc, "normal");
		doc.setTextColor(...MUTED);
		doc.setFontSize(7);
		doc.text(`Page ${i} of ${pages}`, 196, 287, { align: "right" });
	}
}
function sectionTitle(doc, text, y) {
	if (y > 236) {
		doc.addPage();
		pageFrame(doc);
		y = 28;
	}
	setSerif(doc, "bold");
	doc.setFontSize(11);
	doc.setTextColor(...NAVY);
	doc.text(text.toUpperCase(), 14, y);
	const w = doc.getTextWidth(text.toUpperCase());
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.6);
	doc.line(14, y + 1.5, 14 + Math.max(w, 30), y + 1.5);
	doc.setLineWidth(.15);
	doc.line(14, y + 2.4, 196, y + 2.4);
	doc.setTextColor(...INK);
	return y;
}
function brandTable(doc, opts) {
	const o = opts || {};
	if (typeof o.startY === "number" && o.startY > 246) o.startY = ensureSpace(doc, o.startY, 40);
	const sansFont = hasFont(doc, "IBMPlexSans") ? "IBMPlexSans" : "helvetica";
	autoTable(doc, {
		showHead: "everyPage",
		showFoot: "lastPage",
		rowPageBreak: "avoid",
		willDrawPage: () => pageFrame(doc),
		theme: "grid",
		headStyles: {
			fillColor: NAVY,
			textColor: WHITE,
			fontSize: 8.5,
			fontStyle: "bold",
			font: sansFont,
			halign: "left",
			cellPadding: 2.5,
			overflow: "linebreak",
			valign: "middle"
		},
		bodyStyles: {
			fontSize: 8.5,
			textColor: INK,
			cellPadding: 2.5,
			font: sansFont,
			overflow: "linebreak",
			valign: "top"
		},
		alternateRowStyles: { fillColor: ROW_ALT },
		styles: {
			lineColor: GOLD_LT,
			lineWidth: .15,
			overflow: "linebreak",
			cellWidth: "auto",
			font: sansFont
		},
		tableWidth: "auto",
		...o,
		margin: {
			left: 14,
			right: 14,
			top: PAGE_TOP,
			bottom: 31
		}
	});
}
function partyBlock(doc, x, y, w, label, lines) {
	doc.setFillColor(...IVORY);
	doc.rect(x, y, w, 6 + lines.length * 5 + 4, "F");
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.3);
	doc.rect(x, y, w, 6 + lines.length * 5 + 4);
	doc.setFillColor(...GOLD);
	doc.rect(x, y, 1.2, 6 + lines.length * 5 + 4, "F");
	setSerif(doc, "bold");
	doc.setFontSize(8);
	doc.setTextColor(...GOLD);
	doc.text(label.toUpperCase(), x + 4, y + 4.5);
	setSans(doc, "normal");
	doc.setFontSize(8);
	doc.setTextColor(...INK);
	lines.forEach(([k, v], i) => {
		setSans(doc, "bold");
		doc.text(`${k}:`, x + 4, y + 10 + i * 5);
		setSans(doc, "normal");
		doc.text(String(v || "—"), x + 28, y + 10 + i * 5);
	});
	return y + 6 + lines.length * 5 + 6;
}
function fromAndTo(doc, y, recipientLabel, recipientLines) {
	const yA = partyBlock(doc, 14, y, 88, "From", [
		["Company", "Avery Group of Travel"],
		["Address", "IBM Center, Office 204, Karachi"],
		["Phone", "0330-2793701, 0310-2326386"],
		["Email", "averyinternationaltraveltours@gmail.com"]
	]);
	const yB = partyBlock(doc, 108, y, 88, recipientLabel, recipientLines);
	return Math.max(yA, yB);
}
function totalsBand(doc, y, label, value, tone = "gold") {
	y = ensureSpace(doc, y, 13);
	if (tone === "gold") doc.setFillColor(...GOLD);
	else doc.setFillColor(...NAVY);
	doc.rect(14, y, 182, 11, "F");
	doc.setTextColor(...WHITE);
	setSerif(doc, "bold");
	doc.setFontSize(11);
	doc.text(label.toUpperCase(), 18, y + 7.4);
	doc.text(value, 192, y + 7.4, { align: "right" });
	doc.setTextColor(...INK);
	return y + 14;
}
function summaryCards(doc, y, cards) {
	y = ensureSpace(doc, y, 22);
	const n = cards.length;
	const totalW = 182;
	const gap = 2;
	const cardW = (totalW - gap * (n - 1)) / n;
	cards.forEach(([label, value, tone], i) => {
		const x = 14 + i * (cardW + gap);
		doc.setFillColor(...NAVY);
		doc.rect(x, y, cardW, 5, "F");
		doc.setFillColor(...WHITE);
		doc.rect(x, y + 5, cardW, 14, "F");
		doc.setDrawColor(...GOLD_LT);
		doc.setLineWidth(.2);
		doc.rect(x, y, cardW, 19);
		setSans(doc, "bold");
		doc.setFontSize(7);
		doc.setTextColor(...WHITE);
		doc.text(label.toUpperCase(), x + 3, y + 3.5);
		setSerif(doc, "bold");
		doc.setFontSize(11);
		if (tone === "success") doc.setTextColor(...SUCCESS);
		else if (tone === "danger") doc.setTextColor(...DANGER);
		else if (tone === "gold") doc.setTextColor(...GOLD);
		else doc.setTextColor(...NAVY);
		doc.text(value, x + 3, y + 13.5);
	});
	doc.setTextColor(...INK);
	return y + 23;
}
function save(doc, name) {
	doc.save(name.replace(/\s+/g, "_"));
}
function fmtDate(s) {
	if (!s) return "—";
	const d = new Date(s);
	if (isNaN(d.getTime())) return s;
	return d.toLocaleDateString("en-GB", {
		day: "2-digit",
		month: "short",
		year: "numeric"
	});
}
function labelType(t) {
	switch (t) {
		case "client_receive": return "Receive";
		case "supplier_payment": return "Supplier Pmt";
		case "agent_commission": return "Commission";
		case "expense": return "Expense";
		case "purchase": return "Purchase";
		case "client_charge": return "Extra Charge";
		case "client_refund": return "Client Refund";
		case "supplier_refund": return "Supplier Refund";
		default: return t;
	}
}
function inRange(date, from, to) {
	if (!from && !to) return true;
	const d = new Date(date).getTime();
	if (from && d < new Date(from).getTime()) return false;
	if (to && d > (/* @__PURE__ */ new Date(to + "T23:59:59")).getTime()) return false;
	return true;
}
function renderServiceSections(doc, y, bookings) {
	const allHotels = [];
	const allFlights = [];
	const allTransports = [];
	const allVisas = [];
	const allOthers = [];
	bookings.forEach((b) => {
		(b.hotels || []).forEach((h) => allHotels.push({
			...h,
			headId: b.headId
		}));
		(b.flights || []).forEach((f) => allFlights.push({
			...f,
			headId: b.headId
		}));
		(b.transports || []).forEach((t) => allTransports.push({
			...t,
			headId: b.headId
		}));
		(b.visas || []).forEach((v) => allVisas.push({
			...v,
			headId: b.headId
		}));
		(b.others || []).forEach((o) => allOthers.push({
			...o,
			headId: b.headId
		}));
	});
	if (allHotels.length) {
		y = sectionTitle(doc, `Hotels (${allHotels.length})`, y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Booking",
				"City",
				"Hotel",
				"Room",
				"Check-In",
				"Check-Out",
				"Nights"
			]],
			body: allHotels.map((h) => [
				h.headId,
				h.city,
				h.hotelName,
				h.roomType,
				fmtDate(h.checkIn),
				fmtDate(h.checkOut),
				String(h.nights)
			])
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	if (allFlights.length) {
		y = sectionTitle(doc, `Flights (${allFlights.length})`, y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Booking",
				"Date",
				"Flight",
				"From",
				"To",
				"Dep",
				"Arr"
			]],
			body: allFlights.map((f) => [
				f.headId,
				fmtDate(f.date),
				f.flightNo,
				f.from,
				f.to,
				f.departure,
				f.arrival
			])
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	if (allVisas.length) {
		const total = allVisas.reduce((s, v) => s + (v.amount || 0), 0);
		y = sectionTitle(doc, `Visas (${allVisas.length})`, y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Booking",
				"Type",
				"Country",
				"Reference",
				"Issue Date",
				"Amount"
			]],
			body: allVisas.map((v) => [
				v.headId,
				v.visaType,
				v.country,
				v.reference,
				fmtDate(v.issueDate),
				{
					content: formatCurrency(v.amount || 0),
					styles: { halign: "right" }
				}
			]),
			foot: [[{
				content: "Total Visa Amount",
				colSpan: 5,
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}, {
				content: formatCurrency(total),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}]]
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	if (allTransports.length) {
		const total = allTransports.reduce((s, t) => s + (t.amount || 0), 0);
		y = sectionTitle(doc, `Transport (${allTransports.length})`, y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Booking",
				"Service",
				"Route",
				"Vehicle",
				"Date",
				"Amount"
			]],
			body: allTransports.map((t) => [
				t.headId,
				t.service,
				t.route,
				t.vehicle,
				fmtDate(t.date),
				{
					content: formatCurrency(t.amount || 0),
					styles: { halign: "right" }
				}
			]),
			foot: total ? [[{
				content: "Total Transport",
				colSpan: 5,
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}, {
				content: formatCurrency(total),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}]] : void 0
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	if (allOthers.length) {
		const total = allOthers.reduce((s, o) => s + (o.amount || 0), 0);
		y = sectionTitle(doc, `Other Services (${allOthers.length})`, y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Booking",
				"Category",
				"Description",
				"Date",
				"Amount"
			]],
			body: allOthers.map((o) => [
				o.headId,
				o.category,
				o.description,
				fmtDate(o.date),
				{
					content: formatCurrency(o.amount || 0),
					styles: { halign: "right" }
				}
			]),
			foot: total ? [[{
				content: "Total Other",
				colSpan: 4,
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}, {
				content: formatCurrency(total),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}]] : void 0
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	return y;
}
async function generateSupplierLedger(supplier, entries, opts = {}) {
	const doc = new E();
	await loadPdfFonts(doc);
	supplierHeader(doc);
	const filtered = entries.filter((e) => inRange(e.date, opts.fromDate, opts.toDate)).filter((e) => !opts.groupId || e.groupId === opts.groupId);
	const periodLabel = opts.fromDate || opts.toDate ? `${fmtDate(opts.fromDate)} — ${fmtDate(opts.toDate)}` : "All-time";
	const includeOpening = opts.includeOpening !== false && !opts.groupId;
	const openingPayable = includeOpening ? supplier.openingPayable || 0 : 0;
	const openingPaid = includeOpening ? supplier.openingPaid || 0 : 0;
	const openingBF = openingPayable - openingPaid;
	const purchases = filtered.filter((e) => e.type === "purchase");
	const payments = filtered.filter((e) => e.type === "supplier_payment");
	const totalPurchases = purchases.reduce((s, e) => s + e.amount, 0);
	const totalPaid = payments.reduce((s, e) => s + e.amount, 0);
	const grandPayable = openingPayable + totalPurchases;
	const grandPaid = openingPaid + totalPaid;
	const remaining = grandPayable - grandPaid;
	let y = 66;
	y = supplierMetaBar(doc, y, {
		stmtNo: `AV-SS-${supplier.id.replace(/[^0-9A-Z]/gi, "")}-${(/* @__PURE__ */ new Date()).getFullYear()}`,
		period: periodLabel,
		groupLabel: opts.groupId ? opts.groupLabel || opts.groupId : void 0
	});
	y = supplierIdentityCard(doc, y, supplier);
	const pctPaid = grandPayable > 0 ? Math.max(0, Math.min(100, grandPaid / grandPayable * 100)) : 0;
	y = executiveSnapshot(doc, y, {
		payable: grandPayable,
		paid: grandPaid,
		remaining,
		bf: includeOpening ? openingBF : void 0,
		purchases: purchases.length,
		payments: payments.length,
		pctPaid
	});
	const groups = /* @__PURE__ */ new Map();
	for (const p of purchases) {
		const key = p.serviceCategory || "Other";
		if (!groups.has(key)) groups.set(key, []);
		groups.get(key).push(p);
	}
	const order = [
		"Flight",
		"Hotel",
		"Visa",
		"Transport",
		"Ziyarah",
		"Insurance",
		"Other"
	];
	const sortedKeys = [...order.filter((k) => groups.has(k)), ...Array.from(groups.keys()).filter((k) => !order.includes(k))];
	for (const key of sortedKeys) {
		const rows = groups.get(key);
		const catTotal = rows.reduce((s, e) => s + e.amount, 0);
		y = categoryHeading(doc, y, key, rows.length, catTotal, "navy");
		const { head, body } = buildPurchaseTable(key, rows);
		const colSpanForTotal = head[0].length - 1;
		brandTable(doc, {
			startY: y + 1,
			head,
			body,
			foot: [[{
				content: `Total ${key}`,
				colSpan: colSpanForTotal,
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}, {
				content: formatCurrency(catTotal),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}]]
		});
		y = doc.lastAutoTable.finalY + 7;
	}
	if (payments.length || includeOpening && openingPaid > 0) {
		y = categoryHeading(doc, y, "Payments Received", payments.length, grandPaid, "success");
		const body = [];
		if (includeOpening && openingPaid > 0) body.push([{
			content: "Opening Paid (B/F)",
			colSpan: 3,
			styles: {
				fontStyle: "bold",
				fillColor: ROW_ALT
			}
		}, {
			content: formatCurrency(openingPaid),
			styles: {
				halign: "right",
				fontStyle: "bold",
				fillColor: ROW_ALT,
				textColor: NAVY
			}
		}]);
		for (const p of payments) body.push([
			fmtDate(p.date),
			p.id,
			p.note || "—",
			{
				content: formatCurrency(p.amount),
				styles: {
					halign: "right",
					textColor: SUCCESS
				}
			}
		]);
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Date",
				"Receipt",
				"Note",
				"Amount"
			]],
			body,
			foot: [[{
				content: "Total Paid",
				colSpan: 3,
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}, {
				content: formatCurrency(grandPaid),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: SUCCESS
				}
			}]]
		});
		y = doc.lastAutoTable.finalY + 7;
	}
	y = reconciliationBlock(doc, y, {
		openingPayable: includeOpening ? openingPayable : void 0,
		openingPaid: includeOpening ? openingPaid : void 0,
		totalPurchases,
		totalPaid,
		grandPayable,
		grandPaid
	});
	closingHero(doc, y, remaining);
	footer(doc);
	save(doc, `Avery_Supplier_Statement_${supplier.id}.pdf`);
}
function executiveHeader(doc, supertitle, subtitle) {
	markFramed(doc);
	doc.setFillColor(...IVORY);
	doc.rect(0, 0, 210, 297, "F");
	doc.setFillColor(...NAVY);
	doc.rect(0, 0, 210, 54, "F");
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.4);
	doc.line(0, 3, 210, 3);
	doc.setLineWidth(.25);
	doc.line(0, 51, 210, 51);
	doc.setLineWidth(.6);
	doc.line(0, 53, 210, 53);
	try {
		doc.setDrawColor(...GOLD);
		doc.setLineWidth(.4);
		doc.circle(24, 27, 13);
		doc.addImage(AVERY_LOGO_JPEG, "JPEG", 13, 16, 22, 22, void 0, "FAST");
	} catch {}
	setSerif(doc, "bold");
	doc.setFontSize(18);
	doc.setTextColor(...GOLD_LT);
	doc.text("AVERY", 42, 23);
	setSerif(doc, "bold");
	doc.setFontSize(9.5);
	doc.setTextColor(...WHITE);
	doc.text("INTERNATIONAL TRAVEL & TOURS", 42, 29);
	setSans(doc, "normal");
	doc.setFontSize(7);
	doc.setTextColor(...GOLD_LT);
	doc.text("Umrah · Hajj · Ziyarah · International & Domestic Tours · Visas · Transport", 42, 35.5);
	setSerif(doc, "italic");
	doc.setFontSize(7);
	doc.setTextColor(...WHITE);
	doc.text("Curated journeys. Trusted service. Worldwide reach.", 42, 41);
	setSerif(doc, "bold");
	doc.setFontSize(22);
	doc.setTextColor(...WHITE);
	doc.text(supertitle.toUpperCase(), 196, 24, { align: "right" });
	doc.setTextColor(...GOLD_LT);
	doc.text(subtitle.toUpperCase(), 196, 33, { align: "right" });
	setSans(doc, "normal");
	doc.setFontSize(7.5);
	doc.setTextColor(...WHITE);
	const now = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
		day: "2-digit",
		month: "long",
		year: "numeric"
	});
	doc.text(`Issued ${now}`, 196, 40, { align: "right" });
	doc.setTextColor(...INK);
}
function supplierHeader(doc) {
	executiveHeader(doc, "SUPPLIER", "STATEMENT");
}
function supplierMetaBar(doc, y, meta) {
	const h = meta.groupLabel ? 13 : 9;
	doc.setFillColor(...IVORY);
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.25);
	doc.rect(14, y, 182, h, "FD");
	doc.setFillColor(...GOLD);
	doc.rect(14, y, 1.4, h, "F");
	setSans(doc, "bold");
	doc.setFontSize(7);
	doc.setTextColor(...GOLD);
	doc.text("STATEMENT NO.", 19, y + 4);
	doc.text("PERIOD", 92, y + 4);
	setSerif(doc, "bold");
	doc.setFontSize(9);
	doc.setTextColor(...NAVY);
	doc.text(meta.stmtNo, 19, y + 8);
	doc.text(meta.period, 92, y + 8);
	setSans(doc, "bold");
	doc.setFontSize(7);
	doc.setTextColor(...GOLD);
	doc.text("CURRENCY", 168, y + 4);
	setSerif(doc, "bold");
	doc.setFontSize(9);
	doc.setTextColor(...NAVY);
	doc.text("PKR", 168, y + 8);
	if (meta.groupLabel) {
		setSans(doc, "italic");
		doc.setFontSize(7.5);
		doc.setTextColor(...GOLD);
		doc.text(`Filtered by Group  ·  ${meta.groupLabel}`, 19, y + 11.5);
	}
	doc.setTextColor(...INK);
	return y + h + 3;
}
function supplierIdentityCard(doc, y, s) {
	const h = 26;
	doc.setFillColor(...WHITE);
	doc.setDrawColor(...GOLD_LT);
	doc.setLineWidth(.2);
	doc.rect(14, y, 182, h, "FD");
	doc.setFillColor(...NAVY);
	doc.rect(14, y, 62, h, "F");
	doc.setFillColor(...GOLD);
	doc.rect(14, y, 1.2, h, "F");
	setSans(doc, "bold");
	doc.setFontSize(6.8);
	doc.setTextColor(...GOLD_LT);
	doc.text("STATEMENT ISSUED TO", 20, y + 5.5);
	setSerif(doc, "bold");
	doc.setFontSize(13);
	doc.setTextColor(...WHITE);
	doc.text(s.companyName || "—", 20, y + 12.5);
	setSans(doc, "normal");
	doc.setFontSize(7.5);
	doc.setTextColor(...GOLD_LT);
	doc.text(s.id, 20, y + 17.5);
	doc.setTextColor(...WHITE);
	doc.text(s.serviceType || "—", 20, y + 22);
	const col1 = 82;
	const col2 = 140;
	const labelStyle = () => {
		setSans(doc, "bold");
		doc.setFontSize(6.8);
		doc.setTextColor(...GOLD);
	};
	const valStyle = () => {
		setSans(doc, "normal");
		doc.setFontSize(8.5);
		doc.setTextColor(...INK);
	};
	labelStyle();
	doc.text("CONTACT PERSON", col1, y + 5.5);
	valStyle();
	doc.text(s.contactPerson || "—", col1, y + 10);
	labelStyle();
	doc.text("PHONE", col1, y + 15);
	valStyle();
	doc.text(s.phone || "—", col1, y + 19.5);
	labelStyle();
	doc.text("EMAIL", col2, y + 5.5);
	valStyle();
	doc.text(s.email || "—", col2, y + 10);
	labelStyle();
	doc.text("ACCOUNT STATUS", col2, y + 15);
	valStyle();
	doc.text("Active", col2, y + 19.5);
	doc.setTextColor(...INK);
	return y + h + 5;
}
function clientIdentityCard(doc, y, c) {
	const h = 26;
	doc.setFillColor(...WHITE);
	doc.setDrawColor(...GOLD_LT);
	doc.setLineWidth(.2);
	doc.rect(14, y, 182, h, "FD");
	doc.setFillColor(...NAVY);
	doc.rect(14, y, 62, h, "F");
	doc.setFillColor(...GOLD);
	doc.rect(14, y, 1.2, h, "F");
	setSans(doc, "bold");
	doc.setFontSize(6.8);
	doc.setTextColor(...GOLD_LT);
	doc.text("STATEMENT ISSUED TO", 20, y + 5.5);
	setSerif(doc, "bold");
	doc.setFontSize(13);
	doc.setTextColor(...WHITE);
	doc.text(getClientName(c) || "—", 20, y + 12.5);
	setSans(doc, "normal");
	doc.setFontSize(7.5);
	doc.setTextColor(...GOLD_LT);
	doc.text(`Client ID: ${c.id}`, 20, y + 17.5);
	doc.setTextColor(...WHITE);
	doc.text(`Head ID: ${c.headId}`, 20, y + 22);
	const col1 = 82;
	const col2 = 140;
	const labelStyle = () => {
		setSans(doc, "bold");
		doc.setFontSize(6.8);
		doc.setTextColor(...GOLD);
	};
	const valStyle = () => {
		setSans(doc, "normal");
		doc.setFontSize(8.5);
		doc.setTextColor(...INK);
	};
	labelStyle();
	doc.text("PACKAGE TYPE", col1, y + 5.5);
	valStyle();
	doc.text(c.packageType || "Custom Package", col1, y + 10);
	labelStyle();
	doc.text("PHONE NUMBER", col1, y + 15);
	valStyle();
	doc.text(c.phone || "—", col1, y + 19.5);
	labelStyle();
	doc.text("PASSPORT NUMBER", col2, y + 5.5);
	valStyle();
	doc.text(c.passport || "—", col2, y + 10);
	labelStyle();
	doc.text("PAYMENT STATUS", col2, y + 15);
	valStyle();
	doc.text(c.paymentStatus || "Active", col2, y + 19.5);
	doc.setTextColor(...INK);
	return y + h + 5;
}
function executiveSnapshot(doc, y, data) {
	setSerif(doc, "italic");
	doc.setFontSize(9);
	doc.setTextColor(...GOLD);
	doc.text("Executive Snapshot", 14, y);
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.3);
	doc.line(14, y + 1.5, 60, y + 1.5);
	doc.setLineWidth(.1);
	doc.setDrawColor(...GOLD_LT);
	doc.line(60, y + 1.5, 196, y + 1.5);
	y += 5;
	const tiles = [
		{
			label: "Total Payable",
			value: formatCurrency(data.payable),
			tone: "navy"
		},
		{
			label: "Total Paid",
			value: formatCurrency(data.paid),
			tone: "success"
		},
		{
			label: "Outstanding",
			value: formatCurrency(data.remaining),
			tone: data.remaining > 0 ? "danger" : "success"
		},
		{
			label: data.bf !== void 0 ? "Brought Forward" : "Transactions",
			value: data.bf !== void 0 ? formatCurrency(data.bf) : `${data.purchases} PUR · ${data.payments} PMT`,
			tone: "gold"
		}
	];
	const w = 173 / 4;
	const h = 22;
	tiles.forEach((t, i) => {
		const x = 14 + i * 46.25;
		doc.setFillColor(...WHITE);
		doc.setDrawColor(...GOLD_LT);
		doc.setLineWidth(.2);
		doc.rect(x, y, w, h, "FD");
		doc.setDrawColor(...GOLD);
		doc.setLineWidth(.6);
		doc.line(x, y, x + w, y);
		setSans(doc, "bold");
		doc.setFontSize(6.8);
		doc.setTextColor(...MUTED);
		doc.text(t.label.toUpperCase(), x + 3.5, y + 5.5);
		setSerif(doc, "bold");
		doc.setFontSize(t.value.length > 14 ? 10 : 12);
		if (t.tone === "navy") doc.setTextColor(...NAVY);
		else if (t.tone === "success") doc.setTextColor(...SUCCESS);
		else if (t.tone === "danger") doc.setTextColor(...DANGER);
		else doc.setTextColor(...GOLD);
		doc.text(t.value, x + 3.5, y + 15);
	});
	y += 26;
	setSans(doc, "bold");
	doc.setFontSize(7);
	doc.setTextColor(...NAVY);
	doc.text("SETTLEMENT PROGRESS", 14, y);
	setSans(doc, "normal");
	doc.setTextColor(...MUTED);
	doc.text(`${data.pctPaid.toFixed(1)}% of payable settled`, 196, y, { align: "right" });
	const barY = y + 2;
	const barW = 182;
	doc.setFillColor(230, 224, 208);
	doc.rect(14, barY, barW, 4, "F");
	const fillW = Math.max(.6, data.pctPaid / 100 * barW);
	doc.setFillColor(...GOLD);
	doc.rect(14, barY, fillW, 4, "F");
	doc.setDrawColor(...NAVY);
	doc.setLineWidth(.3);
	doc.line(14 + fillW, barY - .6, 14 + fillW, barY + 4.6);
	return y + 10;
}
function categoryHeading(doc, y, label, count, total, tone = "navy") {
	const h = 8.5;
	y = ensureSpace(doc, y, 36.5);
	doc.setFillColor(...GOLD);
	doc.rect(14, y, 1.6, h, "F");
	doc.setFillColor(...IVORY);
	doc.rect(15.6, y, 180.4, h, "F");
	doc.setDrawColor(...GOLD_LT);
	doc.setLineWidth(.15);
	doc.line(14, y + h, 196, y + h);
	setSerif(doc, "bold");
	doc.setFontSize(11);
	doc.setTextColor(...NAVY);
	doc.text(label, 19, y + 6);
	const labelW = doc.getTextWidth(label);
	const pillTxt = `${count} ${count === 1 ? "item" : "items"}`;
	setSans(doc, "bold");
	doc.setFontSize(7);
	const pillW = doc.getTextWidth(pillTxt) + 5;
	const pillX = 19 + labelW + 4;
	doc.setFillColor(...NAVY);
	doc.roundedRect(pillX, y + 2.2, pillW, 4.4, 1.2, 1.2, "F");
	doc.setTextColor(...GOLD_LT);
	doc.text(pillTxt, pillX + pillW / 2, y + 5.3, { align: "center" });
	setSans(doc, "bold");
	doc.setFontSize(7);
	doc.setTextColor(...MUTED);
	doc.text("SECTION TOTAL", 165, y + 3.6, { align: "right" });
	setSerif(doc, "bold");
	doc.setFontSize(10);
	if (tone === "success") doc.setTextColor(...SUCCESS);
	else doc.setTextColor(...NAVY);
	doc.text(formatCurrency(total), 194, y + 6.2, { align: "right" });
	doc.setTextColor(...INK);
	return y + h + 2;
}
function reconciliationBlock(doc, y, d) {
	y = ensureSpace(doc, y, 40);
	setSerif(doc, "italic");
	doc.setFontSize(9);
	doc.setTextColor(...GOLD);
	doc.text("Ledger Reconciliation", 14, y);
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.3);
	doc.line(14, y + 1.5, 60, y + 1.5);
	doc.setLineWidth(.1);
	doc.setDrawColor(...GOLD_LT);
	doc.line(60, y + 1.5, 196, y + 1.5);
	y += 5;
	const colW = 89;
	const leftRows = [];
	if (d.openingPayable !== void 0) leftRows.push(["Opening Payable (B/F)", d.openingPayable]);
	leftRows.push(["New Purchases (Period)", d.totalPurchases]);
	leftRows.push([
		"Grand Total Payable",
		d.grandPayable,
		true
	]);
	const rightRows = [];
	if (d.openingPaid !== void 0) rightRows.push(["Opening Paid (B/F)", d.openingPaid]);
	rightRows.push(["Payments (Period)", d.totalPaid]);
	rightRows.push([
		"Grand Total Paid",
		d.grandPaid,
		true
	]);
	const h = 6 + Math.max(leftRows.length, rightRows.length) * 6.5 + 3;
	drawReconCard(doc, 14, y, colW, h, "Payable Side", NAVY, leftRows);
	drawReconCard(doc, 107, y, colW, h, "Settlement Side", SUCCESS, rightRows);
	return y + h + 6;
}
function drawReconCard(doc, x, y, w, h, title, accent, rows) {
	doc.setFillColor(...WHITE);
	doc.setDrawColor(...GOLD_LT);
	doc.setLineWidth(.2);
	doc.rect(x, y, w, h, "FD");
	doc.setFillColor(...accent);
	doc.rect(x, y, w, 6, "F");
	setSans(doc, "bold");
	doc.setFontSize(7.2);
	doc.setTextColor(...WHITE);
	doc.text(title.toUpperCase(), x + 3, y + 4.2);
	doc.setTextColor(...INK);
	rows.forEach(([label, val, bold], i) => {
		const ry = y + 6 + 5 + i * 6.5;
		if (bold) {
			doc.setFillColor(...IVORY);
			doc.rect(x + .4, ry - 4, w - .8, 6, "F");
		}
		if (bold) setSerif(doc, "bold");
		else setSans(doc, "normal");
		doc.setFontSize(bold ? 9 : 8);
		doc.setTextColor(...bold ? NAVY : INK);
		doc.text(label, x + 3, ry);
		setSerif(doc, "bold");
		doc.setFontSize(bold ? 9.5 : 8.5);
		doc.setTextColor(...bold ? accent : INK);
		doc.text(formatCurrency(val), x + w - 3, ry, { align: "right" });
	});
	doc.setTextColor(...INK);
}
function closingHero(doc, y, remaining, opts) {
	y = ensureSpace(doc, y, 32);
	const h = 30;
	doc.setFillColor(...NAVY);
	doc.rect(14, y, 182, h, "F");
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.5);
	doc.rect(14, y, 182, h);
	doc.setLineWidth(.15);
	doc.rect(16, y + 2, 178, 26);
	doc.setFillColor(...GOLD);
	doc.rect(14, y, 2, h, "F");
	setSans(doc, "bold");
	doc.setFontSize(7.5);
	doc.setTextColor(...GOLD_LT);
	doc.text(opts?.title || "CLOSING BALANCE", 22, y + 9);
	setSerif(doc, "italic");
	doc.setFontSize(8);
	doc.setTextColor(...WHITE);
	doc.text(opts?.subtitle || "Net amount payable to supplier as of statement date.", 22, y + 15);
	setSerif(doc, "bold");
	doc.setFontSize(20);
	const tone = remaining > 0 ? GOLD_LT : [
		180,
		220,
		190
	];
	doc.setTextColor(...tone);
	doc.text(formatCurrency(remaining), 192, y + 15, { align: "right" });
	setSans(doc, "normal");
	doc.setFontSize(7);
	doc.setTextColor(...GOLD_LT);
	const statusTxt = remaining > 0 ? opts?.positiveLabel || "Outstanding — Payment Due" : remaining < 0 ? opts?.negativeLabel || "Overpayment / Advance Credit" : "Fully Settled";
	doc.text(statusTxt, 192, y + 22, { align: "right" });
	setSerif(doc, "italic");
	doc.setFontSize(7);
	doc.setTextColor(...GOLD_LT);
	doc.text("Computer-generated statement · Avery Group of Travel · This document does not require a signature.", 105, y + 27, { align: "center" });
	doc.setTextColor(...INK);
}
function buildPurchaseTable(category, rows) {
	const cur = (n) => formatCurrency(n || 0);
	if (category === "Flight") return {
		head: [[
			"Date",
			"Receipt",
			"Ticket #",
			"PNR",
			"Sector / Route",
			"Trip / Airline",
			"Pax / Fare",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const pnr = d.pnr || "—";
			const tkt = d.ticketNumber || "—";
			const sector = d.sector || d.description || e.note || "—";
			const meta = [d.tripType, d.airline || d.flightNumber].filter(Boolean).join(" · ") || "Flight";
			const pax = (d.adults || 0) + (d.children || 0) + (d.infants || 0);
			const paxText = pax > 0 ? `${pax} Pax` : "—";
			return [
				fmtDate(e.date),
				e.id,
				tkt,
				pnr,
				sector,
				meta,
				paxText,
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
	if (category === "Hotel") return {
		head: [[
			"Date",
			"Receipt",
			"Hotel & City",
			"Room Type / Voucher",
			"Rooms",
			"Nights",
			"Per Night",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const hotelCity = [d.hotelName || e.note, d.city ? `(${d.city})` : null].filter(Boolean).join(" ") || "—";
			const roomMeta = [
				d.roomType,
				d.confirmationNo ? `Ref: ${d.confirmationNo}` : null,
				d.mealPlan
			].filter(Boolean).join(" · ") || "Standard";
			return [
				fmtDate(e.date),
				e.id,
				hotelCity,
				roomMeta,
				String(d.rooms || "—"),
				String(d.nights || "—"),
				{
					content: d.perNight ? cur(d.perNight) : "—",
					styles: { halign: "right" }
				},
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
	if (category === "Package") return {
		head: [[
			"Date",
			"Receipt",
			"Package Title",
			"Scope & Destination",
			"Duration",
			"Inclusions",
			"Pax",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const title = d.packageName || d.description || e.note || "Custom Tour Package";
			const dest = [
				d.packageType,
				d.destinationCountry,
				d.destinationCity ? `[${d.destinationCity}]` : null
			].filter(Boolean).join(" · ") || "—";
			const dur = d.packageDurationDays ? `${d.packageDurationDays} Days` : "—";
			const inc = (d.packageInclusions || []).slice(0, 3).join(", ") || "Full Package";
			const pax = (d.adults || 0) + (d.children || 0) + (d.infants || 0);
			return [
				fmtDate(e.date),
				e.id,
				title,
				dest,
				dur,
				inc,
				String(pax || "—"),
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
	if (category === "Visa") return {
		head: [[
			"Date",
			"Receipt",
			"Country & Type",
			"MOFA / Ref #",
			"Applicants",
			"Pax",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const countryType = [d.country, d.visaType].filter(Boolean).join(" · ") || "Visa Service";
			const ref = d.reference || e.note || "—";
			const applicants = d.applicantNames || "—";
			const pax = (d.adults || 0) + (d.children || 0) + (d.infants || 0);
			return [
				fmtDate(e.date),
				e.id,
				countryType,
				ref,
				applicants,
				String(pax || "—"),
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
	if (category === "Transport") return {
		head: [[
			"Date",
			"Receipt",
			"Route",
			"Vehicle",
			"Date / Driver",
			"Voucher #",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const driverInfo = [d.pickupDate, d.driverName].filter(Boolean).join(" · ") || "—";
			return [
				fmtDate(e.date),
				e.id,
				d.route || e.note || "—",
				d.vehicle || "—",
				driverInfo,
				d.voucherNo || "—",
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
	if (category === "Ziyarah") return {
		head: [[
			"Date",
			"Receipt",
			"City & Sites",
			"Vehicle / Guide",
			"Pax",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const sites = [d.city, d.ziyarahSites].filter(Boolean).join(" · ") || e.note || "Ziyarat Tour";
			const vg = [d.vehicle, d.guideName ? `Guide: ${d.guideName}` : null].filter(Boolean).join(" · ") || "—";
			const pax = (d.adults || 0) + (d.children || 0) + (d.infants || 0);
			return [
				fmtDate(e.date),
				e.id,
				sites,
				vg,
				String(pax || "—"),
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
	return {
		head: [[
			"Date",
			"Receipt",
			"Description",
			"Pax / Notes",
			"Amount"
		]],
		body: rows.map((e) => {
			const d = e.purchaseDetails || {};
			const pax = (d.adults || 0) + (d.children || 0) + (d.infants || 0);
			const notes = [
				pax ? `${pax} Pax` : null,
				d.description,
				e.note
			].filter(Boolean).join(" · ") || "—";
			return [
				fmtDate(e.date),
				e.id,
				d.description || e.note || "—",
				notes,
				{
					content: cur(e.amount),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	};
}
/**
* Agent Statement — professional account statement for one agent.
*  • Client Business  : bookings brought by the agent → Sale − Agent Commission = Net Receivable
*  • Other Sale       : purchases made for the agent ("For Agent") + direct other-sale entries, by service
*  • Receipts         : money received against the selected business
*  Opening balance = everything dated before the From date (+ legacy B/F); closing = opening + period − received.
* `entries` should be the FULL ledger; the function picks the agent's rows itself.
*/
async function generateAgentReport(agent, entries, opts = {}) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, "Agent Account Statement");
	const scope = opts.scope || "both";
	const incClient = scope !== "other";
	const incOther = scope !== "client";
	const includeOpening = opts.includeOpening !== false;
	const from = opts.fromDate, to = opts.toDate;
	const before = (d) => !!from && !!d && new Date(d).getTime() < new Date(from).getTime();
	const within = (d) => !!d && inRange(d, from, to);
	const bookings = (opts.bookings || []).filter((b) => b.agentId === agent.id);
	const headIds = new Set(bookings.map((b) => b.headId));
	const clients = opts.clients || [];
	const bDate = (b) => b.createdAt ? String(b.createdAt).slice(0, 10) : b.travelDate;
	const leadName = (h) => {
		const c = clients.find((x) => x.headId === h);
		return c ? getClientName(c) : "—";
	};
	const otherRows = entries.filter((e) => e.type === "purchase" && e.purchasedFor === "agent" && e.agentId === agent.id || e.type === "other_sale" && e.referenceId === agent.id);
	const otherSaleOf = (e) => e.type === "purchase" ? e.saleAmount ?? e.amount : e.amount;
	const clientReceipts = entries.filter((e) => (e.type === "client_receive" || e.type === "client_refund" || e.type === "client_charge") && e.headId && headIds.has(e.headId));
	const agentReceipts = entries.filter((e) => e.type === "agent_receive" && (e.referenceId === agent.id || e.agentId === agent.id));
	const commissionPaid = entries.filter((e) => e.type === "agent_commission" && e.referenceId === agent.id);
	const bookingNet = (b) => (b.totalAmount || 0) - (b.commission || 0);
	const clientMove = (e) => e.type === "client_charge" ? e.amount : -e.amount;
	let opening = 0;
	if (includeOpening) {
		if (incClient) {
			opening += (agent.openingSales || 0) - (agent.openingCommission || 0);
			opening += bookings.filter((b) => before(bDate(b))).reduce((s, b) => s + bookingNet(b), 0);
			opening += clientReceipts.filter((e) => before(e.date)).reduce((s, e) => s + clientMove(e), 0);
		}
		if (incOther) opening += otherRows.filter((e) => before(e.date)).reduce((s, e) => s + otherSaleOf(e), 0);
		opening -= agentReceipts.filter((e) => before(e.date)).reduce((s, e) => s + e.amount, 0);
	}
	const pBookings = incClient ? bookings.filter((b) => !from && !to ? true : within(bDate(b))) : [];
	const pClientTx = incClient ? clientReceipts.filter((e) => within(e.date) || !from && !to) : [];
	const pOther = incOther ? otherRows.filter((e) => within(e.date) || !from && !to) : [];
	const pAgentRec = agentReceipts.filter((e) => within(e.date) || !from && !to);
	const grossSale = pBookings.reduce((s, b) => s + (b.totalAmount || 0), 0);
	const commission = pBookings.reduce((s, b) => s + (b.commission || 0), 0);
	const netClient = grossSale - commission;
	const extraCharges = pClientTx.filter((e) => e.type === "client_charge").reduce((s, e) => s + e.amount, 0);
	const refunds = pClientTx.filter((e) => e.type === "client_refund").reduce((s, e) => s + e.amount, 0);
	const clientReceived = pClientTx.filter((e) => e.type === "client_receive").reduce((s, e) => s + e.amount, 0);
	const otherSale = pOther.reduce((s, e) => s + otherSaleOf(e), 0);
	pOther.filter((e) => e.type === "purchase").reduce((s, e) => s + e.amount, 0);
	const totalReceived = clientReceived + pAgentRec.reduce((s, e) => s + e.amount, 0);
	const periodBusiness = netClient + extraCharges - refunds + otherSale;
	const closing = opening + periodBusiness - totalReceived;
	const periodLabel = from || to ? `${fmtDate(from)} — ${fmtDate(to)}` : "All-time";
	const scopeLabel = scope === "client" ? "Client Business" : scope === "other" ? "Other Sale" : "Client Business + Other Sale";
	let y = 44;
	y = fromAndTo(doc, y, "Agent", [
		["ID", agent.id],
		["Name", agent.name],
		["Phone", agent.phone],
		["Email", agent.email]
	]);
	doc.setFillColor(...NAVY);
	doc.rect(14, y, 182, 7, "F");
	setSerif(doc, "bold");
	doc.setFontSize(8.5);
	doc.setTextColor(...WHITE);
	doc.text(`Period: ${periodLabel}`, 18, y + 4.9);
	doc.text(`Statement: ${scopeLabel}`, 192, y + 4.9, { align: "right" });
	doc.setTextColor(...INK);
	y += 11;
	y = summaryCards(doc, y, [
		[
			"Opening Balance",
			formatCurrency(opening),
			"ink"
		],
		[
			"Period Business",
			formatCurrency(periodBusiness),
			"gold"
		],
		[
			"Received",
			formatCurrency(totalReceived),
			"success"
		],
		[
			"Closing Balance",
			formatCurrency(closing),
			closing > 0 ? "danger" : "success"
		]
	]);
	const money = (n, color = NAVY) => ({
		content: formatCurrency(n),
		styles: {
			halign: "right",
			textColor: color
		}
	});
	const footRow = (label, span, val, color = NAVY) => [[{
		content: label,
		colSpan: span,
		styles: {
			halign: "right",
			fontStyle: "bold",
			fillColor: ROW_ALT,
			textColor: NAVY
		}
	}, {
		content: formatCurrency(val),
		styles: {
			halign: "right",
			fontStyle: "bold",
			fillColor: ROW_ALT,
			textColor: color
		}
	}]];
	if (incClient) {
		y = categoryHeading(doc, y + 2, "Client Business (via agent reference)", pBookings.length, netClient);
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Date",
				"Head ID",
				"Lead Client",
				"Package",
				"Pax",
				"Sale",
				"Commission",
				"Net"
			]],
			body: pBookings.length ? pBookings.map((b) => [
				fmtDate(bDate(b)),
				b.headId,
				leadName(b.headId),
				b.packageType || "—",
				String(clients.filter((c) => c.headId === b.headId).length),
				money(b.totalAmount || 0, INK),
				money(b.commission || 0, DANGER),
				money(bookingNet(b))
			]) : [[{
				content: "No client bookings in this period",
				colSpan: 8,
				styles: {
					halign: "center",
					textColor: MUTED
				}
			}]],
			foot: [[
				{
					content: "Totals",
					colSpan: 5,
					styles: {
						halign: "right",
						fontStyle: "bold",
						fillColor: ROW_ALT,
						textColor: NAVY
					}
				},
				{
					content: formatCurrency(grossSale),
					styles: {
						halign: "right",
						fontStyle: "bold",
						fillColor: ROW_ALT,
						textColor: INK
					}
				},
				{
					content: formatCurrency(commission),
					styles: {
						halign: "right",
						fontStyle: "bold",
						fillColor: ROW_ALT,
						textColor: DANGER
					}
				},
				{
					content: formatCurrency(netClient),
					styles: {
						halign: "right",
						fontStyle: "bold",
						fillColor: ROW_ALT,
						textColor: NAVY
					}
				}
			]]
		});
		y = doc.lastAutoTable.finalY + 7;
	}
	if (incOther) {
		const groups = /* @__PURE__ */ new Map();
		pOther.forEach((e) => {
			const k = e.serviceCategory || (e.type === "other_sale" ? "Direct Sale" : "Other");
			if (!groups.has(k)) groups.set(k, []);
			groups.get(k).push(e);
		});
		const order = [
			"Flight",
			"Hotel",
			"Package",
			"Visa",
			"Transport",
			"Ziyarah",
			"Insurance",
			"Other",
			"Direct Sale"
		];
		const keys = [...order.filter((k) => groups.has(k)), ...[...groups.keys()].filter((k) => !order.includes(k))];
		if (!keys.length) {
			y = categoryHeading(doc, y, "Other Sale", 0, 0);
			brandTable(doc, {
				startY: y + 1,
				head: [[
					"Date",
					"Client",
					"Description",
					"Amount"
				]],
				body: [[{
					content: "No other sale in this period",
					colSpan: 4,
					styles: {
						halign: "center",
						textColor: MUTED
					}
				}]]
			});
			y = doc.lastAutoTable.finalY + 7;
		}
		for (const k of keys) {
			const rows = groups.get(k);
			const tot = rows.reduce((s, e) => s + otherSaleOf(e), 0);
			y = categoryHeading(doc, y, `Other Sale — ${k}`, rows.length, tot);
			brandTable(doc, {
				startY: y + 1,
				head: [[
					"Date",
					"Ref",
					"Client",
					"Specification / Record Details",
					"Amount"
				]],
				body: rows.map((e) => {
					const d = e.purchaseDetails || {};
					let desc = "—";
					if (k === "Flight") desc = [
						d.pnr && `PNR: ${d.pnr}`,
						d.ticketNumber && `Tkt: ${d.ticketNumber}`,
						d.sector,
						d.airline
					].filter(Boolean).join(" · ") || e.note || "Flight Ticket";
					else if (k === "Hotel") desc = [
						d.hotelName,
						d.city && `(${d.city})`,
						d.rooms && `${d.rooms} Rms`,
						d.nights && `${d.nights} Nts`,
						d.mealPlan
					].filter(Boolean).join(" ") || e.note || "Hotel Booking";
					else if (k === "Package") desc = [
						d.packageName || d.destinationCity,
						d.packageType,
						d.packageDurationDays && `${d.packageDurationDays}D`
					].filter(Boolean).join(" · ") || e.note || "Tour Package";
					else if (k === "Visa") desc = [
						d.country,
						d.visaType,
						d.reference && `Ref: ${d.reference}`
					].filter(Boolean).join(" · ") || e.note || "Visa";
					else if (k === "Transport") desc = [d.route, d.vehicle].filter(Boolean).join(" · ") || e.note || "Transport";
					else desc = [
						d.description,
						e.chargeCategory,
						e.note
					].filter(Boolean).join(" · ") || "Service";
					return [
						fmtDate(e.date),
						e.id,
						e.forClientName || "—",
						desc,
						money(otherSaleOf(e))
					];
				}),
				foot: footRow(`Total ${k}`, 4, tot)
			});
			y = doc.lastAutoTable.finalY + 7;
		}
	}
	const recRows = [...pClientTx.map((e) => ({
		e,
		label: e.type === "client_receive" ? "Client Receipt" : e.type === "client_refund" ? "Client Refund" : `Extra Charge${e.chargeCategory ? ` — ${e.chargeCategory}` : ""}`,
		sign: e.type === "client_charge" ? 1 : -1
	})), ...pAgentRec.map((e) => ({
		e,
		label: "Received from Agent",
		sign: -1
	}))].sort((a, b) => a.e.date.localeCompare(b.e.date));
	y = categoryHeading(doc, y, "Receipts & Adjustments", recRows.length, totalReceived, "success");
	let running = opening;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"Date",
			"Ref",
			"Head",
			"Particulars",
			"Debit",
			"Credit",
			"Balance"
		]],
		body: [
			[{
				content: "Opening Balance",
				colSpan: 6,
				styles: {
					fontStyle: "bold",
					fillColor: ROW_ALT
				}
			}, {
				content: formatCurrency(opening),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}],
			[
				{
					content: "Business booked in period (net of commission)",
					colSpan: 4
				},
				money(netClient + otherSale, INK),
				"",
				money(running += netClient + otherSale)
			],
			...recRows.map(({ e, label, sign }) => {
				running += sign * e.amount;
				return [
					fmtDate(e.date),
					e.id,
					e.headId || "—",
					label,
					sign > 0 ? money(e.amount, INK) : "",
					sign < 0 ? money(e.amount, SUCCESS) : "",
					money(running)
				];
			})
		],
		foot: footRow("Closing Balance", 6, closing, closing > 0 ? DANGER : SUCCESS)
	});
	y = doc.lastAutoTable.finalY + 7;
	y = ensureSpace(doc, y, 70);
	y = sectionTitle(doc, "Account Summary", y);
	y += 5;
	const sumBody = [["Opening Balance", money(opening)]];
	if (incClient) {
		sumBody.push(["Client Sale (gross)", money(grossSale, INK)], ["Less: Agent Commission", money(-commission, DANGER)], ["Net Client Business", money(netClient)]);
		if (extraCharges) sumBody.push(["Add: Extra Charges", money(extraCharges, INK)]);
		if (refunds) sumBody.push(["Less: Client Refunds", money(-refunds, DANGER)]);
	}
	if (incOther) sumBody.push(["Other Sale", money(otherSale)]);
	sumBody.push(["Less: Received", money(-totalReceived, SUCCESS)]);
	brandTable(doc, {
		startY: y,
		body: sumBody,
		columnStyles: { 0: {
			cellWidth: 120,
			fontStyle: "bold"
		} },
		foot: [[{
			content: closing >= 0 ? "Remaining Balance (Receivable)" : "Advance / Credit",
			styles: {
				fillColor: NAVY,
				textColor: WHITE,
				fontStyle: "bold"
			}
		}, {
			content: formatCurrency(Math.abs(closing)),
			styles: {
				fillColor: NAVY,
				textColor: GOLD_LT,
				halign: "right",
				fontStyle: "bold"
			}
		}]]
	});
	y = doc.lastAutoTable.finalY + 6;
	const commEarned = bookings.reduce((s, b) => s + (b.commission || 0), 0) + (agent.openingCommission || 0);
	const commPaid = commissionPaid.reduce((s, e) => s + e.amount, 0) + (agent.openingPaidCommission || 0);
	y = summaryCards(doc, y, [
		[
			"Commission Earned",
			formatCurrency(commEarned),
			"gold"
		],
		[
			"Commission Paid",
			formatCurrency(commPaid),
			"success"
		],
		[
			"Commission Payable",
			formatCurrency(commEarned - commPaid),
			"danger"
		]
	]);
	footer(doc);
	save(doc, `Avery_Agent_Statement_${agent.id}_${scope}.pdf`);
}
async function generateClientStatement(client, entries, opts = {}) {
	const doc = new E();
	await loadPdfFonts(doc);
	executiveHeader(doc, "CLIENT", "STATEMENT");
	const filtered = entries.filter((e) => inRange(e.date, opts.fromDate, opts.toDate));
	const periodLabel = opts.fromDate || opts.toDate ? `${fmtDate(opts.fromDate)} — ${fmtDate(opts.toDate)}` : "All-time";
	const includeOpening = opts.includeOpening !== false;
	const openingPaid = includeOpening ? client.openingPaid || 0 : 0;
	const totalDue = client.amountDue;
	const totalPaid = client.amountPaid + openingPaid;
	const remaining = totalDue - totalPaid;
	let y = 66;
	y = supplierMetaBar(doc, y, {
		stmtNo: `AV-CS-${client.id.replace(/[^0-9A-Z]/gi, "")}-${(/* @__PURE__ */ new Date()).getFullYear()}`,
		period: periodLabel,
		groupLabel: client.packageType ? `${client.packageType} Package · Head ${client.headId}` : void 0
	});
	y = clientIdentityCard(doc, y, client);
	const pctPaid = totalDue > 0 ? Math.max(0, Math.min(100, totalPaid / totalDue * 100)) : 0;
	y = executiveSnapshot(doc, y, {
		payable: totalDue,
		paid: totalPaid,
		remaining,
		bf: includeOpening && openingPaid > 0 ? openingPaid : void 0,
		purchases: opts.bookings ? opts.bookings.length : 1,
		payments: filtered.length,
		pctPaid
	});
	if (opts.bookings && opts.bookings.length) y = renderServiceSections(doc, y, opts.bookings);
	if (filtered.length || includeOpening && openingPaid > 0) {
		y = categoryHeading(doc, y, "Payments Received", filtered.length + (openingPaid > 0 ? 1 : 0), totalPaid, "success");
		const body = [];
		if (includeOpening && openingPaid > 0) body.push([{
			content: "Opening Paid (B/F)",
			colSpan: 3,
			styles: {
				fontStyle: "bold",
				fillColor: ROW_ALT
			}
		}, {
			content: formatCurrency(openingPaid),
			styles: {
				halign: "right",
				fontStyle: "bold",
				fillColor: ROW_ALT,
				textColor: NAVY
			}
		}]);
		for (const p of filtered) body.push([
			fmtDate(p.date),
			p.id,
			p.note || p.referenceName || "Payment Received",
			{
				content: formatCurrency(p.amount),
				styles: {
					halign: "right",
					textColor: SUCCESS
				}
			}
		]);
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Date",
				"Receipt #",
				"Particulars / Notes",
				"Amount"
			]],
			body,
			foot: [[{
				content: "Total Received",
				colSpan: 3,
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: NAVY
				}
			}, {
				content: formatCurrency(totalPaid),
				styles: {
					halign: "right",
					fontStyle: "bold",
					fillColor: ROW_ALT,
					textColor: SUCCESS
				}
			}]]
		});
		y = doc.lastAutoTable.finalY + 7;
	}
	y = reconciliationBlock(doc, y, {
		openingPayable: void 0,
		openingPaid: includeOpening && openingPaid > 0 ? openingPaid : void 0,
		totalPurchases: totalDue,
		totalPaid: filtered.reduce((s, e) => s + e.amount, 0),
		grandPayable: totalDue,
		grandPaid: totalPaid
	});
	closingHero(doc, y, remaining, {
		title: "CLOSING BALANCE",
		subtitle: "Net balance receivable from client as of statement date.",
		positiveLabel: "Outstanding — Payment Due",
		negativeLabel: "Overpayment / Advance Credit"
	});
	footer(doc);
	save(doc, `Avery_Client_Statement_${client.id}.pdf`);
}
async function generatePaymentHistory(title, ownerInfo, entries, summary) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, "Payment History");
	let y = 44;
	y = fromAndTo(doc, y, title, ownerInfo.slice(0, 4).map(([k, v]) => [k, v]));
	const cards = summary.slice(0, 4).map(([l, v, c]) => [
		l,
		v,
		c === "success" ? "success" : c === "destructive" ? "danger" : c === "gold" ? "gold" : "ink"
	]);
	y = summaryCards(doc, y, cards);
	y += 2;
	y = sectionTitle(doc, "Transaction History", y);
	y += 4;
	let running = 0;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"Date",
			"Receipt",
			"Description",
			"Type",
			"Amount",
			"Running"
		]],
		body: entries.map((e) => {
			running += e.amount;
			return [
				fmtDate(e.date),
				e.id,
				e.note || e.referenceName,
				labelType(e.type),
				{
					content: formatCurrency(e.amount),
					styles: { halign: "right" }
				},
				{
					content: formatCurrency(running),
					styles: {
						halign: "right",
						textColor: NAVY
					}
				}
			];
		})
	});
	footer(doc);
	save(doc, `Avery_Payment_History_${title.replace(/\s+/g, "_")}.pdf`);
}
async function generateInvoice(booking, clients, agent, supplier) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, "Tax Invoice");
	let y = 44;
	y = fromAndTo(doc, y, "Bill To", [
		["Head ID", booking.headId],
		["Lead", clients[0] ? getClientName(clients[0]) : "—"],
		["Phone", clients[0]?.phone || "—"],
		["Members", String(booking.members || clients.length)]
	]);
	doc.setFillColor(...NAVY);
	doc.rect(14, y, 182, 7, "F");
	setSerif(doc, "bold");
	doc.setFontSize(9);
	doc.setTextColor(...WHITE);
	doc.text(`Invoice #INV-${booking.headId.replace("AV-HD-", "")}   ·   Package: ${booking.packageType}`, 18, y + 5);
	doc.text(`Travel: ${fmtDate(booking.travelDate)}`, 192, y + 5, { align: "right" });
	doc.setTextColor(...INK);
	y += 11;
	y = sectionTitle(doc, "Client Breakdown", y);
	y += 4;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"#",
			"Client ID",
			"Name",
			"Passport",
			"Due",
			"Paid",
			"Status"
		]],
		body: clients.map((c, i) => [
			String(i + 1),
			c.id,
			getClientName(c),
			c.passport || "—",
			{
				content: formatCurrency(c.amountDue),
				styles: { halign: "right" }
			},
			{
				content: formatCurrency(c.amountPaid),
				styles: {
					halign: "right",
					textColor: SUCCESS
				}
			},
			c.paymentStatus
		])
	});
	y = doc.lastAutoTable.finalY + 6;
	y = renderServiceSections(doc, y, [booking]);
	const balance = booking.totalAmount - booking.amountReceived;
	doc.setFillColor(...IVORY);
	doc.rect(110, y, 86, 32, "F");
	doc.setDrawColor(...GOLD);
	doc.setLineWidth(.4);
	doc.rect(110, y, 86, 32);
	setSans(doc, "normal");
	doc.setFontSize(9);
	doc.setTextColor(...INK);
	doc.text("Total Amount", 114, y + 7);
	doc.text(formatCurrency(booking.totalAmount), 192, y + 7, { align: "right" });
	doc.text("Received", 114, y + 14);
	doc.setTextColor(...SUCCESS);
	doc.text(formatCurrency(booking.amountReceived), 192, y + 14, { align: "right" });
	doc.setTextColor(...INK);
	doc.setFillColor(...GOLD);
	doc.rect(110, y + 19, 86, 13, "F");
	doc.setTextColor(...WHITE);
	setSerif(doc, "bold");
	doc.setFontSize(11);
	doc.text("BALANCE DUE", 114, y + 27.5);
	doc.text(formatCurrency(balance), 192, y + 27.5, { align: "right" });
	if (agent || supplier) {
		setSans(doc, "italic");
		doc.setFontSize(7.5);
		doc.setTextColor(...MUTED);
		doc.text(`Agent: ${agent?.name || "Direct"}   ·   Supplier: ${supplier?.companyName || "—"}`, 14, y + 36);
	}
	footer(doc);
	save(doc, `Avery_Invoice_${booking.headId}.pdf`);
}
async function generatePaymentReceipt(entry, opts) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, "Payment Receipt");
	let y = 44;
	y = fromAndTo(doc, y, "Received From", [
		["Name", opts?.clientName || entry.referenceName],
		["Reference", opts?.reference || entry.headId || "—"],
		["Receipt #", entry.id],
		["Date", fmtDate(entry.date)]
	]);
	brandTable(doc, {
		startY: y,
		head: [[
			"Description",
			"Method",
			"Handled By",
			"Amount (PKR)"
		]],
		body: [[
			entry.note || "Payment received",
			opts?.method || entry.paymentMethod || "Cash / Bank Transfer",
			opts?.handledBy || entry.collectedBy || "Avery Office",
			{
				content: formatCurrency(entry.amount).replace("PKR", "").trim(),
				styles: { halign: "right" }
			}
		]]
	});
	y = doc.lastAutoTable.finalY + 4;
	const pd = entry.purchaseDetails;
	if (pd || entry.type === "purchase" || entry.type === "jv" || entry.chequeNo || entry.txnRef) {
		const detailsRows = [];
		if (pd?.ticketNumber) detailsRows.push(["Ticket Number", pd.ticketNumber]);
		if (pd?.pnr) detailsRows.push(["PNR Booking Ref", pd.pnr]);
		if (pd?.sector) detailsRows.push(["Sector / Route", pd.sector]);
		if (pd?.tripType) detailsRows.push(["Trip Type", pd.tripType]);
		if (pd?.airline) detailsRows.push(["Airline & Flight", [pd.airline, pd.flightNumber].filter(Boolean).join(" · ")]);
		if (pd?.hotelName) detailsRows.push(["Hotel & City", `${pd.hotelName} ${pd.city ? `(${pd.city})` : ""}`]);
		if (pd?.rooms || pd?.nights) detailsRows.push(["Rooms / Nights", `${pd.rooms || 1} Rooms · ${pd.nights || 1} Nights [${pd.mealPlan || "Standard"}]`]);
		if (pd?.packageName) detailsRows.push(["Package Title", pd.packageName]);
		if (pd?.destinationCity) detailsRows.push(["Destination Combo", `${pd.destinationCountry || ""} — ${pd.destinationCity}`]);
		if (pd?.packageInclusions?.length) detailsRows.push(["Inclusions", pd.packageInclusions.join(", ")]);
		if (pd?.visaType) detailsRows.push(["Visa Category", `${pd.country || ""} (${pd.visaType}) · Ref: ${pd.reference || "—"}`]);
		if (pd?.applicantNames) detailsRows.push(["Applicants", pd.applicantNames]);
		if (pd?.route) detailsRows.push(["Transport Route", `${pd.route} (${pd.vehicle || "Standard"})`]);
		if (entry.type === "jv") detailsRows.push(["JV Settlement", entry.jvType === "account_transfer" ? "Account to Account Transfer" : "Reconciliation Adjustment"]);
		if (entry.chequeNo) detailsRows.push(["Cheque No", `${entry.chequeNo} ${entry.chequeDate ? `(Date: ${entry.chequeDate})` : ""}`]);
		if (entry.txnRef) detailsRows.push(["Txn / Ref No", entry.txnRef]);
		if (entry.bankName) detailsRows.push(["Bank Name", entry.bankName]);
		if (detailsRows.length) {
			y = sectionTitle(doc, "Service & Transaction Details", y);
			y += 4;
			brandTable(doc, {
				startY: y,
				head: [["Item / Specification", "Detail Record"]],
				body: detailsRows
			});
			y = doc.lastAutoTable.finalY + 4;
		}
	}
	totalsBand(doc, y, "Total Received", formatCurrency(entry.amount));
	y += 18;
	doc.setDrawColor(...MUTED);
	doc.setLineWidth(.2);
	doc.line(20, y + 6, 80, y + 6);
	doc.line(130, y + 6, 190, y + 6);
	setSans(doc, "normal");
	doc.setFontSize(8);
	doc.setTextColor(...INK);
	doc.text("Authorized Signature", 30, y + 11);
	doc.text("Company Stamp", 145, y + 11);
	doc.setTextColor(...MUTED);
	doc.setFontSize(7);
	doc.text("This is a computer-generated receipt and does not require a physical signature.", 14, y + 22);
	footer(doc);
	save(doc, `Avery_Payment_Receipt_${entry.id}.pdf`);
}
async function generateHotelVoucher(booking, clients, hotels, opts) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, booking.packageType === "Umrah" ? "Umrah Hotel Voucher" : booking.packageType === "Hajj" ? "Hajj Hotel Voucher" : "Hotel Voucher");
	let y = 44;
	y = fromAndTo(doc, y, "Guest Booking", [
		["Head ID", booking.headId],
		["Voucher #", `AV-${booking.headId.replace(/[^0-9]/g, "")}${opts?.voucherSuffix || ""}`],
		["Travel Date", fmtDate(booking.travelDate)],
		["Members", String(clients.length)]
	]);
	y = sectionTitle(doc, "Passenger Details", y);
	y += 4;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"#",
			"Passenger Name",
			"Passport No",
			"Type"
		]],
		body: clients.map((c, i) => [
			String(i + 1),
			getClientName(c),
			c.passport || "—",
			"Adult"
		])
	});
	y = doc.lastAutoTable.finalY + 6;
	if (hotels.length) {
		y = sectionTitle(doc, "Accommodation", y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"City",
				"Hotel Name",
				"Room",
				"Check-In",
				"Check-Out",
				"Nights"
			]],
			body: hotels.map((h) => [
				h.city,
				h.hotelName,
				h.roomType,
				fmtDate(h.checkIn),
				fmtDate(h.checkOut),
				String(h.nights)
			])
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	if (opts?.transports?.length) {
		y = sectionTitle(doc, "Transport", y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Service",
				"Route",
				"Vehicle",
				"Date"
			]],
			body: opts.transports.map((t) => [
				t.service,
				t.route,
				t.vehicle,
				fmtDate(t.date)
			])
		});
		y = doc.lastAutoTable.finalY + 6;
	}
	if (opts?.flights?.length) {
		y = sectionTitle(doc, "Flights", y);
		y += 4;
		brandTable(doc, {
			startY: y + 1,
			head: [[
				"Date",
				"Flight",
				"From",
				"To",
				"Departure",
				"Arrival"
			]],
			body: opts.flights.map((f) => [
				fmtDate(f.date),
				f.flightNo,
				f.from,
				f.to,
				f.departure,
				f.arrival
			])
		});
	}
	footer(doc);
	const cityTag = hotels.length === 1 ? `_${hotels[0].city}` : hotels.length > 1 ? "_All" : "";
	save(doc, `Avery_Hotel_Voucher_${booking.headId}${cityTag}.pdf`);
}
async function generateFlightVoucher(booking, clients, flights) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, "Flight Voucher");
	let y = 44;
	y = fromAndTo(doc, y, "Booking", [
		["Head ID", booking.headId],
		["Voucher #", `AV-FL-${booking.headId.replace(/[^0-9]/g, "")}`],
		["Travel Date", fmtDate(booking.travelDate)],
		["Members", String(clients.length)]
	]);
	y = sectionTitle(doc, "Passenger Details", y);
	y += 4;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"#",
			"Passenger Name",
			"Passport No"
		]],
		body: clients.map((c, i) => [
			String(i + 1),
			getClientName(c),
			c.passport || "—"
		])
	});
	y = doc.lastAutoTable.finalY + 6;
	y = sectionTitle(doc, "Flights", y);
	y += 4;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"Date",
			"Flight",
			"From",
			"To",
			"Departure",
			"Arrival"
		]],
		body: flights.map((f) => [
			fmtDate(f.date),
			f.flightNo,
			f.from,
			f.to,
			f.departure,
			f.arrival
		])
	});
	footer(doc);
	save(doc, `Avery_Flight_Voucher_${booking.headId}.pdf`);
}
async function generateTransportVoucher(booking, clients, transports) {
	const doc = new E();
	await loadPdfFonts(doc);
	header(doc, "Transport Voucher");
	let y = 44;
	y = fromAndTo(doc, y, "Booking", [
		["Head ID", booking.headId],
		["Voucher #", `AV-TR-${booking.headId.replace(/[^0-9]/g, "")}`],
		["Travel Date", fmtDate(booking.travelDate)],
		["Members", String(clients.length)]
	]);
	y = sectionTitle(doc, "Passenger Details", y);
	y += 4;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"#",
			"Passenger Name",
			"Passport No"
		]],
		body: clients.map((c, i) => [
			String(i + 1),
			getClientName(c),
			c.passport || "—"
		])
	});
	y = doc.lastAutoTable.finalY + 6;
	y = sectionTitle(doc, "Transport", y);
	y += 4;
	brandTable(doc, {
		startY: y + 1,
		head: [[
			"Service",
			"Route",
			"Vehicle",
			"Date"
		]],
		body: transports.map((t) => [
			t.service,
			t.route,
			t.vehicle,
			fmtDate(t.date)
		])
	});
	footer(doc);
	save(doc, `Avery_Transport_Voucher_${booking.headId}.pdf`);
}
export { generateInvoice as a, generateSupplierLedger as c, generateHotelVoucher as i, generateTransportVoucher as l, generateClientStatement as n, generatePaymentHistory as o, generateFlightVoucher as r, generatePaymentReceipt as s, generateAgentReport as t };
