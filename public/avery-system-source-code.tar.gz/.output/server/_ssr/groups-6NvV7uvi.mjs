// node_modules/.nitro/vite/services/ssr/assets/groups-6NvV7uvi.js
var DAY = 864e5;
function daysUntil(date) {
	if (!date) return null;
	const t = (/* @__PURE__ */ new Date(`${date}T00:00:00`)).getTime();
	if (Number.isNaN(t)) return null;
	const today = /* @__PURE__ */ new Date();
	const base = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
	return Math.round((t - base) / DAY);
}
function computeUrgency(stats) {
	const capacity = stats.capacity || 0;
	const remainingSeats = capacity > 0 ? Math.max(0, capacity - stats.usedPax) : Infinity;
	const days = daysUntil(stats.group.date);
	const isFull = capacity > 0 && remainingSeats <= 0;
	let level = "normal";
	let reason = "On track";
	if (isFull) {
		level = "full";
		reason = "Group full — closed for new sales";
	} else if (days !== null && days <= 7) {
		level = "critical";
		reason = days < 0 ? `Departed ${Math.abs(days)}d ago` : days === 0 ? "Departs today" : `Departs in ${days} day${days === 1 ? "" : "s"}`;
	} else if (capacity > 0 && remainingSeats <= 3) {
		level = "critical";
		reason = `Only ${remainingSeats} seat${remainingSeats === 1 ? "" : "s"} left`;
	} else if (days !== null && days <= 21 || capacity > 0 && remainingSeats <= 8) {
		level = "warning";
		reason = days !== null && days <= 21 ? `Departs in ${days} days` : `${remainingSeats} seats left`;
	} else if (days === null) {
		level = "undated";
		reason = "No departure date set";
	}
	return {
		remainingSeats: capacity > 0 ? remainingSeats : 0,
		capacity,
		usedPax: stats.usedPax,
		departure: stats.group.date,
		daysToDeparture: days,
		isFull,
		level,
		reason
	};
}
/** Nearest departure first, then lowest remaining seats. Undated groups sink to the bottom. */
function sortByUrgency(list, pick) {
	return [...list].sort((a, b) => {
		const ua = pick(a), ub = pick(b);
		const da = ua.daysToDeparture, db = ub.daysToDeparture;
		if (da === null && db !== null) return 1;
		if (db === null && da !== null) return -1;
		if (da !== null && db !== null && da !== db) return da - db;
		return (ua.capacity > 0 ? ua.remainingSeats : Number.MAX_SAFE_INTEGER) - (ub.capacity > 0 ? ub.remainingSeats : Number.MAX_SAFE_INTEGER);
	});
}
var urgencyTone = {
	full: "border-border bg-muted/40 text-muted-foreground",
	critical: "border-destructive/40 bg-destructive/10 text-destructive",
	warning: "border-warning/40 bg-warning/10 text-warning",
	normal: "border-success/30 bg-success/10 text-success",
	undated: "border-border bg-accent/30 text-muted-foreground"
};
var urgencyLabel = {
	full: "FULL",
	critical: "URGENT",
	warning: "CLOSING",
	normal: "OPEN",
	undated: "NO DATE"
};
function computeGroupStats(group, data) {
	const linkedBookings = data.bookings.filter((b) => b.groupId === group.id);
	const headIds = new Set(linkedBookings.map((b) => b.headId));
	const heads = linkedBookings.map((b) => {
		const cl = data.clients.filter((c) => c.headId === b.headId);
		const lead = cl[0];
		return {
			headId: b.headId,
			booking: b,
			clients: cl,
			leadName: lead ? `${lead.firstName} ${lead.lastName}`.trim() : "—",
			members: b.members || cl.length,
			totalAmount: b.totalAmount || 0,
			received: b.amountReceived || 0,
			pending: Math.max(0, (b.totalAmount || 0) - (b.amountReceived || 0))
		};
	});
	const tagged = data.entries.filter((e) => e.groupId === group.id);
	const purchases = tagged.filter((e) => e.type === "purchase");
	const payments = tagged.filter((e) => e.type === "supplier_payment");
	const groupExpenses = tagged.filter((e) => e.type === "expense");
	const supplierRefunds = tagged.filter((e) => e.type === "supplier_refund");
	const receipts = data.entries.filter((e) => e.type === "client_receive" && headIds.has(e.headId));
	const billedPax = purchases.reduce((s, e) => {
		const d = e.purchaseDetails || {};
		return s + (d.adults || 0) + (d.children || 0) + (d.infants || 0);
	}, 0);
	const usedPax = heads.reduce((s, h) => s + (h.clients.length || h.members || 0), 0);
	const capacity = group.totalPax || 0;
	const revenue = heads.reduce((s, h) => s + h.totalAmount, 0);
	const received = heads.reduce((s, h) => s + h.received, 0);
	const refunds = data.entries.filter((e) => e.type === "client_refund" && headIds.has(e.headId)).reduce((s, e) => s + e.amount, 0);
	const supplierBill = Math.max(0, purchases.reduce((s, e) => s + e.amount, 0) - supplierRefunds.reduce((s, e) => s + e.amount, 0));
	const supplierPaid = payments.reduce((s, e) => s + e.amount, 0);
	const commission = linkedBookings.reduce((s, b) => s + (b.commission || 0), 0);
	const expenses = groupExpenses.reduce((s, e) => s + e.amount, 0);
	const netProfit = revenue - supplierBill - commission - expenses;
	const catMap = /* @__PURE__ */ new Map();
	for (const p of purchases) {
		const key = p.serviceCategory || "Other";
		const cur = catMap.get(key) || {
			count: 0,
			amount: 0
		};
		catMap.set(key, {
			count: cur.count + 1,
			amount: cur.amount + p.amount
		});
	}
	return {
		group,
		supplier: data.suppliers.find((s) => s.id === group.supplierId),
		heads,
		purchases,
		payments,
		groupExpenses,
		receipts,
		usedPax,
		billedPax,
		capacity,
		remainingPax: Math.max(0, capacity - usedPax),
		revenue,
		received,
		refunds,
		pendingReceivable: Math.max(0, revenue - received),
		supplierBill,
		supplierPaid,
		supplierOutstanding: supplierBill - supplierPaid,
		commission,
		expenses,
		netProfit,
		margin: revenue > 0 ? netProfit / revenue * 100 : 0,
		billByCategory: Array.from(catMap.entries()).map(([category, v]) => ({
			category,
			...v
		})).sort((a, b) => b.amount - a.amount)
	};
}
export { urgencyTone as a, urgencyLabel as i, computeUrgency as n, sortByUrgency as r, computeGroupStats as t };
