import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { K as Eye, T as Plane, V as Hotel, W as FileText, f as Trash, g as ShieldCheck, j as OctagonAlert, k as Pencil, l as TriangleAlert, nt as Circle, p as Tag, pt as Car, q as Download, rt as CircleCheck, st as ChevronRight, ut as Check, w as Plus, x as RotateCcw, y as Search } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as formatCurrency, b as computeBookingFinancials, f as getPKTDate, i as computeGroupUsedPax, o as useStore, v as PACKAGE_TYPES, w as getClientName, x as computeBookingProfit } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as cn } from "./utils-DWGjSd5x.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { t as Input } from "./input-CqV36rr2.mjs";
import { t as Label } from "./label-BYIfJH-v.mjs";
import { a as DropdownMenuItemIndicator, c as DropdownMenuRadioItem$1, d as DropdownMenuSubTrigger$1, f as DropdownMenuTrigger$1, i as DropdownMenuItem$1, l as DropdownMenuSeparator$1, n as DropdownMenuCheckboxItem$1, o as DropdownMenuLabel$1, r as DropdownMenuContent$1, s as DropdownMenuPortal, t as DropdownMenu$1, u as DropdownMenuSubContent$1 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BBv8eX6f.mjs";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { t as StatusBadge } from "./StatusBadge-MNA5vWLW.mjs";
import { a as generateInvoice, i as generateHotelVoucher, l as generateTransportVoucher, o as generatePaymentHistory, r as generateFlightVoucher } from "./pdf-DqNVIsfR.mjs";
import { a as paymentAllocations, i as headSupplierPaid, o as purchaseAllocations, r as headCostOf } from "./allocations-CV2mwFEX.mjs";
import { n as SearchableSelect, t as GroupSeatStrip } from "./SearchableSelect-CBJWeT4R.mjs";
import { n as sortEntities, t as SortBar } from "./SortBar-CcXdcaV6.mjs";
// node_modules/.nitro/vite/services/ssr/assets/bookings-C0xGaO-h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DropdownMenu = DropdownMenu$1;
var DropdownMenuTrigger = DropdownMenuTrigger$1;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuSubTrigger$1, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = DropdownMenuSubTrigger$1.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSubContent$1, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = DropdownMenuSubContent$1.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent$1, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = DropdownMenuContent$1.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = DropdownMenuItem$1.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuCheckboxItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	checked,
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = DropdownMenuCheckboxItem$1.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem$1, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = DropdownMenuRadioItem$1.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = DropdownMenuLabel$1.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = DropdownMenuSeparator$1.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
function BookingServicesMenu({ booking, clients }) {
	const store = useStore();
	const [open, setOpen] = (0, import_react.useState)(null);
	const [hotel, setHotel] = (0, import_react.useState)({
		city: "Makkah",
		hotelName: "",
		roomType: "",
		checkIn: "",
		checkOut: "",
		nights: ""
	});
	const [flight, setFlight] = (0, import_react.useState)({
		date: "",
		flightNo: "",
		from: "",
		to: "",
		departure: "",
		arrival: ""
	});
	const [transport, setTransport] = (0, import_react.useState)({
		service: "Airport Transfer",
		route: "",
		vehicle: "Private Car",
		date: ""
	});
	function reset() {
		setOpen(null);
	}
	function saveHotel() {
		if (!hotel.hotelName) return;
		store.addHotel(booking.id, {
			city: hotel.city,
			hotelName: hotel.hotelName,
			roomType: hotel.roomType || "1 Quad",
			checkIn: hotel.checkIn,
			checkOut: hotel.checkOut,
			nights: Number(hotel.nights) || 0
		});
		setHotel({
			city: "Makkah",
			hotelName: "",
			roomType: "",
			checkIn: "",
			checkOut: "",
			nights: ""
		});
		reset();
	}
	function saveFlight() {
		if (!flight.flightNo) return;
		store.addFlight(booking.id, { ...flight });
		setFlight({
			date: "",
			flightNo: "",
			from: "",
			to: "",
			departure: "",
			arrival: ""
		});
		reset();
	}
	function saveTransport() {
		if (!transport.route) return;
		store.addTransport(booking.id, { ...transport });
		setTransport({
			service: "Airport Transfer",
			route: "",
			vehicle: "Private Car",
			date: ""
		});
		reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "rounded p-1 hover:bg-accent",
				title: "Add Service",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5 text-primary" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
			align: "end",
			className: "w-56",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
					className: "text-xs",
					children: "Add Service"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onClick: () => setOpen("hotel"),
					className: "gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hotel, { className: "h-3.5 w-3.5 text-primary" }), " Add Hotel"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onClick: () => setOpen("flight"),
					className: "gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "h-3.5 w-3.5 text-primary" }), " Add Flight"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onClick: () => setOpen("transport"),
					className: "gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "h-3.5 w-3.5 text-primary" }), " Add Transport"]
				}),
				booking.hotels?.length || booking.flights?.length || booking.transports?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
						className: "text-xs",
						children: "Manage"
					}),
					booking.hotels?.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => store.deleteHotel(booking.id, h.id),
						className: "gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3 w-3 text-destructive" }),
							" Remove ",
							h.city,
							" — ",
							h.hotelName
						]
					}, h.id)),
					booking.flights?.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => store.deleteFlight(booking.id, f.id),
						className: "gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3 w-3 text-destructive" }),
							" Remove Flight ",
							f.flightNo
						]
					}, f.id)),
					booking.transports?.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onClick: () => store.deleteTransport(booking.id, t.id),
						className: "gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3 w-3 text-destructive" }),
							" Remove ",
							t.service
						]
					}, t.id))
				] }) : null
			]
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: open === "hotel",
			onOpenChange: (o) => !o && reset(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "bg-card border-border max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add Hotel — ", booking.headId] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "City"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: hotel.city,
								onChange: (e) => setHotel({
									...hotel,
									city: e.target.value
								}),
								placeholder: "Makkah / Madinah",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Room Type"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: hotel.roomType,
								onChange: (e) => setHotel({
									...hotel,
									roomType: e.target.value
								}),
								placeholder: "1 Quad",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Hotel Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: hotel.hotelName,
							onChange: (e) => setHotel({
								...hotel,
								hotelName: e.target.value
							}),
							placeholder: "Noor Al Mashair",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "Check-In"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: hotel.checkIn,
									onChange: (e) => setHotel({
										...hotel,
										checkIn: e.target.value
									}),
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "Check-Out"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: hotel.checkOut,
									onChange: (e) => setHotel({
										...hotel,
										checkOut: e.target.value
									}),
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs",
									children: "Nights"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: hotel.nights,
									onChange: (e) => setHotel({
										...hotel,
										nights: e.target.value
									}),
									className: "bg-accent/20 border-border mt-1 h-8 text-xs"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveHotel,
							className: "w-full",
							children: "Save Hotel"
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: open === "flight",
			onOpenChange: (o) => !o && reset(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "bg-card border-border max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add Flight — ", booking.headId] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: flight.date,
								onChange: (e) => setFlight({
									...flight,
									date: e.target.value
								}),
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Flight No"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.flightNo,
								onChange: (e) => setFlight({
									...flight,
									flightNo: e.target.value
								}),
								placeholder: "XY638",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "From"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.from,
								onChange: (e) => setFlight({
									...flight,
									from: e.target.value
								}),
								placeholder: "Karachi",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "To"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.to,
								onChange: (e) => setFlight({
									...flight,
									to: e.target.value
								}),
								placeholder: "Jeddah",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Departure"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.departure,
								onChange: (e) => setFlight({
									...flight,
									departure: e.target.value
								}),
								placeholder: "13:15",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Arrival"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: flight.arrival,
								onChange: (e) => setFlight({
									...flight,
									arrival: e.target.value
								}),
								placeholder: "16:05",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveFlight,
							className: "w-full",
							children: "Save Flight"
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: open === "transport",
			onOpenChange: (o) => !o && reset(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "bg-card border-border max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add Transport — ", booking.headId] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Service"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: transport.service,
								onChange: (e) => setTransport({
									...transport,
									service: e.target.value
								}),
								placeholder: "Airport Transfer",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs",
								children: "Vehicle"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: transport.vehicle,
								onChange: (e) => setTransport({
									...transport,
									vehicle: e.target.value
								}),
								placeholder: "Private Car",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Route"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: transport.route,
							onChange: (e) => setTransport({
								...transport,
								route: e.target.value
							}),
							placeholder: "JED Airport - Makkah Hotel",
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: transport.date,
							onChange: (e) => setTransport({
								...transport,
								date: e.target.value
							}),
							className: "bg-accent/20 border-border mt-1 h-8 text-xs"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveTransport,
							className: "w-full",
							children: "Save Transport"
						})
					]
				})]
			})
		})
	] });
}
function VoucherDownloadMenu({ booking, clients }) {
	const hasAny = (booking.hotels?.length || 0) + (booking.flights?.length || 0) + (booking.transports?.length || 0) > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "rounded p-1 hover:bg-accent",
			title: "Download Vouchers",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		className: "w-56",
		children: [
			!hasAny && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				disabled: true,
				className: "text-xs text-muted-foreground",
				children: "No services added yet"
			}),
			booking.hotels && booking.hotels.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
					className: "text-xs",
					children: "Hotel Vouchers"
				}),
				booking.hotels.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					className: "gap-2 text-xs",
					onClick: () => generateHotelVoucher(booking, clients, [h], { voucherSuffix: `-${i + 1}` }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hotel, { className: "h-3.5 w-3.5 text-primary" }),
						" ",
						h.city,
						" — ",
						h.hotelName
					]
				}, h.id)),
				booking.hotels.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					className: "gap-2 text-xs font-semibold",
					onClick: () => generateHotelVoucher(booking, clients, booking.hotels, {
						transports: booking.transports,
						flights: booking.flights
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" }), " Download All Hotels"]
				})
			] }),
			booking.flights && booking.flights.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				className: "gap-2 text-xs",
				onClick: () => generateFlightVoucher(booking, clients, booking.flights),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "h-3.5 w-3.5 text-primary" }), " Flight Voucher"]
			})] }),
			booking.transports && booking.transports.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				className: "gap-2 text-xs",
				onClick: () => generateTransportVoucher(booking, clients, booking.transports),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "h-3.5 w-3.5 text-primary" }), " Transport Voucher"]
			}),
			hasAny && (booking.hotels?.length || 0) >= 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				className: "gap-2 text-xs font-semibold",
				onClick: () => generateHotelVoucher(booking, clients, booking.hotels || [], {
					transports: booking.transports,
					flights: booking.flights
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" }), " Combined Voucher (Hotel + Flight + Transport)"]
			})] })
		]
	})] });
}
/** Flat, disclosed amounts only — no interest, no compounding. */
function computeHeadBusiness(headId, clients, bookings, entries) {
	const members = clients.filter((c) => c.headId === headId);
	const booking = bookings.find((b) => b.headId === headId);
	const linked = entries.filter((e) => {
		if (e.headId === headId) return true;
		if (e.type === "purchase") return purchaseAllocations(e).some((l) => l.target === "head" && l.headId === headId);
		if (e.type === "supplier_payment") return paymentAllocations(e).some((l) => l.target === "head" && l.headId === headId);
		return false;
	});
	const otherCosts = linked.filter((e) => e.type === "client_charge").reduce((s, e) => s + e.amount, 0);
	const discountEntries = linked.filter((e) => e.type === "client_discount").reduce((s, e) => s + e.amount, 0);
	const bookingDiscount = Number(booking?.discount) || 0;
	const totalDiscount = bookingDiscount + discountEntries;
	const grossBase = booking?.baseAmount ?? (booking ? booking.totalAmount + bookingDiscount : members.reduce((s, c) => s + (c.baseDue ?? c.amountDue), 0));
	const perPerson = members.length ? Math.round(grossBase / members.length) : grossBase;
	const grossSale = perPerson * (members.length || 1) + otherCosts;
	const totalSale = Math.max(0, grossSale - totalDiscount);
	const refunds = linked.filter((e) => e.type === "client_refund").reduce((s, e) => s + e.amount, 0);
	const netReceivable = Math.max(0, totalSale - refunds);
	const supplierRefunds = linked.filter((e) => e.type === "supplier_refund" && e.headId === headId).reduce((s, e) => s + e.amount, 0);
	const allocatedCost = headCostOf(entries, headId);
	const totalPurchase = Math.max(allocatedCost, booking?.totalCost || 0) - supplierRefunds;
	const originalCommission = booking?.commission || 0;
	let commission = originalCommission;
	if (booking && booking.agentId && booking.agentId !== "Direct" && booking.discountSettlement === "agent_commission") commission = Math.max(0, originalCommission - Math.min(originalCommission, bookingDiscount));
	const received = linked.filter((e) => e.type === "client_receive").reduce((s, e) => s + e.amount, 0);
	const supplierPaid = headSupplierPaid(entries, headId);
	const supplierRemaining = Math.max(0, Math.round(totalPurchase - supplierPaid));
	const allocatedPurchases = [];
	entries.forEach((e) => {
		if (e.type !== "purchase") return;
		purchaseAllocations(e).forEach((l) => {
			if (l.target === "head" && l.headId === headId) allocatedPurchases.push({
				entryId: e.id,
				date: e.date,
				supplier: e.referenceName || e.referenceId || "Supplier",
				service: e.serviceCategory || "Purchase",
				share: l.amount,
				ofTotal: e.amount
			});
		});
	});
	const memberList = members.map((c) => ({
		id: c.id,
		name: `${c.firstName} ${c.lastName}`.trim(),
		ageCategory: c.ageCategory,
		amount: c.amountDue,
		received: c.amountPaid,
		pending: Math.max(0, c.amountDue - c.amountPaid),
		status: c.paymentStatus
	}));
	const lead = members[0];
	return {
		headId,
		leadName: lead ? `${lead.firstName} ${lead.lastName}`.trim() : headId,
		members: members.length,
		perPerson,
		otherCosts,
		grossSale,
		discount: totalDiscount,
		totalSale,
		refunds,
		netReceivable,
		totalPurchase,
		commission,
		netProfit: netReceivable - totalPurchase - commission,
		received,
		outstanding: Math.max(0, netReceivable - received),
		supplierPaid,
		supplierRemaining,
		memberList,
		linked,
		allocatedPurchases
	};
}
function Kpi({ label, value, tone = "text-foreground" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border/60 bg-accent/10 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-1 text-sm font-semibold tabular-nums ${tone}`,
			children: value
		})]
	});
}
function Line({ label, value, sign = "", strong, tone = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between py-1.5 text-xs ${strong ? "border-t border-border/60 pt-2 text-sm font-bold" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: strong ? "" : "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `tabular-nums ${tone}`,
			children: [sign, formatCurrency(value)]
		})]
	});
}
/** Professional booking view: Members tab (per-person money) + Business Ledger tab (cost & profit). */
function BookingViewDialog({ headId, onClose }) {
	const store = useStore();
	const [tab, setTab] = (0, import_react.useState)("members");
	const booking = store.bookings.find((b) => b.headId === headId);
	const hb = (0, import_react.useMemo)(() => headId ? computeHeadBusiness(headId, store.clients, store.bookings, store.entries) : null, [
		headId,
		store.clients,
		store.bookings,
		store.entries
	]);
	if (!headId || !hb) return null;
	const linked = hb.linked;
	const gifts = linked.filter((e) => e.type === "gift" || e.type === "expense").reduce((s, e) => s + e.amount, 0);
	const agent = booking?.agentId ? store.agents.find((a) => a.id === booking.agentId) : null;
	const profit = hb.netProfit - gifts;
	const members = store.clients.filter((c) => c.headId === headId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!headId,
		onOpenChange: (o) => {
			if (!o) {
				onClose();
				setTab("members");
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90vh] max-w-3xl overflow-y-auto border-border bg-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex flex-wrap items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: headId
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-normal text-muted-foreground",
						children: [
							hb.leadName,
							" · ",
							booking?.packageType,
							" · ",
							booking?.travelDate,
							" · ",
							agent ? `Agent: ${agent.name}` : "Direct"
						]
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Net Receivable",
							value: formatCurrency(hb.netReceivable),
							tone: "text-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Received",
							value: formatCurrency(hb.received),
							tone: "text-success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Remaining",
							value: formatCurrency(hb.outstanding),
							tone: "text-destructive"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
							label: "Net Profit",
							value: formatCurrency(profit),
							tone: profit >= 0 ? "text-success" : "text-destructive"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-1 rounded-lg border border-border bg-accent/10 p-1",
					children: ["members", "business"].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(t),
						className: `rounded-md py-2 text-xs font-semibold ${tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
						children: t === "members" ? `Member Details (${members.length})` : "Business Ledger"
					}, t))
				}),
				tab === "members" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [members.map((c) => {
						const refunds = store.entries.filter((e) => e.type === "client_refund" && e.clientId === c.id).reduce((s, e) => s + e.amount, 0);
						const charges = store.entries.filter((e) => e.type === "client_charge" && e.clientId === c.id).reduce((s, e) => s + e.amount, 0);
						const ledger = store.entries.filter((e) => (e.clientId === c.id || e.referenceId === c.id) && [
							"client_receive",
							"client_charge",
							"client_refund"
						].includes(e.type)).sort((a, b) => a.date.localeCompare(b.date));
						const remaining = Math.max(0, c.amountDue - c.amountPaid);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border/60 bg-accent/5 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										children: getClientName(c)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] text-muted-foreground",
										children: [
											c.id,
											" · ",
											c.ageCategory || "Adult",
											" · ",
											c.gender,
											" · ",
											c.passport || "No passport"
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full border px-2 py-0.5 text-[10px] ${c.paymentStatus === "Paid" ? "border-success/40 text-success" : c.paymentStatus === "Partial" ? "border-warning/40 text-warning" : "border-destructive/40 text-destructive"}`,
										children: c.paymentStatus
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Package (per person)",
									value: c.baseDue ?? c.amountDue
								}),
								charges > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Extra charges",
									value: charges,
									sign: "+ "
								}),
								refunds > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Refunds",
									value: refunds,
									sign: "− ",
									tone: "text-destructive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Total Amount",
									value: c.amountDue,
									strong: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Received",
									value: c.amountPaid,
									tone: "text-success"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Remaining",
									value: remaining,
									tone: remaining > 0 ? "text-destructive" : "text-success"
								}),
								ledger.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 border-t border-border/40 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-[10px] uppercase tracking-wider text-muted-foreground",
										children: "Ledger"
									}), ledger.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-[10px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												e.date,
												" · ",
												e.type === "client_receive" ? "Received" : e.type === "client_refund" ? "Refund" : e.chargeCategory || "Charge"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: e.type === "client_receive" ? "text-success" : e.type === "client_refund" ? "text-destructive" : "",
											children: formatCurrency(e.amount)
										})]
									}, e.id))]
								})
							]
						}, c.id);
					}), members.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-6 text-center text-xs text-muted-foreground",
						children: "No members yet."
					})]
				}),
				tab === "business" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-primary/30 bg-primary/5 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Profit & Loss"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: `Sale (${hb.members} × ${formatCurrency(hb.perPerson)})`,
								value: hb.totalSale - hb.otherCosts
							}),
							hb.otherCosts > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Extra charges",
								value: hb.otherCosts,
								sign: "+ "
							}),
							hb.refunds > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Client refunds",
								value: hb.refunds,
								sign: "− "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Net Sale",
								value: hb.netReceivable,
								strong: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Supplier purchases",
								value: hb.totalPurchase,
								sign: "− ",
								tone: "text-warning"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: `Agent commission${agent ? ` (${agent.name})` : ""}`,
								value: hb.commission,
								sign: "− ",
								tone: "text-warning"
							}),
							gifts > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Gifts & expenses",
								value: gifts,
								sign: "− ",
								tone: "text-warning"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								label: "Net Profit",
								value: profit,
								strong: true,
								tone: profit >= 0 ? "text-success" : "text-destructive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 border-t border-border/40 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Supplier paid",
									value: hb.supplierPaid,
									tone: "text-success"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									label: "Supplier remaining",
									value: hb.supplierRemaining,
									tone: "text-destructive"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border/60 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
								children: "Cost Entries"
							}),
							linked.filter((e) => [
								"purchase",
								"supplier_refund",
								"gift",
								"expense"
							].includes(e.type)).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between border-b border-border/30 py-1.5 text-[11px] last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: e.type === "purchase" ? `Purchase — ${e.referenceName}` : e.type === "supplier_refund" ? `Supplier refund — ${e.referenceName}` : e.note || e.referenceName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: [e.date, e.serviceCategory].filter(Boolean).join(" · ")
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: e.type === "supplier_refund" ? "text-success" : "text-warning",
									children: [
										e.type === "supplier_refund" ? "+" : "−",
										" ",
										formatCurrency(e.amount)
									]
								})]
							}, e.id)),
							!linked.some((e) => [
								"purchase",
								"supplier_refund",
								"gift",
								"expense"
							].includes(e.type)) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-4 text-center text-[11px] text-muted-foreground",
								children: "No costs posted yet."
							})
						]
					})]
				})
			]
		})
	});
}
var emptyMember = {
	firstName: "",
	lastName: "",
	gender: "Male",
	ageCategory: "Adult",
	nationality: "",
	passport: "",
	cnic: "",
	dateOfBirth: "",
	dateOfIssue: "",
	dateOfExpire: "",
	phone: "",
	email: ""
};
function BookingsPage() {
	const store = useStore();
	const [viewHead, setViewHead] = (0, import_react.useState)(null);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [step, setStep] = (0, import_react.useState)(1);
	const [memberEditOpen, setMemberEditOpen] = (0, import_react.useState)(false);
	const [memberEdit, setMemberEdit] = (0, import_react.useState)(null);
	const [tabFilter, setTabFilter] = (0, import_react.useState)("active");
	const [lossDealsOnly, setLossDealsOnly] = (0, import_react.useState)(false);
	const [sortKey, setSortKey] = (0, import_react.useState)("date_desc");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const today = getPKTDate();
	const activeBookings = (0, import_react.useMemo)(() => store.bookings.filter((b) => !b.serviceCompleted), [store.bookings]);
	const completedBookings = (0, import_react.useMemo)(() => store.bookings.filter((b) => b.serviceCompleted), [store.bookings]);
	const activeCount = activeBookings.length;
	const completedCount = completedBookings.length;
	const allCount = store.bookings.length;
	const lossDealsCount = (0, import_react.useMemo)(() => {
		return store.bookings.filter((b) => computeBookingFinancials(b).isLoss).length;
	}, [store.bookings]);
	const filteredAndSortedBookings = (0, import_react.useMemo)(() => {
		const list = store.bookings.filter((b) => {
			if (tabFilter === "active" && b.serviceCompleted) return false;
			if (tabFilter === "completed" && !b.serviceCompleted) return false;
			if (lossDealsOnly) {
				if (!computeBookingFinancials(b).isLoss) return false;
			}
			if (searchQuery.trim()) {
				const q = searchQuery.toLowerCase().trim();
				const headMatch = b.headId.toLowerCase().includes(q);
				const pkgMatch = b.packageType.toLowerCase().includes(q);
				const agentMatch = b.agentId?.toLowerCase().includes(q) || false;
				const destMatch = b.destination?.toLowerCase().includes(q) || false;
				const clientMatch = store.clients.filter((c) => c.headId === b.headId).some((c) => `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) || c.passport && c.passport.toLowerCase().includes(q));
				if (!headMatch && !pkgMatch && !agentMatch && !destMatch && !clientMatch) return false;
			}
			return true;
		});
		return sortEntities(list, sortKey, {
			date: (b) => b.travelDate || b.createdAt,
			amount: (b) => b.totalAmount,
			name: (b) => b.headId
		});
	}, [
		store.bookings,
		store.clients,
		tabFilter,
		lossDealsOnly,
		sortKey,
		searchQuery
	]);
	const [form, setForm] = (0, import_react.useState)({
		agentId: "",
		supplierId: "",
		totalAmount: "",
		amountReceived: "",
		totalCost: "",
		commission: "",
		discount: "",
		discountSettlement: "agent_commission",
		supplierDiscount: "",
		packageType: "Umrah",
		status: "Pending",
		travelDate: "",
		adults: "1",
		children: "0",
		infants: "0",
		destination: "",
		driveLink: "",
		pricingMode: "total",
		adultPrice: "",
		childPrice: "",
		infantPrice: ""
	});
	const [memberForms, setMemberForms] = (0, import_react.useState)([]);
	const [memberIndex, setMemberIndex] = (0, import_react.useState)(0);
	const [groupMode, setGroupMode] = (0, import_react.useState)("none");
	const [groupId, setGroupId] = (0, import_react.useState)("");
	const [newGroup, setNewGroup] = (0, import_react.useState)({
		name: "",
		pnr: "",
		flightNumber: "",
		date: "",
		description: "",
		totalPax: ""
	});
	function resetForm() {
		setForm({
			agentId: "",
			supplierId: "",
			totalAmount: "",
			amountReceived: "",
			totalCost: "",
			commission: "",
			discount: "",
			discountSettlement: "agent_commission",
			supplierDiscount: "",
			packageType: "Umrah",
			status: "Pending",
			travelDate: "",
			adults: "1",
			children: "0",
			infants: "0",
			destination: "",
			driveLink: "",
			pricingMode: "total",
			adultPrice: "",
			childPrice: "",
			infantPrice: ""
		});
		setMemberForms([]);
		setMemberIndex(0);
		setStep(1);
		setGroupMode("none");
		setGroupId("");
		setNewGroup({
			name: "",
			pnr: "",
			flightNumber: "",
			date: "",
			description: "",
			totalPax: ""
		});
	}
	function goToStep2() {
		const adults = Math.max(0, Number(form.adults) || 0);
		const children = Math.max(0, Number(form.children) || 0);
		const infants = Math.max(0, Number(form.infants) || 0);
		const total = Math.max(1, adults + children + infants);
		const built = [];
		for (let i = 0; i < total; i++) {
			const existing = memberForms[i];
			const category = i < adults ? "Adult" : i < adults + children ? "Child" : "Infant";
			built.push(existing ? {
				...existing,
				ageCategory: category
			} : {
				...emptyMember,
				ageCategory: category
			});
		}
		setMemberForms(built);
		setMemberIndex(0);
		setStep(2);
	}
	function updateMember(index, field, value) {
		const arr = [...memberForms];
		arr[index] = {
			...arr[index],
			[field]: value
		};
		if (index === 0) {
			if ([
				"nationality",
				"phone",
				"email"
			].includes(field)) {
				for (let i = 1; i < arr.length; i++) if (!arr[i][field]) arr[i] = {
					...arr[i],
					[field]: value
				};
			}
		}
		setMemberForms(arr);
	}
	function handleAdd() {
		const headId = store.generateHeadId();
		const today = getPKTDate();
		const adultsCount = memberForms.filter((m) => m.ageCategory === "Adult").length;
		const childrenCount = memberForms.filter((m) => m.ageCategory === "Child").length;
		const infantsCount = memberForms.filter((m) => m.ageCategory === "Infant").length;
		const childPrice = Number(form.childPrice) || 0;
		const infantPrice = Number(form.infantPrice) || 0;
		let adultPrice = 0;
		let computedTotal = 0;
		if (form.pricingMode === "per_person") {
			adultPrice = Number(form.adultPrice) || 0;
			computedTotal = adultPrice * adultsCount + childPrice * childrenCount + infantPrice * infantsCount;
		} else {
			const totalEntered = Number(form.totalAmount) || 0;
			const adultPortion = Math.max(0, totalEntered - childPrice * childrenCount - infantPrice * infantsCount);
			adultPrice = adultsCount > 0 ? Math.round(adultPortion / adultsCount) : 0;
			computedTotal = totalEntered;
		}
		let finalGroupId = groupMode === "existing" ? groupId || void 0 : void 0;
		if (groupMode === "new" && newGroup.name.trim()) finalGroupId = store.addGroup({
			name: newGroup.name.trim(),
			category: "Booking",
			supplierId: form.supplierId || void 0,
			pnr: newGroup.pnr || void 0,
			flightNumber: newGroup.flightNumber || void 0,
			date: newGroup.date || form.travelDate || void 0,
			description: newGroup.description || void 0,
			totalPax: newGroup.totalPax ? Number(newGroup.totalPax) : void 0
		});
		const custDiscount = Number(form.discount) || 0;
		const grossTotal = computedTotal;
		const netCustomerTotal = Math.max(0, grossTotal - custDiscount);
		const bookingId = store.addBooking({
			headId,
			agentId: form.agentId,
			supplierId: form.supplierId,
			baseAmount: grossTotal,
			totalAmount: netCustomerTotal,
			amountReceived: Number(form.amountReceived) || 0,
			totalCost: Number(form.totalCost) || 0,
			commission: Number(form.commission) || 0,
			discount: custDiscount,
			discountSettlement: form.discountSettlement,
			supplierDiscount: Number(form.supplierDiscount) || 0,
			clientIds: [],
			status: form.status,
			packageType: form.packageType,
			travelDate: form.travelDate,
			createdAt: today,
			members: memberForms.length,
			destination: form.destination,
			driveLink: form.driveLink,
			groupId: finalGroupId
		});
		const clientIds = [];
		const membersCount = memberForms.length || 1;
		const childTotal = childPrice * childrenCount;
		const infantTotal = infantPrice * infantsCount;
		const adultNetPortion = Math.max(0, netCustomerTotal - childTotal - infantTotal);
		const adultNetPrice = adultsCount > 0 ? Math.floor(adultNetPortion / adultsCount) : 0;
		const adultRemainder = adultsCount > 0 ? adultNetPortion - adultNetPrice * adultsCount : 0;
		let adultIdx = 0;
		memberForms.forEach((m, i) => {
			let due = 0;
			let baseDue = 0;
			if (m.ageCategory === "Child") {
				due = childPrice;
				baseDue = childPrice;
			} else if (m.ageCategory === "Infant") {
				due = infantPrice;
				baseDue = infantPrice;
			} else {
				due = adultNetPrice + (adultIdx === 0 ? adultRemainder : 0);
				baseDue = adultPrice;
				adultIdx++;
			}
			if (adultsCount === 0) {
				const perMember = Math.floor(netCustomerTotal / membersCount);
				const rem = netCustomerTotal - perMember * membersCount;
				due = perMember + (i === 0 ? rem : 0);
				baseDue = Math.floor(grossTotal / membersCount);
			}
			const cid = store.addClient({
				headId,
				firstName: m.firstName || `Member`,
				lastName: m.lastName || `${i + 1}`,
				gender: m.gender,
				ageCategory: m.ageCategory,
				nationality: m.nationality || memberForms[0]?.nationality || "",
				passport: m.passport,
				cnic: m.cnic,
				dateOfBirth: m.dateOfBirth,
				dateOfIssue: m.dateOfIssue,
				dateOfExpire: m.dateOfExpire,
				phone: m.phone || memberForms[0]?.phone || "",
				email: m.email || memberForms[0]?.email || "",
				packageType: form.packageType,
				paymentStatus: "Unpaid",
				baseDue,
				amountDue: due,
				amountPaid: 0,
				isVip: false,
				destination: form.destination,
				driveLink: form.driveLink
			});
			clientIds.push(cid);
		});
		store.updateBooking(bookingId, { clientIds });
		if (Number(form.amountReceived) > 0) store.addEntry({
			date: today,
			type: "client_receive",
			headId,
			referenceId: headId,
			referenceName: `Booking ${headId}`,
			amount: Number(form.amountReceived),
			note: `Initial payment for ${headId}`
		});
		if (Number(form.totalCost) > 0 && form.supplierId) {
			const supplier = store.suppliers.find((s) => s.id === form.supplierId);
			store.addEntry({
				date: today,
				type: "supplier_payment",
				headId,
				referenceId: form.supplierId,
				referenceName: supplier?.companyName || form.supplierId,
				amount: Number(form.totalCost),
				note: `Supplier cost for ${headId}`
			});
		}
		if (Number(form.commission) > 0 && form.agentId && form.agentId !== "Direct") {
			const agent = store.agents.find((a) => a.id === form.agentId);
			if (agent) store.updateAgent(agent.id, {
				totalSales: agent.totalSales + (Number(form.totalAmount) || 0),
				totalClients: agent.totalClients + memberForms.length,
				commission: agent.commission + (Number(form.commission) || 0)
			});
		}
		if (Number(form.totalCost) > 0 && form.supplierId) {
			const supplier = store.suppliers.find((s) => s.id === form.supplierId);
			if (supplier) store.updateSupplier(supplier.id, { totalPayable: supplier.totalPayable + (Number(form.totalCost) || 0) });
		}
		resetForm();
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		const headId = selected.headId;
		const wanted = {
			Adult: Math.max(0, Number(form.adults) || 0),
			Child: Math.max(0, Number(form.children) || 0),
			Infant: Math.max(0, Number(form.infants) || 0)
		};
		[
			"Adult",
			"Child",
			"Infant"
		].forEach((cat) => {
			const existing = store.clients.filter((c) => c.headId === headId && (c.ageCategory || "Adult") === cat);
			if (existing.length > wanted[cat]) existing.slice(wanted[cat]).forEach((c) => store.deleteClient(c.id));
			else if (existing.length < wanted[cat]) {
				const lead = store.clients.find((c) => c.headId === headId);
				for (let i = existing.length; i < wanted[cat]; i++) store.addClient({
					headId,
					firstName: cat,
					lastName: String(i + 1),
					gender: "Male",
					ageCategory: cat,
					nationality: lead?.nationality || "",
					passport: "",
					cnic: "",
					dateOfBirth: "",
					dateOfIssue: "",
					dateOfExpire: "",
					phone: lead?.phone || "",
					email: lead?.email || "",
					packageType: form.packageType,
					paymentStatus: "Unpaid",
					amountDue: 0,
					amountPaid: 0,
					isVip: false,
					destination: form.destination,
					driveLink: form.driveLink
				});
			}
		});
		const cs = store.clients.filter((c) => c.headId === headId);
		const adults = cs.filter((c) => (c.ageCategory || "Adult") === "Adult");
		const children = cs.filter((c) => c.ageCategory === "Child");
		const infants = cs.filter((c) => c.ageCategory === "Infant");
		const childPrice = Number(form.childPrice) || 0;
		const infantPrice = Number(form.infantPrice) || 0;
		let adultPrice = 0;
		let computedTotal = 0;
		if (form.pricingMode === "per_person") {
			adultPrice = Number(form.adultPrice) || 0;
			computedTotal = adultPrice * adults.length + childPrice * children.length + infantPrice * infants.length;
		} else {
			computedTotal = Number(form.totalAmount) || 0;
			const rem = Math.max(0, computedTotal - childPrice * children.length - infantPrice * infants.length);
			adultPrice = adults.length > 0 ? Math.round(rem / adults.length) : 0;
		}
		let finalGroupId = groupMode === "existing" ? groupId || void 0 : groupMode === "none" ? void 0 : selected.groupId;
		if (groupMode === "new" && newGroup.name.trim()) finalGroupId = store.addGroup({
			name: newGroup.name.trim(),
			category: "Booking",
			supplierId: form.supplierId || void 0,
			pnr: newGroup.pnr || void 0,
			flightNumber: newGroup.flightNumber || void 0,
			date: newGroup.date || form.travelDate || void 0,
			description: newGroup.description || void 0,
			totalPax: newGroup.totalPax ? Number(newGroup.totalPax) : void 0
		});
		const custDiscount = Number(form.discount) || 0;
		const grossTotal = computedTotal;
		const netCustomerTotal = Math.max(0, grossTotal - custDiscount);
		store.updateBooking(selected.id, {
			agentId: form.agentId,
			supplierId: form.supplierId,
			baseAmount: grossTotal,
			totalAmount: netCustomerTotal,
			amountReceived: Number(form.amountReceived) || 0,
			totalCost: Number(form.totalCost) || 0,
			commission: Number(form.commission) || 0,
			discount: custDiscount,
			discountSettlement: form.discountSettlement,
			supplierDiscount: Number(form.supplierDiscount) || 0,
			packageType: form.packageType,
			status: form.status,
			travelDate: form.travelDate,
			destination: form.destination,
			driveLink: form.driveLink,
			groupId: finalGroupId,
			members: cs.length,
			clientIds: cs.map((c) => c.id)
		});
		const childTotal = childPrice * children.length;
		const infantTotal = infantPrice * infants.length;
		const adultNetPortion = Math.max(0, netCustomerTotal - childTotal - infantTotal);
		const adultNetPrice = adults.length > 0 ? Math.floor(adultNetPortion / adults.length) : 0;
		const adultRemainder = adults.length > 0 ? adultNetPortion - adultNetPrice * adults.length : 0;
		let remaining = Number(form.amountReceived) || 0;
		const ordered = [
			...adults,
			...children,
			...infants
		];
		let adultIdx = 0;
		ordered.forEach((c, idx) => {
			let due = 0;
			let baseDue = 0;
			if (c.ageCategory === "Child") {
				due = childPrice;
				baseDue = childPrice;
			} else if (c.ageCategory === "Infant") {
				due = infantPrice;
				baseDue = infantPrice;
			} else {
				due = adultNetPrice + (adultIdx === 0 ? adultRemainder : 0);
				baseDue = adultPrice;
				adultIdx++;
			}
			if (adults.length === 0) {
				const perMember = Math.floor(netCustomerTotal / (ordered.length || 1));
				const rem = netCustomerTotal - perMember * (ordered.length || 1);
				due = perMember + (idx === 0 ? rem : 0);
				baseDue = Math.floor(grossTotal / (ordered.length || 1));
			}
			let paid = 0;
			let status = "Unpaid";
			if (due <= 0) {
				paid = 0;
				status = "Paid";
			} else if (remaining >= due) {
				paid = due;
				remaining -= due;
				status = "Paid";
			} else if (remaining > 0) {
				paid = remaining;
				remaining = 0;
				status = "Partial";
			}
			store.updateClient(c.id, {
				baseDue: c.baseDue ?? baseDue,
				amountDue: due,
				amountPaid: paid,
				paymentStatus: status,
				packageType: form.packageType,
				destination: form.destination
			});
		});
		setEditOpen(false);
	}
	function openEdit(b) {
		const cs = store.clients.filter((c) => c.headId === b.headId);
		const adults = cs.filter((c) => (c.ageCategory || "Adult") === "Adult");
		const children = cs.filter((c) => c.ageCategory === "Child");
		const infants = cs.filter((c) => c.ageCategory === "Infant");
		setSelected(b);
		const grossSale = b.baseAmount ?? (b.discount ? b.totalAmount + b.discount : b.totalAmount);
		setForm({
			agentId: b.agentId,
			supplierId: b.supplierId,
			totalAmount: String(grossSale),
			amountReceived: String(b.amountReceived),
			totalCost: String(b.totalCost || 0),
			commission: String(b.commission || 0),
			discount: b.discount ? String(b.discount) : "",
			discountSettlement: b.discountSettlement || "agent_commission",
			supplierDiscount: b.supplierDiscount ? String(b.supplierDiscount) : "",
			packageType: b.packageType,
			status: b.status,
			travelDate: b.travelDate,
			adults: String(adults.length || b.members || 1),
			children: String(children.length),
			infants: String(infants.length),
			pricingMode: "total",
			adultPrice: String(adults[0]?.baseDue ?? adults[0]?.amountDue ?? 0),
			childPrice: String(children[0]?.baseDue ?? children[0]?.amountDue ?? 0),
			infantPrice: String(infants[0]?.baseDue ?? infants[0]?.amountDue ?? 0),
			destination: b.destination || "",
			driveLink: b.driveLink || ""
		});
		if (b.groupId) {
			setGroupMode("existing");
			setGroupId(b.groupId);
		} else {
			setGroupMode("none");
			setGroupId("");
		}
		setNewGroup({
			name: "",
			pnr: "",
			flightNumber: "",
			date: "",
			description: "",
			totalPax: ""
		});
		setEditOpen(true);
	}
	function downloadInvoice(b) {
		const clients = store.clients.filter((c) => c.headId === b.headId);
		const agent = store.agents.find((a) => a.id === b.agentId);
		const supplier = store.suppliers.find((s) => s.id === b.supplierId);
		generateInvoice(b, clients, agent, supplier);
	}
	function downloadPaymentHistory(b) {
		const fin = computeBookingFinancials(b);
		const related = store.entries.filter((e) => e.headId === b.headId && e.type === "client_receive");
		const totalReceived = related.reduce((s, e) => s + e.amount, 0);
		const stats = [[
			"Gross Package Price",
			formatCurrency(fin.grossSale),
			"ink"
		]];
		if (fin.discount > 0) {
			stats.push([
				"Client Discount",
				`-${formatCurrency(fin.discount)}`,
				"destructive"
			]);
			stats.push([
				"Net Customer Due",
				formatCurrency(fin.clientPayable),
				"ink"
			]);
		}
		stats.push([
			"Received",
			formatCurrency(totalReceived),
			"success"
		]);
		stats.push([
			"Pending Balance",
			formatCurrency(Math.max(0, fin.clientPayable - totalReceived)),
			"destructive"
		]);
		generatePaymentHistory(`Booking ${b.headId}`, [
			["Head ID", b.headId],
			["Package", b.packageType],
			["Travel Date", b.travelDate],
			["Members", String(b.members)]
		], related, stats);
	}
	const step1Fields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 max-h-[55vh] overflow-y-auto pr-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Head ID will be auto-generated"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Agent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
					value: form.agentId,
					onChange: (v) => setForm({
						...form,
						agentId: v
					}),
					placeholder: "Select Agent or Direct",
					options: [{
						value: "Direct",
						label: "Direct (No Agent)"
					}, ...store.agents.map((a) => ({
						value: a.id,
						label: `${a.id} — ${a.name}`,
						hint: a.phone
					}))],
					className: "mt-1"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Supplier"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
					value: form.supplierId,
					onChange: (v) => setForm({
						...form,
						supplierId: v
					}),
					placeholder: "Select Supplier",
					options: store.suppliers.map((s) => ({
						value: s.id,
						label: `${s.id} — ${s.companyName}`,
						hint: s.serviceType
					})),
					className: "mt-1"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Package Type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.packageType,
					onValueChange: (v) => setForm({
						...form,
						packageType: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-8 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: PACKAGE_TYPES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p,
						children: p
					}, p)) })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Status"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.status,
					onValueChange: (v) => setForm({
						...form,
						status: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-8 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Pending",
							children: "Pending"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Confirmed",
							children: "Confirmed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Cancelled",
							children: "Cancelled"
						})
					] })]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Travel Date"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: form.travelDate,
						onChange: (e) => setForm({
							...form,
							travelDate: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Adults"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0",
						value: form.adults,
						onChange: (e) => setForm({
							...form,
							adults: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Children"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0",
						value: form.children,
						onChange: (e) => setForm({
							...form,
							children: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Infants"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: "0",
						value: form.infants,
						onChange: (e) => setForm({
							...form,
							infants: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border/50 p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs font-semibold",
							children: "Pricing Mode"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1 rounded-md bg-accent/20 p-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setForm({
									...form,
									pricingMode: "total"
								}),
								className: `px-3 py-1 text-[11px] rounded ${form.pricingMode === "total" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
								children: "Total Package"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setForm({
									...form,
									pricingMode: "per_person"
								}),
								className: `px-3 py-1 text-[11px] rounded ${form.pricingMode === "per_person" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
								children: "Per Person"
							})]
						})]
					}),
					form.pricingMode === "total" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Total Amount"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.totalAmount,
								onChange: (e) => setForm({
									...form,
									totalAmount: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Child Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.childPrice,
								onChange: (e) => setForm({
									...form,
									childPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Infant Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.infantPrice,
								onChange: (e) => setForm({
									...form,
									infantPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Adult Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.adultPrice,
								onChange: (e) => setForm({
									...form,
									adultPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Child Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.childPrice,
								onChange: (e) => setForm({
									...form,
									childPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Infant Price (each)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: form.infantPrice,
								onChange: (e) => setForm({
									...form,
									infantPrice: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] })
						]
					}),
					(() => {
						const a = Math.max(0, Number(form.adults) || 0);
						const c = Math.max(0, Number(form.children) || 0);
						const inf = Math.max(0, Number(form.infants) || 0);
						const cp = Number(form.childPrice) || 0;
						const ip = Number(form.infantPrice) || 0;
						let adultEach = 0;
						let total = 0;
						if (form.pricingMode === "per_person") {
							adultEach = Number(form.adultPrice) || 0;
							total = adultEach * a + cp * c + ip * inf;
						} else {
							total = Number(form.totalAmount) || 0;
							const rem = Math.max(0, total - cp * c - ip * inf);
							adultEach = a > 0 ? Math.round(rem / a) : 0;
						}
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3 text-[10px] text-muted-foreground pt-1 border-t border-border/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Adult × ",
									a,
									" @ ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: formatCurrency(adultEach)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Child × ",
									c,
									" @ ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: formatCurrency(cp)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Infant × ",
									inf,
									" @ ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: formatCurrency(ip)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto font-semibold text-foreground",
									children: ["Total: ", formatCurrency(total)]
								})
							]
						});
					})(),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Amount Received (PKR)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: form.amountReceived,
						onChange: (e) => setForm({
							...form,
							amountReceived: e.target.value
						}),
						className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Total Cost (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.totalCost,
					onChange: (e) => setForm({
						...form,
						totalCost: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Commission (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.commission,
					onChange: (e) => setForm({
						...form,
						commission: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			(() => {
				const adultsCount = Math.max(0, Number(form.adults) || 0);
				const childrenCount = Math.max(0, Number(form.children) || 0);
				const infantsCount = Math.max(0, Number(form.infants) || 0);
				const cp = Number(form.childPrice) || 0;
				const ip = Number(form.infantPrice) || 0;
				let sale = 0;
				if (form.pricingMode === "per_person") sale = (Number(form.adultPrice) || 0) * adultsCount + cp * childrenCount + ip * infantsCount;
				else sale = Number(form.totalAmount) || 0;
				const custDiscount = Number(form.discount) || 0;
				const supDiscount = Number(form.supplierDiscount) || 0;
				const rawCost = Number(form.totalCost) || 0;
				const rawComm = Number(form.commission) || 0;
				const netCost = Math.max(0, rawCost - supDiscount);
				const isAgentBooking = Boolean(form.agentId && form.agentId !== "Direct");
				let agentAbsorbed = 0;
				let agencyAbsorbed = custDiscount;
				if (isAgentBooking && form.discountSettlement === "agent_commission") {
					agentAbsorbed = Math.min(rawComm, custDiscount);
					agencyAbsorbed = custDiscount - agentAbsorbed;
				}
				const netComm = Math.max(0, rawComm - agentAbsorbed);
				const netProfit = sale - agencyAbsorbed - netCost - netComm;
				const isLoss = netProfit < 0;
				const lossAmount = Math.abs(netProfit);
				const marginPct = sale > 0 ? netProfit / sale * 100 : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border/80 bg-gradient-to-b from-card/80 to-accent/10 p-3.5 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-border/40 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-foreground",
									children: "Discount & Margin Protection Engine"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: "Settle concessions from agent commission, capture supplier rebates, and isolate loss deals."
								})] })]
							}), isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-rose-500/15 border border-rose-500/40 px-2 py-0.5 text-[10px] font-bold text-rose-400 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3 w-3 text-rose-500 shrink-0" }), "Negative Margin"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-emerald-500/15 border border-emerald-500/40 px-2 py-0.5 text-[10px] font-semibold text-emerald-400 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3 w-3 text-emerald-400 shrink-0" }), "Protected Margin"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-[11px] font-medium flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Customer Concession (PKR)" }), custDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-amber-400 font-mono",
									children: ["-", formatCurrency(custDiscount)]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								value: form.discount,
								onChange: (e) => setForm({
									...form,
									discount: e.target.value
								}),
								placeholder: "e.g. 5000",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-[11px] font-medium flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Supplier Rebate / Disc (PKR)" }), supDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-emerald-400 font-mono",
									children: ["+", formatCurrency(supDiscount)]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								value: form.supplierDiscount,
								onChange: (e) => setForm({
									...form,
									supplierDiscount: e.target.value
								}),
								placeholder: "e.g. 3000",
								className: "bg-accent/20 border-border mt-1 h-8 text-xs"
							})] })]
						}),
						isAgentBooking && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border/50 bg-background/50 p-2.5 space-y-1.5 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold text-foreground",
										children: "Discount Settlement Method:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] text-muted-foreground font-mono",
										children: ["Agent Commission: ", formatCurrency(rawComm)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setForm({
											...form,
											discountSettlement: "agent_commission"
										}),
										className: `rounded-md p-2 text-left transition border text-[11px] ${form.discountSettlement === "agent_commission" ? "border-primary bg-primary/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/20 text-muted-foreground hover:bg-accent/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-foreground",
											children: "Settle from Agent Commission"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] text-muted-foreground",
											children: "Protects agency profit — agent absorbs concession."
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setForm({
											...form,
											discountSettlement: "agency_absorbed"
										}),
										className: `rounded-md p-2 text-left transition border text-[11px] ${form.discountSettlement === "agency_absorbed" ? "border-amber-500 bg-amber-500/15 font-semibold text-foreground shadow-sm" : "border-border/60 bg-accent/20 text-muted-foreground hover:bg-accent/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-foreground",
											children: "Agency Absorbs Concession"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[9px] text-muted-foreground",
											children: "Agency absorbs full discount; agent keeps commission."
										})]
									})]
								}),
								custDiscount > 0 && form.discountSettlement === "agent_commission" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-blue-400 font-medium",
									children: [
										"🛡️ Agent absorbs ",
										formatCurrency(agentAbsorbed),
										" · Agent net commission becomes ",
										formatCurrency(netComm),
										agencyAbsorbed > 0 && ` (Agency absorbs remaining ${formatCurrency(agencyAbsorbed)})`
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-lg p-2.5 space-y-1.5 ${isLoss ? "border border-rose-500/60 bg-rose-500/10 text-rose-200" : "border border-emerald-500/30 bg-emerald-500/10 text-emerald-200"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex items-center gap-1.5",
										children: isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-4 w-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-400",
											children: "NEGATIVE MARGIN LOSS DEAL"
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-emerald-400",
											children: "Projected Agency Net Margin"
										})] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `font-mono text-sm font-bold ${isLoss ? "text-rose-400" : "text-emerald-400"}`,
										children: [isLoss ? `-${formatCurrency(lossAmount)}` : formatCurrency(netProfit), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] ml-1 font-normal",
											children: [
												"(",
												marginPct.toFixed(1),
												"%)"
											]
										})]
									})]
								}),
								isLoss && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-rose-300 font-medium",
									children: [
										"⚠️ Alert: Costs (",
										formatCurrency(netCost),
										") and Agent Commission (",
										formatCurrency(netComm),
										") exceed the discounted sale price (",
										formatCurrency(sale - agencyAbsorbed),
										")!"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2 text-[10px] text-muted-foreground border-t border-border/30 pt-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Sale: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: formatCurrency(sale)
										})] }),
										custDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Disc: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
											className: "text-amber-400",
											children: ["-", formatCurrency(custDiscount)]
										})] }),
										supDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Sup Rebate: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
											className: "text-emerald-400",
											children: ["+", formatCurrency(supDiscount)]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Net Cost: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: formatCurrency(netCost)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Net Comm: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: formatCurrency(netComm)
										})] })
									]
								})
							]
						})
					]
				});
			})(),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Destination"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.destination,
				onChange: (e) => setForm({
					...form,
					destination: e.target.value
				}),
				placeholder: "Makkah / Madinah",
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Google Drive Link (optional)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.driveLink,
				onChange: (e) => setForm({
					...form,
					driveLink: e.target.value
				}),
				placeholder: "https://drive.google.com/...",
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-primary/40 bg-primary/5 p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
							children: "Group / PNR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted-foreground",
							children: "Link this booking to a shared supplier batch (flight PNR, hotel rooming, etc.)"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1 text-[10px]",
							children: [
								"none",
								"existing",
								"new"
							].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setGroupMode(m),
								className: `rounded px-2 py-1 font-medium transition ${groupMode === m ? "bg-primary text-primary-foreground" : "bg-accent/40 text-muted-foreground hover:bg-accent/60"}`,
								children: m === "none" ? "No Group" : m === "existing" ? "Add to Group" : "+ New Group"
							}, m))
						})]
					}),
					groupMode === "existing" && (() => {
						const list = form.supplierId ? store.groups.filter((g) => !g.supplierId || g.supplierId === form.supplierId) : store.groups;
						const requested = Math.max(1, (Number(form.adults) || 0) + (Number(form.children) || 0) + (Number(form.infants) || 0));
						const selected = list.find((g) => g.id === groupId);
						const used = selected ? computeGroupUsedPax(selected.id) : 0;
						const remaining = selected?.totalPax != null ? Math.max(0, selected.totalPax - used) : null;
						const overflow = selected?.totalPax != null && used + requested > selected.totalPax;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
								value: groupId,
								onChange: setGroupId,
								placeholder: list.length ? "Select existing group..." : "No groups yet — create a new one",
								options: list.map((g) => {
									const u = computeGroupUsedPax(g.id);
									const cap = g.totalPax != null ? ` · ${u}/${g.totalPax} used` : ` · ${u} used`;
									return {
										value: g.id,
										label: `${g.id} — ${g.name}`,
										hint: [
											g.category,
											g.pnr && `PNR ${g.pnr}`,
											g.flightNumber,
											g.date
										].filter(Boolean).join(" · ") + cap
									};
								}),
								className: "mt-1"
							}), selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex flex-wrap items-center gap-3 rounded-md px-3 py-2 text-[11px] ${overflow ? "bg-destructive/15 text-destructive" : "bg-accent/20 text-foreground"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Capacity:" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: selected.totalPax ?? "∞"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: ["Used: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: used
										})]
									}),
									remaining !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: ["Remaining: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: overflow ? "text-destructive" : "text-success",
											children: remaining
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-auto text-muted-foreground",
										children: ["This booking: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-foreground",
											children: requested
										})]
									}),
									overflow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-full font-semibold",
										children: "⚠ Exceeds group capacity"
									})
								]
							})]
						});
					})(),
					groupMode === "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Group Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: newGroup.name,
									onChange: (e) => setNewGroup({
										...newGroup,
										name: e.target.value
									}),
									placeholder: "Umrah Group Feb-26 / PK-234",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px]",
									children: "Total Persons (capacity)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "0",
									value: newGroup.totalPax,
									onChange: (e) => setNewGroup({
										...newGroup,
										totalPax: e.target.value
									}),
									placeholder: "e.g. 30",
									className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "PNR"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newGroup.pnr,
										onChange: (e) => setNewGroup({
											...newGroup,
											pnr: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Flight / Ref #"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newGroup.flightNumber,
										onChange: (e) => setNewGroup({
											...newGroup,
											flightNumber: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: newGroup.date,
										onChange: (e) => setNewGroup({
											...newGroup,
											date: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[10px]",
								children: "Description"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: newGroup.description,
								onChange: (e) => setNewGroup({
									...newGroup,
									description: e.target.value
								}),
								className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
							})] })
						]
					})
				]
			})
		]
	});
	const currentMember = memberForms[memberIndex];
	const step2Fields = currentMember ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 max-h-[55vh] overflow-y-auto pr-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between rounded-lg bg-accent/20 px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-semibold text-primary",
				children: [
					"Member ",
					memberIndex + 1,
					" of ",
					memberForms.length,
					" ",
					memberIndex === 0 && "(Head)"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1",
				children: memberForms.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-6 rounded-full ${i === memberIndex ? "bg-primary" : i < memberIndex ? "bg-primary/50" : "bg-border"}` }, i))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-border/50 p-3 space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Type"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: currentMember.ageCategory,
						onValueChange: (v) => updateMember(memberIndex, "ageCategory", v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "bg-accent/20 border-border mt-0.5 h-7 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Adult",
								children: "Adult"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Child",
								children: "Child"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Infant",
								children: "Infant"
							})
						] })]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Gender"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: currentMember.gender,
						onValueChange: (v) => updateMember(memberIndex, "gender", v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "bg-accent/20 border-border mt-0.5 h-7 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Male",
								children: "Male"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Female",
								children: "Female"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Custom",
								children: "Custom"
							})
						] })]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "First Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.firstName,
						onChange: (e) => updateMember(memberIndex, "firstName", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Last Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.lastName,
						onChange: (e) => updateMember(memberIndex, "lastName", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Nationality"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.nationality,
						onChange: (e) => updateMember(memberIndex, "nationality", e.target.value),
						placeholder: memberIndex > 0 ? "Auto from Member 1" : "e.g. Pakistani",
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Date of Birth"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: currentMember.dateOfBirth,
						onChange: (e) => updateMember(memberIndex, "dateOfBirth", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Passport Number"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.passport,
						onChange: (e) => updateMember(memberIndex, "passport", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "CNIC"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.cnic,
						onChange: (e) => updateMember(memberIndex, "cnic", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Date of Issue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: currentMember.dateOfIssue,
						onChange: (e) => updateMember(memberIndex, "dateOfIssue", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Date of Expire"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: currentMember.dateOfExpire,
						onChange: (e) => updateMember(memberIndex, "dateOfExpire", e.target.value),
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Contact"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.phone,
						onChange: (e) => updateMember(memberIndex, "phone", e.target.value),
						placeholder: memberIndex > 0 ? "Auto from Member 1" : "",
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[10px]",
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: currentMember.email,
						onChange: (e) => updateMember(memberIndex, "email", e.target.value),
						placeholder: memberIndex > 0 ? "Auto from Member 1" : "",
						className: "bg-accent/20 border-border mt-0.5 h-7 text-xs"
					})] })]
				})
			]
		})]
	}) : null;
	const editFormFields = step1Fields;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingViewDialog, {
				headId: viewHead,
				onClose: () => setViewHead(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Bookings (Head IDs)",
				subtitle: "Master booking management",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: (o) => {
						setAddOpen(o);
						if (!o) resetForm();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: resetForm,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Booking"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border max-w-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [step === 1 ? "Step 1: Booking Details" : "Step 2: Member Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-muted-foreground",
								children: "(Head ID: Auto-generated)"
							})] }) }),
							step === 1 ? step1Fields : step2Fields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: goToStep2,
									className: "w-full",
									children: "Next → Member Details"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => {
										if (memberIndex === 0) setStep(1);
										else setMemberIndex(memberIndex - 1);
									},
									className: "flex-1",
									children: memberIndex === 0 ? "← Booking Details" : "← Previous Member"
								}), memberIndex < memberForms.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => setMemberIndex(memberIndex + 1),
									className: "flex-1",
									children: "Next Member →"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: handleAdd,
									className: "flex-1",
									children: "Create Booking"
								})] })
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupSeatStrip, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 p-1 bg-accent/20 rounded-xl border border-border/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTabFilter("active"),
							className: `px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${tabFilter === "active" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Active Bookings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `px-1.5 py-0.2 rounded-full text-[10px] font-mono ${tabFilter === "active" ? "bg-primary-foreground/20 text-primary-foreground" : "bg-accent text-muted-foreground"}`,
								children: activeCount
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTabFilter("completed"),
							className: `px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${tabFilter === "completed" ? "bg-emerald-600 text-white shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Completed / Fulfilled" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.2 rounded-full text-[10px] font-mono ${tabFilter === "completed" ? "bg-white/20 text-white" : "bg-accent text-muted-foreground"}`,
									children: completedCount
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTabFilter("all"),
							className: `px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${tabFilter === "all" ? "bg-accent text-foreground shadow-sm font-semibold" : "text-muted-foreground hover:text-foreground"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "All Records" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-muted-foreground font-mono",
								children: [
									"(",
									allCount,
									")"
								]
							})]
						}),
						lossDealsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLossDealsOnly((prev) => !prev),
							className: `px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 border ml-1 ${lossDealsOnly ? "bg-rose-500/25 text-rose-300 border-rose-500/60 shadow-sm" : "bg-background/40 text-rose-400 border-rose-500/30 hover:bg-rose-500/10"}`,
							title: "Filter to isolate negative-margin loss bookings immediately",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3.5 w-3.5 text-rose-500 animate-pulse" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Loss Deals" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-1.5 py-0.2 rounded-full text-[10px] font-mono ${lossDealsOnly ? "bg-rose-500 text-white" : "bg-rose-500/20 text-rose-400"}`,
									children: lossDealsCount
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-w-[200px] flex-1 sm:flex-initial",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Search ID, client, passport...",
							className: "h-8 pl-8 text-xs bg-background/50 border-border/60"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBar, {
						value: sortKey,
						onChange: setSortKey,
						label: "Sort by:"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Head ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Package"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Members"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Agent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Total"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Received"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Pending"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Profit Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Fulfillment"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Travel"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filteredAndSortedBookings.map((b) => {
							const pending = b.totalAmount - b.amountReceived;
							const clients = store.clients.filter((c) => c.headId === b.headId);
							computeBookingProfit(b);
							const isEarned = b.profitStatus === "earned";
							const isFulfilled = Boolean(b.serviceCompleted);
							const isPastTravel = Boolean(b.travelDate && b.travelDate < today);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 transition-colors hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold text-primary",
										children: b.headId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: b.packageType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: clients.length
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground",
										children: b.agentId || "Direct"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 font-mono",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: formatCurrency(b.totalAmount) }), b.discount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-amber-400 font-sans",
											children: ["Disc: -", formatCurrency(b.discount)]
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-success font-mono",
										children: formatCurrency(b.amountReceived)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-destructive font-mono",
										children: formatCurrency(pending)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: (() => {
											const fin = computeBookingFinancials(b);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col gap-1 items-start",
												children: [
													fin.isLoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono font-bold text-xs text-rose-400 flex items-center gap-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonAlert, { className: "h-3 w-3 text-rose-500 shrink-0" }),
															"-",
															formatCurrency(fin.lossAmount)
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "rounded bg-rose-500/15 border border-rose-500/30 px-1.5 py-0.5 text-[9px] font-bold text-rose-400 uppercase tracking-wider",
														children: [
															"Loss Deal (",
															fin.marginPercent.toFixed(1),
															"%)"
														]
													})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-mono font-bold text-xs text-foreground",
														children: formatCurrency(fin.netProfit)
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-muted-foreground font-mono",
														children: [
															"(",
															fin.marginPercent.toFixed(1),
															"%)"
														]
													})] }),
													fin.discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-amber-400/90 font-mono",
														children: [
															"Disc: ",
															formatCurrency(fin.discount),
															" ",
															b.discountSettlement === "agent_commission" ? "(Agent)" : "(Agency)"
														]
													}),
													fin.supplierDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-emerald-400/90 font-mono",
														children: ["Rebate: +", formatCurrency(fin.supplierDiscount)]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => {
															store.toggleBookingProfitStatus(b.id);
															toast.success(isEarned ? `Reverted ${b.headId} to Unearned Profit` : `Converted ${b.headId} to Earned Actual Profit`);
														},
														className: `rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider transition ${isEarned ? "bg-success/20 text-success border border-success/40 hover:bg-success/30" : "bg-warning/20 text-warning border border-warning/40 hover:bg-warning/30"}`,
														title: "Click to toggle between Earned and Unearned",
														children: isEarned ? "✓ Earned" : "⏳ Unearned"
													})
												]
											});
										})()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: isFulfilled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold text-emerald-400 flex items-center gap-1 w-fit",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3 shrink-0" }), "Completed"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													store.toggleBookingCompleted(b.id);
													toast.success(`Reopened ${b.headId} back to Active Bookings`);
												},
												className: "text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 transition",
												title: "Reopen into Active bookings",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-2.5 w-2.5" }), " Reopen Active"]
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [isPastTravel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 text-[10px] font-bold text-amber-400 flex items-center gap-1 w-fit",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3 w-3 shrink-0" }), "Travelled"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded bg-accent/40 px-2 py-0.5 text-[10px] font-medium text-muted-foreground block w-fit",
												children: "Active Trip"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												variant: "outline",
												onClick: () => {
													store.toggleBookingCompleted(b.id);
													toast.success(`Marked ${b.headId} as Completed / Fulfilled`);
												},
												className: "h-6 px-2 text-[10px] gap-1 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-colors",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-2.5 w-2.5 text-emerald-500" }), "Mark Fulfilled"]
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: b.status })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground text-xs",
										children: b.travelDate
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setViewHead(b.headId),
													className: "rounded p-1 hover:bg-accent",
													title: "View booking",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3.5 w-3.5 text-primary" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => downloadInvoice(b),
													className: "rounded p-1 hover:bg-accent",
													title: "Download Invoice",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-3.5 w-3.5 text-success" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => downloadPaymentHistory(b),
													className: "rounded p-1 hover:bg-accent",
													title: "Payment History PDF",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingServicesMenu, {
													booking: b,
													clients
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoucherDownloadMenu, {
													booking: b,
													clients
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openEdit(b),
													className: "rounded p-1 hover:bg-accent",
													title: "Edit booking (completed bookings can be modified anytime)",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => store.deleteBooking(b.id),
													className: "rounded p-1 hover:bg-accent",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
												})
											]
										})
									})
								]
							}, b.id);
						}), filteredAndSortedBookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 12,
							className: "px-4 py-8 text-center text-xs text-muted-foreground",
							children: tabFilter === "active" ? "No active departures found. All bookings are currently fulfilled or filtered." : tabFilter === "completed" ? "No completed / fulfilled bookings yet." : "No bookings match your current search and filters."
						}) })] })]
					})
				})
			}),
			filteredAndSortedBookings.map((b) => {
				const clients = store.clients.filter((c) => c.headId === b.headId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: b.headId
								}),
								" — Clients (",
								clients.length,
								")"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									"Supplier: ",
									b.supplierId,
									" | Destination: ",
									b.destination || "—"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								className: "h-7 gap-1 text-[11px]",
								onClick: () => {
									const head = store.clients.find((c) => c.headId === b.headId);
									setMemberEdit({
										id: "",
										headId: b.headId,
										firstName: "",
										lastName: "",
										gender: "Male",
										ageCategory: "Adult",
										nationality: head?.nationality || "",
										passport: "",
										cnic: "",
										dateOfBirth: "",
										dateOfIssue: "",
										dateOfExpire: "",
										phone: head?.phone || "",
										email: head?.email || "",
										packageType: b.packageType,
										paymentStatus: "Unpaid",
										amountDue: 0,
										amountPaid: 0,
										isVip: false,
										destination: b.destination
									});
									setMemberEditOpen(true);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), " Add Member"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setMemberEdit({ ...c });
								setMemberEditOpen(true);
							},
							className: "flex items-center justify-between rounded-lg border border-border/50 bg-accent/10 px-4 py-3 text-left transition-colors hover:bg-accent/30 hover:border-primary/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium truncate",
										children: getClientName(c)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[9px] px-1.5 py-0.5 rounded-full uppercase tracking-wide ${c.ageCategory === "Child" ? "bg-warning/20 text-warning" : c.ageCategory === "Infant" ? "bg-blue-500/20 text-blue-400" : "bg-primary/20 text-primary"}`,
										children: c.ageCategory || "Adult"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										c.id,
										" · ",
										c.passport || "—"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										formatCurrency(c.amountPaid),
										" / ",
										formatCurrency(c.amountDue)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })]
							})]
						}, c.id))
					})]
				}, b.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Booking — ", selected?.headId] }) }),
						editFormFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: memberEditOpen,
				onOpenChange: setMemberEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
							memberEdit && !memberEdit.id ? "Add New Member" : "Edit Member",
							memberEdit && memberEdit.id ? ` — ${getClientName(memberEdit)}` : "",
							memberEdit && memberEdit.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-muted-foreground",
								children: memberEdit.id
							})
						] }) }),
						memberEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 max-h-[60vh] overflow-y-auto pr-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: memberEdit.ageCategory || "Adult",
										onValueChange: (v) => setMemberEdit({
											...memberEdit,
											ageCategory: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Adult",
												children: "Adult"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Child",
												children: "Child"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Infant",
												children: "Infant"
											})
										] })]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Gender"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: memberEdit.gender,
										onValueChange: (v) => setMemberEdit({
											...memberEdit,
											gender: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "bg-accent/20 border-border mt-0.5 h-8 text-xs",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Male",
												children: "Male"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Female",
												children: "Female"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Custom",
												children: "Custom"
											})
										] })]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "First Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.firstName,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											firstName: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Last Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.lastName,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											lastName: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Nationality"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.nationality,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											nationality: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date of Birth"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: memberEdit.dateOfBirth || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											dateOfBirth: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Passport"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.passport,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											passport: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "CNIC"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.cnic || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											cnic: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date of Issue"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: memberEdit.dateOfIssue || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											dateOfIssue: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Date of Expire"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: memberEdit.dateOfExpire || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											dateOfExpire: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Contact"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.phone,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											phone: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: memberEdit.email || "",
										onChange: (e) => setMemberEdit({
											...memberEdit,
											email: e.target.value
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Amount Due"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: memberEdit.amountDue,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											amountDue: Number(e.target.value) || 0
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px]",
										children: "Amount Paid"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: memberEdit.amountPaid,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											amountPaid: Number(e.target.value) || 0
										}),
										className: "bg-accent/20 border-border mt-0.5 h-8 text-xs"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "vip",
										type: "checkbox",
										checked: memberEdit.isVip,
										onChange: (e) => setMemberEdit({
											...memberEdit,
											isVip: e.target.checked
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "vip",
										className: "text-xs",
										children: "Mark as VIP"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								if (!memberEdit) return;
								const paid = memberEdit.amountPaid;
								const due = memberEdit.amountDue;
								const status = paid >= due && due > 0 ? "Paid" : paid > 0 ? "Partial" : "Unpaid";
								if (!memberEdit.id) {
									const { id: _omit, ...rest } = memberEdit;
									const newId = store.addClient({
										...rest,
										paymentStatus: status
									});
									const booking = store.bookings.find((bk) => bk.headId === memberEdit.headId);
									if (booking) store.updateBooking(booking.id, {
										clientIds: [...booking.clientIds, newId],
										members: (booking.members || booking.clientIds.length) + 1
									});
								} else store.updateClient(memberEdit.id, {
									...memberEdit,
									paymentStatus: status
								});
								setMemberEditOpen(false);
							},
							className: "w-full",
							children: "Save Member"
						})
					]
				})
			})
		]
	});
}
export { BookingsPage as component };
