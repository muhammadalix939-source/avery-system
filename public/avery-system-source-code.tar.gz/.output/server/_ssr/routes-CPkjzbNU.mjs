import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { C as Receipt, J as DollarSign, et as Clock, r as Users, u as TrendingUp, yt as BookOpen } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, o as useStore } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as StatusBadge } from "./StatusBadge-MNA5vWLW.mjs";
import { a as XAxis, c as CartesianGrid, d as Tooltip, i as YAxis, l as Pie, n as BarChart, o as Bar, p as ResponsiveContainer, t as PieChart, u as Cell } from "../_libs/recharts+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/routes-CPkjzbNU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StatsCard({ title, value, subtitle, icon: Icon, trend, delay = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		initial: {
			opacity: 0,
			y: 20
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			delay
		},
		className: "glass-card glass-card-hover rounded-xl p-4 md:p-5 transition-all duration-300",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 space-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs font-medium uppercase tracking-wider text-muted-foreground",
						title,
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-base font-bold text-foreground md:text-xl whitespace-nowrap tabular-nums tracking-tight truncate",
						title: value,
						children: value
					}),
					subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: subtitle
					}),
					trend && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: `text-xs font-medium ${trend.positive ? "text-success" : "text-destructive"}`,
						children: [
							trend.positive ? "↑" : "↓",
							" ",
							trend.value
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 border border-primary/20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-primary" })
			})]
		})
	});
}
var pieData = [
	{
		name: "Umrah",
		value: 45,
		color: "oklch(0.8 0.12 80)"
	},
	{
		name: "Hajj",
		value: 35,
		color: "oklch(0.7 0.15 155)"
	},
	{
		name: "Tour",
		value: 20,
		color: "oklch(0.6 0.15 280)"
	}
];
var monthOrder = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function Dashboard() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const store = useStore();
	const o = store.opening;
	const bookingHeadSet = new Set(store.bookings.map((b) => b.headId));
	const liveClientReceived = store.bookings.reduce((s, b) => s + (b.amountReceived || 0), 0) + store.entries.filter((e) => e.type === "client_receive" && !bookingHeadSet.has(e.headId)).reduce((s, e) => s + e.amount, 0);
	const livePurchases = store.entries.filter((e) => e.type === "purchase").reduce((s, e) => s + e.amount, 0);
	const liveSupplierPaid = store.entries.filter((e) => e.type === "supplier_payment").reduce((s, e) => s + e.amount, 0);
	const liveExpenses = store.entries.filter((e) => e.type === "expense").reduce((s, e) => s + e.amount, 0);
	const liveAgentCommissionPaid = store.entries.filter((e) => e.type === "agent_commission").reduce((s, e) => s + e.amount, 0);
	const clientRefunds = store.entries.filter((e) => e.type === "client_refund").reduce((s, e) => s + e.amount, 0);
	const supplierRefunds = store.entries.filter((e) => e.type === "supplier_refund").reduce((s, e) => s + e.amount, 0);
	const purchaseHeads = new Set(store.entries.filter((e) => e.type === "purchase" && e.headId).map((e) => e.headId));
	const bookingCostFallback = store.bookings.filter((b) => !purchaseHeads.has(b.headId)).reduce((s, b) => s + (b.totalCost || 0), 0);
	const totalBusinessCost = Math.max(0, livePurchases + bookingCostFallback - supplierRefunds);
	const agentCommissionEarned = store.bookings.reduce((s, b) => s + (b.commission || 0), 0);
	const bookedSales = store.bookings.reduce((s, b) => s + b.totalAmount, 0);
	const totalRevenue = liveClientReceived + (o.revenue || 0);
	const totalPending = Math.max(0, bookedSales + (o.pending || 0) - totalRevenue);
	const totalClients = store.clients.length + (o.clients || 0);
	const totalBookings = store.bookings.length + (o.bookings || 0);
	const supplierPayable = store.suppliers.reduce((s, sp) => s + Math.max(0, sp.totalPayable + (sp.openingPayable || 0) - (sp.totalPaid + (sp.openingPaid || 0))), 0) + (o.supplierDue || 0);
	const totalExpenses = liveExpenses;
	totalRevenue - totalBusinessCost - totalExpenses - agentCommissionEarned + (o.profit || 0);
	totalRevenue + supplierRefunds - liveSupplierPaid - totalExpenses - liveAgentCommissionPaid - clientRefunds;
	const hasAnyData = store.bookings.length > 0 || store.clients.length > 0 || store.entries.length > 0 || store.agents.length > 0 || store.suppliers.length > 0;
	const currentMonthIdx = (/* @__PURE__ */ new Date()).getMonth();
	const sortedMonthly = [...store.monthlyData].sort((a, b) => {
		const aIdx = monthOrder.indexOf(a.month);
		const bIdx = monthOrder.indexOf(b.month);
		return (currentMonthIdx - aIdx + 12) % 12 - (currentMonthIdx - bIdx + 12) % 12;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Dashboard",
				subtitle: "Overview of your travel business"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 md:gap-4 lg:grid-cols-3 xl:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCard, {
						title: "Total Revenue",
						value: formatCurrency(totalRevenue),
						icon: DollarSign,
						delay: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCard, {
						title: "Pending",
						value: formatCurrency(totalPending),
						icon: Clock,
						delay: .05
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCard, {
						title: "Active Bookings",
						value: String(totalBookings),
						subtitle: "Head IDs",
						icon: BookOpen,
						delay: .1
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCard, {
						title: "Total Clients",
						value: String(totalClients),
						icon: Users,
						delay: .15
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCard, {
						title: "Supplier Due",
						value: formatCurrency(supplierPayable),
						icon: TrendingUp,
						delay: .2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsCard, {
						title: "Expenses",
						value: formatCurrency(totalExpenses),
						icon: Receipt,
						delay: .25
					})
				]
			}),
			hasAnyData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: .3 },
					className: "glass-card rounded-xl lg:col-span-2 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold text-foreground",
						children: "Monthly Revenue"
					}), mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: 260,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: store.monthlyData,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									strokeDasharray: "3 3",
									stroke: "oklch(0.28 0.01 260)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "month",
									stroke: "oklch(0.6 0.02 260)",
									fontSize: 12
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									stroke: "oklch(0.6 0.02 260)",
									fontSize: 12,
									tickFormatter: (v) => `${(v / 1e3).toFixed(0)}k`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "oklch(0.17 0.01 260)",
									border: "1px solid oklch(0.28 0.01 260)",
									borderRadius: "8px",
									color: "oklch(0.95 0.01 80)"
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "revenue",
									fill: "oklch(0.8 0.12 80)",
									radius: [
										4,
										4,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "profit",
									fill: "oklch(0.7 0.15 155)",
									radius: [
										4,
										4,
										0,
										0
									]
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[260px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
						children: "Loading chart..."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: .35 },
					className: "glass-card rounded-xl p-5 flex flex-col justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold text-foreground",
								children: "Package Distribution"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] font-medium text-muted-foreground",
								children: [totalBookings, " Active"]
							})]
						}),
						mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex items-center justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: 200,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
									data: pieData,
									cx: "50%",
									cy: "50%",
									innerRadius: 54,
									outerRadius: 78,
									paddingAngle: 4,
									dataKey: "value",
									stroke: "none",
									children: pieData.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: entry.color }, index))
								}) })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl font-bold text-foreground tracking-tight leading-none",
									children: totalBookings || 100
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-wider text-muted-foreground mt-1 font-medium",
									children: "Bookings"
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-[200px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
							children: "Loading chart..."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex justify-center gap-2.5 flex-wrap",
							children: pieData.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-xs text-muted-foreground bg-accent/25 px-2.5 py-1 rounded-full border border-border/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 w-2 rounded-full shrink-0",
										style: { background: entry.color }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: entry.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground font-mono",
										children: [
											"(",
											entry.value,
											"%)"
										]
									})
								]
							}, entry.name))
						})
					]
				})]
			}),
			hasAnyData && sortedMonthly.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .4 },
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-semibold text-foreground",
							children: "Monthly Financial Records"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary/10 border border-primary/30 px-2 py-0.5 text-[10px] font-semibold text-primary",
							children: "FY 2026"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Month-by-month revenue, client throughput, and gross profit breakdown"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border/60 bg-card/60 px-3 py-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground text-[10px] uppercase block",
								children: "Year-to-date Revenue"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-foreground font-display text-sm",
								children: formatCurrency(sortedMonthly.reduce((s, m) => s + m.revenue, 0))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border/60 bg-card/60 px-3 py-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground text-[10px] uppercase block",
								children: "Net Profit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-success font-display text-sm",
								children: formatCurrency(sortedMonthly.reduce((s, m) => s + m.profit, 0))
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-lg border border-border/50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border bg-muted/30 text-left text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Month"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Clients"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Volume Share"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Revenue"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Profit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Margin"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border/40",
							children: sortedMonthly.map((m, i) => {
								const maxRev = Math.max(...sortedMonthly.map((x) => x.revenue), 1);
								const pctOfMax = Math.round(m.revenue / maxRev * 100);
								const margin = m.revenue > 0 ? Math.round(m.profit / m.revenue * 100) : 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: `transition-colors hover:bg-accent/40 ${i === 0 ? "bg-primary/5 font-medium" : ""}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-medium text-foreground",
													children: [m.month, " 2026"]
												}), i === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 text-[9px] font-bold text-emerald-400",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" }), "CURRENT"]
												})]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center rounded-md bg-secondary/60 px-2 py-0.5 text-xs text-foreground font-medium",
												children: [m.clients, " pax"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-24 sm:w-32 bg-secondary/50 rounded-full h-1.5 overflow-hidden",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "bg-primary h-full rounded-full transition-all",
													style: { width: `${pctOfMax}%` }
												})
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-right font-semibold text-primary font-mono tabular-nums",
											children: formatCurrency(m.revenue)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-right font-semibold text-success font-mono tabular-nums",
											children: formatCurrency(m.profit)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-block rounded px-1.5 py-0.5 text-[11px] font-semibold text-muted-foreground bg-muted font-mono",
												children: [margin, "%"]
											})
										})
									]
								}, m.month);
							})
						})]
					})
				})]
			}),
			hasAnyData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: .45 },
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold text-foreground",
						children: "Recent Bookings"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [store.bookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg bg-accent/20 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: b.headId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									b.packageType,
									" · ",
									b.clientIds.length,
									" clients"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-primary",
									children: formatCurrency(b.amountReceived)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: b.status })]
							})]
						}, b.id)), store.bookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "No bookings yet."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: .5 },
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold text-foreground",
						children: "Agent Performance"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [store.agents.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg bg-accent/20 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: a.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									a.id,
									" · ",
									a.totalClients + (a.openingClients || 0),
									" clients"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-primary",
									children: formatCurrency(a.totalSales + (a.openingSales || 0))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: ["Commission: ", formatCurrency(a.commission + (a.openingCommission || 0))]
								})]
							})]
						}, a.id)), store.agents.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "No agents yet."
						})]
					})]
				})]
			}),
			!hasAnyData && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass-card rounded-xl p-10 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No data yet. Add a booking, client, agent or entry to see live insights."
				})
			})
		]
	});
}
export { Dashboard as component };
