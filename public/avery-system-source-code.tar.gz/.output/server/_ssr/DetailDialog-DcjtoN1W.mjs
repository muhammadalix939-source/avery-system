import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { J as DollarSign, Tt as ArrowLeft, W as FileText, q as Download, r as Users, st as ChevronRight } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, w as getClientName } from "./router-2ATn7EQ0.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { t as StatusBadge } from "./StatusBadge-MNA5vWLW.mjs";
import { c as generateSupplierLedger, n as generateClientStatement, o as generatePaymentHistory, t as generateAgentReport } from "./pdf-DqNVIsfR.mjs";
import { t as agentOtherSaleRows } from "./allocations-CV2mwFEX.mjs";
import { t as ClientChecklistPanel } from "./ClientChecklistPanel-DESLP8C7.mjs";
// node_modules/.nitro/vite/services/ssr/assets/DetailDialog-DcjtoN1W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DetailDialog({ open, onOpenChange, type, data, entries = [], allClients = [], allBookings = [] }) {
	const [subView, setSubView] = (0, import_react.useState)("main");
	const [selectedClient, setSelectedClient] = (0, import_react.useState)(null);
	const [includeOpening, setIncludeOpening] = (0, import_react.useState)(true);
	if (!data) return null;
	function handleClose(o) {
		if (!o) {
			setSubView("main");
			setSelectedClient(null);
		}
		onOpenChange(o);
	}
	function handleDownload() {
		if (!data) return;
		if (type === "client") generateClientStatement(data, entries);
		if (type === "supplier") generateSupplierLedger(data, entries);
		if (type === "agent") generateAgentReport(data, entries, {
			bookings: allBookings,
			clients: allClients
		});
	}
	function handleHistory() {
		if (!data) return;
		if (type === "client") {
			const c = data;
			generatePaymentHistory(`Client ${c.id}`, [
				["Client ID", c.id],
				["Name", getClientName(c)],
				["Head ID", c.headId],
				["Phone", c.phone]
			], entries.filter((e) => e.type === "client_receive"), [
				[
					"Total Due",
					formatCurrency(c.amountDue),
					"ink"
				],
				[
					"Paid",
					formatCurrency(c.amountPaid),
					"success"
				],
				[
					"Remaining",
					formatCurrency(c.amountDue - c.amountPaid),
					"destructive"
				]
			]);
		}
		if (type === "supplier") {
			const s = data;
			const payable = s.totalPayable + (s.openingPayable || 0);
			const paid = s.totalPaid + (s.openingPaid || 0);
			generatePaymentHistory(`Supplier ${s.id}`, [
				["Supplier ID", s.id],
				["Company", s.companyName],
				["Contact", s.contactPerson]
			], entries.filter((e) => e.type === "supplier_payment"), [
				[
					"Payable",
					formatCurrency(payable),
					"ink"
				],
				[
					"Paid",
					formatCurrency(paid),
					"success"
				],
				[
					"Remaining",
					formatCurrency(payable - paid),
					"destructive"
				]
			]);
		}
		if (type === "agent") {
			const a = data;
			generatePaymentHistory(`Agent ${a.id}`, [
				["Agent ID", a.id],
				["Name", a.name],
				["Phone", a.phone]
			], entries.filter((e) => e.type === "agent_commission" && e.referenceId === a.id), [
				[
					"Commission",
					formatCurrency(a.commission),
					"ink"
				],
				[
					"Paid",
					formatCurrency(a.paidCommission || 0),
					"success"
				],
				[
					"Payable",
					formatCurrency((a.commission || 0) - (a.paidCommission || 0)),
					"destructive"
				]
			]);
		}
	}
	function getAgentStats(a) {
		const agentBookings = allBookings.filter((b) => b.agentId === a.id);
		const agentClients = allClients.filter((c) => agentBookings.some((b) => b.headId === c.headId));
		const otherSaleList = agentOtherSaleRows(entries, a.id);
		const otherSaleTotal = otherSaleList.reduce((s, r) => s + r.sale, 0);
		const otherSaleCost = otherSaleList.reduce((s, r) => s + r.cost, 0);
		const totalSales = agentBookings.reduce((s, b) => s + b.totalAmount, 0) + (a.openingSales || 0) + otherSaleTotal;
		const totalCommission = agentBookings.reduce((s, b) => s + (b.commission || 0), 0) + (a.openingCommission || 0);
		const paidCommission = entries.filter((e) => e.type === "agent_commission" && e.referenceId === a.id).reduce((s, e) => s + e.amount, 0) + (a.openingPaidCommission || 0);
		const received = agentBookings.reduce((s, b) => s + (b.amountReceived || 0), 0) + entries.filter((e) => e.type === "agent_receive" && e.referenceId === a.id).reduce((s, e) => s + e.amount, 0);
		const netReceivable = Math.max(0, totalSales - totalCommission);
		return {
			agentBookings,
			agentClients,
			totalSales,
			totalCommission,
			paidCommission,
			otherSaleList,
			otherSaleTotal,
			otherSaleCost,
			payable: totalCommission - paidCommission,
			received,
			netReceivable,
			outstanding: netReceivable - received
		};
	}
	function getSupplierStats(s) {
		const supplierBookings = allBookings.filter((b) => b.supplierId === s.id);
		const purchaseTotal = entries.filter((e) => e.type === "purchase" && e.referenceId === s.id).reduce((sum, e) => sum + e.amount, 0);
		const bookingCostTotal = supplierBookings.reduce((sum, b) => sum + (b.totalCost || 0), 0);
		const totalCost = Math.max(s.totalPayable || 0, purchaseTotal || 0, bookingCostTotal || 0) + (s.openingPayable || 0);
		const totalPaid = entries.filter((e) => e.type === "supplier_payment" && e.referenceId === s.id).reduce((sum, e) => sum + e.amount, 0) + (s.openingPaid || 0);
		return {
			supplierBookings,
			totalCost,
			totalPaid,
			remaining: totalCost - totalPaid
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: handleClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[85vh] overflow-y-auto bg-card border-border max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [
					subView !== "main" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setSubView("main");
							setSelectedClient(null);
						},
						className: "gap-1 text-xs px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3.5 w-3.5" }), " Back"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-primary text-sm flex-1",
						children: subView === "statement" ? `Statement — ${type === "supplier" ? data.companyName : type === "agent" ? data.name : getClientName(data)}` : subView === "client-detail" && selectedClient ? `${getClientName(selectedClient)}` : subView === "clients" && type === "agent" ? `Clients of ${data.name}` : subView === "othersale" && type === "agent" ? `Other Sale — ${data.name}` : subView === "business" && type === "agent" ? `Business Account — ${data.name}` : subView === "bookings" && type === "supplier" ? `Bookings — ${data.companyName}` : type === "client" ? `Client: ${getClientName(data)}` : type === "agent" ? `Agent: ${data.name}` : type === "supplier" ? `Supplier: ${data.companyName}` : `Booking: ${data.headId}`
					}),
					type !== "booking" && subView === "main" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setSubView("statement"),
								className: "gap-1.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-3.5 w-3.5" }), " View"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: handleDownload,
								className: "gap-1.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), " Statement"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: handleHistory,
								className: "gap-1.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), " History"]
							})
						]
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 text-sm",
				children: [
					subView === "main" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						type === "client" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [renderClient(data), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientChecklistPanel, { client: data })] }),
						type === "agent" && renderAgentFull(data, getAgentStats(data), () => setSubView("clients"), () => setSubView("business"), () => setSubView("othersale")),
						type === "supplier" && renderSupplierFull(data, getSupplierStats(data), () => setSubView("bookings")),
						type === "booking" && renderBooking(data),
						entries.length > 0 && type === "agent" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerBlock, {
							title: "Client Business Ledger",
							hint: "Every client transaction of the bookings this agent brought — receipts, extra charges and refunds.",
							rows: entries.filter((e) => e.type === "client_receive" || e.type === "client_charge" || e.type === "client_refund")
						}) }),
						entries.length > 0 && type !== "agent" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerBlock, {
							title: "Transaction History",
							rows: entries
						})
					] }),
					subView === "clients" && type === "agent" && (() => {
						const stats = getAgentStats(data);
						const grouped = /* @__PURE__ */ new Map();
						stats.agentClients.forEach((c) => {
							if (!grouped.has(c.headId)) grouped.set(c.headId, []);
							grouped.get(c.headId).push(c);
						});
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									stats.agentClients.length,
									" total clients across ",
									grouped.size,
									" bookings"
								]
							}), Array.from(grouped.entries()).map(([headId, members]) => {
								const booking = allBookings.find((b) => b.headId === headId);
								const totalPaid = members.reduce((s, c) => s + c.amountPaid, 0);
								const totalDue = members.reduce((s, c) => s + c.amountDue, 0);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border/50 p-3 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-primary",
											children: headId
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-muted-foreground",
											children: [
												members.length,
												" members · ",
												booking?.packageType || "",
												" · ",
												booking?.destination || ""
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right text-[10px]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Total: ", formatCurrency(booking?.totalAmount || totalDue)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-success",
												children: ["Paid: ", formatCurrency(totalPaid)]
											})]
										})]
									}), members.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => {
											setSelectedClient(c);
											setSubView("client-detail");
										},
										className: "flex items-center justify-between rounded bg-accent/20 px-3 py-2 cursor-pointer hover:bg-accent/40 transition-colors",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium",
											children: getClientName(c)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-muted-foreground",
											children: [
												c.id,
												" · ",
												c.passport
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 text-muted-foreground" })]
										})]
									}, c.id))]
								}, headId);
							})]
						});
					})(),
					subView === "othersale" && type === "agent" && (() => {
						const stats = getAgentStats(data);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
										label: "Other Sale",
										value: formatCurrency(stats.otherSaleTotal),
										color: "text-primary"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
										label: "Purchase Cost",
										value: formatCurrency(stats.otherSaleCost),
										color: "text-warning"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
										label: "Profit",
										value: formatCurrency(stats.otherSaleTotal - stats.otherSaleCost),
										color: "text-success"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border border-border/50 p-3 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
										children: "Other Sale Entries"
									}),
									stats.otherSaleList.map((row, idx) => {
										const e = row.entry;
										const sale = row.sale;
										const cost = row.cost;
										const isSplit = row.line && row.line.amount !== e.amount;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between rounded bg-accent/20 px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-medium",
												children: row.line?.forClientName || e.forClientName || e.note || e.referenceName
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-muted-foreground",
												children: [[
													e.date,
													e.serviceCategory,
													e.type === "purchase" ? `Supplier: ${e.referenceName}` : "Direct"
												].filter(Boolean).join(" · "), isSplit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "block text-[9.5px] text-primary/80",
													children: [
														"Share of ",
														e.id,
														" (",
														formatCurrency(row.line.amount),
														" of ",
														formatCurrency(e.amount),
														" cost)"
													]
												})]
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-right text-[10px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Sale: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-primary",
													children: formatCurrency(sale)
												})] }), cost > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													"Cost: ",
													formatCurrency(cost),
													" · Profit: ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-success",
														children: formatCurrency(sale - cost)
													})
												] })]
											})]
										}, `${e.id}-${row.line?.id || idx}`);
									}),
									stats.otherSaleList.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "py-2 text-center text-[11px] text-muted-foreground",
										children: "No other sale yet. Post a Purchase entry \"For Agent\" to add one."
									})
								]
							})]
						});
					})(),
					subView === "business" && type === "agent" && (() => {
						const stats = getAgentStats(data);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-primary/30 bg-primary/5 p-3 space-y-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
											children: "Business Account (Receivable from Agent)"
										}),
										stats.otherSaleTotal > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "incl. Other Sale"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: formatCurrency(stats.otherSaleTotal)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Gross Sale"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: formatCurrency(stats.totalSales)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Less: Agent Commission"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-destructive",
												children: ["− ", formatCurrency(stats.totalCommission)]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between border-t border-border/50 pt-1.5 text-xs font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Net Receivable" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-primary",
												children: formatCurrency(stats.netReceivable)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "Received"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-success",
												children: formatCurrency(stats.received)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between border-t border-border/50 pt-1.5 text-sm font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Remaining" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: stats.outstanding > 0 ? "text-destructive" : "text-success",
												children: formatCurrency(stats.outstanding)
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
											label: "Bookings",
											value: String(stats.agentBookings.length)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
											label: "Clients",
											value: String(stats.agentClients.length)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
											label: "Commission Payable",
											value: formatCurrency(stats.payable),
											color: "text-destructive"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border/50 p-3 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
											children: "Booking-wise Receivable"
										}),
										stats.agentBookings.map((b) => {
											const net = Math.max(0, (b.totalAmount || 0) - (b.commission || 0));
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between rounded bg-accent/20 px-3 py-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-medium",
													children: b.headId
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] text-muted-foreground",
													children: [b.packageType, b.destination].filter(Boolean).join(" · ")
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-right text-[10px]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Net: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-semibold text-primary",
														children: formatCurrency(net)
													})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
														"Received: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-success",
															children: formatCurrency(b.amountReceived || 0)
														}),
														" · Due: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-destructive",
															children: formatCurrency(Math.max(0, net - (b.amountReceived || 0)))
														})
													] })]
												})]
											}, b.id);
										}),
										stats.agentBookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "py-2 text-center text-[11px] text-muted-foreground",
											children: "No bookings brought by this agent yet."
										})
									]
								})
							]
						});
					})(),
					subView === "bookings" && type === "supplier" && (() => {
						const stats = getSupplierStats(data);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [stats.supplierBookings.length, " bookings"]
							}), stats.supplierBookings.map((b) => {
								const members = allClients.filter((c) => c.headId === b.headId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border/50 p-3 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-primary",
												children: b.headId
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-muted-foreground",
												children: [
													b.packageType,
													" · ",
													b.destination || "",
													" · ",
													b.members,
													" members"
												]
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-right text-[10px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Cost: ", formatCurrency(b.totalCost || 0)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Amount: ", formatCurrency(b.totalAmount)] })]
											})]
										}),
										members.slice(0, 3).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => {
												setSelectedClient(c);
												setSubView("client-detail");
											},
											className: "flex items-center justify-between rounded bg-accent/20 px-3 py-2 cursor-pointer hover:bg-accent/40 transition-colors text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												getClientName(c),
												" — ",
												c.id
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-muted-foreground" })]
										}, c.id)),
										members.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-muted-foreground text-center",
											children: [
												"+",
												members.length - 3,
												" more"
											]
										})
									]
								}, b.id);
							})]
						});
					})(),
					subView === "client-detail" && selectedClient && renderClient(selectedClient),
					subView === "statement" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementView, {
						type,
						data,
						entries,
						includeOpening,
						onToggleOpening: setIncludeOpening,
						onDownload: handleDownload
					})
				]
			})]
		})
	});
}
function Row({ label, value, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between border-b border-border/30 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `font-medium ${color || ""}`,
			children: value
		})]
	});
}
var ENTRY_LABELS = {
	client_receive: "Payment Received",
	client_charge: "Extra Charge",
	client_refund: "Refund to Client",
	supplier_payment: "Supplier Payment",
	supplier_refund: "Refund from Supplier",
	agent_commission: "Commission Paid",
	purchase: "Purchase",
	expense: "Expense"
};
var INFLOW = /* @__PURE__ */ new Set(["client_receive", "supplier_refund"]);
function LedgerBlock({ title, hint, rows }) {
	if (rows.length === 0) return null;
	const total = rows.reduce((s, e) => s + (INFLOW.has(e.type) ? e.amount : -e.amount), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `text-xs font-bold ${total >= 0 ? "text-success" : "text-destructive"}`,
				children: [total >= 0 ? "+" : "-", formatCurrency(Math.abs(total))]
			})]
		}),
		hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-[10px] text-muted-foreground",
			children: hint
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: rows.map((e) => {
				const inflow = INFLOW.has(e.type);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between rounded-lg bg-accent/20 px-3 py-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate font-medium",
							children: [ENTRY_LABELS[e.type] || e.type, e.note ? ` — ${e.note}` : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-muted-foreground",
							children: [
								e.date,
								e.headId,
								e.chargeCategory,
								e.serviceCategory
							].filter(Boolean).join(" · ")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `shrink-0 pl-2 ${inflow ? "text-success" : "text-destructive"}`,
						children: [inflow ? "+" : "-", formatCurrency(e.amount)]
					})]
				}, e.id);
			})
		})
	] });
}
function StatCard({ label, value, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-accent/20 p-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `text-sm font-bold ${color || ""}`,
			children: value
		})]
	});
}
function renderClient(c) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Client ID",
			value: c.id
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Head ID",
			value: c.headId
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "First Name",
			value: c.firstName
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Last Name",
			value: c.lastName
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Gender",
			value: c.gender
		}),
		c.nationality && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Nationality",
			value: c.nationality
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Passport",
			value: c.passport
		}),
		c.cnic && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "CNIC",
			value: c.cnic
		}),
		c.dateOfBirth && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Date of Birth",
			value: c.dateOfBirth
		}),
		c.dateOfIssue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Date of Issue",
			value: c.dateOfIssue
		}),
		c.dateOfExpire && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Date of Expire",
			value: c.dateOfExpire
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Phone",
			value: c.phone
		}),
		c.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Email",
			value: c.email
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Package",
			value: c.packageType
		}),
		c.destination && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Destination",
			value: c.destination
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Amount Due",
			value: formatCurrency(c.amountDue)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Amount Paid",
			value: formatCurrency(c.amountPaid),
			color: "text-success"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Remaining",
			value: formatCurrency(c.amountDue - c.amountPaid),
			color: "text-destructive"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between border-b border-border/30 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Status"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "VIP",
			value: c.isVip ? "⭐ Yes" : "No"
		}),
		c.driveLink && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Drive Link",
			value: c.driveLink
		})
	] });
}
function renderAgentFull(a, stats, onViewClients, onViewBusiness, onViewOtherSale) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Agent ID",
			value: a.id
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Name",
			value: a.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Phone",
			value: a.phone
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Email",
			value: a.email
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between border-b border-border/30 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Status"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: a.status })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2 pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total Sales",
					value: formatCurrency(stats.totalSales),
					color: "text-primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total Clients",
					value: String(stats.agentClients.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Bookings",
					value: String(stats.agentBookings.length)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Net Receivable",
					value: formatCurrency(stats.netReceivable),
					color: "text-primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Received",
					value: formatCurrency(stats.received),
					color: "text-success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Remaining",
					value: formatCurrency(stats.outstanding),
					color: "text-destructive"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentServices, {
			bookings: stats.agentBookings,
			otherRows: stats.otherSaleRows || []
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onViewClients,
					variant: "outline",
					className: "w-full gap-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5" }),
						" View All Clients (",
						stats.agentClients.length,
						") ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 ml-auto" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onViewBusiness,
					variant: "outline",
					className: "w-full gap-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-3.5 w-3.5" }),
						" View Business Account ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 ml-auto" })
					]
				}),
				onViewOtherSale && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: onViewOtherSale,
					variant: "outline",
					className: "w-full gap-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-3.5 w-3.5" }),
						" View Other Sale ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 ml-auto" })
					]
				})
			]
		})
	] });
}
function renderSupplierFull(s, stats, onViewBookings) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Supplier ID",
			value: s.id
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Company",
			value: s.companyName
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Contact",
			value: s.contactPerson
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Phone",
			value: s.phone
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Email",
			value: s.email
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Service Type",
			value: s.serviceType
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2 pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total Cost",
					value: formatCurrency(stats.totalCost),
					color: "text-primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Total Paid",
					value: formatCurrency(stats.totalPaid),
					color: "text-success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Remaining",
					value: formatCurrency(stats.remaining),
					color: "text-destructive"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Bookings",
				value: String(stats.supplierBookings.length)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Payment %",
				value: stats.totalCost > 0 ? `${Math.round(stats.totalPaid / stats.totalCost * 100)}%` : "0%"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: onViewBookings,
			variant: "outline",
			className: "w-full gap-2 text-xs",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-3.5 w-3.5" }),
				" View All Bookings (",
				stats.supplierBookings.length,
				") ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 ml-auto" })
			]
		})
	] });
}
function renderBooking(b) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Booking ID",
			value: b.id
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Head ID",
			value: b.headId
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Package",
			value: b.packageType
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Agent",
			value: b.agentId || "Direct"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Supplier",
			value: b.supplierId
		}),
		b.destination && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Destination",
			value: b.destination
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Members",
			value: String(b.members || b.clientIds.length)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Total Amount",
			value: formatCurrency(b.totalAmount)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Received",
			value: formatCurrency(b.amountReceived),
			color: "text-success"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Pending",
			value: formatCurrency(b.totalAmount - b.amountReceived),
			color: "text-destructive"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Total Cost",
			value: formatCurrency(b.totalCost || 0)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Commission",
			value: formatCurrency(b.commission || 0)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between border-b border-border/30 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Status"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: b.status })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Travel Date",
			value: b.travelDate
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Created",
			value: b.createdAt
		}),
		b.driveLink && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Drive Link",
			value: b.driveLink
		})
	] });
}
var CATEGORY_LABELS = {
	flight: "Flight / Tickets",
	ticket: "Flight / Tickets",
	hotel: "Hotel Accommodation",
	visa: "Visa Services",
	transport: "Transportation",
	ziyarah: "Ziyarah",
	insurance: "Insurance",
	other: "Other Services"
};
function StatementView({ type, data, entries, includeOpening, onToggleOpening, onDownload }) {
	if (type === "supplier") {
		const s = data;
		const purchases = entries.filter((e) => e.type === "purchase");
		const payments = entries.filter((e) => e.type === "supplier_payment");
		const grouped = /* @__PURE__ */ new Map();
		purchases.forEach((e) => {
			const key = CATEGORY_LABELS[(e.serviceCategory || "other").toLowerCase()] || CATEGORY_LABELS.other;
			if (!grouped.has(key)) grouped.set(key, []);
			grouped.get(key).push(e);
		});
		const purchaseTotal = purchases.reduce((sum, e) => sum + e.amount, 0);
		const paidTotal = payments.reduce((sum, e) => sum + e.amount, 0);
		const opening = includeOpening ? s.openingPayable || 0 : 0;
		const openingPaid = includeOpening ? s.openingPaid || 0 : 0;
		const grandPayable = opening + purchaseTotal;
		const grandPaid = openingPaid + paidTotal;
		const balance = grandPayable - grandPaid;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementHeader, {
					title: "Supplier Ledger Statement",
					rows: [
						["Supplier", s.companyName],
						["Contact", s.contactPerson],
						["Phone", s.phone]
					],
					includeOpening,
					onToggle: onToggleOpening,
					onDownload,
					hasOpening: (s.openingPayable || 0) > 0 || (s.openingPaid || 0) > 0
				}),
				includeOpening && (s.openingPayable || s.openingPaid) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Brought Forward (B/F)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
							label: "Opening Payable",
							value: formatCurrency(s.openingPayable || 0)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
							label: "Opening Paid",
							value: formatCurrency(s.openingPaid || 0),
							tone: "success"
						})]
					})
				}) : null,
				grouped.size === 0 && payments.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground text-center py-6",
					children: "No transactions recorded yet."
				}),
				Array.from(grouped.entries()).map(([label, items]) => {
					const subtotal = items.reduce((s, e) => s + e.amount, 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
						title: label,
						rightLabel: formatCurrency(subtotal),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementTable, {
							columns: [
								"Date",
								"Description",
								"Amount"
							],
							rows: items.map((e) => [
								e.date,
								e.note || "—",
								formatCurrency(e.amount)
							])
						})
					}, label);
				}),
				payments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Payments Made",
					rightLabel: formatCurrency(paidTotal),
					tone: "success",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementTable, {
						columns: [
							"Date",
							"Method / Note",
							"Amount"
						],
						rows: payments.map((e) => [
							e.date,
							e.note || "Payment",
							formatCurrency(e.amount)
						])
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Overview",
					highlight: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 text-xs",
						children: [
							includeOpening && (s.openingPayable || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Opening Payable",
								value: formatCurrency(s.openingPayable || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Total Purchases",
								value: formatCurrency(purchaseTotal)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Grand Total Payable",
								value: formatCurrency(grandPayable),
								bold: true
							}),
							includeOpening && (s.openingPaid || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Opening Paid",
								value: formatCurrency(s.openingPaid || 0),
								tone: "success"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Payments Made",
								value: formatCurrency(paidTotal),
								tone: "success"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Grand Total Paid",
								value: formatCurrency(grandPaid),
								bold: true,
								tone: "success"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-primary/30 pt-1.5 mt-1.5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Closing Balance",
								value: formatCurrency(balance),
								bold: true,
								tone: balance > 0 ? "destructive" : "success"
							})
						]
					})
				})
			]
		});
	}
	if (type === "agent") {
		const a = data;
		const commissions = entries.filter((e) => e.type === "agent_commission");
		const earned = a.commission || 0;
		const paid = commissions.reduce((s, e) => s + e.amount, 0);
		const opening = includeOpening ? a.openingCommission || 0 : 0;
		const openingPaid = includeOpening ? a.openingPaidCommission || 0 : 0;
		const totalEarned = earned + opening;
		const totalPaid = paid + openingPaid;
		const balance = totalEarned - totalPaid;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementHeader, {
					title: "Agent Commission Statement",
					rows: [
						["Agent", a.name],
						["Phone", a.phone],
						["Email", a.email]
					],
					includeOpening,
					onToggle: onToggleOpening,
					onDownload,
					hasOpening: (a.openingCommission || 0) > 0 || (a.openingPaidCommission || 0) > 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionCard, {
					title: "Commissions Earned",
					rightLabel: formatCurrency(earned),
					children: [includeOpening && (a.openingCommission || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] text-muted-foreground pb-2 border-b border-border/30 mb-2",
						children: ["B/F Opening Commission: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground font-medium",
							children: formatCurrency(a.openingCommission || 0)
						})]
					}), earned === 0 && commissions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground py-2",
						children: "No commission activity yet."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Total commission accrued from bookings."
					})]
				}),
				commissions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Commission Payments",
					rightLabel: formatCurrency(paid),
					tone: "success",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementTable, {
						columns: [
							"Date",
							"Description",
							"Amount"
						],
						rows: commissions.map((e) => [
							e.date,
							e.note || "Payment",
							formatCurrency(e.amount)
						])
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
					title: "Overview",
					highlight: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Total Commission",
								value: formatCurrency(totalEarned),
								bold: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Total Paid",
								value: formatCurrency(totalPaid),
								bold: true,
								tone: "success"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-primary/30 pt-1.5 mt-1.5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
								label: "Payable Balance",
								value: formatCurrency(balance),
								bold: true,
								tone: balance > 0 ? "destructive" : "success"
							})
						]
					})
				})
			]
		});
	}
	const c = data;
	const receipts = entries.filter((e) => e.type === "client_receive");
	const paid = receipts.reduce((s, e) => s + e.amount, 0);
	const remaining = c.amountDue - c.amountPaid;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementHeader, {
				title: "Client Account Statement",
				rows: [
					["Client", getClientName(c)],
					["Head ID", c.headId],
					["Phone", c.phone]
				],
				includeOpening,
				onToggle: onToggleOpening,
				onDownload,
				hasOpening: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
				title: "Booking Charges",
				rightLabel: formatCurrency(c.amountDue),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
							label: "Package",
							value: c.packageType
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
							label: "Destination",
							value: c.destination || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
							label: "Total Due",
							value: formatCurrency(c.amountDue)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
							label: "Amount Paid",
							value: formatCurrency(c.amountPaid),
							tone: "success"
						})
					]
				})
			}),
			receipts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
				title: "Payments Received",
				rightLabel: formatCurrency(paid),
				tone: "success",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementTable, {
					columns: [
						"Date",
						"Description",
						"Amount"
					],
					rows: receipts.map((e) => [
						e.date,
						e.note || "Receipt",
						formatCurrency(e.amount)
					])
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionCard, {
				title: "Overview",
				highlight: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
							label: "Total Due",
							value: formatCurrency(c.amountDue),
							bold: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
							label: "Total Paid",
							value: formatCurrency(c.amountPaid),
							bold: true,
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-primary/30 pt-1.5 mt-1.5" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewRow, {
							label: "Remaining Balance",
							value: formatCurrency(remaining),
							bold: true,
							tone: remaining > 0 ? "destructive" : "success"
						})
					]
				})
			})
		]
	});
}
function StatementHeader({ title, rows, includeOpening, onToggle, onDownload, hasOpening }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-primary/30 bg-gradient-to-br from-primary/5 to-transparent p-3 space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-widest text-primary/70",
					children: "Avery Group of Travel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-primary font-serif",
					children: title
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: onDownload,
					className: "gap-1.5 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), " PDF"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2 text-[11px] pt-1 border-t border-border/30",
				children: rows.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground text-[9px] uppercase",
					children: k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium truncate",
					children: v
				})] }, k))
			}),
			hasOpening && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-[11px] pt-1 cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: includeOpening,
					onChange: (e) => onToggle(e.target.checked),
					className: "accent-primary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Include opening balance (B/F)"
				})]
			})
		]
	});
}
function SectionCard({ title, rightLabel, tone, highlight, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-lg border ${highlight ? "border-primary/40 bg-primary/5" : "border-border/50 bg-accent/10"} overflow-hidden`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `flex items-center justify-between px-3 py-2 border-b ${highlight ? "border-primary/30 bg-primary/10" : "border-border/40 bg-accent/20"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-semibold uppercase tracking-wider text-primary font-serif",
				children: title
			}), rightLabel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-xs font-bold ${tone === "success" ? "text-success" : tone === "destructive" ? "text-destructive" : "text-primary"}`,
				children: rightLabel
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-3",
			children
		})]
	});
}
function StatementTable({ columns, rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-[11px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-b border-border/40",
				children: columns.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: `py-1.5 px-2 text-[10px] uppercase text-muted-foreground font-medium ${i === columns.length - 1 ? "text-right" : "text-left"}`,
					children: c
				}, c))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-b border-border/20 last:border-0",
				children: r.map((cell, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: `py-1.5 px-2 ${j === r.length - 1 ? "text-right font-medium" : "text-left"}`,
					children: cell
				}, j))
			}, i)) })]
		})
	});
}
function MiniStat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[9px] uppercase text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `text-xs font-semibold ${tone === "success" ? "text-success" : tone === "destructive" ? "text-destructive" : ""}`,
		children: value
	})] });
}
function OverviewRow({ label, value, bold, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `text-muted-foreground ${bold ? "font-semibold text-foreground" : ""}`,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `${bold ? "font-bold" : "font-medium"} ${tone === "success" ? "text-success" : tone === "destructive" ? "text-destructive" : ""}`,
			children: value
		})]
	});
}
/** One-by-one service breakdown for an agent (bookings' services + other-sale purchases), grouped like the supplier view. */
function AgentServices({ bookings, otherRows }) {
	const groups = {
		Hotel: [],
		Flight: [],
		Visa: [],
		Transport: [],
		Other: []
	};
	bookings.forEach((b) => {
		(b.hotels || []).forEach((h, i) => groups.Hotel.push({
			key: `${b.id}h${i}`,
			head: b.headId,
			title: h.hotelName || h.name || "Hotel",
			sub: [
				h.city,
				h.checkIn && `${h.checkIn} → ${h.checkOut || ""}`,
				h.rooms && `${h.rooms} room(s)`
			].filter(Boolean).join(" · ")
		}));
		(b.flights || []).forEach((f, i) => groups.Flight.push({
			key: `${b.id}f${i}`,
			head: b.headId,
			title: [f.airline, f.flightNumber].filter(Boolean).join(" ") || "Flight",
			sub: [
				f.from && `${f.from} → ${f.to || ""}`,
				f.departureDate || f.date,
				f.pnr && `PNR ${f.pnr}`
			].filter(Boolean).join(" · ")
		}));
		(b.visas || []).forEach((v, i) => groups.Visa.push({
			key: `${b.id}v${i}`,
			head: b.headId,
			title: v.visaType || v.type || "Visa",
			sub: [v.country, v.status].filter(Boolean).join(" · ")
		}));
		(b.transports || []).forEach((t, i) => groups.Transport.push({
			key: `${b.id}t${i}`,
			head: b.headId,
			title: t.route || t.vehicle || "Transport",
			sub: [t.vehicle, t.date].filter(Boolean).join(" · ")
		}));
		(b.others || []).forEach((o, i) => groups.Other.push({
			key: `${b.id}o${i}`,
			head: b.headId,
			title: o.name || o.description || "Service",
			sub: o.description || ""
		}));
	});
	otherRows.forEach((e) => {
		const cat = e.serviceCategory && groups[e.serviceCategory] ? e.serviceCategory : "Other";
		const d = e.purchaseDetails || {};
		groups[cat].push({
			key: e.id,
			head: e.forClientName || "Other Sale",
			title: d.hotelName || d.visaType || d.route || d.description || e.note || "Other Sale",
			sub: [
				e.date,
				d.city,
				`Other Sale`
			].filter(Boolean).join(" · "),
			amount: e.type === "purchase" ? e.saleAmount ?? e.amount : e.amount
		});
	});
	const keys = Object.keys(groups).filter((k) => groups[k].length);
	if (!keys.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-lg border border-border/50 p-3 text-center text-[11px] text-muted-foreground",
		children: "No services recorded for this agent yet."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
			children: "Services — one by one"
		}), keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-border/50",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border/40 bg-accent/10 px-3 py-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold text-primary",
					children: k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[10px] text-muted-foreground",
					children: [groups[k].length, " item(s)"]
				})]
			}), groups[k].map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border/20 px-3 py-1.5 last:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs font-medium",
						children: it.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-[10px] text-muted-foreground",
						children: [it.head, it.sub ? ` · ${it.sub}` : ""]
					})]
				}), it.amount != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold text-primary",
					children: formatCurrency(it.amount)
				})]
			}, it.key))]
		}, k))]
	});
}
export { DetailDialog as t };
