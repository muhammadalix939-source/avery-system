import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Et as Archive, I as Lock, bt as Bell, lt as CheckCheck, mt as CalendarDays, r as Users, st as ChevronRight, tt as ClipboardCheck, u as TrendingUp, x as RotateCcw, y as Search } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, h as getChecklist, m as checklistProgress, o as useStore, w as getClientName } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { t as ClientChecklistPanel } from "./ClientChecklistPanel-DESLP8C7.mjs";
import { a as urgencyTone, i as urgencyLabel, n as computeUrgency, r as sortByUrgency, t as computeGroupStats } from "./groups-6NvV7uvi.mjs";
import { t as ChecklistBadge } from "./ChecklistBadge-Th7wyJYT.mjs";
// node_modules/.nitro/vite/services/ssr/assets/alerts-BhCqHcr9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AlertsPage() {
	const store = useStore();
	const [tab, setTab] = (0, import_react.useState)("groups");
	const [query, setQuery] = (0, import_react.useState)("");
	const [showCompleted, setShowCompleted] = (0, import_react.useState)(false);
	const [showFullGroups, setShowFullGroups] = (0, import_react.useState)(false);
	const [openClient, setOpenClient] = (0, import_react.useState)(null);
	const [openGroupId, setOpenGroupId] = (0, import_react.useState)(null);
	const [selectedIds, setSelectedIds] = (0, import_react.useState)([]);
	const groupRows = (0, import_react.useMemo)(() => {
		const rows = store.groups.map((g) => {
			const stats = computeGroupStats(g, store);
			return {
				stats,
				urgency: computeUrgency(stats)
			};
		});
		return sortByUrgency(rows, (r) => r.urgency);
	}, [store]);
	const q = query.trim().toLowerCase();
	const filteredGroups = (0, import_react.useMemo)(() => groupRows.filter((r) => !q || [
		r.stats.group.name,
		r.stats.group.id,
		r.stats.group.pnr,
		r.stats.group.category,
		r.stats.group.date,
		r.stats.supplier?.companyName
	].filter(Boolean).join(" ").toLowerCase().includes(q)), [groupRows, q]);
	const activeGroups = (0, import_react.useMemo)(() => filteredGroups.filter((r) => !r.urgency.isFull), [filteredGroups]);
	const archivedGroups = (0, import_react.useMemo)(() => filteredGroups.filter((r) => r.urgency.isFull), [filteredGroups]);
	const shownGroups = showFullGroups ? archivedGroups : activeGroups;
	const groupTotals = (0, import_react.useMemo)(() => ({
		profit: shownGroups.reduce((s, r) => s + r.stats.netProfit, 0),
		sales: shownGroups.reduce((s, r) => s + r.stats.revenue, 0),
		seats: shownGroups.reduce((s, r) => s + (r.urgency.capacity > 0 ? r.urgency.remainingSeats : 0), 0)
	}), [shownGroups]);
	const openGroup = openGroupId ? groupRows.find((r) => r.stats.group.id === openGroupId) : null;
	const clientRows = (0, import_react.useMemo)(() => {
		const rows = store.clients.map((c) => ({
			client: c,
			progress: checklistProgress(c)
		}));
		const archived = rows.filter((r) => r.client.checklistArchived || r.progress.isComplete);
		const active = rows.filter((r) => !r.client.checklistArchived && !r.progress.isComplete);
		return (showCompleted ? archived : active).filter((r) => !q || [
			getClientName(r.client),
			r.client.id,
			r.client.headId,
			r.client.phone,
			r.client.packageType,
			...getChecklist(r.client).map((i) => `${i.label} ${i.status}`)
		].join(" ").toLowerCase().includes(q)).sort((a, b) => a.progress.percent - b.progress.percent);
	}, [
		store.clients,
		q,
		showCompleted
	]);
	/** Head-wise grouping of the client alerts: one block per Head ID with its members. */
	const headGroups = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		clientRows.forEach((r) => {
			const key = r.client.headId || "No Head";
			if (!map.has(key)) map.set(key, []);
			map.get(key).push(r);
		});
		return Array.from(map.entries()).map(([headId, members]) => {
			return {
				headId,
				members,
				completed: members.filter((m) => m.progress.isComplete).length,
				booking: store.bookings.find((b) => b.headId === headId),
				percent: Math.round(members.reduce((s, m) => s + m.progress.percent, 0) / (members.length || 1))
			};
		}).sort((a, b) => a.percent - b.percent);
	}, [clientRows, store.bookings]);
	const visibleIds = clientRows.map((r) => r.client.id);
	const selected = selectedIds.filter((id) => visibleIds.includes(id));
	function toggleSelect(id) {
		setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
	}
	function completeClients(ids) {
		ids.forEach((id) => {
			const c = store.clients.find((x) => x.id === id);
			if (!c) return;
			getChecklist(c).forEach((it) => {
				if (it.status !== "Completed") store.updateChecklistItem(id, it.id, { status: "Completed" });
			});
			store.setChecklistArchived(id, true);
		});
		setSelectedIds([]);
	}
	const urgentCount = groupRows.filter((r) => r.urgency.level === "critical").length;
	const pendingClients = store.clients.filter((c) => !c.checklistArchived && !checklistProgress(c).isComplete).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Alerts Hub",
				subtitle: `${urgentCount} urgent group${urgentCount === 1 ? "" : "s"} · ${pendingClients} client${pendingClients === 1 ? "" : "s"} with pending services`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [["groups", "clients"].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab(t),
					className: `flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold capitalize transition-all ${tab === t ? "bg-primary text-primary-foreground" : "bg-accent/30 text-muted-foreground hover:bg-accent/50"}`,
					children: [
						t === "groups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-3.5 w-3.5" }),
						t,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-background/30 px-1.5 text-[10px]",
							children: t === "groups" ? activeGroups.length : clientRows.length
						})
					]
				}, t)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-lg border border-dashed border-border px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground",
					children: "Payments · coming soon"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card flex items-center gap-2 rounded-xl px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: tab === "groups" ? "Search group, PNR, date, supplier..." : "Search client, head ID, service item...",
					className: "w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
				})]
			}),
			tab === "groups" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: showFullGroups ? "outline" : "default",
								className: "h-8 gap-1 text-xs",
								onClick: () => setShowFullGroups(false),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3.5 w-3.5" }),
									" Active (",
									activeGroups.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: showFullGroups ? "default" : "outline",
								className: "h-8 gap-1 text-xs",
								onClick: () => setShowFullGroups(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3.5 w-3.5" }),
									" Completed archive (",
									archivedGroups.length,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-auto flex flex-wrap items-center gap-2 text-[10px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-border/60 bg-accent/20 px-2.5 py-1",
										children: ["Sales ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-primary",
											children: formatCurrency(groupTotals.sales)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-border/60 bg-accent/20 px-2.5 py-1",
										children: ["Profit ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: groupTotals.profit >= 0 ? "text-success" : "text-destructive",
											children: formatCurrency(groupTotals.profit)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-border/60 bg-accent/20 px-2.5 py-1",
										children: ["Seats Left ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: groupTotals.seats })]
									})
								]
							})
						]
					}),
					shownGroups.map(({ stats, urgency }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 10
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: Math.min(i * .03, .3) },
						onClick: () => setOpenGroupId(stats.group.id),
						className: `glass-card glass-card-hover flex cursor-pointer flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-3 ${urgency.isFull ? "opacity-60 hover:opacity-100" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full border px-2 py-0.5 text-[9px] font-bold ${urgencyTone[urgency.level]}`,
								children: urgencyLabel[urgency.level]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold",
								children: stats.group.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground",
								children: [
									stats.group.id,
									stats.group.category,
									stats.group.date || "no date",
									stats.supplier?.companyName
								].filter(Boolean).join(" · ")
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-5 text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px] uppercase tracking-wide text-muted-foreground",
									children: "Seats Left"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm font-bold ${urgency.remainingSeats <= 3 ? "text-destructive" : "text-success"}`,
									children: urgency.capacity > 0 ? `${urgency.remainingSeats} / ${urgency.capacity}` : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px] uppercase tracking-wide text-muted-foreground",
									children: "Sales"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-primary",
									children: formatCurrency(stats.revenue)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px] uppercase tracking-wide text-muted-foreground",
									children: "Profit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm font-bold ${stats.netProfit >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(stats.netProfit)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "min-w-[120px] text-[10px] text-muted-foreground",
									children: urgency.reason
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 text-muted-foreground" })
							]
						})]
					}, stats.group.id)),
					shownGroups.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						icon: Bell,
						text: showFullGroups ? "No full / closed groups yet." : "No active group alerts match your search."
					})
				]
			}),
			tab === "clients" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: showCompleted ? "outline" : "default",
						className: "h-8 gap-1 text-xs",
						onClick: () => setShowCompleted(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-3.5 w-3.5" }), " Active"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: showCompleted ? "default" : "outline",
						className: "h-8 gap-1 text-xs",
						onClick: () => setShowCompleted(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "h-3.5 w-3.5" }), " Completed archive"]
					}),
					!showCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							className: "h-8 gap-1 text-xs",
							onClick: () => setSelectedIds(visibleIds),
							children: "Select all"
						}),
						selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							className: "h-8 gap-1 text-xs",
							onClick: () => setSelectedIds([]),
							children: [
								"Clear (",
								selected.length,
								")"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							className: "h-8 gap-1 text-xs",
							onClick: () => completeClients(selected),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-3.5 w-3.5" }), " Complete selected members"]
						})] }),
						selected.length === 0 && visibleIds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							className: "h-8 gap-1 text-xs",
							onClick: () => completeClients(visibleIds),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-3.5 w-3.5" }), " Mark all complete"]
						})
					] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [headGroups.map((hg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: Math.min(i * .04, .3) },
					className: "glass-card rounded-xl p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-border/50 pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-primary",
								children: hg.headId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground",
								children: [
									`${hg.members.length} member${hg.members.length === 1 ? "" : "s"}`,
									hg.booking?.packageType,
									hg.booking?.destination,
									hg.booking?.travelDate
								].filter(Boolean).join(" · ")
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full border border-border/60 bg-accent/20 px-2.5 py-1 text-[10px]",
								children: [
									hg.completed,
									"/",
									hg.members.length,
									" members done · ",
									hg.percent,
									"%"
								]
							}), !showCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								className: "h-7 text-[10px]",
								onClick: () => setSelectedIds((prev) => Array.from(/* @__PURE__ */ new Set([...prev, ...hg.members.map((m) => m.client.id)]))),
								children: "Select head"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								className: "h-7 gap-1 text-[10px]",
								onClick: () => completeClients(hg.members.map((m) => m.client.id)),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-3 w-3" }), " All complete"]
							})] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: hg.members.map(({ client, progress }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							onClick: () => setOpenClient(client),
							className: "flex flex-wrap items-center justify-between gap-3 rounded-lg bg-accent/20 px-3 py-2 cursor-pointer transition-colors hover:bg-accent/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [!showCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: selected.includes(client.id),
									onClick: (e) => e.stopPropagation(),
									onChange: () => toggleSelect(client.id),
									className: "h-3.5 w-3.5 accent-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold",
									children: getClientName(client)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-muted-foreground",
									children: [
										client.id,
										" · ",
										client.packageType
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: getChecklist(client).filter((it) => it.status !== "Completed").map((it) => it.label).slice(0, 3).join(", ") || "All services arranged"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChecklistBadge, { client }),
									(client.checklistArchived || progress.isComplete) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										className: "h-7 gap-1 text-[10px]",
										onClick: (e) => {
											e.stopPropagation();
											store.setChecklistArchived(client.id, false);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3 w-3" }), " Re-open"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 text-muted-foreground" })
								]
							})]
						}, client.id))
					})]
				}, hg.headId)), headGroups.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					icon: ClipboardCheck,
					text: showCompleted ? "No completed client checklists yet." : "No pending client services. Everything is arranged."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!openGroup,
				onOpenChange: (o) => !o && setOpenGroupId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "bg-card border-border max-w-lg max-h-[85vh] overflow-y-auto",
					children: openGroup && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupAlertDetail, { stats: openGroup.stats })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!openClient,
				onOpenChange: (o) => !o && setOpenClient(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "bg-card border-border max-w-lg max-h-[85vh] overflow-y-auto",
					children: openClient && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-primary text-sm",
						children: [getClientName(openClient), " — Service Checklist"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-muted-foreground",
						children: [
							openClient.id,
							" · ",
							openClient.headId,
							" · ",
							openClient.packageType
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientChecklistPanel, { client: openClient })] })
				})
			})
		]
	});
}
function Empty({ icon: Icon, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-card flex flex-col items-center rounded-xl py-14 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mb-3 h-10 w-10 text-muted-foreground/30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: text
		})]
	});
}
function GroupAlertDetail({ stats }) {
	const u = computeUrgency(stats);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "flex flex-wrap items-center gap-2 text-sm text-primary",
				children: [stats.group.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full border px-2 py-0.5 text-[9px] font-bold ${urgencyTone[u.level]}`,
					children: urgencyLabel[u.level]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-muted-foreground",
				children: [
					stats.group.id,
					stats.group.pnr && `PNR ${stats.group.pnr}`,
					stats.group.category,
					stats.group.date,
					stats.supplier?.companyName
				].filter(Boolean).join(" · ")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
						label: "Seats Left",
						value: u.capacity > 0 ? `${u.remainingSeats} / ${u.capacity}` : "—",
						tone: u.remainingSeats <= 3 ? "text-destructive" : "text-success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
						label: "Sales",
						value: formatCurrency(stats.revenue),
						tone: "text-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
						label: "Supplier Bill",
						value: formatCurrency(stats.supplierBill),
						tone: "text-warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
						label: "Net Profit",
						value: formatCurrency(stats.netProfit),
						tone: stats.netProfit >= 0 ? "text-success" : "text-destructive"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border/50 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }),
						" Heads in this group (",
						stats.heads.length,
						") · margin ",
						stats.margin.toFixed(1),
						"%"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-56 space-y-1.5 overflow-y-auto",
					children: [stats.heads.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded bg-accent/20 px-2.5 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium",
							children: h.leadName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] text-muted-foreground",
							children: [
								h.headId,
								" · ",
								h.members,
								" member",
								h.members === 1 ? "" : "s"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right text-[10px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Total ", formatCurrency(h.totalAmount)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-success",
								children: ["Received ", formatCurrency(h.received)]
							})]
						})]
					}, h.headId)), stats.heads.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-2 text-center text-[11px] text-muted-foreground",
						children: "No heads booked in this group yet."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] text-muted-foreground",
				children: u.reason
			})
		]
	});
}
function Box({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-accent/20 p-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[9px] uppercase tracking-wide text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `text-sm font-bold ${tone || ""}`,
			children: value
		})]
	});
}
export { AlertsPage as component };
