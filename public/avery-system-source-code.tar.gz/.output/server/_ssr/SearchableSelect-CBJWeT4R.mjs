import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { at as ChevronsUpDown, mt as CalendarDays, r as Users, st as ChevronRight, ut as Check, y as Search, z as Layers } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, o as useStore, w as getClientName } from "./router-2ATn7EQ0.mjs";
import { t as cn } from "./utils-DWGjSd5x.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { t as StatusBadge } from "./StatusBadge-MNA5vWLW.mjs";
import { a as urgencyTone, i as urgencyLabel, n as computeUrgency, r as sortByUrgency, t as computeGroupStats } from "./groups-6NvV7uvi.mjs";
import { t as _e } from "../_libs/cmdk.mjs";
import { i as PopoverTrigger$1, n as PopoverContent$1, r as PopoverPortal, t as Popover$1 } from "../_libs/radix-ui__react-popover.mjs";
// node_modules/.nitro/vite/services/ssr/assets/SearchableSelect-CBJWeT4R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Live seat-status widget for the Group Sale / Bill entry screen.
*  Active groups only, ordered by urgency; click any group for a quick view. */
function GroupSeatStrip() {
	const store = useStore();
	const [quickId, setQuickId] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		const active = store.groups.map((g) => ({
			stats: computeGroupStats(g, store),
			urgency: computeUrgency(computeGroupStats(g, store))
		})).filter((r) => !r.urgency.isFull);
		return sortByUrgency(active, (r) => r.urgency);
	}, [store]);
	const quick = quickId ? store.groups.find((g) => g.id === quickId) : null;
	const quickStats = quick ? computeGroupStats(quick, store) : null;
	const totals = (0, import_react.useMemo)(() => ({
		profit: rows.reduce((s, r) => s + r.stats.netProfit, 0),
		seats: rows.reduce((s, r) => s + (r.urgency.capacity > 0 ? r.urgency.remainingSeats : 0), 0),
		sales: rows.reduce((s, r) => s + r.stats.revenue, 0)
	}), [rows]);
	if (store.groups.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-card rounded-xl p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "h-4 w-4 text-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-wider text-primary",
						children: "Live Seat Status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-muted-foreground",
						children: "Most urgent groups first · click for quick view"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
								label: "Group Sales",
								value: formatCurrency(totals.sales),
								tone: "text-primary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
								label: "Group Profit",
								value: formatCurrency(totals.profit),
								tone: totals.profit >= 0 ? "text-success" : "text-destructive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
								label: "Seats Left",
								value: String(totals.seats),
								tone: totals.seats <= 3 ? "text-destructive" : "text-foreground"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3 overflow-x-auto pb-1",
				children: [rows.map(({ stats, urgency }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setQuickId(stats.group.id),
					className: `min-w-[210px] shrink-0 rounded-xl border p-3 text-left transition-all hover:border-primary/50 ${urgencyTone[urgency.level]}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs font-semibold text-foreground",
								children: stats.group.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full border border-current px-1.5 py-0.5 text-[9px] font-bold",
								children: urgencyLabel[urgency.level]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 flex items-center gap-1 text-[10px] text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3 w-3" }),
								" ",
								stats.group.date || "No date"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1.5 flex items-center gap-1 text-[11px] font-semibold text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3 w-3" }), urgency.capacity > 0 ? `${urgency.remainingSeats} of ${urgency.capacity} seats left` : `${stats.usedPax} pax booked`]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[10px] opacity-80",
							children: urgency.reason
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between border-t border-current/20 pt-1.5 text-[10px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: ["Sales ", formatCurrency(stats.revenue)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `font-semibold ${stats.netProfit >= 0 ? "text-success" : "text-destructive"}`,
								children: ["Profit ", formatCurrency(stats.netProfit)]
							})]
						})
					]
				}, stats.group.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-3 text-xs text-muted-foreground",
					children: "All groups are full — see the Full / Closed section on the Groups page."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!quick,
				onOpenChange: (o) => !o && setQuickId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "bg-card border-border max-w-lg max-h-[85vh] overflow-y-auto",
					children: quick && quickStats && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickView, { stats: quickStats })
				})
			})
		]
	});
}
function QuickView({ stats }) {
	const store = useStore();
	const urgency = computeUrgency(stats);
	const members = stats.heads.flatMap((h) => h.clients.map((c) => ({
		c,
		headId: h.headId
	})));
	const nextDeparture = store.groups.map((g) => g.date).filter(Boolean).sort().find((d) => d >= (stats.group.date || "")) || stats.group.date;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "flex flex-wrap items-center gap-2 text-primary text-sm",
				children: [stats.group.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full border px-2 py-0.5 text-[9px] font-bold ${urgencyTone[urgency.level]}`,
					children: urgencyLabel[urgency.level]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-muted-foreground",
				children: [
					stats.group.id,
					stats.group.pnr && `PNR ${stats.group.pnr}`,
					stats.group.category,
					stats.supplier?.companyName
				].filter(Boolean).join(" · ")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total Seats",
						value: String(urgency.capacity || "—")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Booked",
						value: String(stats.usedPax),
						tone: "text-warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Remaining",
						value: urgency.capacity ? String(urgency.remainingSeats) : "—",
						tone: urgency.remainingSeats <= 3 ? "text-destructive" : "text-success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Departure",
						value: stats.group.date || "—",
						tone: "text-primary"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border/50 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
					children: [
						"Booked Clients (",
						members.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-56 space-y-1.5 overflow-y-auto",
					children: [members.map(({ c, headId }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded bg-accent/20 px-2.5 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium",
							children: getClientName(c)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] text-muted-foreground",
							children: [
								c.id,
								" · ",
								headId
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted-foreground",
								children: formatCurrency(c.amountPaid)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })]
						})]
					}, c.id)), members.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-2 text-center text-[11px] text-muted-foreground",
						children: "No clients booked in this group yet."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-1 text-[10px] text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" }),
					" Next departure on record: ",
					nextDeparture || "—"
				]
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-accent/20 p-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[9px] uppercase tracking-wide text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `text-sm font-bold ${tone || ""}`,
			children: value
		})]
	});
}
function Pill({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "rounded-full border border-border/60 bg-accent/20 px-2.5 py-1 text-[10px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "uppercase tracking-wide text-muted-foreground",
			children: [label, " "]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `font-bold ${tone || ""}`,
			children: value
		})]
	});
}
var Command$1 = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e, {
	ref,
	className: cn("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground", className),
	...props
}));
Command$1.displayName = _e.displayName;
var CommandInput = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex items-center border-b px-3",
	"cmdk-input-wrapper": "",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-2 h-4 w-4 shrink-0 opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Input, {
		ref,
		className: cn("flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	})]
}));
CommandInput.displayName = _e.Input.displayName;
var CommandList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.List, {
	ref,
	className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
	...props
}));
CommandList.displayName = _e.List.displayName;
var CommandEmpty = import_react.forwardRef((props, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Empty, {
	ref,
	className: "py-6 text-center text-sm",
	...props
}));
CommandEmpty.displayName = _e.Empty.displayName;
var CommandGroup = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Group, {
	ref,
	className: cn("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", className),
	...props
}));
CommandGroup.displayName = _e.Group.displayName;
var CommandSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Separator, {
	ref,
	className: cn("-mx-1 h-px bg-border", className),
	...props
}));
CommandSeparator.displayName = _e.Separator.displayName;
var CommandItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
	ref,
	className: cn("relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", className),
	...props
}));
CommandItem.displayName = _e.Item.displayName;
var CommandShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	});
};
CommandShortcut.displayName = "CommandShortcut";
var Popover = Popover$1;
var PopoverTrigger = PopoverTrigger$1;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent$1, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}) }));
PopoverContent.displayName = PopoverContent$1.displayName;
function SearchableSelect({ options, value, onChange, placeholder = "Select...", emptyText = "No results.", className }) {
	const [open, setOpen] = import_react.useState(false);
	const selected = options.find((o) => o.value === value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				role: "combobox",
				"aria-expanded": open,
				className: cn("w-full justify-between bg-accent/20 border-border h-8 text-xs font-normal", className),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: selected ? selected.label : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: placeholder
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "ml-2 h-3.5 w-3.5 shrink-0 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[--radix-popover-trigger-width] p-0 bg-popover border-border",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
				placeholder: "Search...",
				className: "h-9 text-xs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, {
				className: "max-h-60 overflow-y-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: emptyText }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, { children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: `${opt.label} ${opt.value} ${opt.hint ?? ""}`,
					onSelect: () => {
						onChange(opt.value);
						setOpen(false);
					},
					className: "text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("mr-2 h-3.5 w-3.5", value === opt.value ? "opacity-100" : "opacity-0") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: opt.label }), opt.hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: opt.hint
						})]
					})]
				}, opt.value)) })]
			})] })
		})]
	});
}
export { SearchableSelect as n, GroupSeatStrip as t };
