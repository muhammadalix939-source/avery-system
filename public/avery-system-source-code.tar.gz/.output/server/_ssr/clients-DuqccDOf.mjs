import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as Phone, K as Eye, f as Trash, k as Pencil, q as Download, w as Plus } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, o as useStore, v as PACKAGE_TYPES, w as getClientName } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { t as Input } from "./input-CqV36rr2.mjs";
import { t as Label } from "./label-BYIfJH-v.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BBv8eX6f.mjs";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { t as StatusBadge } from "./StatusBadge-MNA5vWLW.mjs";
import { n as generateClientStatement } from "./pdf-DqNVIsfR.mjs";
import { t as ConfirmDelete } from "./ConfirmDelete-C6E2xoIe.mjs";
import { t as ClientChecklistPanel } from "./ClientChecklistPanel-DESLP8C7.mjs";
import { t as DetailDialog } from "./DetailDialog-DcjtoN1W.mjs";
import { t as ChecklistBadge } from "./ChecklistBadge-Th7wyJYT.mjs";
// node_modules/.nitro/vite/services/ssr/assets/clients-DuqccDOf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClientsPage() {
	const store = useStore();
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [detailOpen, setDetailOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		headId: "",
		firstName: "",
		lastName: "",
		gender: "Male",
		nationality: "",
		passport: "",
		cnic: "",
		dateOfBirth: "",
		dateOfIssue: "",
		dateOfExpire: "",
		phone: "",
		email: "",
		packageType: "Umrah",
		amountDue: "",
		isVip: false,
		destination: "",
		driveLink: ""
	});
	const filtered = filter === "All" ? store.clients : store.clients.filter((c) => c.paymentStatus === filter);
	const emptyForm = {
		headId: "",
		firstName: "",
		lastName: "",
		gender: "Male",
		nationality: "",
		passport: "",
		cnic: "",
		dateOfBirth: "",
		dateOfIssue: "",
		dateOfExpire: "",
		phone: "",
		email: "",
		packageType: "Umrah",
		amountDue: "",
		isVip: false,
		destination: "",
		driveLink: ""
	};
	function handleAdd() {
		store.addClient({
			headId: form.headId,
			firstName: form.firstName,
			lastName: form.lastName,
			gender: form.gender,
			nationality: form.nationality,
			passport: form.passport,
			cnic: form.cnic,
			dateOfBirth: form.dateOfBirth,
			dateOfIssue: form.dateOfIssue,
			dateOfExpire: form.dateOfExpire,
			phone: form.phone,
			email: form.email,
			packageType: form.packageType,
			paymentStatus: "Unpaid",
			amountDue: Number(form.amountDue) || 0,
			amountPaid: 0,
			isVip: form.isVip,
			destination: form.destination,
			driveLink: form.driveLink
		});
		setForm(emptyForm);
		setAddOpen(false);
	}
	function handleEdit() {
		if (!selected) return;
		store.updateClient(selected.id, {
			headId: form.headId,
			firstName: form.firstName,
			lastName: form.lastName,
			gender: form.gender,
			nationality: form.nationality,
			passport: form.passport,
			cnic: form.cnic,
			dateOfBirth: form.dateOfBirth,
			dateOfIssue: form.dateOfIssue,
			dateOfExpire: form.dateOfExpire,
			phone: form.phone,
			email: form.email,
			packageType: form.packageType,
			amountDue: Number(form.amountDue) || 0,
			isVip: form.isVip,
			destination: form.destination,
			driveLink: form.driveLink
		});
		setEditOpen(false);
	}
	function openEdit(c) {
		setSelected(c);
		setForm({
			headId: c.headId,
			firstName: c.firstName,
			lastName: c.lastName,
			gender: c.gender,
			nationality: c.nationality || "",
			passport: c.passport,
			cnic: c.cnic || "",
			dateOfBirth: c.dateOfBirth || "",
			dateOfIssue: c.dateOfIssue || "",
			dateOfExpire: c.dateOfExpire || "",
			phone: c.phone,
			email: c.email || "",
			packageType: c.packageType,
			amountDue: String(c.amountDue),
			isVip: c.isVip,
			destination: c.destination || "",
			driveLink: c.driveLink || ""
		});
		setEditOpen(true);
	}
	function downloadStatement(c) {
		const entries = store.entries.filter((e) => e.referenceId === c.id || e.headId === c.headId);
		generateClientStatement(c, entries);
	}
	const relatedEntries = selected ? store.entries.filter((e) => e.referenceId === selected.id || e.headId === selected.headId) : [];
	const formFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 max-h-[55vh] overflow-y-auto pr-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Head ID"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.headId,
					onChange: (e) => setForm({
						...form,
						headId: e.target.value
					}),
					placeholder: "AV-HD-001",
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Nationality"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.nationality,
					onChange: (e) => setForm({
						...form,
						nationality: e.target.value
					}),
					placeholder: "e.g. Pakistani",
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "First Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.firstName,
						onChange: (e) => setForm({
							...form,
							firstName: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Last Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.lastName,
						onChange: (e) => setForm({
							...form,
							lastName: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Gender"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: form.gender,
						onValueChange: (v) => setForm({
							...form,
							gender: v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "bg-accent/20 border-border mt-1 h-8 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Male",
								children: "Male"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Female",
								children: "Female"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Custom",
								children: "Custom"
							})
						] })]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Passport Number"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.passport,
					onChange: (e) => setForm({
						...form,
						passport: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "CNIC"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.cnic,
					onChange: (e) => setForm({
						...form,
						cnic: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Date of Birth"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: form.dateOfBirth,
						onChange: (e) => setForm({
							...form,
							dateOfBirth: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Date of Issue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: form.dateOfIssue,
						onChange: (e) => setForm({
							...form,
							dateOfIssue: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Date of Expire"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: form.dateOfExpire,
						onChange: (e) => setForm({
							...form,
							dateOfExpire: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-8 text-xs"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.phone,
					onChange: (e) => setForm({
						...form,
						phone: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Email (optional)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.email,
					onChange: (e) => setForm({
						...form,
						email: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Package Type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.packageType,
					onValueChange: (v) => setForm({
						...form,
						packageType: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-8 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: PACKAGE_TYPES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p,
						children: p
					}, p)) })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Amount Due (PKR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: form.amountDue,
					onChange: (e) => setForm({
						...form,
						amountDue: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-8 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Destination"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.destination,
				onChange: (e) => setForm({
					...form,
					destination: e.target.value
				}),
				placeholder: "Makkah / Madinah",
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Drive Link (optional)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.driveLink,
				onChange: (e) => setForm({
					...form,
					driveLink: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-8 text-xs"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: form.isVip,
					onChange: (e) => setForm({
						...form,
						isVip: e.target.checked
					}),
					className: "rounded"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "VIP Client"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Client Management",
				subtitle: `${store.clients.length} total clients`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: setAddOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: () => setForm(emptyForm),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add Client"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border max-w-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add New Client" }) }),
							formFields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleAdd,
								className: "w-full",
								children: "Add Client"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"All",
					"Paid",
					"Partial",
					"Unpaid"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setFilter(f),
					className: `rounded-lg px-4 py-2 text-xs font-medium transition-all ${filter === f ? "bg-primary text-primary-foreground" : "bg-accent/30 text-muted-foreground hover:bg-accent/50"}`,
					children: f
				}, f))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Client ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Head ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Phone"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Package"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Due"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Services"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filtered.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/50 transition-colors hover:bg-accent/30",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-semibold text-primary",
									children: c.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 font-medium",
									children: [
										getClientName(c),
										" ",
										c.isVip && "⭐"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: c.headId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3 w-3" }), c.phone]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: c.packageType
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-success",
									children: formatCurrency(c.amountPaid)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-destructive",
									children: formatCurrency(c.amountDue - c.amountPaid)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChecklistBadge, {
										client: c,
										compact: true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => {
													setSelected(c);
													setDetailOpen(true);
												},
												className: "rounded p-1 hover:bg-accent",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3.5 w-3.5 text-primary" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => downloadStatement(c),
												className: "rounded p-1 hover:bg-accent",
												title: "Download Statement",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5 text-success" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => openEdit(c),
												className: "rounded p-1 hover:bg-accent",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setDeleteTarget(c),
												className: "rounded p-1 hover:bg-accent",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
											})
										]
									})
								})
							]
						}, c.id)) })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-w-lg max-h-[88vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Client — ", selected?.id] }) }),
						formFields,
						selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientChecklistPanel, { client: selected })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleEdit,
							className: "w-full",
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
				open: !!deleteTarget,
				onOpenChange: (o) => {
					if (!o) setDeleteTarget(null);
				},
				title: `Delete ${deleteTarget ? getClientName(deleteTarget) : "client"}?`,
				description: "This client record, along with their service checklist, will be permanently removed.",
				onConfirm: () => {
					if (deleteTarget) store.deleteClient(deleteTarget.id);
					setDeleteTarget(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailDialog, {
				open: detailOpen,
				onOpenChange: setDetailOpen,
				type: "client",
				data: selected,
				entries: relatedEntries,
				allClients: store.clients,
				allBookings: store.bookings
			})
		]
	});
}
export { ClientsPage as component };
