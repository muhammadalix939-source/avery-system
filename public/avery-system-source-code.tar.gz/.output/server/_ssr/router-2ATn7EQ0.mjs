import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createFileRoute, d as HeadContent, f as useLocation, g as lazyRouteComponent, h as Outlet, m as createRouter, u as Scripts, v as createRootRoute, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getApp, o as getApps, s as initializeApp } from "../_libs/@firebase/app+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { C as Receipt, H as HandCoins, N as Menu, P as LogOut, R as LayoutDashboard, S as RefreshCw, W as FileText, X as CreditCard, Y as Database, _ as Settings, bt as Bell, c as Truck, ft as ChartColumn, i as UserCog, m as Sparkles, n as Wallet, r as Users, s as Undo2, t as X, y as Search, yt as BookOpen, z as Layers } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import "../_libs/firebase.mjs";
import { a as signOut, i as signInWithPopup, n as getAuth, r as onAuthStateChanged, t as GoogleAuthProvider } from "../_libs/firebase__auth.mjs";
import { a as setDoc, c as doc, i as getDocs, l as getFirestore, n as getDoc, o as writeBatch, r as getDocFromServer, s as collection, t as deleteDoc, u as initializeFirestore } from "../_libs/@firebase/firestore+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/router-2ATn7EQ0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var styles_default = "/assets/styles-DYodTW9Z.css";
var num = (v) => {
	const n = typeof v === "string" ? Number(v.replace(/,/g, "")) : Number(v);
	return Number.isFinite(n) ? n : 0;
};
var arr = (v) => Array.isArray(v) ? v : [];
function normalizeEntry(e, i = 0) {
	return {
		...e,
		id: String(e.id || `E-LEGACY-${i + 1}`),
		date: String(e.date || (typeof e.createdAt === "string" ? e.createdAt.slice(0, 10) : "") || "2026-01-01"),
		type: e.type || "expense",
		headId: String(e.headId || ""),
		referenceId: String(e.referenceId || ""),
		referenceName: String(e.referenceName || ""),
		amount: num(e.amount),
		note: String(e.note || ""),
		createdAt: String(e.createdAt || e.date || "2026-01-01T00:00:00")
	};
}
function normalizeBooking(b) {
	return {
		...b,
		totalAmount: num(b.totalAmount),
		amountReceived: num(b.amountReceived),
		totalCost: num(b.totalCost),
		commission: num(b.commission),
		members: num(b.members),
		clientIds: arr(b.clientIds),
		hotels: arr(b.hotels),
		flights: arr(b.flights),
		transports: arr(b.transports),
		visas: arr(b.visas),
		others: arr(b.others),
		ziyarahs: arr(b.ziyarahs),
		packageInfo: b.packageInfo ? {
			...b.packageInfo,
			inclusions: arr(b.packageInfo.inclusions)
		} : void 0
	};
}
function normalizeClient(c) {
	return {
		...c,
		amountDue: num(c.amountDue),
		amountPaid: num(c.amountPaid)
	};
}
function normalizeSupplier(s) {
	return {
		...s,
		id: String(s.id || ""),
		companyName: String(s.companyName || ""),
		contactPerson: String(s.contactPerson || ""),
		phone: String(s.phone || ""),
		email: String(s.email || ""),
		serviceType: String(s.serviceType || "Other"),
		totalPayable: num(s.totalPayable),
		totalPaid: num(s.totalPaid),
		openingPayable: num(s.openingPayable),
		openingPaid: num(s.openingPaid)
	};
}
/** Re-create any account that entries still point to but was deleted / missing in the backup. */
function restoreMissingAccounts(accounts, entries) {
	const have = new Set(accounts.map((a) => a.id));
	const out = accounts.map((a) => ({
		...a,
		openingBalance: num(a.openingBalance)
	}));
	for (const e of entries) {
		const id = e.accountId;
		if (id && !have.has(id)) {
			have.add(id);
			out.push({
				id,
				name: `Recovered ${id}`,
				type: "Cash",
				openingBalance: 0,
				openingDate: "2026-01-01"
			});
		}
	}
	return out;
}
var SERVICE_TYPES = [
	"Umrah Package",
	"Hajj Package",
	"Hotel",
	"Flight",
	"Visa",
	"Transport",
	"Ziyarah",
	"Domestic Tour",
	"International Tour",
	"Insurance",
	"Other"
];
var PACKAGE_TYPES = [
	"Umrah",
	"Umrah Economy",
	"Umrah Standard",
	"Umrah VIP",
	"Hajj",
	"Hajj Shifting",
	"Hajj Aziziya",
	"Ziyarah",
	"International Tour",
	"Domestic Tour",
	"Pakistan Tour",
	"Honeymoon Package",
	"Group Tour",
	"Family Package",
	"Visa Only",
	"Tour",
	"Custom"
];
function getClientName(c) {
	return `${c.firstName} ${c.lastName}`.trim() || "—";
}
function computeBookingFinancials(b) {
	const discount = Number(b.discount) || 0;
	const grossSale = Number(b.baseAmount !== void 0 ? b.baseAmount : discount > 0 && b.totalAmount ? b.totalAmount < 1e6 && b.totalAmount !== (b.baseAmount || b.totalAmount) ? b.totalAmount + discount : b.totalAmount : b.totalAmount) || 0;
	const netSale = b.baseAmount !== void 0 ? Number(b.totalAmount) || 0 : Math.max(0, grossSale - discount);
	const clientPayable = netSale;
	const sale = netSale;
	const supplierDisc = Number(b.supplierDiscount) || 0;
	const grossCost = Number(b.totalCost) || 0;
	const netCost = Math.max(0, grossCost - supplierDisc);
	const originalCommission = Number(b.commission) || 0;
	let netCommission = originalCommission;
	let agentAbsorbedDiscount = 0;
	let agencyAbsorbedDiscount = 0;
	if (b.agentId && b.agentId !== "Direct" && b.discountSettlement === "agent_commission") {
		agentAbsorbedDiscount = Math.min(originalCommission, discount);
		netCommission = Math.max(0, originalCommission - agentAbsorbedDiscount);
		agencyAbsorbedDiscount = Math.max(0, discount - agentAbsorbedDiscount);
	} else agencyAbsorbedDiscount = discount;
	const netProfit = grossSale - agencyAbsorbedDiscount - netCost - netCommission;
	const isLoss = netProfit < 0;
	return {
		sale,
		grossSale,
		discount,
		clientPayable,
		supplierDiscount: supplierDisc,
		netCost,
		netCommission,
		agentAbsorbedDiscount,
		agencyAbsorbedDiscount,
		netProfit,
		isLoss,
		lossAmount: isLoss ? Math.abs(netProfit) : 0,
		marginPercent: sale > 0 ? Math.round(netProfit / sale * 100) : 0
	};
}
function computeBookingProfit(b) {
	return computeBookingFinancials(b).netProfit;
}
var mockAgents = [
	{
		id: "AV-A001",
		name: "Ahmed Khan",
		phone: "03001234567",
		email: "ahmed@av.com",
		totalSales: 25e5,
		totalClients: 45,
		commission: 125e3,
		paidCommission: 5e4,
		status: "Active"
	},
	{
		id: "AV-A002",
		name: "Sara Ali",
		phone: "03009876543",
		email: "sara@av.com",
		totalSales: 18e5,
		totalClients: 32,
		commission: 9e4,
		paidCommission: 3e4,
		status: "Active"
	},
	{
		id: "AV-A003",
		name: "Usman Malik",
		phone: "03115554444",
		email: "usman@av.com",
		totalSales: 95e4,
		totalClients: 18,
		commission: 47500,
		paidCommission: 0,
		status: "Active"
	}
];
var mockSuppliers = [
	{
		id: "AV-S001",
		companyName: "Al-Haram Hotels",
		contactPerson: "Fahad Sheikh",
		phone: "03211112222",
		email: "fahad@alharam.com",
		serviceType: "Hotel",
		totalPayable: 35e4,
		totalPaid: 2e5,
		openingPayable: 45e4,
		openingPaid: 3e5
	},
	{
		id: "AV-S002",
		companyName: "Sky Wings Airlines",
		contactPerson: "Bilal Ahmed",
		phone: "03223334444",
		email: "bilal@skywings.com",
		serviceType: "Flight",
		totalPayable: 49e4,
		totalPaid: 0,
		openingPayable: 11e4,
		openingPaid: 6e5
	},
	{
		id: "AV-S003",
		companyName: "Noor Transport",
		contactPerson: "Imran Hussain",
		phone: "03335556666",
		email: "imran@noor.com",
		serviceType: "Transport",
		totalPayable: 1e5,
		totalPaid: 0,
		openingPayable: 1e5,
		openingPaid: 12e4
	},
	{
		id: "AV-S004",
		companyName: "Fast Visa Services",
		contactPerson: "Tariq Mehmood",
		phone: "03447778888",
		email: "tariq@fastvisa.com",
		serviceType: "Visa",
		totalPayable: 0,
		totalPaid: 0,
		openingPayable: 15e4,
		openingPaid: 15e4
	}
];
var mockClients = [
	{
		id: "AV-C001",
		headId: "AV-HD-001",
		firstName: "Muhammad",
		lastName: "Ali",
		gender: "Male",
		nationality: "Pakistani",
		passport: "AB1234567",
		phone: "03001111111",
		packageType: "Umrah",
		paymentStatus: "Paid",
		baseDue: 1e5,
		amountDue: 99e3,
		amountPaid: 99e3,
		isVip: true
	},
	{
		id: "AV-C002",
		headId: "AV-HD-001",
		firstName: "Fatima",
		lastName: "Ali",
		gender: "Female",
		nationality: "Pakistani",
		passport: "AB1234568",
		phone: "03001111112",
		packageType: "Umrah",
		paymentStatus: "Paid",
		baseDue: 1e5,
		amountDue: 99e3,
		amountPaid: 99e3,
		isVip: false
	},
	{
		id: "AV-C003",
		headId: "AV-HD-001",
		firstName: "Hassan",
		lastName: "Ali",
		gender: "Male",
		nationality: "Pakistani",
		passport: "AB1234569",
		phone: "03001111113",
		packageType: "Umrah",
		paymentStatus: "Partial",
		baseDue: 1e5,
		amountDue: 99e3,
		amountPaid: 52e3,
		isVip: false
	},
	{
		id: "AV-C004",
		headId: "AV-HD-001",
		firstName: "Aisha",
		lastName: "Ali",
		gender: "Female",
		nationality: "Pakistani",
		passport: "AB1234570",
		phone: "03001111114",
		packageType: "Umrah",
		paymentStatus: "Unpaid",
		baseDue: 1e5,
		amountDue: 99e3,
		amountPaid: 0,
		isVip: false
	},
	{
		id: "AV-C005",
		headId: "AV-HD-001",
		firstName: "Omar",
		lastName: "Ali",
		gender: "Male",
		nationality: "Pakistani",
		passport: "AB1234571",
		phone: "03001111115",
		packageType: "Umrah",
		paymentStatus: "Unpaid",
		baseDue: 1e5,
		amountDue: 99e3,
		amountPaid: 0,
		isVip: false
	},
	{
		id: "AV-C006",
		headId: "AV-HD-002",
		firstName: "Zainab",
		lastName: "Raza",
		gender: "Female",
		nationality: "Pakistani",
		passport: "CD5678901",
		phone: "03002222221",
		packageType: "Hajj",
		paymentStatus: "Paid",
		amountDue: 25e4,
		amountPaid: 25e4,
		isVip: true
	},
	{
		id: "AV-C007",
		headId: "AV-HD-002",
		firstName: "Aamir",
		lastName: "Raza",
		gender: "Male",
		nationality: "Pakistani",
		passport: "CD5678902",
		phone: "03002222222",
		packageType: "Hajj",
		paymentStatus: "Paid",
		amountDue: 25e4,
		amountPaid: 25e4,
		isVip: false
	},
	{
		id: "AV-C008",
		headId: "AV-HD-002",
		firstName: "Nadia",
		lastName: "Raza",
		gender: "Female",
		nationality: "Pakistani",
		passport: "CD5678903",
		phone: "03002222223",
		packageType: "Hajj",
		paymentStatus: "Partial",
		amountDue: 25e4,
		amountPaid: 1e5,
		isVip: false
	},
	{
		id: "AV-C009",
		headId: "AV-HD-003",
		firstName: "Kamran",
		lastName: "Sheikh",
		gender: "Male",
		nationality: "Pakistani",
		passport: "EF9012345",
		phone: "03003333331",
		packageType: "Tour",
		paymentStatus: "Paid",
		amountDue: 8e4,
		amountPaid: 8e4,
		isVip: false
	},
	{
		id: "AV-C010",
		headId: "AV-HD-003",
		firstName: "Sadia",
		lastName: "Sheikh",
		gender: "Female",
		nationality: "Pakistani",
		passport: "EF9012346",
		phone: "03003333332",
		packageType: "Tour",
		paymentStatus: "Unpaid",
		amountDue: 8e4,
		amountPaid: 0,
		isVip: false
	}
];
var mockBookings = [
	{
		id: "B001",
		headId: "AV-HD-001",
		agentId: "AV-A001",
		supplierId: "AV-S001",
		baseAmount: 5e5,
		totalAmount: 495e3,
		amountReceived: 25e4,
		totalCost: 35e4,
		commission: 25e3,
		clientIds: [
			"AV-C001",
			"AV-C002",
			"AV-C003",
			"AV-C004",
			"AV-C005"
		],
		status: "Confirmed",
		packageType: "Umrah",
		travelDate: "2026-06-15",
		createdAt: "2026-03-01",
		members: 5,
		destination: "Makkah / Madinah",
		profitStatus: "earned",
		profitEarnedDate: "2026-03-20",
		discount: 5e3,
		discountSettlement: "agent_commission"
	},
	{
		id: "B002",
		headId: "AV-HD-002",
		agentId: "AV-A002",
		supplierId: "AV-S002",
		totalAmount: 75e4,
		amountReceived: 6e5,
		totalCost: 5e5,
		commission: 3e4,
		clientIds: [
			"AV-C006",
			"AV-C007",
			"AV-C008"
		],
		status: "Confirmed",
		packageType: "Hajj",
		travelDate: "2026-07-10",
		createdAt: "2026-02-15",
		members: 3,
		destination: "Makkah / Madinah",
		profitStatus: "earned",
		profitEarnedDate: "2026-03-25",
		supplierDiscount: 1e4
	},
	{
		id: "B003",
		headId: "AV-HD-003",
		agentId: "AV-A003",
		supplierId: "AV-S003",
		totalAmount: 16e4,
		amountReceived: 8e4,
		totalCost: 1e5,
		commission: 8e3,
		clientIds: ["AV-C009", "AV-C010"],
		status: "Pending",
		packageType: "Tour",
		travelDate: "2026-05-20",
		createdAt: "2026-04-01",
		members: 2,
		destination: "Istanbul, Turkey",
		profitStatus: "unearned"
	}
];
var mockMonthlyData = [
	{
		month: "Jan",
		revenue: 45e4,
		clients: 12,
		profit: 85e3
	},
	{
		month: "Feb",
		revenue: 62e4,
		clients: 18,
		profit: 124e3
	},
	{
		month: "Mar",
		revenue: 38e4,
		clients: 10,
		profit: 72e3
	},
	{
		month: "Apr",
		revenue: 89e4,
		clients: 25,
		profit: 178e3
	}
];
function distributePayment(clients, totalReceived) {
	let remaining = totalReceived;
	return clients.map((client) => {
		if (remaining <= 0) return {
			...client,
			amountPaid: 0,
			paymentStatus: "Unpaid"
		};
		if (remaining >= client.amountDue) {
			remaining -= client.amountDue;
			return {
				...client,
				amountPaid: client.amountDue,
				paymentStatus: "Paid"
			};
		}
		const paid = remaining;
		remaining = 0;
		return {
			...client,
			amountPaid: paid,
			paymentStatus: "Partial"
		};
	});
}
function formatCurrency(amount) {
	const n = Math.round(Number(amount) || 0);
	const formatted = Math.abs(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	return n < 0 ? `-Rs ${formatted}` : `Rs ${formatted}`;
}
function generateId(prefix, num) {
	return `${prefix}${String(num).padStart(3, "0")}`;
}
/** Preset inclusions — extendable by the user from the package builder (saved in the store). */
var DEFAULT_INCLUSIONS = [
	{
		label: "Flight Tickets",
		kind: "flight"
	},
	{
		label: "Hotel Accommodation",
		kind: "hotel"
	},
	{
		label: "Visa Processing",
		kind: "visa"
	},
	{
		label: "Private Transport",
		kind: "transport"
	},
	{
		label: "Guided Ziyarah",
		kind: "ziyarah"
	},
	{
		label: "Ziyarah Makkah",
		kind: "ziyarah"
	},
	{
		label: "Ziyarah Madinah",
		kind: "ziyarah"
	},
	{
		label: "Daily Breakfast",
		kind: "meal"
	},
	{
		label: "Travel Insurance",
		kind: "insurance"
	},
	{
		label: "Meet & Greet at Airport",
		kind: "guide"
	},
	{
		label: "Nusuk / Mukim Permit",
		kind: "processing"
	},
	{
		label: "Zam Zam Water (5L)",
		kind: "custom"
	},
	{
		label: "Tour Guide",
		kind: "guide"
	},
	{
		label: "Laundry Service",
		kind: "custom"
	},
	{
		label: "Wheelchair Assistance",
		kind: "custom"
	}
];
var CHECKLIST_STATUSES = [
	"Pending",
	"In Progress",
	"Completed"
];
/** Default service items every package client starts with (agent can add/edit/delete). */
var DEFAULT_CHECKLIST_LABELS = [
	"Transport",
	"Ziyarat",
	"Hotel",
	"Visa"
];
function defaultChecklist() {
	return DEFAULT_CHECKLIST_LABELS.map((label, i) => ({
		id: `chk-${i + 1}-${label.toLowerCase()}`,
		label,
		status: "Pending"
	}));
}
/** Never returns undefined — clients without a stored checklist fall back to defaults. */
function getChecklist(c) {
	return c.checklist && c.checklist.length ? c.checklist : defaultChecklist();
}
function checklistProgress(c) {
	const items = getChecklist(c);
	const completed = items.filter((i) => i.status === "Completed").length;
	const inProgress = items.filter((i) => i.status === "In Progress").length;
	const total = items.length;
	return {
		total,
		completed,
		inProgress,
		pending: total - completed - inProgress,
		percent: total ? Math.round(completed / total * 100) : 0,
		isComplete: total > 0 && completed === total,
		label: `${completed}/${total}`
	};
}
/** Cycle a status on tick: Pending → In Progress → Completed → Pending */
function nextStatus(s) {
	return s === "Pending" ? "In Progress" : s === "In Progress" ? "Completed" : "Pending";
}
var statusTone = {
	Pending: "text-muted-foreground border-border bg-muted/40",
	"In Progress": "text-warning border-warning/30 bg-warning/10",
	Completed: "text-success border-success/30 bg-success/10"
};
function getPKTDate() {
	return (/* @__PURE__ */ new Date()).toLocaleString("en-CA", {
		timeZone: "Asia/Karachi",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	});
}
var firebase_applet_config_default = {
	projectId: "xanthic-indexer-c01dl",
	appId: "1:953490779506:web:e8712915ee0c0fd1b101eb",
	apiKey: "AIzaSyBksymUs26wVeVpbf2epVPFaK71TtnDgbU",
	authDomain: "xanthic-indexer-c01dl.firebaseapp.com",
	firestoreDatabaseId: "ai-studio-averysystem-5c8ff428-09d9-4efc-b1e2-cdf13d93aca8",
	storageBucket: "xanthic-indexer-c01dl.firebasestorage.app",
	messagingSenderId: "953490779506",
	measurementId: "",
	oAuthClientId: "953490779506-uli1635558mfr1t4kr95ueg9peinqu3m.apps.googleusercontent.com",
	recaptchaSiteKey: ""
};
var app = getApps().length === 0 ? initializeApp(firebase_applet_config_default) : getApp();
var db = (() => {
	try {
		return initializeFirestore(app, { ignoreUndefinedProperties: true }, firebase_applet_config_default.firestoreDatabaseId);
	} catch {
		return getFirestore(app, firebase_applet_config_default.firestoreDatabaseId);
	}
})();
var auth = getAuth(app);
function handleFirestoreError(error, operationType, path) {
	const errInfo = {
		error: error instanceof Error ? error.message : String(error),
		authInfo: {
			userId: auth.currentUser?.uid,
			email: auth.currentUser?.email,
			emailVerified: auth.currentUser?.emailVerified,
			isAnonymous: auth.currentUser?.isAnonymous,
			tenantId: auth.currentUser?.tenantId,
			providerInfo: auth.currentUser?.providerData?.map((provider) => ({
				providerId: provider.providerId,
				email: provider.email
			})) || []
		},
		operationType,
		path
	};
	console.error("Firestore Error: ", JSON.stringify(errInfo));
	throw new Error(JSON.stringify(errInfo));
}
/**
* Validate Connection to Firestore
* Only runs remote probe when authenticated or explicitly requested
*/
async function testConnection() {
	if (typeof window === "undefined") return {
		ok: true,
		message: "Server-side render (bypassed)"
	};
	if (!auth.currentUser) return {
		ok: true,
		message: "Local mode active (sign in to sync with Cloud DB)"
	};
	try {
		await getDocFromServer(doc(db, "test", "connection"));
		return {
			ok: true,
			message: "Connected to Cloud Firestore"
		};
	} catch (error) {
		const msg = error instanceof Error ? error.message : String(error);
		if (msg.includes("the client is offline") || msg.includes("token-service-api")) return {
			ok: false,
			message: "Cloud connection offline or token service pending"
		};
		return {
			ok: true,
			message: "Connection verified"
		};
	}
}
/**
* Sign in using Google Provider via popup
*/
async function signInWithGoogle() {
	const provider = new GoogleAuthProvider();
	provider.setCustomParameters({ prompt: "select_account" });
	try {
		return (await signInWithPopup(auth, provider)).user;
	} catch (err) {
		const code = err?.code;
		const msgLower = (err instanceof Error ? err.message : String(err)).toLowerCase();
		const currentHost = typeof window !== "undefined" ? window.location.hostname : "";
		if (code === "auth/unauthorized-domain") {
			const errorMsg = `Domain "${currentHost}" is not authorized. Please add "${currentHost}" to Firebase Console -> Authentication -> Settings -> Authorized Domains.`;
			console.error(errorMsg);
			throw new Error(errorMsg);
		}
		if (code === "auth/missing-initial-state" || msgLower.includes("missing initial state") || msgLower.includes("sessionstorage")) throw new Error("Mobile App WebView blocked Google popup. Please open this app in your device's browser (Chrome / Safari).");
		if (code === "auth/popup-blocked" || msgLower.includes("popup")) throw new Error("Popup blocked. Please open this app in your mobile browser (Chrome/Safari) or enable popups.");
		if (code === "auth/popup-closed-by-user") throw new Error("Sign-in popup was closed before completing.");
		console.error("Sign in with Google error:", err);
		throw err;
	}
}
/**
* Sign out current user
*/
async function logOut() {
	await signOut(auth);
}
/**
* Delete an entity from a Firestore collection
*/
async function deleteDocFromFirestore(collectionName, id) {
	if (!auth.currentUser) return;
	const path = `${collectionName}/${id}`;
	try {
		await deleteDoc(doc(db, collectionName, id));
	} catch (err) {
		handleFirestoreError(err, "delete", path);
	}
}
/**
* Pull all documents from a Firestore collection
*/
async function fetchCollectionFromFirestore(collectionName) {
	const path = collectionName;
	try {
		return (await getDocs(collection(db, collectionName))).docs.map((d) => d.data());
	} catch (err) {
		handleFirestoreError(err, "list", path);
	}
}
/**
* Recursively cleans undefined and non-serializable fields before sending to Firestore
*/
function cleanDataForFirestore(data) {
	if (data === void 0 || data === null) return data;
	return JSON.parse(JSON.stringify(data));
}
/**
* Fetch a single document from Firestore
*/
async function fetchDocFromFirestore(collectionName, id) {
	const path = `${collectionName}/${id}`;
	try {
		const snap = await getDoc(doc(db, collectionName, id));
		if (!snap.exists()) return null;
		return snap.data();
	} catch (err) {
		handleFirestoreError(err, "get", path);
	}
}
/**
* Push full app state to Firestore
*/
async function pushFullStateToFirestore(state, opts) {
	if (!auth.currentUser) throw new Error("Must be signed in to sync to Cloud Database");
	const collectionsToSync = [
		{
			name: "clients",
			items: state.clients || []
		},
		{
			name: "bookings",
			items: state.bookings || []
		},
		{
			name: "agents",
			items: state.agents || []
		},
		{
			name: "suppliers",
			items: state.suppliers || []
		},
		{
			name: "entries",
			items: state.entries || []
		},
		{
			name: "groups",
			items: state.groups || []
		},
		{
			name: "accounts",
			items: state.accounts || []
		},
		{
			name: "drawers",
			items: state.drawers || []
		}
	];
	for (const { name, items } of collectionsToSync) {
		if (opts?.pruneOrphans) try {
			const remoteDocs = await getDocs(collection(db, name));
			const keepIds = new Set((items || []).map((it) => String(it.id)));
			const deleteBatch = writeBatch(db);
			let count = 0;
			remoteDocs.docs.forEach((d) => {
				if (!keepIds.has(d.id)) {
					deleteBatch.delete(d.ref);
					count++;
				}
			});
			if (count > 0) await deleteBatch.commit();
		} catch (err) {
			console.warn(`Could not prune orphans in ${name}:`, err);
		}
		if (!items || items.length === 0) continue;
		const chunkSize = 400;
		for (let i = 0; i < items.length; i += chunkSize) {
			const chunk = items.slice(i, i + chunkSize);
			const batch = writeBatch(db);
			for (const item of chunk) if (item.id) {
				const cleanItem = cleanDataForFirestore(item);
				batch.set(doc(db, name, String(item.id)), cleanItem, { merge: true });
			}
			await batch.commit();
		}
	}
	if (state.opening) await setDoc(doc(db, "settings", "opening"), {
		id: "opening",
		data: cleanDataForFirestore(state.opening)
	}, { merge: true });
	if (state.alertSettings) await setDoc(doc(db, "settings", "alertSettings"), {
		id: "alertSettings",
		data: cleanDataForFirestore(state.alertSettings)
	}, { merge: true });
}
var defaultAlertSettings = {
	lowBalance: 2e4,
	agentDueLimit: 1e5,
	unmatchedDays: 7,
	clientOverdueDays: 15
};
/** Money direction implied by an entry type (used for Account posting). */
function entryDirection(type) {
	return type === "client_receive" || type === "supplier_refund" || type === "other_sale" || type === "agent_receive" ? "in" : "out";
}
var STORAGE_KEY = "av-crm-store-v1";
var defaultOpening = {
	revenue: 0,
	pending: 0,
	bookings: 0,
	clients: 0,
	supplierDue: 0,
	profit: 0,
	cost: 0,
	expenses: 0,
	commission: 0,
	cash: 0
};
var defaultDrawers = [{
	id: "DR-001",
	name: "Muhammad Ali",
	role: "Managing Partner",
	phone: "0330-2793701",
	sharePercent: 60,
	notes: "Lead Operations & Agency Strategy"
}, {
	id: "DR-002",
	name: "Executive Partner",
	role: "Partner / Director",
	sharePercent: 40,
	notes: "Investment & Capital Partner"
}];
var defaultEntries = [
	{
		id: "E001",
		date: "2026-03-15",
		type: "client_receive",
		headId: "AV-HD-001",
		referenceId: "AV-C001",
		referenceName: "Muhammad Ali",
		amount: 1e5,
		note: "Initial deposit",
		createdAt: "2026-03-15T10:00:00"
	},
	{
		id: "E002",
		date: "2026-03-20",
		type: "client_receive",
		headId: "AV-HD-001",
		referenceId: "AV-C002",
		referenceName: "Fatima Ali",
		amount: 1e5,
		note: "Full payment",
		createdAt: "2026-03-20T14:30:00"
	},
	{
		id: "E003",
		date: "2026-03-25",
		type: "supplier_payment",
		headId: "",
		referenceId: "AV-S001",
		referenceName: "Al-Haram Hotels",
		amount: 2e5,
		note: "Hotel advance",
		createdAt: "2026-03-25T11:00:00"
	},
	{
		id: "E004",
		date: "2026-04-01",
		type: "agent_commission",
		headId: "",
		referenceId: "AV-A001",
		referenceName: "Ahmed Khan",
		amount: 5e4,
		note: "March commission",
		createdAt: "2026-04-01T09:00:00"
	},
	{
		id: "E005",
		date: "2026-04-05",
		type: "expense",
		headId: "",
		referenceId: "",
		referenceName: "Office Rent",
		amount: 3e4,
		note: "Monthly office rent",
		createdAt: "2026-04-05T12:00:00"
	},
	{
		id: "E006",
		date: "2026-02-10",
		type: "client_receive",
		headId: "AV-HD-002",
		referenceId: "AV-C006",
		referenceName: "Zainab Raza",
		amount: 25e4,
		note: "Full payment Hajj",
		createdAt: "2026-02-10T10:00:00"
	}
];
function loadState() {
	return {
		clients: [...mockClients],
		bookings: [...mockBookings],
		agents: [...mockAgents],
		suppliers: [...mockSuppliers],
		monthlyData: [...mockMonthlyData],
		entries: defaultEntries,
		drawers: defaultDrawers,
		counters: {
			client: 11,
			agent: 4,
			supplier: 5,
			booking: 4,
			head: 4,
			entry: 7
		}
	};
}
var initial = loadState();
var clients = initial.clients;
var bookings = initial.bookings;
var agents = initial.agents;
var suppliers = initial.suppliers;
var monthlyData = initial.monthlyData;
var entries = initial.entries;
var opening = initial.opening || { ...defaultOpening };
var groups = initial.groups || [];
var accounts = initial.accounts || [{
	id: "AC-001",
	name: "Main Cash",
	type: "Cash",
	openingBalance: 0,
	openingDate: "2026-01-01"
}];
var drawers = initial.drawers || defaultDrawers;
var alertSettings = initial.alertSettings || { ...defaultAlertSettings };
var readAlerts = initial.readAlerts || [];
var customInclusions = initial.customInclusions || [];
var customCombos = initial.customCombos || [];
var nextAccountNum = 2;
var nextDrawerNum = (initial.drawers?.length || 2) + 1;
var nextClientNum = initial.counters.client;
var nextAgentNum = initial.counters.agent;
var nextSupplierNum = initial.counters.supplier;
var nextBookingNum = initial.counters.booking;
var nextHeadNum = initial.counters.head;
var nextEntryNum = initial.counters.entry;
var nextGroupNum = initial.counters.group || 1;
function recalculateCounters() {
	entries.forEach((en) => {
		const num = parseInt(en.id.replace(/\D/g, ""), 10);
		if (!isNaN(num) && num >= nextEntryNum) nextEntryNum = num + 1;
	});
	clients.forEach((c) => {
		const num = parseInt(c.id.replace(/\D/g, ""), 10);
		if (!isNaN(num) && num >= nextClientNum) nextClientNum = num + 1;
	});
	bookings.forEach((bk) => {
		const num = parseInt(bk.id.replace(/\D/g, ""), 10);
		if (!isNaN(num) && num >= nextBookingNum) nextBookingNum = num + 1;
		const headNum = parseInt((bk.headId || "").replace(/\D/g, ""), 10);
		if (!isNaN(headNum) && headNum >= nextHeadNum) nextHeadNum = headNum + 1;
	});
	agents.forEach((ag) => {
		const num = parseInt(ag.id.replace(/\D/g, ""), 10);
		if (!isNaN(num) && num >= nextAgentNum) nextAgentNum = num + 1;
	});
	suppliers.forEach((sp) => {
		const num = parseInt(sp.id.replace(/\D/g, ""), 10);
		if (!isNaN(num) && num >= nextSupplierNum) nextSupplierNum = num + 1;
	});
	groups.forEach((gp) => {
		const num = parseInt(gp.id.replace(/\D/g, ""), 10);
		if (!isNaN(num) && num >= nextGroupNum) nextGroupNum = num + 1;
	});
}
var saveTimer = null;
var cloudDebounceTimer = null;
var cloudSyncStatus = "idle";
var lastSyncedAt = null;
async function syncToCloud(opts) {
	if (typeof window === "undefined" || !auth.currentUser) return {
		success: false,
		reason: "not_authenticated"
	};
	cloudSyncStatus = "syncing";
	listeners.forEach((l) => l());
	try {
		await pushFullStateToFirestore({
			clients,
			bookings,
			agents,
			suppliers,
			entries,
			groups,
			accounts,
			drawers,
			opening,
			alertSettings
		}, opts);
		cloudSyncStatus = "synced";
		lastSyncedAt = (/* @__PURE__ */ new Date()).toLocaleTimeString();
		listeners.forEach((l) => l());
		return { success: true };
	} catch (err) {
		cloudSyncStatus = "error";
		listeners.forEach((l) => l());
		throw err;
	}
}
async function loadFromCloud() {
	if (typeof window === "undefined" || !auth.currentUser) return {
		success: false,
		reason: "not_authenticated"
	};
	cloudSyncStatus = "syncing";
	listeners.forEach((l) => l());
	try {
		const [c, b, a, s, e, g, acc, dr, openDoc, alertDoc] = await Promise.all([
			fetchCollectionFromFirestore("clients"),
			fetchCollectionFromFirestore("bookings"),
			fetchCollectionFromFirestore("agents"),
			fetchCollectionFromFirestore("suppliers"),
			fetchCollectionFromFirestore("entries"),
			fetchCollectionFromFirestore("groups"),
			fetchCollectionFromFirestore("accounts"),
			fetchCollectionFromFirestore("drawers"),
			fetchDocFromFirestore("settings", "opening"),
			fetchDocFromFirestore("settings", "alertSettings")
		]);
		if (c?.length) {
			const map = /* @__PURE__ */ new Map();
			c.forEach((item) => {
				if (item.id) map.set(item.id, normalizeClient(item));
			});
			clients = Array.from(map.values());
		}
		if (b?.length) {
			const map = /* @__PURE__ */ new Map();
			b.forEach((item) => {
				if (item.id) map.set(item.id, normalizeBooking(item));
			});
			bookings = Array.from(map.values());
		}
		if (a?.length) {
			const map = /* @__PURE__ */ new Map();
			a.forEach((item) => {
				if (item.id) map.set(item.id, item);
			});
			agents = Array.from(map.values());
		}
		if (s?.length) {
			const map = /* @__PURE__ */ new Map();
			s.forEach((item) => {
				if (item.id) map.set(item.id, normalizeSupplier(item));
			});
			suppliers = Array.from(map.values());
		}
		if (e?.length) {
			const map = /* @__PURE__ */ new Map();
			e.forEach((item, i) => {
				if (item.id) map.set(item.id, normalizeEntry(item, i));
			});
			entries = Array.from(map.values());
		}
		if (g?.length) {
			const map = /* @__PURE__ */ new Map();
			g.forEach((item) => {
				if (item.id) map.set(item.id, item);
			});
			groups = Array.from(map.values());
		}
		if (acc?.length) {
			const map = /* @__PURE__ */ new Map();
			acc.forEach((item) => {
				if (item.id) map.set(item.id, item);
			});
			accounts = Array.from(map.values());
		}
		if (dr?.length) {
			const map = /* @__PURE__ */ new Map();
			dr.forEach((item) => {
				if (item.id) map.set(item.id, item);
			});
			drawers = Array.from(map.values());
		}
		if (openDoc?.data) opening = {
			...defaultOpening,
			...openDoc.data
		};
		if (alertDoc?.data) alertSettings = {
			...defaultAlertSettings,
			...alertDoc.data
		};
		accounts = restoreMissingAccounts(accounts, entries);
		recalculateCounters();
		resyncDerived();
		cloudSyncStatus = "synced";
		lastSyncedAt = (/* @__PURE__ */ new Date()).toLocaleTimeString();
		notify();
		return {
			success: true,
			count: clients.length + bookings.length + entries.length
		};
	} catch (err) {
		cloudSyncStatus = "error";
		listeners.forEach((l) => l());
		throw err;
	}
}
function persist() {
	if (typeof window === "undefined") return;
	if (!hydrated) return;
	if (saveTimer) clearTimeout(saveTimer);
	saveTimer = setTimeout(() => {
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify({
				clients,
				bookings,
				agents,
				suppliers,
				monthlyData,
				entries,
				opening,
				groups,
				accounts,
				drawers,
				alertSettings,
				readAlerts,
				customInclusions,
				customCombos,
				counters: {
					client: nextClientNum,
					agent: nextAgentNum,
					supplier: nextSupplierNum,
					booking: nextBookingNum,
					head: nextHeadNum,
					entry: nextEntryNum,
					group: nextGroupNum
				}
			}));
		} catch {}
	}, 150);
	if (auth.currentUser) {
		if (cloudDebounceTimer) clearTimeout(cloudDebounceTimer);
		cloudDebounceTimer = setTimeout(() => {
			syncToCloud().catch(() => {});
		}, 2500);
	}
}
function takeStateSnapshot() {
	return {
		clients: JSON.parse(JSON.stringify(clients)),
		bookings: JSON.parse(JSON.stringify(bookings)),
		agents: JSON.parse(JSON.stringify(agents)),
		suppliers: JSON.parse(JSON.stringify(suppliers)),
		entries: JSON.parse(JSON.stringify(entries)),
		accounts: JSON.parse(JSON.stringify(accounts)),
		drawers: JSON.parse(JSON.stringify(drawers)),
		groups: JSON.parse(JSON.stringify(groups))
	};
}
function restoreStateSnapshot(s) {
	clients = s.clients;
	bookings = s.bookings;
	agents = s.agents;
	suppliers = s.suppliers;
	entries = s.entries;
	accounts = s.accounts;
	drawers = s.drawers;
	groups = s.groups;
	resyncDerived();
	notify();
}
var lastUndoAction = null;
var undoExpiryTimer = null;
function registerUndoableAction(description, rollback) {
	lastUndoAction = {
		description,
		rollback
	};
	if (undoExpiryTimer) clearTimeout(undoExpiryTimer);
	undoExpiryTimer = setTimeout(() => {
		lastUndoAction = null;
		listeners.forEach((l) => l());
	}, 9e3);
	toast.success(description, {
		duration: 8500,
		action: {
			label: "Undo (8s)",
			onClick: () => {
				rollback();
				lastUndoAction = null;
				if (undoExpiryTimer) clearTimeout(undoExpiryTimer);
				toast.info("Action reverted successfully!", { duration: 3e3 });
			}
		}
	});
	listeners.forEach((l) => l());
}
function undoLastAction() {
	if (lastUndoAction) {
		lastUndoAction.rollback();
		lastUndoAction = null;
		if (undoExpiryTimer) clearTimeout(undoExpiryTimer);
		toast.info("Action reverted successfully!", { duration: 3e3 });
	} else toast.info("No action available to undo", { duration: 2500 });
}
function hasUndo() {
	return !!lastUndoAction;
}
var listeners = /* @__PURE__ */ new Set();
function notify() {
	persist();
	listeners.forEach((l) => l());
}
var hydrated = false;
function hydrateFromStorage() {
	if (hydrated || typeof window === "undefined") return;
	hydrated = true;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return;
		const s = JSON.parse(raw);
		if (Array.isArray(s.clients)) clients = s.clients.map((c) => normalizeClient(c));
		if (Array.isArray(s.bookings)) bookings = s.bookings.map((b) => normalizeBooking(b));
		if (Array.isArray(s.agents)) agents = s.agents;
		if (Array.isArray(s.suppliers)) suppliers = s.suppliers;
		if (Array.isArray(s.monthlyData)) monthlyData = s.monthlyData;
		if (Array.isArray(s.entries)) entries = s.entries.map((e, i) => normalizeEntry(e, i));
		opening = {
			...defaultOpening,
			...s.opening || {}
		};
		if (Array.isArray(s.groups)) groups = s.groups;
		if (Array.isArray(s.accounts)) accounts = s.accounts;
		accounts = restoreMissingAccounts(accounts, entries);
		if (s.drawers && s.drawers.length) {
			drawers = s.drawers;
			nextDrawerNum = s.drawers.length + 1;
		}
		if (s.alertSettings) alertSettings = {
			...defaultAlertSettings,
			...s.alertSettings
		};
		if (s.readAlerts) readAlerts = s.readAlerts;
		if (Array.isArray(s.customInclusions)) customInclusions = s.customInclusions;
		if (Array.isArray(s.customCombos)) customCombos = s.customCombos;
		nextAccountNum = accounts.length + 1;
		if (s.counters) {
			nextClientNum = s.counters.client;
			nextAgentNum = s.counters.agent;
			nextSupplierNum = s.counters.supplier;
			nextBookingNum = s.counters.booking;
			nextHeadNum = s.counters.head;
			nextEntryNum = s.counters.entry;
			nextGroupNum = s.counters.group || nextGroupNum;
		}
		recalculateCounters();
	} catch {}
	resyncDerived();
	listeners.forEach((l) => l());
}
/** How many pax are already consumed by a given group — CLIENT members only.
*  Supplier purchases / bills / expenses tagged to the group never consume seats. */
function computeGroupUsedPax(groupId) {
	return bookings.filter((b) => b.groupId === groupId).reduce((sum, b) => {
		return sum + (clients.filter((c) => c.headId === b.headId).length || b.members || 0);
	}, 0);
}
/** Agents are ALWAYS derived: sales / clients / commission come from bookings,
*  paid commission comes from the ledger. Never mutated by deltas. */
function resyncAgents() {
	agents = agents.map((a) => {
		const ab = bookings.filter((b) => b.agentId === a.id);
		const heads = new Set(ab.map((b) => b.headId));
		const memberCount = clients.filter((c) => heads.has(c.headId)).length;
		const totalCommission = ab.reduce((s, b) => {
			const orig = b.commission || 0;
			if (b.discount && b.discountSettlement === "agent_commission") {
				const agentAbsorbed = Math.min(orig, b.discount);
				return s + Math.max(0, orig - agentAbsorbed);
			}
			return s + orig;
		}, 0);
		return {
			...a,
			totalSales: ab.reduce((s, b) => s + (b.totalAmount || 0), 0),
			totalClients: memberCount || ab.reduce((s, b) => s + (b.members || 0), 0),
			commission: totalCommission,
			paidCommission: entries.filter((e) => e.type === "agent_commission" && e.referenceId === a.id).reduce((s, e) => s + e.amount, 0)
		};
	});
}
/** Suppliers are derived from purchases / refunds / discounts / payments (booking cost as fallback). */
function resyncSuppliers() {
	suppliers = suppliers.map((s) => {
		const purchases = entries.filter((e) => e.type === "purchase" && e.referenceId === s.id).reduce((sum, e) => sum + e.amount, 0);
		const refunds = entries.filter((e) => e.type === "supplier_refund" && e.referenceId === s.id).reduce((sum, e) => sum + e.amount, 0);
		const discounts = entries.filter((e) => e.type === "supplier_discount" && e.referenceId === s.id).reduce((sum, e) => sum + e.amount, 0);
		const payments = entries.filter((e) => e.type === "supplier_payment" && e.referenceId === s.id).reduce((sum, e) => sum + e.amount, 0);
		const bookingCost = bookings.filter((b) => b.supplierId === s.id).reduce((sum, b) => {
			const baseCost = b.totalCost || 0;
			const bSupDisc = b.supplierDiscount || 0;
			return sum + Math.max(0, baseCost - bSupDisc);
		}, 0);
		return {
			...s,
			totalPayable: Math.max(0, Math.max(purchases, bookingCost) - refunds - discounts),
			totalPaid: payments
		};
	});
}
/** Recompute everything that is derived. Cheap for CRM-sized data. */
function resyncDerived() {
	resyncSuppliers();
	resyncAgents();
}
function resyncFromEntries(refIds) {
	const headIds = new Set(refIds.headIds || []);
	resyncDerived();
	if (headIds.size) headIds.forEach((headId) => {
		const gross = entries.filter((e) => e.type === "client_receive" && e.headId === headId).reduce((s, e) => s + e.amount, 0);
		const refundList = entries.filter((e) => e.type === "client_refund" && e.headId === headId);
		const refunded = refundList.reduce((s, e) => s + e.amount, 0);
		const discountList = entries.filter((e) => e.type === "client_discount" && e.headId === headId);
		const discountTotal = discountList.reduce((s, e) => s + e.amount, 0);
		const charges = entries.filter((e) => e.type === "client_charge" && e.headId === headId);
		const chargeTotal = charges.reduce((s, e) => s + e.amount, 0);
		const totalReceived = Math.max(0, gross - refunded);
		bookings = bookings.map((b) => {
			if (b.headId !== headId) return b;
			const base = b.baseAmount ?? b.totalAmount;
			return {
				...b,
				baseAmount: base,
				extraCharges: chargeTotal,
				refunded,
				totalAmount: Math.max(0, base + chargeTotal - refunded - discountTotal),
				amountReceived: totalReceived
			};
		});
		const leadId = clients.filter((c) => c.headId === headId)[0]?.id;
		clients = clients.map((c) => {
			if (c.headId !== headId) return c;
			const extra = charges.filter((e) => e.clientId ? e.clientId === c.id : c.id === leadId).reduce((s, e) => s + e.amount, 0);
			const refund = refundList.filter((e) => e.clientId ? e.clientId === c.id : c.id === leadId).reduce((s, e) => s + e.amount, 0);
			const discount = discountList.filter((e) => e.clientId ? e.clientId === c.id : c.id === leadId).reduce((s, e) => s + e.amount, 0);
			const base = c.baseDue ?? c.amountDue;
			return {
				...c,
				baseDue: base,
				extraCharges: extra,
				refunded: refund,
				amountDue: Math.max(0, base + extra - refund - discount)
			};
		});
		let remaining = totalReceived;
		clients = clients.map((c) => {
			if (c.headId !== headId) return c;
			if (remaining <= 0) return {
				...c,
				amountPaid: 0,
				paymentStatus: "Unpaid"
			};
			if (remaining >= c.amountDue) {
				remaining -= c.amountDue;
				return {
					...c,
					amountPaid: c.amountDue,
					paymentStatus: "Paid"
				};
			}
			const paid = remaining;
			remaining = 0;
			return {
				...c,
				amountPaid: paid,
				paymentStatus: "Partial"
			};
		});
	});
	resyncAgents();
}
/** Live balance of an account: opening balance + transactions on or after openingDate. */
function computeAccountBalance(accountId) {
	const acc = (accounts || []).find((a) => a.id === accountId);
	if (!acc) return 0;
	const minDate = acc.openingDate || "";
	return (entries || []).reduce((bal, e) => {
		if (!e) return bal;
		const eDate = e.date || "";
		if (minDate && eDate < minDate) return bal;
		const amt = Number(e.amount) || 0;
		if (e.accountId === accountId) return (e.direction || entryDirection(e.type)) === "in" ? bal + amt : bal - amt;
		if (e.type === "jv" && e.toAccountId === accountId) return bal + amt;
		return bal;
	}, Number(acc.openingBalance) || 0);
}
/** Immutable, chronologically running ledger for one account strictly starting from openingDate. */
function buildAccountLedger(accountId) {
	const acc = (accounts || []).find((a) => a.id === accountId);
	if (!acc) return [];
	const minDate = acc.openingDate || "";
	let running = Number(acc.openingBalance) || 0;
	const relevant = [];
	for (const e of entries || []) {
		if (!e) continue;
		const eDate = e.date || "";
		if (minDate && eDate < minDate) continue;
		if (e.accountId === accountId) {
			const dir = e.direction || entryDirection(e.type);
			let desc = e.note || e.chargeCategory || (e.type ? e.type.replace(/_/g, " ") : "Transaction");
			if (e.type === "jv") {
				if (e.toAccountId) {
					const dest = (accounts || []).find((a) => a.id === e.toAccountId);
					desc = `JV Transfer → ${dest ? dest.name : e.toAccountId}${e.note ? ` (${e.note})` : ""}`;
				} else desc = `JV Adjustment: ${e.note || "Settlement"}`;
			} else if (e.referenceName) desc = `${desc} — ${e.referenceName}`;
			relevant.push({
				e,
				direction: dir,
				desc
			});
		} else if (e.type === "jv" && e.toAccountId === accountId) {
			const src = (accounts || []).find((a) => a.id === e.accountId);
			const desc = `JV Transfer ← ${src ? src.name : e.accountId || "Source"}${e.note ? ` (${e.note})` : ""}`;
			relevant.push({
				e,
				direction: "in",
				desc
			});
		}
	}
	relevant.sort((a, b) => {
		const da = a.e.date || "";
		const db = b.e.date || "";
		if (da !== db) return da.localeCompare(db);
		return (a.e.id || "").localeCompare(b.e.id || "");
	});
	return relevant.map(({ e, direction, desc }) => {
		const amt = Number(e.amount) || 0;
		running = direction === "in" ? running + amt : running - amt;
		return {
			id: e.id,
			date: e.date,
			description: desc,
			transactionType: e.type,
			amount: amt,
			direction,
			runningBalanceAfter: running
		};
	});
}
function useStore() {
	const [, setTick] = (0, import_react.useState)(0);
	const rerender = (0, import_react.useCallback)(() => setTick((t) => t + 1), []);
	(0, import_react.useEffect)(() => {
		listeners.add(rerender);
		hydrateFromStorage();
		return () => {
			listeners.delete(rerender);
		};
	}, [rerender]);
	return {
		clients,
		bookings,
		agents,
		suppliers,
		monthlyData,
		entries,
		opening,
		groups,
		accounts,
		drawers,
		alertSettings,
		readAlerts,
		customInclusions,
		customCombos,
		addDrawer: (data) => {
			const snap = takeStateSnapshot();
			const id = `DR-${String(nextDrawerNum++).padStart(3, "0")}`;
			drawers = [...drawers, {
				...data,
				id
			}];
			notify();
			registerUndoableAction(`Drawer ${data.name} added`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateDrawer: (id, data) => {
			const snap = takeStateSnapshot();
			const target = drawers.find((d) => d.id === id);
			drawers = drawers.map((d) => d.id === id ? {
				...d,
				...data
			} : d);
			notify();
			registerUndoableAction(`Drawer ${target?.name || id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteDrawer: (id) => {
			const snap = takeStateSnapshot();
			const target = drawers.find((d) => d.id === id);
			drawers = drawers.filter((d) => d.id !== id);
			notify();
			registerUndoableAction(`Drawer ${target?.name || id} deleted`, () => restoreStateSnapshot(snap));
		},
		setBookingProfitStatus: (bookingId, status) => {
			const snap = takeStateSnapshot();
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				profitStatus: status,
				profitEarnedDate: status === "earned" ? getPKTDate() : void 0
			} : b);
			notify();
			registerUndoableAction(`Booking ${bookingId} profit marked as ${status}`, () => restoreStateSnapshot(snap));
		},
		toggleBookingProfitStatus: (bookingId) => {
			const snap = takeStateSnapshot();
			let nextStatus = "earned";
			bookings = bookings.map((b) => {
				if (b.id !== bookingId) return b;
				nextStatus = b.profitStatus === "earned" ? "unearned" : "earned";
				return {
					...b,
					profitStatus: nextStatus,
					profitEarnedDate: nextStatus === "earned" ? getPKTDate() : void 0
				};
			});
			notify();
			registerUndoableAction(`Booking ${bookingId} profit changed to ${nextStatus}`, () => restoreStateSnapshot(snap));
		},
		setBookingCompleted: (bookingId, completed) => {
			const snap = takeStateSnapshot();
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				serviceCompleted: completed,
				completedAt: completed ? (/* @__PURE__ */ new Date()).toISOString() : void 0
			} : b);
			notify();
			registerUndoableAction(`Booking ${bookingId} marked as ${completed ? "Completed" : "Active"}`, () => restoreStateSnapshot(snap));
		},
		toggleBookingCompleted: (bookingId) => {
			const snap = takeStateSnapshot();
			let nextCompleted = true;
			bookings = bookings.map((b) => {
				if (b.id !== bookingId) return b;
				nextCompleted = !b.serviceCompleted;
				return {
					...b,
					serviceCompleted: nextCompleted,
					completedAt: nextCompleted ? (/* @__PURE__ */ new Date()).toISOString() : void 0
				};
			});
			notify();
			registerUndoableAction(`Booking ${bookingId} status toggled`, () => restoreStateSnapshot(snap));
		},
		addAccount: (data) => {
			const snap = takeStateSnapshot();
			const id = `AC-${String(nextAccountNum++).padStart(3, "0")}`;
			accounts = [...accounts, {
				...data,
				id
			}];
			notify();
			registerUndoableAction(`Account ${data.name} created`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateAccount: (id, data) => {
			const snap = takeStateSnapshot();
			const target = accounts.find((a) => a.id === id);
			accounts = accounts.map((a) => a.id === id ? {
				...a,
				...data
			} : a);
			notify();
			registerUndoableAction(`Account ${target?.name || id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteAccount: (id) => {
			const snap = takeStateSnapshot();
			const target = accounts.find((a) => a.id === id);
			accounts = accounts.filter((a) => a.id !== id);
			notify();
			registerUndoableAction(`Account ${target?.name || id} deleted`, () => restoreStateSnapshot(snap));
		},
		setAlertSettings: (data) => {
			alertSettings = {
				...alertSettings,
				...data
			};
			notify();
		},
		markAlertRead: (id) => {
			if (!readAlerts.includes(id)) readAlerts = [...readAlerts, id];
			notify();
		},
		markAllAlertsRead: (ids) => {
			readAlerts = [.../* @__PURE__ */ new Set([...readAlerts, ...ids])];
			notify();
		},
		/** Set the reconciliation state of a supplier purchase row. */
		setEntryReconciled: (id, state) => {
			entries = entries.map((e) => e.id === id ? {
				...e,
				reconciled: state
			} : e);
			notify();
		},
		addGroup: (data) => {
			const snap = takeStateSnapshot();
			const id = `AV-G-${String(nextGroupNum++).padStart(3, "0")}`;
			const g = {
				...data,
				id,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			groups = [...groups, g];
			notify();
			registerUndoableAction(`Purchase Group ${data.pnr || id} created`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateGroup: (id, data) => {
			const snap = takeStateSnapshot();
			groups = groups.map((g) => g.id === id ? {
				...g,
				...data
			} : g);
			notify();
			registerUndoableAction(`Purchase Group ${id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteGroup: (id) => {
			const snap = takeStateSnapshot();
			groups = groups.filter((g) => g.id !== id);
			entries = entries.map((e) => e.groupId === id ? {
				...e,
				groupId: void 0
			} : e);
			notify();
			registerUndoableAction(`Purchase Group ${id} deleted`, () => restoreStateSnapshot(snap));
		},
		addClient: (data) => {
			recalculateCounters();
			const snap = takeStateSnapshot();
			const id = generateId("AV-C", nextClientNum++);
			clients = [...clients, {
				...data,
				id,
				baseDue: data.amountDue,
				extraCharges: 0
			}];
			resyncAgents();
			notify();
			registerUndoableAction(`Client ${`${data.firstName || ""} ${data.lastName || ""}`.trim() || id} added`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateClient: (id, data) => {
			const snap = takeStateSnapshot();
			const target = clients.find((c) => c.id === id);
			clients = clients.map((c) => {
				if (c.id !== id) return c;
				const next = {
					...c,
					...data
				};
				if (data.amountDue !== void 0) {
					next.baseDue = data.amountDue;
					next.amountDue = data.amountDue + (c.extraCharges || 0);
				}
				return next;
			});
			notify();
			registerUndoableAction(`Client ${target ? `${target.firstName} ${target.lastName}`.trim() : id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteClient: (id) => {
			const snap = takeStateSnapshot();
			const target = clients.find((c) => c.id === id);
			clients = clients.filter((c) => c.id !== id);
			bookings = bookings.map((b) => ({
				...b,
				clientIds: b.clientIds.filter((cid) => cid !== id)
			}));
			resyncAgents();
			notify();
			deleteDocFromFirestore("clients", id).catch(() => {});
			registerUndoableAction(`Client ${target ? `${target.firstName} ${target.lastName}`.trim() : id} deleted`, () => restoreStateSnapshot(snap));
		},
		addChecklistItem: (clientId, label) => {
			const item = {
				id: `chk-${Date.now().toString(36)}`,
				label: label.trim() || "New item",
				status: "Pending"
			};
			clients = clients.map((c) => c.id === clientId ? {
				...c,
				checklist: [...c.checklist?.length ? c.checklist : defaultChecklist(), item]
			} : c);
			notify();
			return item.id;
		},
		updateChecklistItem: (clientId, itemId, data) => {
			clients = clients.map((c) => {
				if (c.id !== clientId) return c;
				const base = c.checklist?.length ? c.checklist : defaultChecklist();
				return {
					...c,
					checklist: base.map((i) => i.id === itemId ? {
						...i,
						...data
					} : i)
				};
			});
			notify();
		},
		deleteChecklistItem: (clientId, itemId) => {
			clients = clients.map((c) => {
				if (c.id !== clientId) return c;
				const base = c.checklist?.length ? c.checklist : defaultChecklist();
				return {
					...c,
					checklist: base.filter((i) => i.id !== itemId)
				};
			});
			notify();
		},
		setChecklistArchived: (clientId, archived) => {
			clients = clients.map((c) => c.id === clientId ? {
				...c,
				checklistArchived: archived
			} : c);
			notify();
		},
		addAgent: (data) => {
			recalculateCounters();
			const snap = takeStateSnapshot();
			const id = generateId("AV-A", nextAgentNum++);
			agents = [...agents, {
				...data,
				id
			}];
			notify();
			registerUndoableAction(`Agent ${data.name || id} added`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateAgent: (id, data) => {
			const snap = takeStateSnapshot();
			const target = agents.find((a) => a.id === id);
			agents = agents.map((a) => a.id === id ? {
				...a,
				...data
			} : a);
			notify();
			registerUndoableAction(`Agent ${target?.name || id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteAgent: (id) => {
			const snap = takeStateSnapshot();
			const target = agents.find((a) => a.id === id);
			agents = agents.filter((a) => a.id !== id);
			notify();
			deleteDocFromFirestore("agents", id).catch(() => {});
			registerUndoableAction(`Agent ${target?.name || id} deleted`, () => restoreStateSnapshot(snap));
		},
		addSupplier: (data) => {
			recalculateCounters();
			const snap = takeStateSnapshot();
			const id = generateId("AV-S", nextSupplierNum++);
			suppliers = [...suppliers, {
				...data,
				id
			}];
			notify();
			registerUndoableAction(`Supplier ${data.companyName || id} added`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateSupplier: (id, data) => {
			const snap = takeStateSnapshot();
			const target = suppliers.find((s) => s.id === id);
			suppliers = suppliers.map((s) => s.id === id ? {
				...s,
				...data
			} : s);
			notify();
			registerUndoableAction(`Supplier ${target?.companyName || id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteSupplier: (id) => {
			const snap = takeStateSnapshot();
			const target = suppliers.find((s) => s.id === id);
			suppliers = suppliers.filter((s) => s.id !== id);
			notify();
			deleteDocFromFirestore("suppliers", id).catch(() => {});
			registerUndoableAction(`Supplier ${target?.companyName || id} deleted`, () => restoreStateSnapshot(snap));
		},
		addBooking: (data) => {
			recalculateCounters();
			const snap = takeStateSnapshot();
			const id = `B${String(nextBookingNum++).padStart(3, "0")}`;
			bookings = [...bookings, {
				...data,
				id,
				baseAmount: data.totalAmount,
				extraCharges: 0
			}];
			resyncDerived();
			notify();
			registerUndoableAction(`Booking ${id} (${data.packageType || "Custom"}) created`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateBooking: (id, data) => {
			const snap = takeStateSnapshot();
			const before = bookings.find((b) => b.id === id);
			bookings = bookings.map((b) => {
				if (b.id !== id) return b;
				const next = {
					...b,
					...data
				};
				if (data.totalAmount !== void 0) {
					next.baseAmount = data.totalAmount;
					next.totalAmount = data.totalAmount + (b.extraCharges || 0);
				}
				return next;
			});
			const after = bookings.find((b) => b.id === id);
			if (before && after) {
				const headClients = clients.filter((c) => c.headId === after.headId);
				const totalChanged = (before.totalAmount || 0) !== (after.totalAmount || 0);
				const receivedChanged = (before.amountReceived || 0) !== (after.amountReceived || 0);
				if ((totalChanged || receivedChanged) && headClients.length > 0) {
					const perPerson = Math.round((after.totalAmount || 0) / headClients.length);
					let remaining = after.amountReceived || 0;
					clients = clients.map((c) => {
						if (c.headId !== after.headId) return c;
						const due = totalChanged ? perPerson : c.amountDue;
						if (remaining <= 0) return {
							...c,
							amountDue: due,
							amountPaid: 0,
							paymentStatus: "Unpaid"
						};
						if (remaining >= due) {
							remaining -= due;
							return {
								...c,
								amountDue: due,
								amountPaid: due,
								paymentStatus: "Paid"
							};
						}
						const paid = remaining;
						remaining = 0;
						return {
							...c,
							amountDue: due,
							amountPaid: paid,
							paymentStatus: "Partial"
						};
					});
					if (receivedChanged) {
						const existingReceived = entries.filter((e) => e.type === "client_receive" && e.headId === after.headId).reduce((s, e) => s + e.amount, 0);
						const delta = (after.amountReceived || 0) - existingReceived;
						if (delta !== 0) {
							recalculateCounters();
							const eid = `E${String(nextEntryNum++).padStart(3, "0")}`;
							entries = [...entries, {
								id: eid,
								date: getPKTDate(),
								type: "client_receive",
								headId: after.headId,
								referenceId: after.headId,
								referenceName: `Booking ${after.headId}`,
								amount: delta,
								note: `Adjustment from booking edit`,
								createdAt: (/* @__PURE__ */ new Date()).toLocaleString("en-PK", { timeZone: "Asia/Karachi" })
							}];
						}
					}
				}
			}
			resyncDerived();
			notify();
			registerUndoableAction(`Booking ${id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteBooking: (id) => {
			const snap = takeStateSnapshot();
			const b = bookings.find((x) => x.id === id);
			if (!b) {
				notify();
				return;
			}
			const headId = b.headId;
			const clientsToDelete = clients.filter((c) => c.headId === headId);
			const entriesToDelete = entries.filter((e) => e.headId === headId);
			clients = clients.filter((c) => c.headId !== headId);
			entries = entries.filter((e) => e.headId !== headId);
			bookings = bookings.filter((x) => x.id !== id);
			resyncDerived();
			notify();
			deleteDocFromFirestore("bookings", id).catch(() => {});
			clientsToDelete.forEach((c) => deleteDocFromFirestore("clients", c.id).catch(() => {}));
			entriesToDelete.forEach((e) => deleteDocFromFirestore("entries", e.id).catch(() => {}));
			registerUndoableAction(`Booking ${id} deleted`, () => restoreStateSnapshot(snap));
		},
		addEntry: (data) => {
			recalculateCounters();
			const snap = takeStateSnapshot();
			const id = `E${String(nextEntryNum++).padStart(3, "0")}`;
			const entry = {
				...data,
				id,
				createdAt: (/* @__PURE__ */ new Date()).toLocaleString("en-PK", { timeZone: "Asia/Karachi" })
			};
			entries = [...entries, entry];
			resyncFromEntries({
				supplierIds: data.type === "purchase" || data.type === "supplier_payment" || data.type === "supplier_refund" || data.type === "supplier_discount" ? [data.referenceId] : [],
				agentIds: data.type === "agent_commission" ? [data.referenceId] : [],
				headIds: (data.type === "client_receive" || data.type === "client_charge" || data.type === "client_refund" || data.type === "client_discount") && data.headId ? [data.headId] : []
			});
			notify();
			registerUndoableAction(`Entry ${id} (${data.type.replace(/_/g, " ")}) recorded`, () => restoreStateSnapshot(snap));
			return id;
		},
		updateEntry: (id, data) => {
			const snap = takeStateSnapshot();
			const before = entries.find((e) => e.id === id);
			entries = entries.map((e) => e.id === id ? {
				...e,
				...data
			} : e);
			const after = entries.find((e) => e.id === id);
			const supplierIds = /* @__PURE__ */ new Set();
			const agentIds = /* @__PURE__ */ new Set();
			const headIds = /* @__PURE__ */ new Set();
			[before, after].forEach((e) => {
				if (!e) return;
				if (e.type === "purchase" || e.type === "supplier_payment" || e.type === "supplier_refund" || e.type === "supplier_discount") {
					if (e.referenceId) supplierIds.add(e.referenceId);
				}
				if (e.type === "agent_commission") {
					if (e.referenceId) agentIds.add(e.referenceId);
				}
				if (e.type === "client_receive" || e.type === "client_charge" || e.type === "client_refund" || e.type === "client_discount") {
					if (e.headId) headIds.add(e.headId);
				}
			});
			resyncFromEntries({
				supplierIds: [...supplierIds],
				agentIds: [...agentIds],
				headIds: [...headIds]
			});
			notify();
			registerUndoableAction(`Entry ${id} updated`, () => restoreStateSnapshot(snap));
		},
		deleteEntry: (id) => {
			const snap = takeStateSnapshot();
			const e = entries.find((x) => x.id === id);
			entries = entries.filter((x) => x.id !== id && (!x.allocationOf || x.allocationOf !== id));
			if (e) resyncFromEntries({
				supplierIds: (e.type === "purchase" || e.type === "supplier_payment" || e.type === "supplier_refund" || e.type === "supplier_discount") && e.referenceId ? [e.referenceId] : [],
				agentIds: e.type === "agent_commission" && e.referenceId ? [e.referenceId] : [],
				headIds: (e.type === "client_receive" || e.type === "client_charge" || e.type === "client_refund" || e.type === "client_discount") && e.headId ? [e.headId] : []
			});
			notify();
			deleteDocFromFirestore("entries", id).catch(() => {});
			registerUndoableAction(`Entry ${id} deleted`, () => restoreStateSnapshot(snap));
		},
		generateHeadId: () => {
			recalculateCounters();
			return `AV-HD-${String(nextHeadNum++).padStart(3, "0")}`;
		},
		addHotel: (bookingId, data) => {
			const id = `H${Date.now().toString(36)}`;
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				hotels: [...b.hotels || [], {
					...data,
					id
				}]
			} : b);
			notify();
			return id;
		},
		deleteHotel: (bookingId, hotelId) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				hotels: (b.hotels || []).filter((h) => h.id !== hotelId)
			} : b);
			notify();
		},
		addFlight: (bookingId, data) => {
			const id = `F${Date.now().toString(36)}`;
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				flights: [...b.flights || [], {
					...data,
					id
				}]
			} : b);
			notify();
			return id;
		},
		deleteFlight: (bookingId, flightId) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				flights: (b.flights || []).filter((f) => f.id !== flightId)
			} : b);
			notify();
		},
		addTransport: (bookingId, data) => {
			const id = `T${Date.now().toString(36)}`;
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				transports: [...b.transports || [], {
					...data,
					id
				}]
			} : b);
			notify();
			return id;
		},
		deleteTransport: (bookingId, transportId) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				transports: (b.transports || []).filter((t) => t.id !== transportId)
			} : b);
			notify();
		},
		addVisa: (bookingId, data) => {
			const id = `V${Date.now().toString(36)}`;
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				visas: [...b.visas || [], {
					...data,
					id
				}]
			} : b);
			notify();
			return id;
		},
		deleteVisa: (bookingId, visaId) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				visas: (b.visas || []).filter((v) => v.id !== visaId)
			} : b);
			notify();
		},
		addOther: (bookingId, data) => {
			const id = `O${Date.now().toString(36)}`;
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				others: [...b.others || [], {
					...data,
					id
				}]
			} : b);
			notify();
			return id;
		},
		deleteOther: (bookingId, otherId) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				others: (b.others || []).filter((o) => o.id !== otherId)
			} : b);
			notify();
		},
		addZiyarah: (bookingId, data) => {
			const id = `Z${Date.now().toString(36)}`;
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				ziyarahs: [...b.ziyarahs || [], {
					...data,
					id
				}]
			} : b);
			notify();
			return id;
		},
		updateZiyarah: (bookingId, zId, data) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				ziyarahs: (b.ziyarahs || []).map((z) => z.id === zId ? {
					...z,
					...data
				} : z)
			} : b);
			notify();
		},
		deleteZiyarah: (bookingId, zId) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				ziyarahs: (b.ziyarahs || []).filter((z) => z.id !== zId)
			} : b);
			notify();
		},
		updateHotel: (bookingId, hotelId, data) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				hotels: (b.hotels || []).map((h) => h.id === hotelId ? {
					...h,
					...data
				} : h)
			} : b);
			notify();
		},
		updateFlight: (bookingId, flightId, data) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				flights: (b.flights || []).map((f) => f.id === flightId ? {
					...f,
					...data
				} : f)
			} : b);
			notify();
		},
		updateTransport: (bookingId, transportId, data) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				transports: (b.transports || []).map((t) => t.id === transportId ? {
					...t,
					...data
				} : t)
			} : b);
			notify();
		},
		updateVisa: (bookingId, visaId, data) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				visas: (b.visas || []).map((v) => v.id === visaId ? {
					...v,
					...data
				} : v)
			} : b);
			notify();
		},
		updateOther: (bookingId, otherId, data) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				others: (b.others || []).map((o) => o.id === otherId ? {
					...o,
					...data
				} : o)
			} : b);
			notify();
		},
		setPackageInfo: (bookingId, info) => {
			bookings = bookings.map((b) => b.id === bookingId ? {
				...b,
				packageInfo: {
					...b.packageInfo || { inclusions: [] },
					...info,
					inclusions: info.inclusions ?? b.packageInfo?.inclusions ?? []
				}
			} : b);
			notify();
		},
		addCustomInclusion: (label) => {
			const l = label.trim();
			if (!l) return false;
			if ([...DEFAULT_INCLUSIONS.map((i) => i.label), ...customInclusions].includes(l)) return false;
			customInclusions = [...customInclusions, l];
			notify();
			return true;
		},
		addCustomCombo: (label) => {
			const l = label.trim();
			if (!l) return false;
			if (!customCombos.includes(l)) {
				customCombos = [...customCombos, l];
				notify();
			}
			return true;
		},
		setOpeningBalances: (data) => {
			opening = {
				...opening,
				...data
			};
			notify();
		},
		undoLastAction,
		hasUndo,
		resetAllData: (opts) => {
			clients = [];
			bookings = [];
			agents = [];
			suppliers = [];
			entries = [];
			monthlyData = [];
			groups = [];
			readAlerts = [];
			if (!opts?.keepOpening) opening = { ...defaultOpening };
			nextClientNum = 1;
			nextAgentNum = 1;
			nextSupplierNum = 1;
			nextBookingNum = 1;
			nextHeadNum = 1;
			nextEntryNum = 1;
			nextGroupNum = 1;
			notify();
		},
		restoreCleanBaseline: async (andPushToCloud = false) => {
			const snap = takeStateSnapshot();
			clients = mockClients.map((c) => ({ ...c }));
			bookings = mockBookings.map((b) => ({ ...b }));
			agents = mockAgents.map((a) => ({ ...a }));
			suppliers = mockSuppliers.map((s) => ({ ...s }));
			entries = defaultEntries.map((e) => ({ ...e }));
			monthlyData = [...mockMonthlyData];
			groups = [];
			accounts = [{
				id: "AC-001",
				name: "Main Cash",
				type: "Cash",
				openingBalance: 0,
				openingDate: "2026-01-01"
			}];
			drawers = [...defaultDrawers];
			opening = { ...defaultOpening };
			readAlerts = [];
			nextClientNum = 11;
			nextAgentNum = 4;
			nextSupplierNum = 5;
			nextBookingNum = 4;
			nextHeadNum = 4;
			nextEntryNum = 7;
			nextGroupNum = 1;
			recalculateCounters();
			resyncDerived();
			notify();
			if (andPushToCloud) {
				if (!auth.currentUser) throw new Error("Please connect your Google Account first in the Cloud Database section to authenticate cloud database overwrite.");
				cloudSyncStatus = "syncing";
				notify();
				try {
					await pushFullStateToFirestore({
						clients,
						bookings,
						agents,
						suppliers,
						entries,
						groups,
						accounts,
						drawers,
						opening,
						alertSettings
					}, { pruneOrphans: true });
					lastSyncedAt = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-PK", { timeZone: "Asia/Karachi" });
					cloudSyncStatus = "synced";
				} catch (err) {
					cloudSyncStatus = "error";
					notify();
					throw err;
				}
				notify();
			}
			registerUndoableAction("Restored clean pre-error data baseline", () => restoreStateSnapshot(snap));
			return { success: true };
		},
		cloudSyncStatus,
		lastSyncedAt,
		syncToCloud,
		loadFromCloud
	};
}
function daysSince(date) {
	const t = new Date(date).getTime();
	if (Number.isNaN(t)) return 0;
	return Math.floor((Date.now() - t) / 864e5);
}
function buildAlerts(data) {
	const { clients, bookings, agents, suppliers, entries, accounts, settings } = data;
	const out = [];
	bookings.forEach((b) => {
		const due = Math.max(0, (b.totalAmount || 0) - (b.amountReceived || 0));
		if (due <= 0) return;
		if (!(daysSince(b.travelDate) > -settings.clientOverdueDays)) return;
		const lead = clients.find((c) => c.headId === b.headId);
		const name = lead ? `${lead.firstName} ${lead.lastName}`.trim() : b.headId;
		out.push({
			id: `due-${b.id}`,
			kind: "payment_due",
			severity: "urgent",
			message: `${name} — ${formatCurrency(due)} outstanding for travel on ${b.travelDate}`,
			timestamp: b.travelDate,
			href: "/clients"
		});
	});
	accounts.forEach((a) => {
		const bal = computeAccountBalance(a.id);
		if (bal >= settings.lowBalance) return;
		out.push({
			id: `low-${a.id}`,
			kind: "low_balance",
			severity: "urgent",
			message: `${a.name} balance is ${formatCurrency(bal)} — below ${formatCurrency(settings.lowBalance)}`,
			timestamp: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
			href: "/accounts"
		});
	});
	suppliers.forEach((s) => {
		const stale = entries.filter((e) => e.type === "purchase" && e.referenceId === s.id && e.reconciled !== "matched" && daysSince(e.date) >= settings.unmatchedDays);
		if (!stale.length) return;
		out.push({
			id: `recon-${s.id}-${stale.length}`,
			kind: "reconciliation",
			severity: "info",
			message: `${stale.length} unmatched ${stale.length === 1 ? "entry" : "entries"} — ${s.companyName} supplier ledger`,
			timestamp: stale[0].date,
			href: "/suppliers"
		});
	});
	agents.forEach((a) => {
		const remaining = (a.openingSales || 0) + (a.totalSales || 0) - (a.commission || 0) - (a.openingCommission || 0) - ((a.openingPaidCommission || 0) + (a.paidCommission || 0));
		if (remaining <= settings.agentDueLimit) return;
		out.push({
			id: `agent-${a.id}`,
			kind: "agent_balance",
			severity: "urgent",
			message: `Agent ${a.name} — ${formatCurrency(remaining)} remaining due`,
			timestamp: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
			href: "/agents"
		});
	});
	entries.filter((e) => e.refundOf || /revers|correct/i.test(e.note || "")).slice(-5).forEach((e) => {
		out.push({
			id: `audit-${e.id}`,
			kind: "audit",
			severity: "info",
			message: `Correction posted on ${e.refundOf || e.id} — ${formatCurrency(e.amount)} ${entryDirection(e.type)}`,
			timestamp: e.date,
			href: "/entries"
		});
	});
	return out.sort((a, b) => a.severity === b.severity ? a.timestamp < b.timestamp ? 1 : -1 : a.severity === "urgent" ? -1 : 1);
}
var sections = [
	{
		title: "Overview",
		items: [
			{
				to: "/",
				icon: LayoutDashboard,
				label: "Dashboard"
			},
			{
				to: "/ai",
				icon: Sparkles,
				label: "Omni AI Assistant"
			},
			{
				to: "/alerts",
				icon: Bell,
				label: "Alerts"
			},
			{
				to: "/search",
				icon: Search,
				label: "Search"
			}
		]
	},
	{
		title: "Operations",
		items: [
			{
				to: "/bookings",
				icon: BookOpen,
				label: "Bookings"
			},
			{
				to: "/groups",
				icon: Layers,
				label: "Groups"
			},
			{
				to: "/clients",
				icon: Users,
				label: "Clients"
			},
			{
				to: "/agents",
				icon: UserCog,
				label: "Agents"
			},
			{
				to: "/suppliers",
				icon: Truck,
				label: "Suppliers"
			}
		]
	},
	{
		title: "Finance",
		items: [
			{
				to: "/accounts",
				icon: Wallet,
				label: "Accounts"
			},
			{
				to: "/payments",
				icon: CreditCard,
				label: "Payments"
			},
			{
				to: "/entries",
				icon: FileText,
				label: "Entries"
			},
			{
				to: "/expenses",
				icon: Receipt,
				label: "Expenses"
			},
			{
				to: "/drawings",
				icon: HandCoins,
				label: "Drawings"
			},
			{
				to: "/reports",
				icon: ChartColumn,
				label: "Financial Reports"
			}
		]
	},
	{
		title: "System",
		items: [{
			to: "/settings",
			icon: Settings,
			label: "Settings"
		}]
	}
];
function AppSidebar() {
	const location = useLocation();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [user, setUser] = (0, import_react.useState)(null);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const store = useStore();
	(0, import_react.useEffect)(() => {
		setMounted(true);
		const unsub = onAuthStateChanged(auth, (u) => {
			setUser(u);
		});
		return () => unsub();
	}, []);
	const unread = (0, import_react.useMemo)(() => {
		try {
			return buildAlerts({
				clients: store.clients,
				bookings: store.bookings,
				agents: store.agents,
				suppliers: store.suppliers,
				entries: store.entries,
				accounts: store.accounts,
				settings: store.alertSettings
			}).filter((a) => !store.readAlerts.includes(a.id)).length;
		} catch {
			return 0;
		}
	}, [
		store.clients,
		store.bookings,
		store.agents,
		store.suppliers,
		store.entries,
		store.accounts,
		store.alertSettings,
		store.readAlerts
	]);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [location.pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "fixed inset-x-0 top-0 z-30 flex h-14 items-center justify-between border-b border-sidebar-border bg-sidebar/95 backdrop-blur-md px-4 md:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/avery-gold-logo.jpg",
					alt: "Avery Logo",
					className: "h-8 w-8 rounded-full border border-primary/50 object-cover shadow-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-sm font-bold tracking-wide gold-text",
					children: "AVERY"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-1 text-[11px] text-muted-foreground",
					children: "Travel & Tours"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					mounted && store.hasUndo && store.hasUndo() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => store.undoLastAction && store.undoLastAction(),
						title: "Undo last action",
						className: "flex items-center gap-1 rounded-md border border-primary/50 bg-primary/10 px-2 py-1 text-xs font-medium text-primary active-press",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-3.5 w-3.5" }), "Undo"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/alerts",
						"aria-label": "Alerts",
						className: "relative rounded-md border border-border p-2 text-foreground active-press",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-5 w-5" }), mounted && unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -right-1 -top-1 rounded-full bg-destructive px-1 text-[10px] font-semibold text-destructive-foreground",
							children: unread
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Open menu",
						onClick: () => setOpen(true),
						className: "rounded-md border border-border p-2 text-foreground active-press",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
					})
				]
			})]
		}),
		open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-40 bg-background/70 backdrop-blur-sm md:hidden",
			onClick: () => setOpen(false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: `fixed left-0 top-0 z-50 flex h-screen w-[260px] flex-col border-r border-sidebar-border bg-sidebar/95 backdrop-blur-xl transition-transform duration-300 md:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-14 shrink-0 items-center gap-2.5 border-b border-sidebar-border px-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/avery-gold-logo.jpg",
							alt: "Avery International Travel & Tours",
							className: "h-8 w-8 rounded-full border border-primary/50 object-cover shadow-sm gold-glow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-sm font-bold leading-none gold-text tracking-wide",
									children: "AVERY"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground font-medium truncate",
									children: "Travel & Tours"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[8.5px] uppercase tracking-[0.15em] text-muted-foreground/75 mt-0.5",
								children: "Operations Suite"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Close menu",
							onClick: () => setOpen(false),
							className: "text-muted-foreground md:hidden active-press",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})
					]
				}),
				mounted && store.hasUndo && store.hasUndo() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-2.5 mt-2 shrink-0 rounded border border-primary/40 bg-primary/10 px-2 py-1 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => store.undoLastAction && store.undoLastAction(),
						className: "flex w-full items-center justify-center gap-1 text-[11px] font-semibold text-primary hover:underline active-press",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-3 w-3" }), "Revert / Undo Last Action"]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "sidebar-scroll min-h-0 flex-1 overflow-y-auto px-3 py-2.5",
					children: sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/80",
							children: s.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-0.5",
							children: s.items.map((item) => {
								const isActive = location.pathname === item.to || item.to !== "/" && location.pathname.startsWith(item.to);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									className: `relative flex items-center gap-3 rounded-md px-3 py-[7px] text-sm transition-all touch-effect ${isActive ? "bg-sidebar-accent font-semibold text-foreground shadow-sm" : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground"}`,
									children: [
										isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r bg-primary gold-glow" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `h-4 w-4 shrink-0 ${isActive ? "text-primary" : ""}` }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex-1",
											children: item.label
										}),
										mounted && item.to === "/alerts" && unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-destructive px-1.5 py-0.5 text-[10px] font-semibold leading-none text-destructive-foreground",
											children: unread
										})
									]
								}, item.to);
							})
						})]
					}, s.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "shrink-0 border-t border-sidebar-border bg-sidebar/80 px-3 py-2.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 rounded-lg border border-border/60 bg-card/60 px-2.5 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2 w-2 shrink-0 rounded-full ${mounted && user ? "bg-emerald-500 animate-pulse" : "bg-amber-500"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1 leading-tight",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-medium text-foreground",
									children: mounted && user ? "Cloud DB active" : "Local DB (ready)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-[10px] text-muted-foreground",
									children: mounted && user ? user.email || user.displayName : "Not synced to cloud"
								})]
							}),
							mounted && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Sync cloud",
								title: "Sync with cloud",
								disabled: store.cloudSyncStatus === "syncing",
								onClick: async () => {
									try {
										toast.loading("Syncing with Firestore...", { id: "cloud-sync" });
										await store.syncToCloud();
										toast.success("Synced with Cloud DB", { id: "cloud-sync" });
									} catch {
										toast.error("Sync failed", { id: "cloud-sync" });
									}
								},
								className: "rounded-md p-1.5 text-primary transition-colors hover:bg-primary/15 disabled:opacity-50",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${store.cloudSyncStatus === "syncing" ? "animate-spin" : ""}` })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Sign out",
								title: "Sign out",
								onClick: async () => {
									await logOut();
									setUser(null);
									toast.info("Signed out of Cloud DB");
								},
								className: "rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" })
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								"aria-label": "Connect cloud database",
								title: "Connect Google Cloud Firestore for persistence across devices",
								onClick: async () => {
									try {
										const u = await signInWithGoogle();
										setUser(u);
										toast.success(`Connected as ${u.email}`);
										await store.syncToCloud();
									} catch (err) {
										toast.error(err instanceof Error ? err.message : "Sign-in failed");
									}
								},
								className: "flex shrink-0 items-center gap-1 rounded-md bg-primary px-2 py-1 text-[11px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "h-3 w-3" }), "Connect"]
							})
						]
					})
				})
			]
		})
	] });
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "gold-text text-7xl font-bold",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
var Route$16 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Avery International Travel & Tours — Operations Suite" },
			{
				name: "description",
				content: "Enterprise Travel Agency CRM, Accounts & Ledger System"
			},
			{
				property: "og:title",
				content: "Avery International Travel & Tours"
			},
			{
				name: "twitter:title",
				content: "Avery International Travel & Tours"
			},
			{
				property: "og:description",
				content: "Curated journeys. Trusted service. Worldwide reach."
			},
			{
				name: "twitter:description",
				content: "Curated journeys. Trusted service. Worldwide reach."
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				property: "og:type",
				content: "website"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: `if(typeof window!=='undefined'&&!window.$_TSR){window.$_TSR={h:function(){this.hydrated=true;},e:function(){this.streamEnded=true;},c:function(){},p:function(s){if(this.initialized)s();else this.buffer.push(s);},buffer:[],router:{manifest:{},dehydratedData:null,matches:[]}};}` } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			suppressHydrationWarning: true,
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})]
		})]
	});
}
function RootComponent() {
	const location = useLocation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen bg-background",
		suppressHydrationWarning: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppSidebar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-w-0 flex-1 px-4 pb-8 pt-20 md:ml-[260px] md:px-8 md:pt-8",
				suppressHydrationWarning: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "page-transition",
					suppressHydrationWarning: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}, location.pathname)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
				position: "top-right",
				richColors: true,
				closeButton: true,
				expand: false,
				duration: 8500
			})
		]
	});
}
var $$splitComponentImporter$15 = () => import("./routes-CPkjzbNU.mjs");
var Route$15 = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter$15, "component"),
	head: () => ({ meta: [
		{ title: "Dashboard — AV Travel CRM" },
		{
			name: "description",
			content: "Live overview of bookings, revenue, groups and dues for Avery Travel."
		},
		{
			property: "og:title",
			content: "Dashboard — Avery Travel CRM"
		},
		{
			property: "og:description",
			content: "Live overview of bookings, revenue, groups and dues for Avery Travel."
		}
	] })
});
var $$splitComponentImporter$14 = () => import("./accounts-SYV7-UlB.mjs");
var Route$14 = createFileRoute("/accounts")({
	head: () => ({ meta: [
		{ title: "Accounts & Profit Engine — Avery Travel CRM" },
		{
			name: "description",
			content: "Chart of accounts, liquid balances, earned vs unearned profits, and partner drawing cards."
		},
		{
			property: "og:title",
			content: "Accounts & Profit Engine — Avery Travel CRM"
		},
		{
			property: "og:description",
			content: "Chart of accounts, liquid balances, earned vs unearned profits, and partner drawing cards."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./agents-jhmWM0fb.mjs");
var Route$13 = createFileRoute("/agents")({
	component: lazyRouteComponent($$splitComponentImporter$13, "component"),
	head: () => ({ meta: [{ title: "Agents — AV Travel CRM" }] })
});
var $$splitComponentImporter$12 = () => import("./ai-oMu4Vol5.mjs");
var Route$12 = createFileRoute("/ai")({
	component: lazyRouteComponent($$splitComponentImporter$12, "component"),
	head: () => ({ meta: [{ title: "Omni AI Assistant — Avery Travel CRM" }, {
		name: "description",
		content: "Free LLM API and Omni Router for Travel Itineraries, Financial Analysis, and Client Messaging."
	}] })
});
var $$splitComponentImporter$11 = () => import("./alerts-BhCqHcr9.mjs");
var Route$11 = createFileRoute("/alerts")({
	component: lazyRouteComponent($$splitComponentImporter$11, "component"),
	head: () => ({ meta: [
		{ title: "Alerts Hub — Avery International Travel & Tours" },
		{
			name: "description",
			content: "Seat-urgency alerts for closing groups and package-completion alerts for every client, in one operational hub."
		},
		{
			property: "og:title",
			content: "Alerts Hub — Avery International Travel & Tours"
		},
		{
			property: "og:description",
			content: "Closing groups, low seats and pending client services — prioritised for daily travel operations."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] })
});
var $$splitComponentImporter$10 = () => import("./bookings-C0xGaO-h.mjs");
var Route$10 = createFileRoute("/bookings")({
	component: lazyRouteComponent($$splitComponentImporter$10, "component"),
	head: () => ({ meta: [{ title: "Bookings — AV Travel CRM" }] })
});
var $$splitComponentImporter$9 = () => import("./clients-DuqccDOf.mjs");
var Route$9 = createFileRoute("/clients")({
	component: lazyRouteComponent($$splitComponentImporter$9, "component"),
	head: () => ({ meta: [{ title: "Clients — AV Travel CRM" }] })
});
var $$splitComponentImporter$8 = () => import("./drawings-Dj_SlEtQ.mjs");
var Route$8 = createFileRoute("/drawings")({
	head: () => ({ meta: [
		{ title: "Owner Drawings — Avery Travel CRM" },
		{
			name: "description",
			content: "Owner and partner drawings with business profit on each drawing date and retained profit today."
		},
		{
			property: "og:title",
			content: "Owner Drawings — Avery Travel CRM"
		},
		{
			property: "og:description",
			content: "Owner and partner drawings with profit at the time of each drawing and today."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./entries-cI-vtBQL.mjs");
var Route$7 = createFileRoute("/entries")({
	component: lazyRouteComponent($$splitComponentImporter$7, "component"),
	head: () => ({ meta: [{ title: "Entries — AV Travel CRM" }] })
});
/** Money that flows INTO the business (shown with a + sign). */
/** Entries where real money moves — these capture account + instrument details. */
var $$splitComponentImporter$6 = () => import("./expenses-B3AYU_eL.mjs");
var Route$6 = createFileRoute("/expenses")({
	component: lazyRouteComponent($$splitComponentImporter$6, "component"),
	head: () => ({ meta: [{ title: "Expenses — AV Travel CRM" }] })
});
var $$splitComponentImporter$5 = () => import("./groups-DOA1QAFv.mjs");
var Route$5 = createFileRoute("/groups")({
	component: lazyRouteComponent($$splitComponentImporter$5, "component"),
	head: () => ({ meta: [
		{ title: "Group Management — Avery Travel CRM" },
		{
			name: "description",
			content: "Track every PNR / batch group: linked heads, member details, supplier bill, group expenses and net profit in one professional view."
		},
		{
			property: "og:title",
			content: "Group Management — Avery Travel CRM"
		},
		{
			property: "og:description",
			content: "Group-wise supplier bill, gifts & extra expenses, and live net profit for every travel batch."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] })
});
var $$splitComponentImporter$4 = () => import("./payments-CgOzNjB0.mjs");
var Route$4 = createFileRoute("/payments")({
	component: lazyRouteComponent($$splitComponentImporter$4, "component"),
	head: () => ({ meta: [{ title: "Payments — AV Travel CRM" }] })
});
var $$splitComponentImporter$3 = () => import("./reports-Bo67Iyun.mjs");
var Route$3 = createFileRoute("/reports")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	head: () => ({ meta: [{ title: "Financial Reports — AV Travel CRM" }, {
		name: "description",
		content: "Professional financial analytics, profitability and cash flow reports."
	}] })
});
var $$splitComponentImporter$2 = () => import("./search-CvboVYeB.mjs");
var Route$2 = createFileRoute("/search")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [{ title: "Search — AV Travel CRM" }] })
});
var $$splitComponentImporter$1 = () => import("./settings-BVZ-w220.mjs");
var Route$1 = createFileRoute("/settings")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [{ title: "Settings — Avery Group of Travel" }] })
});
var $$splitComponentImporter = () => import("./suppliers-CbQl0aQo.mjs");
var Route = createFileRoute("/suppliers")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Suppliers — AV Travel CRM" }] })
});
var rootRouteChildren = {
	IndexRoute: Route$15.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$16
	}),
	AccountsRoute: Route$14.update({
		id: "/accounts",
		path: "/accounts",
		getParentRoute: () => Route$16
	}),
	AgentsRoute: Route$13.update({
		id: "/agents",
		path: "/agents",
		getParentRoute: () => Route$16
	}),
	AiRoute: Route$12.update({
		id: "/ai",
		path: "/ai",
		getParentRoute: () => Route$16
	}),
	AlertsRoute: Route$11.update({
		id: "/alerts",
		path: "/alerts",
		getParentRoute: () => Route$16
	}),
	BookingsRoute: Route$10.update({
		id: "/bookings",
		path: "/bookings",
		getParentRoute: () => Route$16
	}),
	ClientsRoute: Route$9.update({
		id: "/clients",
		path: "/clients",
		getParentRoute: () => Route$16
	}),
	DrawingsRoute: Route$8.update({
		id: "/drawings",
		path: "/drawings",
		getParentRoute: () => Route$16
	}),
	EntriesRoute: Route$7.update({
		id: "/entries",
		path: "/entries",
		getParentRoute: () => Route$16
	}),
	ExpensesRoute: Route$6.update({
		id: "/expenses",
		path: "/expenses",
		getParentRoute: () => Route$16
	}),
	GroupsRoute: Route$5.update({
		id: "/groups",
		path: "/groups",
		getParentRoute: () => Route$16
	}),
	PaymentsRoute: Route$4.update({
		id: "/payments",
		path: "/payments",
		getParentRoute: () => Route$16
	}),
	ReportsRoute: Route$3.update({
		id: "/reports",
		path: "/reports",
		getParentRoute: () => Route$16
	}),
	SearchRoute: Route$2.update({
		id: "/search",
		path: "/search",
		getParentRoute: () => Route$16
	}),
	SettingsRoute: Route$1.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$16
	}),
	SuppliersRoute: Route.update({
		id: "/suppliers",
		path: "/suppliers",
		getParentRoute: () => Route$16
	})
};
var routeTree = Route$16._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function DefaultErrorComponent({ error, reset }) {
	const router = useRouter();
	error instanceof Error && error.message;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						xmlns: "http://www.w3.org/2000/svg",
						className: "h-8 w-8 text-destructive",
						fill: "none",
						viewBox: "0 0 24 24",
						stroke: "currentColor",
						strokeWidth: 2,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							strokeLinecap: "round",
							strokeLinejoin: "round",
							d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight text-foreground",
					children: "Something went wrong"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "An unexpected error occurred. Please try again."
				}),
				false,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex items-center justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
if (typeof window !== "undefined") {
	const w = window;
	if (!w.$_TSR) w.$_TSR = {
		h() {
			this.hydrated = true;
			this.c();
		},
		e() {
			this.streamEnded = true;
			this.c();
		},
		c() {
			if (this.hydrated && this.streamEnded) delete w.$_TSR;
		},
		p(s) {
			if (this.initialized) s();
			else this.buffer.push(s);
		},
		buffer: [],
		router: {
			manifest: {},
			dehydratedData: null,
			matches: []
		}
	};
}
var getRouter = () => {
	return createRouter({
		routeTree,
		context: {},
		scrollRestoration: true,
		defaultPreloadStaleTime: 0,
		defaultErrorComponent: DefaultErrorComponent
	});
};
export { formatCurrency as C, distributePayment as S, statusTone as _, entryDirection as a, computeBookingFinancials as b, logOut as c, testConnection as d, getPKTDate as f, nextStatus as g, getChecklist as h, computeGroupUsedPax as i, checklistProgress as m, buildAccountLedger as n, useStore as o, CHECKLIST_STATUSES as p, computeAccountBalance as r, auth as s, router_exports as t, signInWithGoogle as u, PACKAGE_TYPES as v, getClientName as w, computeBookingProfit as x, SERVICE_TYPES as y };
