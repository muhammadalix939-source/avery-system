import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as Lock, U as Gift, f as Trash, k as Pencil, n as Wallet, r as Users, st as ChevronRight, u as TrendingUp, w as Plus, y as Search, z as Layers } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, f as getPKTDate, o as useStore } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { t as Input } from "./input-CqV36rr2.mjs";
import { t as Label } from "./label-BYIfJH-v.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BBv8eX6f.mjs";
import { a as DialogTrigger, i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { t as StatusBadge } from "./StatusBadge-MNA5vWLW.mjs";
import { t as ConfirmDelete } from "./ConfirmDelete-C6E2xoIe.mjs";
import { a as urgencyTone, i as urgencyLabel, n as computeUrgency, t as computeGroupStats } from "./groups-6NvV7uvi.mjs";
import { n as sortEntities, t as SortBar } from "./SortBar-CcXdcaV6.mjs";
// node_modules/.nitro/vite/services/ssr/assets/groups-DOA1QAFv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GROUP_CATEGORIES = [
	"Flight",
	"Hotel",
	"Visa",
	"Transport",
	"Ziyarah",
	"Insurance",
	"Other"
];
var EXTRA_CATEGORIES = [
	"Gift",
	"Hospitality",
	"Ihram / Kit",
	"Zam Zam",
	"Meals",
	"Documentation",
	"Transport Extra",
	"Other"
];
var emptyForm = {
	name: "",
	category: "Flight",
	supplierId: "",
	date: "",
	pnr: "",
	flightNumber: "",
	description: "",
	totalPax: ""
};
function GroupsPage() {
	const store = useStore();
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [expenseFor, setExpenseFor] = (0, import_react.useState)(null);
	const [search, setSearch] = (0, import_react.useState)("");
	const [sortKey, setSortKey] = (0, import_react.useState)("date_desc");
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const stats = (0, import_react.useMemo)(() => store.groups.map((g) => computeGroupStats(g, store)), [store]);
	const filtered = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		const base = q ? stats.filter((s) => [
			s.group.id,
			s.group.name,
			s.group.pnr,
			s.group.flightNumber,
			s.group.category,
			s.supplier?.companyName
		].filter(Boolean).join(" ").toLowerCase().includes(q)) : stats;
		return sortEntities(base, sortKey, {
			date: (s) => s.group.date || s.group.createdAt,
			amount: (s) => s.revenue || s.supplierBill,
			name: (s) => s.group.name || s.group.id
		});
	}, [
		stats,
		search,
		sortKey
	]);
	const activeGroups = (0, import_react.useMemo)(() => filtered.filter((s) => !computeUrgency(s).isFull), [filtered]);
	const fullGroups = (0, import_react.useMemo)(() => filtered.filter((s) => computeUrgency(s).isFull), [filtered]);
	const totals = (0, import_react.useMemo)(() => ({
		groups: stats.length,
		pax: stats.reduce((s, x) => s + x.usedPax, 0),
		revenue: stats.reduce((s, x) => s + x.revenue, 0),
		bill: stats.reduce((s, x) => s + x.supplierBill, 0),
		extras: stats.reduce((s, x) => s + x.expenses, 0),
		profit: stats.reduce((s, x) => s + x.netProfit, 0),
		seatsLeft: stats.reduce((s, x) => s + (x.capacity > 0 ? Math.max(0, x.capacity - x.usedPax) : 0), 0)
	}), [stats]);
	const detail = detailId ? stats.find((s) => s.group.id === detailId) : null;
	function payload() {
		return {
			name: form.name || "Untitled Group",
			category: form.category,
			supplierId: form.supplierId || void 0,
			date: form.date || void 0,
			pnr: form.pnr || void 0,
			flightNumber: form.flightNumber || void 0,
			description: form.description || void 0,
			totalPax: Number(form.totalPax) || 0
		};
	}
	function openEdit(g) {
		setSelected(g);
		setForm({
			name: g.name,
			category: g.category,
			supplierId: g.supplierId || "",
			date: g.date || "",
			pnr: g.pnr || "",
			flightNumber: g.flightNumber || "",
			description: g.description || "",
			totalPax: String(g.totalPax || "")
		});
		setEditOpen(true);
	}
	const formFields = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Group Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: form.name,
					onChange: (e) => setForm({
						...form,
						name: e.target.value
					}),
					placeholder: "e.g. Umrah Batch 12 Jun",
					className: "bg-accent/20 border-border mt-1 h-9 text-xs"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Category"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.category,
					onValueChange: (v) => setForm({
						...form,
						category: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-9 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: GROUP_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: c,
						children: c
					}, c)) })]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Supplier"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: form.supplierId || "none",
					onValueChange: (v) => setForm({
						...form,
						supplierId: v === "none" ? "" : v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "bg-accent/20 border-border mt-1 h-9 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select supplier" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "none",
						children: "No supplier"
					}), store.suppliers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: s.id,
						children: s.companyName
					}, s.id))] })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs",
					children: "Travel / Service Date"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: form.date,
					onChange: (e) => setForm({
						...form,
						date: e.target.value
					}),
					className: "bg-accent/20 border-border mt-1 h-9 text-xs"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "PNR"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.pnr,
						onChange: (e) => setForm({
							...form,
							pnr: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Flight / Ref No."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.flightNumber,
						onChange: (e) => setForm({
							...form,
							flightNumber: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Capacity (Pax)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: form.totalPax,
						onChange: (e) => setForm({
							...form,
							totalPax: e.target.value
						}),
						className: "bg-accent/20 border-border mt-1 h-9 text-xs"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: "Description"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: form.description,
				onChange: (e) => setForm({
					...form,
					description: e.target.value
				}),
				className: "bg-accent/20 border-border mt-1 h-9 text-xs"
			})] })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Group Management",
				subtitle: `${store.groups.length} groups · PNR / batch level profitability`,
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open: addOpen,
					onOpenChange: setAddOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "gap-2",
							onClick: () => setForm({
								...emptyForm,
								date: getPKTDate()
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Group"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "bg-card border-border max-h-[85vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Create Group" }) }),
							formFields,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								onClick: () => {
									store.addGroup(payload());
									setAddOpen(false);
								},
								children: "Create Group"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-4 lg:grid-cols-4 xl:grid-cols-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: Layers,
						label: "Groups",
						value: String(totals.groups)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: Users,
						label: "Total Pax",
						value: String(totals.pax)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: Users,
						label: "Seats Left",
						value: String(totals.seatsLeft),
						tone: totals.seatsLeft <= 3 ? "text-destructive" : "text-success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: TrendingUp,
						label: "Group Sales",
						value: formatCurrency(totals.revenue),
						tone: "text-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: Wallet,
						label: "Supplier Bill",
						value: formatCurrency(totals.bill),
						tone: "text-warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: Gift,
						label: "Extras / Gifts",
						value: formatCurrency(totals.extras),
						tone: "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						icon: TrendingUp,
						label: "Group Profit",
						value: formatCurrency(totals.profit),
						tone: totals.profit >= 0 ? "text-success" : "text-destructive"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card flex items-center gap-2 rounded-xl px-3 py-2 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: "Search group, PNR, flight, supplier...",
						className: "w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortBar, {
					value: sortKey,
					onChange: setSortKey,
					label: "Sort by:"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 xl:grid-cols-2",
				children: [activeGroups.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupCard, {
					s,
					index: i,
					onOpen: () => setDetailId(s.group.id),
					onExpense: () => setExpenseFor(s.group),
					onEdit: () => openEdit(s.group),
					onDelete: () => setDeleteTarget(s.group)
				}, s.group.id)), activeGroups.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "glass-card rounded-xl p-12 text-center text-sm text-muted-foreground xl:col-span-2",
					children: "No active groups. Create a group to track PNR-level cost and profit."
				})]
			}),
			fullGroups.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t border-border/60 pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
							children: [
								"Full / Closed Groups (",
								fullGroups.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: "Closed for new sales — still searchable everywhere"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 gap-4 xl:grid-cols-2",
					children: fullGroups.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupCard, {
						s,
						index: i,
						muted: true,
						onOpen: () => setDetailId(s.group.id),
						onExpense: () => setExpenseFor(s.group),
						onEdit: () => openEdit(s.group),
						onDelete: () => setDeleteTarget(s.group)
					}, s.group.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
				open: !!deleteTarget,
				onOpenChange: (o) => {
					if (!o) setDeleteTarget(null);
				},
				title: `Delete group ${deleteTarget?.name || ""}?`,
				description: "The group will be removed and any tagged entries will be untagged. Bookings and clients are not deleted.",
				onConfirm: () => {
					if (deleteTarget) store.deleteGroup(deleteTarget.id);
					setDeleteTarget(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editOpen,
				onOpenChange: setEditOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "bg-card border-border max-h-[85vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit Group — ", selected?.id] }) }),
						formFields,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: () => {
								if (selected) store.updateGroup(selected.id, payload());
								setEditOpen(false);
							},
							children: "Save Changes"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupExpenseDialog, {
				group: expenseFor,
				onClose: () => setExpenseFor(null),
				onSubmit: (data) => {
					store.addEntry({
						date: data.date || getPKTDate(),
						type: "expense",
						headId: data.category,
						referenceId: "",
						referenceName: data.description || data.category,
						amount: data.amount,
						note: `${expenseFor?.name || ""} (${expenseFor?.id || ""}) — ${data.note}`.trim(),
						groupId: expenseFor?.id
					});
					setExpenseFor(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!detail,
				onOpenChange: (o) => !o && setDetailId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "bg-card border-border max-w-4xl max-h-[88vh] overflow-y-auto",
					children: detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupDetail, {
						stats: detail,
						onAddExpense: () => setExpenseFor(detail.group)
					})
				})
			})
		]
	});
}
function GroupCard({ s, index, muted, onOpen, onExpense, onEdit, onDelete }) {
	const u = computeUrgency(s);
	const pct = s.capacity > 0 ? Math.min(100, Math.round(s.usedPax / s.capacity * 100)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 16
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: { delay: Math.min(index * .05, .3) },
		className: `glass-card cursor-pointer rounded-xl p-5 transition-colors hover:border-primary/40 ${muted ? "opacity-60 hover:opacity-100" : ""}`,
		onClick: onOpen,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: s.group.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-md bg-accent/40 px-2 py-0.5 text-[10px] font-semibold uppercase text-primary",
								children: s.group.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full border px-2 py-0.5 text-[9px] font-bold ${urgencyTone[u.level]}`,
								children: urgencyLabel[u.level]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[10px] text-muted-foreground",
						children: [
							s.group.id,
							s.group.pnr && `PNR ${s.group.pnr}`,
							s.group.flightNumber,
							s.group.date,
							s.supplier?.companyName
						].filter(Boolean).join(" · ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-[10px] font-medium text-muted-foreground",
						children: u.reason
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 gap-1",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onExpense,
							className: "rounded p-1 hover:bg-accent",
							title: "Add gift / extra expense",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-3.5 w-3.5 text-primary" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onEdit,
							className: "rounded p-1 hover:bg-accent",
							title: "Edit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onDelete,
							className: "rounded p-1 hover:bg-accent",
							title: "Delete",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
						})
					]
				})]
			}),
			s.capacity > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1 flex justify-between text-[10px] text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					s.usedPax,
					" / ",
					s.capacity,
					" clients booked"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: u.remainingSeats <= 3 && !u.isFull ? "font-semibold text-destructive" : "",
					children: [s.remainingPax, " seats left"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 h-2 overflow-hidden rounded-full bg-accent/30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `h-full rounded-full transition-all ${u.isFull ? "bg-muted-foreground" : "bg-primary"}`,
					style: { width: `${pct}%` }
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2 border-t border-border/50 pt-3 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Sales",
						value: formatCurrency(s.revenue),
						tone: "text-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Supplier Bill",
						value: formatCurrency(s.supplierBill),
						tone: "text-warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Extras",
						value: formatCurrency(s.expenses),
						tone: "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Net Profit",
						value: formatCurrency(s.netProfit),
						tone: s.netProfit >= 0 ? "text-success" : "text-destructive"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between text-[10px] text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					s.heads.length,
					" head",
					s.heads.length === 1 ? "" : "s",
					" · margin ",
					s.margin.toFixed(1),
					"%"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1 text-primary",
					children: ["Open detail ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
				})]
			})
		]
	});
}
function Kpi({ icon: Icon, label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "glass-card rounded-xl p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-4 w-4 ${tone || "text-primary"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] uppercase tracking-wide text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-base font-bold ${tone || ""}`,
				children: value
			})] })]
		})
	});
}
function Cell({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[9px] uppercase tracking-wide text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `font-semibold ${tone || ""}`,
		children: value
	})] });
}
function GroupExpenseDialog({ group, onClose, onSubmit }) {
	const [date, setDate] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("Gift");
	const [description, setDescription] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!group,
		onOpenChange: (o) => {
			if (!o) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "bg-card border-border max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "text-primary",
				children: "Add Group Expense"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					group?.name,
					" · ",
					group?.id,
					" — gifts, hospitality and extras booked against this group reduce its net profit."
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							className: "bg-accent/20 border-border mt-1 h-9 text-xs"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Type"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: category,
							onValueChange: setCategory,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "bg-accent/20 border-border mt-1 h-9 text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: EXTRA_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c,
								children: c
							}, c)) })]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Description"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						placeholder: "e.g. Ihram kits for 30 pax",
						className: "bg-accent/20 border-border mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Amount (PKR)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						className: "bg-accent/20 border-border mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Note"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: note,
						onChange: (e) => setNote(e.target.value),
						className: "bg-accent/20 border-border mt-1 h-9 text-xs"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => {
							onSubmit({
								date,
								category,
								description,
								amount: Number(amount) || 0,
								note
							});
							setDate("");
							setCategory("Gift");
							setDescription("");
							setAmount("");
							setNote("");
						},
						children: "Add to Group"
					})
				]
			})]
		})
	});
}
function GroupDetail({ stats, onAddExpense }) {
	const [openHead, setOpenHead] = (0, import_react.useState)(null);
	const g = stats.group;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "flex flex-wrap items-center gap-2 text-primary",
				children: [g.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-md bg-accent/40 px-2 py-0.5 text-[10px] font-semibold uppercase",
					children: g.category
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					g.id,
					g.pnr && `PNR ${g.pnr}`,
					g.flightNumber,
					g.date,
					stats.supplier?.companyName,
					g.description
				].filter(Boolean).join(" · ")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Group Sales",
						value: formatCurrency(stats.revenue),
						tone: "text-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Received",
						value: formatCurrency(stats.received),
						tone: "text-success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Pending",
						value: formatCurrency(stats.pendingReceivable),
						tone: "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Clients (Pax)",
						value: stats.capacity ? `${stats.usedPax} / ${stats.capacity}` : String(stats.usedPax)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Supplier Bill",
						value: formatCurrency(stats.supplierBill),
						tone: "text-warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Supplier Paid",
						value: formatCurrency(stats.supplierPaid),
						tone: "text-success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Outstanding",
						value: formatCurrency(stats.supplierOutstanding),
						tone: "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Commission",
						value: formatCurrency(stats.commission)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card grid grid-cols-2 gap-3 rounded-xl p-4 sm:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Extras / Gifts",
						value: formatCurrency(stats.expenses),
						tone: "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Client Refunds",
						value: formatCurrency(stats.refunds),
						tone: "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Supplier Billed Pax",
						value: String(stats.billedPax)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Net Profit",
						value: formatCurrency(stats.netProfit),
						tone: stats.netProfit >= 0 ? "text-success" : "text-destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Margin",
						value: `${stats.margin.toFixed(1)}%`,
						tone: stats.margin >= 0 ? "text-success" : "text-destructive"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] text-muted-foreground",
				children: "Seat capacity counts CLIENT members only — supplier bills, purchases and extras never consume seats. Net Profit = Group Sales (net of refunds) − Supplier Bill − Agent Commission − Extras / Gifts"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: `Heads in this group (${stats.heads.length})`,
				children: [stats.heads.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No booking is linked to this group yet." }), stats.heads.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setOpenHead(openHead === h.headId ? null : h.headId),
						className: "flex w-full items-center justify-between gap-3 px-3 py-2 text-left hover:bg-accent/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-primary",
							children: h.headId
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] text-muted-foreground",
							children: [
								h.leadName,
								" · ",
								h.members,
								" member",
								h.members === 1 ? "" : "s",
								" · ",
								h.booking.packageType
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4 text-[10px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Total ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-primary",
									children: formatCurrency(h.totalAmount)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Paid ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-success",
									children: formatCurrency(h.received)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Due ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-destructive",
									children: formatCurrency(h.pending)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: h.booking.status })
							]
						})]
					}), openHead === h.headId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-border/50 p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-[11px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-left uppercase tracking-wide text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Client"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Type"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Passport"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Contact"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right",
										children: "Due"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right",
										children: "Paid"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Status"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [h.clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-border/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 font-semibold text-primary",
										children: c.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											c.firstName,
											" ",
											c.lastName
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1",
										children: c.ageCategory || "Adult"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1",
										children: c.passport || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1",
										children: c.phone || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(c.amountDue)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right text-success",
										children: formatCurrency(c.amountPaid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: c.paymentStatus })
									})
								]
							}, c.id)), h.clients.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "py-3 text-center text-muted-foreground",
								children: "No member detail recorded."
							}) })] })]
						})
					})]
				}, h.headId))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Supplier Bill (purchases tagged to this group)",
				children: [stats.purchases.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No purchase entry tagged to this group." }), stats.billByCategory.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-md bg-accent/30 px-3 py-1.5 text-[11px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold uppercase tracking-wide text-primary",
							children: [
								c.category,
								" · ",
								c.count
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-warning",
							children: formatCurrency(c.amount)
						})]
					}), stats.purchases.filter((p) => (p.serviceCategory || "Other") === c.category).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-3 py-1 text-[11px] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							p.date,
							" · ",
							p.referenceName,
							" ",
							p.note ? `· ${p.note}` : ""
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: formatCurrency(p.amount)
						})]
					}, p.id))]
				}, c.category))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Supplier Payments",
				children: [stats.payments.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No settlement recorded for this group." }), stats.payments.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-3 py-1 text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							p.date,
							" · ",
							p.referenceName,
							" ",
							p.note ? `· ${p.note}` : ""
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-success",
						children: formatCurrency(p.amount)
					})]
				}, p.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Gifts & Extra Expenses",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					className: "h-7 gap-1 text-[11px]",
					onClick: onAddExpense,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-3 w-3" }), " Add"]
				}),
				children: [stats.groupExpenses.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No gift or extra expense booked to this group." }), stats.groupExpenses.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-3 py-1 text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							e.date,
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "text-foreground",
								children: e.headId
							}),
							" · ",
							e.referenceName
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold text-destructive",
						children: ["- ", formatCurrency(e.amount)]
					})]
				}, e.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Client Receipts (heads of this group)",
				children: [stats.receipts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No client receipt recorded." }), stats.receipts.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-3 py-1 text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							r.date,
							" · ",
							r.headId,
							" · ",
							r.referenceName
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-success",
						children: formatCurrency(r.amount)
					})]
				}, r.id))]
			})
		]
	});
}
function Section({ title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border/60 pb-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "text-[11px] font-semibold uppercase tracking-widest text-muted-foreground",
				children: title
			}), action]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children
		})]
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-3 py-2 text-[11px] text-muted-foreground",
		children: text
	});
}
export { GroupsPage as component };
