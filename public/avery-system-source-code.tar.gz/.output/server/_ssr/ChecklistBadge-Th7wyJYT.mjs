import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { m as checklistProgress } from "./router-2ATn7EQ0.mjs";
// node_modules/.nitro/vite/services/ssr/assets/ChecklistBadge-Th7wyJYT.js
var import_jsx_runtime = require_jsx_runtime();
/** Compact "3/5 Complete" progress pill shown wherever a client is listed. */
function ChecklistBadge({ client, compact = false }) {
	const p = checklistProgress(client);
	const tone = p.isComplete ? "border-success/30 bg-success/10 text-success" : p.completed === 0 ? "border-border bg-muted/40 text-muted-foreground" : "border-warning/30 bg-warning/10 text-warning";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-semibold ${tone}`,
		title: `Service checklist: ${p.completed} of ${p.total} completed`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tracking-wide",
			children: p.label
		}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium opacity-80",
			children: p.isComplete ? "Complete" : "Complete"
		})]
	});
}
export { ChecklistBadge as t };
