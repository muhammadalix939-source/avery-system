import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { q as Download, ut as Check } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-DWGjSd5x.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { t as Input } from "./input-CqV36rr2.mjs";
import { t as Label } from "./label-BYIfJH-v.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
// node_modules/.nitro/vite/services/ssr/assets/StatementDialog---dpE8yt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
function StatementDialog({ open, onOpenChange, title, subtitle, groups, showScope, onDownload }) {
	const [incClient, setIncClient] = (0, import_react.useState)(true);
	const [incOther, setIncOther] = (0, import_react.useState)(true);
	const [fromDate, setFromDate] = (0, import_react.useState)("");
	const [toDate, setToDate] = (0, import_react.useState)("");
	const [includeOpening, setIncludeOpening] = (0, import_react.useState)(true);
	const [groupId, setGroupId] = (0, import_react.useState)("");
	function handle(allTime = false) {
		const g = groups?.find((x) => x.id === groupId);
		if (showScope && !incClient && !incOther) return;
		const scope = showScope ? incClient && incOther ? "both" : incClient ? "client" : "other" : void 0;
		onDownload(allTime ? {
			includeOpening,
			groupId: groupId || void 0,
			groupLabel: g?.label,
			scope
		} : {
			fromDate: fromDate || void 0,
			toDate: toDate || void 0,
			includeOpening,
			groupId: groupId || void 0,
			groupLabel: g?.label,
			scope
		});
		onOpenChange(false);
	}
	function preset(months) {
		const to = /* @__PURE__ */ new Date();
		const from = /* @__PURE__ */ new Date();
		from.setMonth(from.getMonth() - months);
		setFromDate(from.toISOString().slice(0, 10));
		setToDate(to.toISOString().slice(0, 10));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "bg-card border-border max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "text-primary",
				children: title
			}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: subtitle
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "From Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: fromDate,
							onChange: (e) => setFromDate(e.target.value),
							className: "bg-accent/20 border-border mt-1 h-9 text-xs"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "To Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: toDate,
							onChange: (e) => setToDate(e.target.value),
							className: "bg-accent/20 border-border mt-1 h-9 text-xs"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => preset(1),
								className: "text-xs",
								children: "Last 30 days"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => preset(3),
								className: "text-xs",
								children: "Last 3 months"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => preset(6),
								className: "text-xs",
								children: "Last 6 months"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => preset(12),
								className: "text-xs",
								children: "Last year"
							})
						]
					}),
					groups && groups.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs",
							children: "Filter by Group (optional)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: groupId,
							onChange: (e) => setGroupId(e.target.value),
							className: "mt-1 w-full rounded-md border border-border bg-accent/20 px-2 py-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "All groups (no filter)"
							}), groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: g.id,
								children: [g.label, g.hint ? ` — ${g.hint}` : ""]
							}, g.id))]
						}),
						groupId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[10px] text-muted-foreground",
							children: "Only purchases tagged to this group will be included. Opening balance is disabled for group-filtered statements."
						})
					] }),
					showScope && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-lg border border-border/50 bg-accent/10 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Include in statement"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-start gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: incClient,
									onCheckedChange: (v) => setIncClient(!!v)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Client business ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "— clients by his reference, sale minus his commission"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-start gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: incOther,
									onCheckedChange: (v) => setIncOther(!!v)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Other sale ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "— purchases made for this agent, service-wise"
								})] })]
							}),
							!incClient && !incOther && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-destructive",
								children: "Select at least one."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 rounded-lg border border-border/50 bg-accent/10 p-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							checked: includeOpening,
							onCheckedChange: (v) => setIncludeOpening(!!v)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Include opening balance (brought-forward) in totals" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => handle(true),
							variant: "outline",
							className: "flex-1 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " All-time"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => handle(false),
							className: "flex-1 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download"]
						})]
					})
				]
			})]
		})
	});
}
export { StatementDialog as n, Checkbox as t };
