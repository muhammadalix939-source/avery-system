import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { C as Receipt, Dt as Activity, E as PiggyBank, J as DollarSign, O as Percent, St as Award, n as Wallet, r as Users, u as TrendingUp, yt as BookOpen } from "../_libs/lucide-react.mjs";
import { C as formatCurrency, o as useStore } from "./router-2ATn7EQ0.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { i as DialogTitle, n as DialogContent, r as DialogHeader, t as Dialog } from "./dialog-7YhFwwXP.mjs";
import { a as topProfitableBookings, i as profitByPackage, n as expenseBreakdown, r as monthlyTrend, t as computeTotals } from "./reports-Fx3YLxZs.mjs";
import { a as XAxis, c as CartesianGrid, d as Tooltip, f as Legend, i as YAxis, l as Pie, n as BarChart, o as Bar, p as ResponsiveContainer, r as LineChart, s as Line, t as PieChart, u as Cell } from "../_libs/recharts+[...].mjs";
// node_modules/.nitro/vite/services/ssr/assets/reports-Bo67Iyun.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"oklch(0.8 0.12 80)",
	"oklch(0.7 0.15 155)",
	"oklch(0.6 0.15 280)",
	"oklch(0.7 0.18 30)",
	"oklch(0.65 0.13 200)",
	"oklch(0.75 0.14 320)",
	"oklch(0.7 0.12 100)"
];
function KpiCard({ title, value, sub, icon: Icon, accent, onClick, delay = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
		type: "button",
		onClick,
		initial: {
			opacity: 0,
			y: 16
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .4,
			delay
		},
		whileHover: { y: -2 },
		className: "glass-card glass-card-hover w-full rounded-xl p-5 text-left transition-all",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-2xl font-bold ${accent || "gold-text"}`,
						children: value
					}),
					sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: sub
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-primary" })
			})]
		})
	});
}
function ReportsPage() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const store = useStore();
	const [drill, setDrill] = (0, import_react.useState)(null);
	const [pkgFilter, setPkgFilter] = (0, import_react.useState)("All");
	const [agentFilter, setAgentFilter] = (0, import_react.useState)("All");
	const filteredBookings = (0, import_react.useMemo)(() => store.bookings.filter((b) => (pkgFilter === "All" || b.packageType === pkgFilter) && (agentFilter === "All" || b.agentId === agentFilter)), [
		store.bookings,
		pkgFilter,
		agentFilter
	]);
	const headFilter = (0, import_react.useMemo)(() => new Set(filteredBookings.map((b) => b.headId)), [filteredBookings]);
	const filteredEntries = (0, import_react.useMemo)(() => {
		if (pkgFilter === "All" && agentFilter === "All") return store.entries;
		return store.entries.filter((e) => !e.headId || headFilter.has(e.headId));
	}, [
		store.entries,
		headFilter,
		pkgFilter,
		agentFilter
	]);
	const input = (0, import_react.useMemo)(() => ({
		bookings: filteredBookings,
		clients: store.clients,
		agents: store.agents,
		suppliers: store.suppliers,
		entries: filteredEntries,
		opening: store.opening
	}), [
		filteredBookings,
		store.clients,
		store.agents,
		store.suppliers,
		filteredEntries,
		store.opening
	]);
	const t = (0, import_react.useMemo)(() => computeTotals(input), [input]);
	const byPkg = (0, import_react.useMemo)(() => profitByPackage(input), [input]);
	const trend = (0, import_react.useMemo)(() => monthlyTrend(input), [input]);
	const expCats = (0, import_react.useMemo)(() => expenseBreakdown(input), [input]);
	const topBookings = (0, import_react.useMemo)(() => topProfitableBookings(input, 5), [input]);
	const openDrill = (title, rows) => setDrill({
		title,
		rows,
		total: rows.reduce((s, r) => s + r.amount, 0)
	});
	const drillRevenue = () => openDrill("Total Revenue — Client Receipts", filteredEntries.filter((e) => e.type === "client_receive").map((e) => ({
		label: e.referenceName,
		sub: e.headId,
		date: e.date,
		amount: e.amount
	})));
	const drillCost = () => openDrill("Total Cost — Purchases & Booking Costs", [...filteredEntries.filter((e) => e.type === "purchase").map((e) => ({
		label: e.referenceName + (e.serviceCategory ? ` · ${e.serviceCategory}` : ""),
		sub: e.headId,
		date: e.date,
		amount: e.amount
	})), ...filteredBookings.filter((b) => !filteredEntries.some((e) => e.type === "purchase" && e.headId === b.headId)).map((b) => ({
		label: `Booking ${b.headId}`,
		sub: b.packageType,
		date: b.createdAt,
		amount: b.totalCost || 0
	}))]);
	const drillExpenses = () => openDrill("Expenses", filteredEntries.filter((e) => e.type === "expense").map((e) => ({
		label: e.referenceName,
		sub: e.note,
		date: e.date,
		amount: e.amount
	})));
	const drillSupplierPaid = () => openDrill("Supplier Payments", filteredEntries.filter((e) => e.type === "supplier_payment").map((e) => ({
		label: e.referenceName,
		sub: e.note,
		date: e.date,
		amount: e.amount
	})));
	const drillCommissionPaid = () => openDrill("Commissions Paid", filteredEntries.filter((e) => e.type === "agent_commission").map((e) => ({
		label: e.referenceName,
		sub: e.note,
		date: e.date,
		amount: e.amount
	})));
	const drillCommissionEarned = () => openDrill("Commissions Earned (per Booking)", filteredBookings.filter((b) => (b.commission || 0) > 0).map((b) => ({
		label: `Booking ${b.headId}`,
		sub: b.packageType,
		date: b.createdAt,
		amount: b.commission || 0
	})));
	const drillPending = () => openDrill("Pending Receivables", filteredBookings.filter((b) => b.totalAmount - b.amountReceived > 0).map((b) => ({
		label: `Booking ${b.headId}`,
		sub: `${b.packageType} · received ${formatCurrency(b.amountReceived)}`,
		date: b.createdAt,
		amount: b.totalAmount - b.amountReceived
	})));
	const drillSupplierPayable = () => openDrill("Supplier Payable", store.suppliers.map((s) => {
		const payable = s.totalPayable + (s.openingPayable || 0) - (s.totalPaid + (s.openingPaid || 0));
		return {
			label: s.companyName,
			sub: s.serviceType,
			amount: Math.max(0, payable)
		};
	}).filter((r) => r.amount > 0));
	const hasData = store.bookings.length > 0 || store.entries.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Financial Reports",
				subtitle: "Executive analytics, profitability & cash flow — click any card for details"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card flex flex-wrap items-center gap-3 rounded-xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
						children: "Filters"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: pkgFilter,
						onChange: (e) => setPkgFilter(e.target.value),
						className: "rounded-md border border-border bg-background px-3 py-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "All",
							children: "All Packages"
						}), Array.from(new Set(store.bookings.map((b) => b.packageType))).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p,
							children: p
						}, p))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: agentFilter,
						onChange: (e) => setAgentFilter(e.target.value),
						className: "rounded-md border border-border bg-background px-3 py-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "All",
							children: "All Agents"
						}), store.agents.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.id,
							children: a.name
						}, a.id))]
					}),
					(pkgFilter !== "All" || agentFilter !== "All") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setPkgFilter("All");
							setAgentFilter("All");
						},
						className: "rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground hover:bg-accent",
						children: "Reset"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Total Revenue",
						value: formatCurrency(t.totalRevenue),
						sub: "Client receipts + opening",
						icon: DollarSign,
						onClick: drillRevenue,
						delay: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Total Cost",
						value: formatCurrency(t.totalCost),
						sub: "Purchases + booking cost",
						icon: TrendingUp,
						onClick: drillCost,
						delay: .03
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Gross Profit",
						value: formatCurrency(t.grossProfit),
						sub: "Revenue − Cost",
						icon: PiggyBank,
						accent: t.grossProfit >= 0 ? "text-success" : "text-destructive",
						delay: .06
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Net Profit",
						value: formatCurrency(t.netProfit),
						sub: "After expenses & commission",
						icon: Award,
						accent: t.netProfit >= 0 ? "text-success" : "text-destructive",
						delay: .09
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Profit Margin",
						value: `${t.margin.toFixed(2)}%`,
						sub: "Net Profit / Revenue",
						icon: Percent,
						accent: t.margin >= 0 ? "text-success" : "text-destructive",
						delay: .12
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Cash on Hand",
						value: formatCurrency(t.cashOnHand),
						sub: "Net liquidity",
						icon: Wallet,
						delay: .15
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Pending Receivables",
						value: formatCurrency(t.pending),
						sub: "Click to view bookings",
						icon: Activity,
						onClick: drillPending,
						delay: .18
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Supplier Payable",
						value: formatCurrency(t.supplierPayable),
						sub: "Outstanding to suppliers",
						icon: Users,
						onClick: drillSupplierPayable,
						delay: .21
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Expenses",
						value: formatCurrency(t.expenses),
						sub: "Operating expenses",
						icon: Receipt,
						onClick: drillExpenses,
						delay: .24
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Commission Earned",
						value: formatCurrency(t.commissionEarned),
						sub: "Across all bookings",
						icon: Award,
						onClick: drillCommissionEarned,
						delay: .27
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Commission Paid",
						value: formatCurrency(t.commissionPaid),
						sub: "Outflow to agents",
						icon: Wallet,
						onClick: drillCommissionPaid,
						delay: .3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Supplier Paid",
						value: formatCurrency(t.supplierPaid),
						sub: "Outflow to suppliers",
						icon: Wallet,
						onClick: drillSupplierPaid,
						delay: .33
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Avg Profit / Booking",
						value: formatCurrency(t.avgProfitPerBooking),
						icon: BookOpen,
						delay: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Avg Ticket Size",
						value: formatCurrency(t.avgTicketSize),
						sub: "Per booking",
						icon: DollarSign,
						delay: .05
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Avg Revenue / Client",
						value: formatCurrency(t.avgRevenuePerClient),
						icon: Users,
						delay: .1
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						title: "Collection Efficiency",
						value: `${t.collectionEfficiency.toFixed(1)}%`,
						sub: "Received / Booked",
						icon: Percent,
						delay: .15
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-4 text-sm font-semibold",
					children: "Profit Breakdown by Package Type"
				}), byPkg.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No bookings yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: 260,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: byPkg,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								strokeDasharray: "3 3",
								stroke: "oklch(0.28 0.01 260)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "packageType",
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11,
								tickFormatter: (v) => `${(v / 1e3).toFixed(0)}k`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "oklch(0.17 0.01 260)",
									border: "1px solid oklch(0.28 0.01 260)",
									borderRadius: 8
								},
								formatter: (v) => formatCurrency(Number(v))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "revenue",
								fill: "oklch(0.8 0.12 80)",
								name: "Revenue",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "cost",
								fill: "oklch(0.6 0.15 280)",
								name: "Cost",
								radius: [
									4,
									4,
									0,
									0
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "profit",
								fill: "oklch(0.7 0.15 155)",
								name: "Profit",
								radius: [
									4,
									4,
									0,
									0
								]
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[260px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
					children: "Loading chart..."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Package"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Bookings"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Revenue"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Cost"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Profit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Margin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Avg Profit"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: byPkg.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/50 hover:bg-accent/30",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-medium",
									children: r.packageType
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.bookings
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-primary",
									children: formatCurrency(r.revenue)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: formatCurrency(r.cost)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-3 py-2 ${r.profit >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(r.profit)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2",
									children: [r.margin.toFixed(1), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: formatCurrency(r.avgProfit)
								})
							]
						}, r.packageType)) })]
					})
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-4 text-sm font-semibold",
					children: "Monthly Performance Trend"
				}), trend.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No transactions yet."
				}) : mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: 280,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data: trend,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								strokeDasharray: "3 3",
								stroke: "oklch(0.28 0.01 260)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "month",
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "oklch(0.6 0.02 260)",
								fontSize: 11,
								tickFormatter: (v) => `${(v / 1e3).toFixed(0)}k`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "oklch(0.17 0.01 260)",
									border: "1px solid oklch(0.28 0.01 260)",
									borderRadius: 8
								},
								formatter: (v) => formatCurrency(Number(v))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "revenue",
								stroke: "oklch(0.8 0.12 80)",
								strokeWidth: 2,
								dot: false,
								name: "Revenue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "cost",
								stroke: "oklch(0.6 0.15 280)",
								strokeWidth: 2,
								dot: false,
								name: "Cost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "profit",
								stroke: "oklch(0.7 0.15 155)",
								strokeWidth: 2,
								dot: false,
								name: "Profit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "expenses",
								stroke: "oklch(0.7 0.18 30)",
								strokeWidth: 2,
								dot: false,
								name: "Expenses"
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[280px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
					children: "Loading trend..."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-1 text-sm font-semibold",
							children: "Cash Flow Statement"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-[11px] text-muted-foreground",
							children: "Real money movement only — unpaid purchases are excluded (they sit in Supplier Payable)."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
							className: "w-full text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Opening Cash / Bank"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.openingCash)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b border-border",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold text-success",
										colSpan: 2,
										children: "Inflows"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Client Receipts (gross)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.liveReceived + t.clientRefunds)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Less: Refunds to Clients"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-2 py-2 text-right text-destructive",
										children: ["− ", formatCurrency(t.clientRefunds)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold",
										children: "Net Cash Received"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right font-semibold text-success",
										children: formatCurrency(t.liveReceived)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-b border-border",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold text-destructive",
										colSpan: 2,
										children: "Outflows"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Supplier Payments"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.supplierPaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Expenses (live)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.expenses - t.openingExpenses)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: "Commission Paid"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right",
										children: formatCurrency(t.commissionPaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-semibold",
										children: "Total Outflows"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right font-semibold text-destructive",
										children: formatCurrency(t.supplierPaid + (t.expenses - t.openingExpenses) + t.commissionPaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-3 text-base font-bold",
									children: "Closing Cash on Hand"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-2 py-3 text-right text-base font-bold ${t.cashOnHand >= 0 ? "text-success" : "text-destructive"}`,
									children: formatCurrency(t.cashOnHand)
								})] })
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-lg border border-border/60 bg-accent/10 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[11px] font-semibold uppercase tracking-wider text-primary",
								children: "Profit Reconciliation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
								className: "w-full text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"Revenue (live ",
											formatCurrency(t.liveReceived),
											" + B/F ",
											formatCurrency(t.openingRevenue),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.totalRevenue)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"− Cost of Sales (live ",
											formatCurrency(t.totalCost - t.openingCost),
											" + B/F ",
											formatCurrency(t.openingCost),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.totalCost)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-border/50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1 font-semibold",
											children: "= Gross Profit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `py-1 text-right font-semibold ${t.grossProfit >= 0 ? "text-success" : "text-destructive"}`,
											children: formatCurrency(t.grossProfit)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"− Expenses (incl. B/F ",
											formatCurrency(t.openingExpenses),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.expenses)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1",
										children: [
											"− Agent Commission earned (incl. B/F ",
											formatCurrency(t.openingCommission),
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.commissionEarned)
									})] }),
									t.openingProfit !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1",
										children: "+ Manual profit adjustment"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right",
										children: formatCurrency(t.openingProfit)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1.5 text-sm font-bold",
											children: "= Net Profit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `py-1.5 text-right text-sm font-bold ${t.netProfit >= 0 ? "text-success" : "text-destructive"}`,
											children: formatCurrency(t.netProfit)
										})]
									})
								] })
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: "Expense Breakdown"
					}), expCats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "No expenses recorded."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: 200,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
							data: expCats,
							dataKey: "amount",
							nameKey: "category",
							cx: "50%",
							cy: "50%",
							innerRadius: 45,
							outerRadius: 75,
							stroke: "none",
							children: expCats.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: COLORS[i % COLORS.length] }, i))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							contentStyle: {
								background: "oklch(0.17 0.01 260)",
								border: "1px solid oklch(0.28 0.01 260)",
								borderRadius: 8
							},
							formatter: (v) => formatCurrency(Number(v))
						})] })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[200px] w-full rounded-lg bg-accent/10 animate-pulse flex items-center justify-center text-xs text-muted-foreground",
						children: "Loading chart..."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
						className: "mt-3 w-full text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: expCats.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-2 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-2 inline-block h-2 w-2 rounded-full align-middle",
										style: { background: COLORS[i % COLORS.length] }
									}), r.category]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-2 text-right",
									children: formatCurrency(r.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-2 py-2 text-right text-xs text-muted-foreground",
									children: [r.pct.toFixed(1), "%"]
								})
							]
						}, r.category)) })
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: "Agent Performance"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Agent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Sales"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Earned"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Outstanding"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [store.agents.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-2 py-3 text-xs text-muted-foreground",
							children: "No agents."
						}) }), store.agents.map((a) => {
							const sales = a.totalSales + (a.openingSales || 0);
							const earned = a.commission + (a.openingCommission || 0);
							const paid = a.paidCommission + (a.openingPaidCommission || 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-medium",
										children: a.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-primary",
										children: formatCurrency(sales)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: formatCurrency(earned)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-success",
										children: formatCurrency(paid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-destructive",
										children: formatCurrency(Math.max(0, earned - paid))
									})
								]
							}, a.id);
						})] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "glass-card rounded-xl p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-4 text-sm font-semibold",
						children: "Supplier Spend"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Supplier"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Payable"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2",
									children: "Remaining"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [store.suppliers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 4,
							className: "px-2 py-3 text-xs text-muted-foreground",
							children: "No suppliers."
						}) }), store.suppliers.map((s) => {
							const payable = s.totalPayable + (s.openingPayable || 0);
							const paid = s.totalPaid + (s.openingPaid || 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-accent/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-medium",
										children: s.companyName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: formatCurrency(payable)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-success",
										children: formatCurrency(paid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-destructive",
										children: formatCurrency(Math.max(0, payable - paid))
									})
								]
							}, s.id);
						})] })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "glass-card rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-4 text-sm font-semibold",
					children: "Top 5 Most Profitable Bookings"
				}), topBookings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No bookings yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Head ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Package"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Revenue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Cost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2 py-2",
								children: "Profit"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: topBookings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/50 hover:bg-accent/30",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2 font-medium",
								children: b.headId
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: b.packageType
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2 text-primary",
								children: formatCurrency(b.totalAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: formatCurrency(b._cost)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `px-2 py-2 ${b._profit >= 0 ? "text-success" : "text-destructive"}`,
								children: formatCurrency(b._profit)
							})
						]
					}, b.id)) })]
				})]
			}),
			!hasData && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass-card rounded-xl p-10 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No data yet. Add bookings or entries to see live financial reports."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!drill,
				onOpenChange: (o) => !o && setDrill(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: drill?.title }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-h-[60vh] overflow-y-auto",
						children: [drill && drill.rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-8 text-center text-sm text-muted-foreground",
							children: "No records."
						}), drill && drill.rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border text-left text-xs uppercase text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2",
										children: "Date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2",
										children: "Reference"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2",
										children: "Detail"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2 text-right",
										children: "Amount"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [drill.rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-xs text-muted-foreground",
										children: r.date || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 font-medium",
										children: r.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-xs text-muted-foreground",
										children: r.sub || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 text-right text-primary",
										children: formatCurrency(r.amount)
									})
								]
							}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "bg-accent/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 3,
									className: "px-2 py-3 font-semibold",
									children: "Total"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-3 text-right font-bold gold-text",
									children: formatCurrency(drill.total)
								})]
							})] })]
						})]
					})]
				})
			})
		]
	});
}
export { ReportsPage as component };
