import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Ct as ArrowUpDown } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BBv8eX6f.mjs";
// node_modules/.nitro/vite/services/ssr/assets/SortBar-CcXdcaV6.js
var import_jsx_runtime = require_jsx_runtime();
var STANDARD_SORT_OPTIONS = [
	{
		value: "date_desc",
		label: "Date: Newest First",
		category: "date"
	},
	{
		value: "date_asc",
		label: "Date: Oldest First",
		category: "date"
	},
	{
		value: "amount_desc",
		label: "Amount: Highest First",
		category: "amount"
	},
	{
		value: "amount_asc",
		label: "Amount: Lowest First",
		category: "amount"
	},
	{
		value: "name_asc",
		label: "Name / ID: A → Z",
		category: "alpha"
	},
	{
		value: "name_desc",
		label: "Name / ID: Z → A",
		category: "alpha"
	}
];
/**
* Universal stable multi-criteria sorting function
*/
function sortEntities(items, sortKey, accessors) {
	return [...items].sort((a, b) => {
		switch (sortKey) {
			case "date_desc": {
				const da = accessors.date ? accessors.date(a) || "" : "";
				return (accessors.date ? accessors.date(b) || "" : "").localeCompare(da);
			}
			case "date_asc": {
				const da = accessors.date ? accessors.date(a) || "" : "";
				const db = accessors.date ? accessors.date(b) || "" : "";
				return da.localeCompare(db);
			}
			case "amount_desc": {
				const amtA = accessors.amount ? Number(accessors.amount(a)) || 0 : 0;
				return (accessors.amount ? Number(accessors.amount(b)) || 0 : 0) - amtA;
			}
			case "amount_asc": return (accessors.amount ? Number(accessors.amount(a)) || 0 : 0) - (accessors.amount ? Number(accessors.amount(b)) || 0 : 0);
			case "name_asc": {
				const na = accessors.name ? (accessors.name(a) || "").toLowerCase() : "";
				const nb = accessors.name ? (accessors.name(b) || "").toLowerCase() : "";
				return na.localeCompare(nb);
			}
			case "name_desc": {
				const na = accessors.name ? (accessors.name(a) || "").toLowerCase() : "";
				return (accessors.name ? (accessors.name(b) || "").toLowerCase() : "").localeCompare(na);
			}
			default: return 0;
		}
	});
}
function SortBar({ value, onChange, options = STANDARD_SORT_OPTIONS, className = "", label = "Sort by:" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center gap-2 ${className}`,
		children: [label && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-[11px] font-medium text-muted-foreground whitespace-nowrap flex items-center gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-3 w-3 text-muted-foreground/70" }), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
			value,
			onValueChange: (v) => onChange(v),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
				className: "h-8 text-xs bg-background/50 border-border/60 hover:border-primary/50 transition-colors w-[180px]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select sorting..." })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
				align: "end",
				className: "border-border bg-card",
				children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: opt.value,
					className: "text-xs",
					children: opt.label
				}, opt.value))
			})]
		})]
	});
}
export { sortEntities as n, SortBar as t };
