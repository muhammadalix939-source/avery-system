import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Et as Archive, f as Trash, k as Pencil, ut as Check, w as Plus, x as RotateCcw } from "../_libs/lucide-react.mjs";
import { _ as statusTone, g as nextStatus, h as getChecklist, m as checklistProgress, o as useStore, p as CHECKLIST_STATUSES } from "./router-2ATn7EQ0.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { t as Input } from "./input-CqV36rr2.mjs";
import { t as ConfirmDelete } from "./ConfirmDelete-C6E2xoIe.mjs";
// node_modules/.nitro/vite/services/ssr/assets/ClientChecklistPanel-DESLP8C7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Service Checklist panel — full add / edit / delete per client with tick-through statuses. */
function ClientChecklistPanel({ client }) {
	const store = useStore();
	const live = store.clients.find((c) => c.id === client.id) || client;
	const items = getChecklist(live);
	const progress = checklistProgress(live);
	const [newLabel, setNewLabel] = (0, import_react.useState)("");
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [editLabel, setEditLabel] = (0, import_react.useState)("");
	const [deleteId, setDeleteId] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border/60 bg-accent/10 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-wider text-primary",
					children: "Service Checklist"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[10px] text-muted-foreground",
					children: [
						"Tick each service as it is arranged — ",
						progress.label,
						" completed"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[10px] font-semibold text-muted-foreground",
						children: [progress.percent, "%"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						className: "h-7 gap-1 text-[10px]",
						onClick: () => store.setChecklistArchived(live.id, !live.checklistArchived),
						children: live.checklistArchived ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3 w-3" }), " Re-open"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "h-3 w-3" }), " Archive"] })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 h-1.5 overflow-hidden rounded-full bg-accent/40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full bg-primary transition-all",
					style: { width: `${progress.percent}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-lg bg-card/60 px-2.5 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => store.updateChecklistItem(live.id, item.id, { status: nextStatus(item.status) }),
							title: "Click to change status",
							className: `flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${item.status === "Completed" ? "border-success bg-success/20 text-success" : item.status === "In Progress" ? "border-warning bg-warning/20 text-warning" : "border-border text-transparent"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" })
						}),
						editId === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoFocus: true,
							value: editLabel,
							onChange: (e) => setEditLabel(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter") {
									store.updateChecklistItem(live.id, item.id, { label: editLabel.trim() || item.label });
									setEditId(null);
								}
							},
							className: "h-7 flex-1 border-border bg-accent/20 text-xs"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex-1 text-xs ${item.status === "Completed" ? "text-muted-foreground line-through" : ""}`,
							children: item.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: item.status,
							onChange: (e) => store.updateChecklistItem(live.id, item.id, { status: e.target.value }),
							className: `rounded-full border px-2 py-0.5 text-[10px] font-semibold outline-none ${statusTone[item.status]}`,
							children: CHECKLIST_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								className: "bg-card text-foreground",
								children: s
							}, s))
						}),
						editId === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								store.updateChecklistItem(live.id, item.id, { label: editLabel.trim() || item.label });
								setEditId(null);
							},
							className: "rounded p-1 hover:bg-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-success" })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setEditId(item.id);
								setEditLabel(item.label);
							},
							className: "rounded p-1 hover:bg-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5 text-warning" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setDeleteId(item.id),
							className: "rounded p-1 hover:bg-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "h-3.5 w-3.5 text-destructive" })
						})
					]
				}, item.id)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-3 text-center text-[11px] text-muted-foreground",
					children: "No checklist items — add the services this client needs."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: newLabel,
					onChange: (e) => setNewLabel(e.target.value),
					placeholder: "Add custom item (e.g. Zam Zam, Laundry, Ihram Kit)",
					onKeyDown: (e) => {
						if (e.key === "Enter" && newLabel.trim()) {
							store.addChecklistItem(live.id, newLabel);
							setNewLabel("");
						}
					},
					className: "h-8 border-border bg-accent/20 text-xs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "h-8 gap-1 text-xs",
					disabled: !newLabel.trim(),
					onClick: () => {
						store.addChecklistItem(live.id, newLabel);
						setNewLabel("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5" }), " Add"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
				open: !!deleteId,
				onOpenChange: (o) => {
					if (!o) setDeleteId(null);
				},
				title: "Delete checklist item?",
				description: "This service item will be removed from this client's checklist.",
				onConfirm: () => {
					if (deleteId) store.deleteChecklistItem(live.id, deleteId);
					setDeleteId(null);
				}
			})
		]
	});
}
export { ClientChecklistPanel as t };
