import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { M as MessageSquare, Q as Compass, S as RefreshCw, Y as Database, Z as Copy, h as SlidersHorizontal, m as Sparkles, st as ChevronRight, u as TrendingUp, ut as Check, v as Send, vt as Bot } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as formatCurrency, o as useStore } from "./router-2ATn7EQ0.mjs";
import { t as PageHeader } from "./PageHeader-07QqiQmj.mjs";
import { t as Button } from "./button-DzZUc1go.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as Textarea } from "./textarea-DvN15-gJ.mjs";
// node_modules/.nitro/vite/services/ssr/assets/ai-oMu4Vol5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var runOmniAIRoute = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("f07e9bd9f5c8d55bc7ca2af8f80a92f901eda385f0a90d58f811158f5d6df047"));
var MODES = [
	{
		id: "crm_assistant",
		label: "CRM Copilot",
		icon: Bot,
		desc: "Ask queries about your bookings, agents, revenue, and daily operations"
	},
	{
		id: "itinerary_generator",
		label: "Itinerary Builder",
		icon: Compass,
		desc: "Generate professional day-by-day Umrah, Hajj & Tour travel packages"
	},
	{
		id: "profit_advisor",
		label: "Profit Advisor",
		icon: TrendingUp,
		desc: "Analyze profit margins, supplier cost efficiency & cash flow strategy"
	},
	{
		id: "client_message_drafter",
		label: "Client Messaging",
		icon: MessageSquare,
		desc: "Draft personalized WhatsApp/SMS alerts in English & Roman Urdu"
	}
];
var QUICK_PROMPTS = {
	crm_assistant: [
		"Give me an executive summary of our active bookings and overall business health.",
		"Which agent has brought the most revenue and what is their commission?",
		"Review our outstanding client balances and suggest immediate collection priorities.",
		"Summarize all pending travel dates scheduled for the upcoming 30 days."
	],
	itinerary_generator: [
		"Create a 15-day VIP Umrah itinerary with 5 nights in Makkah (Clock Tower) and 5 nights in Madinah (Dar Al Taqwa). Include Ziyarat points.",
		"Draft a 10-day Economy Umrah itinerary for a family of 4 with private transport between Jeddah, Makkah, and Madinah.",
		"Design a 7-day Northern Pakistan Tour itinerary (Hunza, Skardu, Attabad Lake) with hotels and meal plans.",
		"Generate a 21-day Standard Hajj package schedule with Aziziya shifting and Mina/Arafat guidance."
	],
	profit_advisor: [
		"Analyze our package revenue vs supplier purchase costs and suggest margin improvements.",
		"How should we price our upcoming Ramadan Umrah packages to maximize gross margins?",
		"Evaluate our supplier payables and suggest an optimal payment schedule to preserve cash on hand.",
		"What strategies can help increase our booking ticket size and client retention?"
	],
	client_message_drafter: [
		"Draft a polite WhatsApp payment reminder for a client whose remaining balance of Rs 150,000 is overdue before travel.",
		"Draft an official booking confirmation message with flight details and hotel check-in instructions in Urdu & English.",
		"Create a welcome message wishing a blessed journey to an Umrah family departing tomorrow.",
		"Draft a notification informing a client that their Saudi Umrah eVisa has been successfully issued."
	]
};
function OmniAIPage() {
	const store = useStore();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [activeMode, setActiveMode] = (0, import_react.useState)("crm_assistant");
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [includeContext, setIncludeContext] = (0, import_react.useState)(true);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [response, setResponse] = (0, import_react.useState)(null);
	const [responseModel, setResponseModel] = (0, import_react.useState)("gemini-3.8-flash");
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const crmSnapshot = (0, import_react.useMemo)(() => {
		const totalRev = store.bookings.reduce((s, b) => s + (b.amountReceived || 0), 0) + (store.opening.revenue || 0);
		const totalPurchases = store.entries.filter((e) => e.type === "purchase").reduce((s, e) => s + e.amount, 0);
		const totalExpenses = store.entries.filter((e) => e.type === "expense").reduce((s, e) => s + e.amount, 0);
		const totalProfit = totalRev - totalPurchases - totalExpenses + (store.opening.profit || 0);
		const supplierDue = store.suppliers.reduce((s, sp) => s + Math.max(0, (sp.totalPayable || 0) - (sp.totalPaid || 0)), 0);
		return {
			totalRevenue: totalRev,
			totalProfit,
			totalBookings: store.bookings.length,
			totalClients: store.clients.length,
			supplierDue,
			recentBookings: store.bookings.slice(0, 5).map((b) => ({
				headId: b.headId,
				packageType: b.packageType,
				amount: b.totalAmount,
				status: b.status
			})),
			topAgents: store.agents.slice(0, 5).map((a) => ({
				name: a.name,
				clients: a.totalClients,
				sales: a.totalSales
			}))
		};
	}, [
		store.bookings,
		store.clients,
		store.suppliers,
		store.entries,
		store.agents,
		store.opening
	]);
	const handleSend = async (customPrompt) => {
		const textToSend = (customPrompt || prompt).trim();
		if (!textToSend) {
			toast.info("Please enter a prompt or pick a quick suggestion");
			return;
		}
		setLoading(true);
		setResponse(null);
		try {
			const res = await runOmniAIRoute({ data: {
				mode: activeMode,
				prompt: textToSend,
				crmSnapshot: includeContext ? crmSnapshot : void 0
			} });
			if (res.success && res.content) {
				setResponse(res.content);
				setResponseModel(res.model || "gemini-3.8-flash");
				toast.success("AI response generated");
			} else {
				toast.error(res.error || "Failed to generate response");
				setResponse(`Error: ${res.error || "Could not retrieve response from Gemini API"}`);
			}
		} catch (e) {
			const msg = e instanceof Error ? e.message : "Error communicating with Omni AI server";
			toast.error(msg);
			setResponse(`Error: ${msg}`);
		} finally {
			setLoading(false);
		}
	};
	const handleCopy = () => {
		if (!response) return;
		navigator.clipboard.writeText(response);
		setCopied(true);
		toast.success("Copied to clipboard");
		setTimeout(() => setCopied(false), 2e3);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Omni AI Assistant",
				subtitle: "Executive AI Co-pilot & Itinerary Generator powered by Gemini 3.8 Flash",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Omni Router · Gemini 3.8 Flash" })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: MODES.map((m) => {
					const Icon = m.icon;
					const isSelected = activeMode === m.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setActiveMode(m.id);
							setResponse(null);
						},
						className: `flex flex-col text-left rounded-xl p-4 border transition-all ${isSelected ? "border-primary bg-primary/10 shadow-sm" : "border-border/60 bg-card/60 hover:border-border hover:bg-card/90"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-2 rounded-lg ${isSelected ? "bg-primary text-primary-foreground" : "bg-accent/40 text-foreground"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-sm text-foreground",
								children: m.label
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground line-clamp-2",
							children: m.desc
						})]
					}, m.id);
				})
			}),
			mounted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-border/60 bg-accent/15 p-4 text-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "h-4 w-4 text-primary shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: "Live CRM Context Feed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "The Omni Router seamlessly injects real-time agency metrics into prompts for accurate answers."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-3 font-mono text-[11px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["Rev: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: formatCurrency(crmSnapshot.totalRevenue)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["Profit: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-success",
										children: formatCurrency(crmSnapshot.totalProfit)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["Bookings: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: crmSnapshot.totalBookings
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5 cursor-pointer select-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: includeContext,
								onChange: (e) => setIncludeContext(e.target.checked),
								className: "rounded border-input text-primary focus:ring-primary h-3.5 w-3.5"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground",
								children: "Include Context"
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-sm font-semibold flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4 text-primary" }), "Prompt & Request"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground font-mono",
									children: MODES.find((m) => m.id === activeMode)?.label
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: prompt,
								onChange: (e) => setPrompt(e.target.value),
								placeholder: `Type your instructions in English, Urdu, or Roman Urdu...\ne.g. "${QUICK_PROMPTS[activeMode][0]}"`,
								rows: 5,
								className: "resize-none text-sm bg-background/60"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => {
										setPrompt("");
										setResponse(null);
									},
									className: "text-xs text-muted-foreground h-8",
									children: "Clear"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => handleSend(),
									disabled: loading || !prompt.trim(),
									size: "sm",
									className: "gap-2 text-xs h-8",
									children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3.5 w-3.5 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Processing..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ask Omni AI" })] })
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-5 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
							children: [
								"Suggested ",
								MODES.find((m) => m.id === activeMode)?.label,
								" Prompts"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: QUICK_PROMPTS[activeMode].map((qp, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									setPrompt(qp);
									handleSend(qp);
								},
								disabled: loading,
								className: "group flex w-full items-start gap-2 rounded-lg border border-border/50 bg-accent/10 p-2.5 text-left text-xs transition-colors hover:border-primary/40 hover:bg-primary/5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 text-muted-foreground group-hover:text-primary shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground/90 group-hover:text-foreground",
									children: qp
								})]
							}, idx))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card rounded-xl p-6 min-h-[460px] flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-border/50 pb-4 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm font-semibold",
									children: "Executive AI Response"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-muted-foreground font-mono",
									children: [
										"Model: ",
										responseModel,
										" · Latency: Low"
									]
								})] })]
							}), response && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: handleCopy,
								className: "gap-1.5 text-xs h-8",
								children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-emerald-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copied ? "Copied" : "Copy" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 flex flex-col justify-start",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-8 w-8 animate-spin text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-foreground",
									children: "Omni AI is thinking..."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: "Routing through Gemini 3.8 Flash with live CRM context"
								})] })]
							}) : response ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "prose prose-sm dark:prose-invert max-w-none text-foreground text-xs leading-relaxed whitespace-pre-wrap font-sans bg-accent/5 p-4 rounded-lg border border-border/40 overflow-y-auto max-h-[600px]",
								children: response
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 flex flex-col items-center justify-center p-8 text-center text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "h-10 w-10 text-muted-foreground/40 mb-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-foreground",
										children: "Omni AI Assistant Ready"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs max-w-md mt-1",
										children: "Select a suggested prompt from the left or type any custom request. Your assistant has direct access to live bookings, package details, and financial ledgers."
									})
								]
							})
						})]
					})
				})]
			})
		]
	});
}
export { OmniAIPage as component };
