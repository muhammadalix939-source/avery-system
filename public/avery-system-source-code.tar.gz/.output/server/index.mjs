globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { t as FastResponse } from "./_libs/srvx.mjs";
// #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs").then((n) => n.i)) };
globalThis.__nitro_vite_envs__ = services;
// #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/avery-gold-logo.jpg": {
		"type": "image/jpeg",
		"etag": "\"5945-riqW/34ufbZtZH7EUx6g44ZpLVU\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 22853,
		"path": "../public/avery-gold-logo.jpg"
	},
	"/placeholder.svg": {
		"type": "image/svg+xml",
		"etag": "\"6fd1-qWQOhyJn/rRMFfFPaVsAALDm3NY\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 28625,
		"path": "../public/placeholder.svg"
	},
	"/assets/ChecklistBadge-DEB0WH27.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45f-2jxXUt5I9ncB0/8TR4cETcw5lr8\"",
		"mtime": "2026-11-07T00:02:03.721Z",
		"size": 1119,
		"path": "../public/assets/ChecklistBadge-DEB0WH27.js"
	},
	"/assets/ClientChecklistPanel-DGr4SzW7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"224e-ZD7Vw08k9liZxjSmi/LQsG0cAz8\"",
		"mtime": "2026-11-07T00:02:03.721Z",
		"size": 8782,
		"path": "../public/assets/ClientChecklistPanel-DGr4SzW7.js"
	},
	"/assets/ConfirmDelete-BaLNwYHE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2623-d1G2Ys2G9OtpzJohaK+eATN66Ds\"",
		"mtime": "2026-11-07T00:02:03.721Z",
		"size": 9763,
		"path": "../public/assets/ConfirmDelete-BaLNwYHE.js"
	},
	"/assets/DetailDialog-BQz-pf5v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f438-g3+DEeu1SneWhoRZaEjJ3rAg6JA\"",
		"mtime": "2026-11-07T00:02:03.721Z",
		"size": 62520,
		"path": "../public/assets/DetailDialog-BQz-pf5v.js"
	},
	"/assets/StatementDialog-C7VKb__5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"459f-HAQyGFQGgrZ5aTO3YZKo/G3mNB0\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 17823,
		"path": "../public/assets/StatementDialog-C7VKb__5.js"
	},
	"/assets/SearchableSelect-Do-d2KwI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b52f-WdWGvSzrkAl59k5rP7qlGW5dQnI\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 46383,
		"path": "../public/assets/SearchableSelect-Do-d2KwI.js"
	},
	"/assets/agents-DKYoHNrt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4936-ICEuGLb2XlVL+OiL/L4e9Sg4vLg\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 18742,
		"path": "../public/assets/agents-DKYoHNrt.js"
	},
	"/assets/ai-DkNj6b3S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"780b-0zv3AoyCblii6wSNBm1i8l7F0uU\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 30731,
		"path": "../public/assets/ai-DkNj6b3S.js"
	},
	"/assets/allocations-CV2mwFEX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2430-G4xoqnm6YOz90yZt5Dpk35iJhNE\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 9264,
		"path": "../public/assets/allocations-CV2mwFEX.js"
	},
	"/assets/alerts-BGFRqGrf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6fa9-U+7z+C/WG8Nh6XhX5ngCF5F1VWw\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 28585,
		"path": "../public/assets/alerts-BGFRqGrf.js"
	},
	"/assets/button-Z-9RZnLG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"706-Rj4PxFQrpcSngCWzFrhCnnZZMek\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 1798,
		"path": "../public/assets/button-Z-9RZnLG.js"
	},
	"/assets/calendar-days-Yg4oQ1c5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"418-mSeCoDkbzVjC6gRRg35GyqYhy6o\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 1048,
		"path": "../public/assets/calendar-days-Yg4oQ1c5.js"
	},
	"/assets/accounts-Pczn4F0y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"147f0-7eJlOAoIX1Gs0+opwVHAMyUyoD8\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 83952,
		"path": "../public/assets/accounts-Pczn4F0y.js"
	},
	"/assets/check-CgDXgYNO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dd-1+y7Rt2t5zaPiYxSrzVwmD9mLYw\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 477,
		"path": "../public/assets/check-CgDXgYNO.js"
	},
	"/assets/SortBar-T98xQysI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fee-rCxtgwOkx8pg6r0kKKNXD5kpslI\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 4078,
		"path": "../public/assets/SortBar-T98xQysI.js"
	},
	"/assets/circle-check-CPvWbtJ5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25d-fJmE9NTKLYbd2bbZmREtg+wy9yU\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 605,
		"path": "../public/assets/circle-check-CPvWbtJ5.js"
	},
	"/assets/clients-R_hPTwl-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5dd5-tCa0CX8GhCNbXV7aj+18+lUvwIo\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 24021,
		"path": "../public/assets/clients-R_hPTwl-.js"
	},
	"/assets/bookings-Dovmh05e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f875-ChiU6ug75aPM5Hl5/aoNwxYX0G8\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 194677,
		"path": "../public/assets/bookings-Dovmh05e.js"
	},
	"/assets/chevron-right-C7dOGd2P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f9-W/yKsz3IrH8brwNFu/aW2bEMQHE\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 505,
		"path": "../public/assets/chevron-right-C7dOGd2P.js"
	},
	"/assets/clock-t2Qg8pfP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21e-fwrS96cs6lcynF8bUhHSS8FHHDA\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 542,
		"path": "../public/assets/clock-t2Qg8pfP.js"
	},
	"/assets/StatusBadge-6vwJ3trL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ee-LJDf+v9BzB/mMCv3kkZnbncxtqc\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 1006,
		"path": "../public/assets/StatusBadge-6vwJ3trL.js"
	},
	"/assets/clsx-Cbd36OJ7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"51b1b-oXAfpKttADqGS40KWyyTxagTDbA\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 334619,
		"path": "../public/assets/clsx-Cbd36OJ7.js"
	},
	"/assets/PieChart-BN5tTl0f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e2604-T/Y/ETrs/kIJHBuu046mj8zOkC0\"",
		"mtime": "2026-11-07T00:02:03.722Z",
		"size": 927236,
		"path": "../public/assets/PieChart-BN5tTl0f.js"
	},
	"/assets/compass-CDUpyvlR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"276-qCybSc6WFe6M3V3P+sbYppa0m38\"",
		"mtime": "2026-11-07T00:02:03.723Z",
		"size": 630,
		"path": "../public/assets/compass-CDUpyvlR.js"
	},
	"/assets/dialog-Bb6Qejxv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14d2a-GoWL9vHIjfkmE525mAJD9yb1gm4\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 85290,
		"path": "../public/assets/dialog-Bb6Qejxv.js"
	},
	"/assets/dist-CSjedjeS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"668-o0PykdzMHEiZmh4vBgtFV4Med2s\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 1640,
		"path": "../public/assets/dist-CSjedjeS.js"
	},
	"/assets/dist-Caq8Ts7X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5fa-KoYHu2PDpqJN6/hUscWoAKLiNvA\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 1530,
		"path": "../public/assets/dist-Caq8Ts7X.js"
	},
	"/assets/dist-DLKJvZed.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a63-blc4KKO+EppHx9+kLGamvi1o+X0\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 2659,
		"path": "../public/assets/dist-DLKJvZed.js"
	},
	"/assets/dollar-sign-KRXdzSMz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"264-PyH+zcqYLafcGP7Ka/yOIzFj7YM\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 612,
		"path": "../public/assets/dollar-sign-KRXdzSMz.js"
	},
	"/assets/download-CEfpC1QR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27c-B8INvH3XlKv94SQC2zajUNHqfyY\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 636,
		"path": "../public/assets/download-CEfpC1QR.js"
	},
	"/assets/drawings-BNgIiqEs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24fc-DVGMO5BuKPbQFox0vIhzlIRdYIk\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 9468,
		"path": "../public/assets/drawings-BNgIiqEs.js"
	},
	"/assets/entries-il0Iy_AZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36761-2sG/fjgFTDnRYWGXq1HQ8HJYY2Q\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 223073,
		"path": "../public/assets/entries-il0Iy_AZ.js"
	},
	"/assets/expenses-Wzb3ZbNW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a9c-hwNANrsKgYTSh17MjTqo/T7WoaE\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 19100,
		"path": "../public/assets/expenses-Wzb3ZbNW.js"
	},
	"/assets/eye-CC3nCxz_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26f-30vHx+4SswHfwQPG1OsLVKWwTcw\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 623,
		"path": "../public/assets/eye-CC3nCxz_.js"
	},
	"/assets/groups-6NvV7uvi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"163b-+1FrcaoEP3IEcmeV9TUokF1mR0o\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 5691,
		"path": "../public/assets/groups-6NvV7uvi.js"
	},
	"/assets/groups-BLqAA3-Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aaf1-WpBkSWUXdx0wgbp5xcnzyVqSHhs\"",
		"mtime": "2026-11-07T00:02:03.724Z",
		"size": 43761,
		"path": "../public/assets/groups-BLqAA3-Y.js"
	},
	"/assets/html2canvas-Caj4fWEA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"51159-0qfsDDHHaO8ckgC7JBja/l2Yzq8\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 332121,
		"path": "../public/assets/html2canvas-Caj4fWEA.js"
	},
	"/assets/index.es-F4aSkJtl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e1ca-rPIeyjXnCIl76geo0o4CoROADJ0\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 319946,
		"path": "../public/assets/index.es-F4aSkJtl.js"
	},
	"/assets/input-mqPdBZ5K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3bc-Y5ZTCbyph/hbBS/gYvGRxOEnjpI\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 956,
		"path": "../public/assets/input-mqPdBZ5K.js"
	},
	"/assets/label-C_GFC7te.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a4-i+vZC1E1rwVLhEVa9+hWkwubrQM\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 1444,
		"path": "../public/assets/label-C_GFC7te.js"
	},
	"/assets/landmark-C2bF4lO7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ad-enIHX1jw/RAP2xuwrHFvDaMHW1o\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 1453,
		"path": "../public/assets/landmark-C2bF4lO7.js"
	},
	"/assets/lock-CgWNLG0r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24c-VZKIm7XO8r11laPiLm4XLW3dYUA\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 588,
		"path": "../public/assets/lock-CgWNLG0r.js"
	},
	"/assets/octagon-alert-lg_q6oU2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36b-UqfIQLQxRb7RyYgMcOuVevOFHck\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 875,
		"path": "../public/assets/octagon-alert-lg_q6oU2.js"
	},
	"/assets/payments-B7cfkBRV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"239a-AfEWAaKC+PqtsgTHHZZ4qfjmxZA\"",
		"mtime": "2026-11-07T00:02:03.725Z",
		"size": 9114,
		"path": "../public/assets/payments-B7cfkBRV.js"
	},
	"/assets/pencil-B3wEbWek.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"284-iRt/eSqU75YhsMoqUngHv8QT/1g\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 644,
		"path": "../public/assets/pencil-B3wEbWek.js"
	},
	"/assets/plus-DpXfoyfH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"203-QMVs+Ty8QkA56Lj7gPY9Kg2soyE\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 515,
		"path": "../public/assets/plus-DpXfoyfH.js"
	},
	"/assets/index-BgfHyeon.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"db2fc-n6G3eDrIyNErxa1SomhRjtgjg3Q\"",
		"mtime": "2026-11-07T00:02:03.721Z",
		"size": 897788,
		"path": "../public/assets/index-BgfHyeon.js"
	},
	"/assets/pdf-S7DRzVmW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c13a7-ESG00TRJM3jitgy/sdpht3Mzn1U\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 791463,
		"path": "../public/assets/pdf-S7DRzVmW.js"
	},
	"/assets/purify.es-DMQ8cimK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14ec8-vlErhjTiwgYESFCCuVEDKHjzOTQ\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 85704,
		"path": "../public/assets/purify.es-DMQ8cimK.js"
	},
	"/assets/reports-BUxgOdhW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d086-XjKBZEkyduOhceLz6d3ZYRoJKCo\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 118918,
		"path": "../public/assets/reports-BUxgOdhW.js"
	},
	"/assets/reports-Fx3YLxZs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18d8-mtUiiDSHjftUK6B7F8uuJwL9Jro\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 6360,
		"path": "../public/assets/reports-Fx3YLxZs.js"
	},
	"/assets/rolldown-runtime-DQp2zzRu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6fa-nzpNm4AVgCjh9OVbFBrbTIjLSGc\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 1786,
		"path": "../public/assets/rolldown-runtime-DQp2zzRu.js"
	},
	"/assets/rotate-ccw-Q-S1YtUF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"242-SpnqdVEvx+1eVP9fxcmPXCwNwJY\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 578,
		"path": "../public/assets/rotate-ccw-Q-S1YtUF.js"
	},
	"/assets/routes-DZMlNs3t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ead-SzQ3XeR7wgQL+jE8T43VbexY8j4\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 24237,
		"path": "../public/assets/routes-DZMlNs3t.js"
	},
	"/assets/search-Cfhd1oNG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"232a-/ta1N3H20iKgkFdFoYYNzuyEdmQ\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 9002,
		"path": "../public/assets/search-Cfhd1oNG.js"
	},
	"/assets/select-51KhIokW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2288b-rrzK6DyT37m0cNZR7G7jcIfBRrM\"",
		"mtime": "2026-11-07T00:02:03.726Z",
		"size": 141451,
		"path": "../public/assets/select-51KhIokW.js"
	},
	"/assets/settings-DLBg4PAS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f4f-N9uX/rPyWvUhXZumqIUYnX9Hm7s\"",
		"mtime": "2026-11-07T00:02:03.727Z",
		"size": 36687,
		"path": "../public/assets/settings-DLBg4PAS.js"
	},
	"/assets/shield-check-BDluUh3C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c0-+zSWLEjDuCb3fiZLglTVwrvQgag\"",
		"mtime": "2026-11-07T00:02:03.727Z",
		"size": 704,
		"path": "../public/assets/shield-check-BDluUh3C.js"
	},
	"/assets/trash-YMvfXcpp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30a-GB6pRI0U0Qgl2qUaix4qhNURXvM\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 778,
		"path": "../public/assets/trash-YMvfXcpp.js"
	},
	"/assets/trending-up-CdHn1ffe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22c-OfBxCoRgtjLegOG6zTn8sgaLWL4\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 556,
		"path": "../public/assets/trending-up-CdHn1ffe.js"
	},
	"/assets/triangle-alert-CI6HNCIP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2cb-wkIf+BzMEijaVblNUpTaVRQ7jjU\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 715,
		"path": "../public/assets/triangle-alert-CI6HNCIP.js"
	},
	"/assets/utils-AV1U8VYN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1780b-/2K9n/JxNnl6kqEZys/Ea2QVvSw\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 96267,
		"path": "../public/assets/utils-AV1U8VYN.js"
	},
	"/fonts/IBMPlexSans-Bold.ttf": {
		"type": "font/ttf",
		"etag": "\"321a4-y6mzp+hOKk/QogKCmRQ5ePNQCak\"",
		"mtime": "2026-11-07T00:02:08.576Z",
		"size": 205220,
		"path": "../public/fonts/IBMPlexSans-Bold.ttf"
	},
	"/assets/textarea-MZb_Jg8r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c1-Ul9/tuFaBS11eAxQYIsaMxo0XpA\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 1473,
		"path": "../public/assets/textarea-MZb_Jg8r.js"
	},
	"/assets/styles-DYodTW9Z.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"24402-wRItCXnP0s/ALwKuUz3Ht+Ehk5I\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 148482,
		"path": "../public/assets/styles-DYodTW9Z.css"
	},
	"/fonts/IBMPlexSans-Regular.ttf": {
		"type": "font/ttf",
		"etag": "\"321c4-clSsEeR7UwIqRSvEw3J9OU4l5JM\"",
		"mtime": "2026-11-07T00:02:08.576Z",
		"size": 205252,
		"path": "../public/fonts/IBMPlexSans-Regular.ttf"
	},
	"/assets/suppliers-DVVVwzff.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5587-jOYapbkMZEjV5VmdibrSB4rixok\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 21895,
		"path": "../public/assets/suppliers-DVVVwzff.js"
	},
	"/fonts/LibreBaskerville-Bold.ttf": {
		"type": "font/ttf",
		"etag": "\"1a100-pzPll25ivxZvv31FhQIvpadUVKc\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 106752,
		"path": "../public/fonts/LibreBaskerville-Bold.ttf"
	},
	"/fonts/LibreBaskerville-Regular.ttf": {
		"type": "font/ttf",
		"etag": "\"1a0e8-vtxo3fgQMt/EyDnX2UaE66wNSgc\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 106728,
		"path": "../public/fonts/LibreBaskerville-Regular.ttf"
	},
	"/assets/aistudio/IMG-20260722-WA0052_3__d8b69380.jpg": {
		"type": "image/jpeg",
		"etag": "\"5945-riqW/34ufbZtZH7EUx6g44ZpLVU\"",
		"mtime": "2026-11-07T00:02:08.576Z",
		"size": 22853,
		"path": "../public/assets/aistudio/IMG-20260722-WA0052_3__d8b69380.jpg"
	},
	"/assets/aistudio/Screenshot_2026-10-26_153257_8e2ca0f8.png": {
		"type": "image/png",
		"etag": "\"10804-lsOBdVrMx6L0mNUwPlNxKiiDO5E\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 67588,
		"path": "../public/assets/aistudio/Screenshot_2026-10-26_153257_8e2ca0f8.png"
	},
	"/assets/aistudio/Screenshot_20261102-032821_a609ea3a.png": {
		"type": "image/png",
		"etag": "\"27037-YwsrrKpFXh+bxcmGQUZVfXtWCJM\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 159799,
		"path": "../public/assets/aistudio/Screenshot_20261102-032821_a609ea3a.png"
	},
	"/assets/store-DLjJF6C7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16b769-7nHCBDymSsZahT9g26RwUWLso78\"",
		"mtime": "2026-11-07T00:02:03.728Z",
		"size": 1488745,
		"path": "../public/assets/store-DLjJF6C7.js"
	},
	"/assets/aistudio/Screenshot_20261102-210053_deb3b100.png": {
		"type": "image/png",
		"etag": "\"1a180-njeQ68K9WDDz18Nlue4Tx9ZJ4T8\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 106880,
		"path": "../public/assets/aistudio/Screenshot_20261102-210053_deb3b100.png"
	},
	"/assets/aistudio/styles_ac9ce3df.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a38-usZtJYIh87iGtjToII/7Y0TicPg\"",
		"mtime": "2026-11-07T00:02:08.577Z",
		"size": 6712,
		"path": "../public/assets/aistudio/styles_ac9ce3df.css"
	}
};
// #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
// node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
// #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_0jRgqU = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_0jRgqU
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
// node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
// #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
// #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
// node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
// node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
// node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
export { cloudflare_module_default as default };
